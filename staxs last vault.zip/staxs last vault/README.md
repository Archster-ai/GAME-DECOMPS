# STAX: The Last Vault

A cinematic 3D platformer for **Godot 4.3+** (Forward+). Every coin in Goldhaven has been stolen, including Stax's forty-seven dollars and a button. Put on the dollar-sign shades, grab eight keys across eight increasingly strange worlds, and open The Last Vault.

Every model, texture, sound effect, voice and music track is generated procedurally at runtime. The project has no asset files.

## Run

Open the folder in Godot 4.3 or newer and press **F5**, or run `godot --path .`.

## Chapters

| # | Chapter | What's there |
|---|---|---|
| 1 | **Goldhaven Rooftops** | Sunset parkour over a living city: traffic below, a blimp overhead, the villain's broadcast on a giant billboard. Window-washer rides, a wall-kick alley, a crane jib, and a balcony spiral up the Bank Tower. |
| 2 | **The Breakfast Dimension** | Pancake towers, syrup lakes, fried-egg bounce pads, a toaster elevator and the Toast Legion. Sir Waffleton keeps guard. |
| 3 | **The Infinite Tax Office** | An endless fluorescent office with conveyor belts of forms, slamming APPROVED stamps and staplers that bite. Gary from Accounting has been here since 1648. |
| 4 | **The Lost Sock Nebula** | Where every missing sock goes: low-gravity zones, sock islands, moths and a Washing Machine Planet. Help Lefty find Righty. |
| 5 | **The Scribble Kingdom** | A world drawn in crayon by a seven-year-old, wobbling over a sheet of notebook paper. It draws itself into existence. Lollipop trees, a rainbow bridge, paper airplanes, a pencil bridge and eraser blocks that rub themselves out under your feet. |
| 6 | **The Rubber Duck Desert** | Scorching sand, giant rubber ducks, pickle cacti and soap-bubble bounce pads, all at the bottom of a colossal bathtub. At the end, a pirate ship crashes out of the sky and Captain Moneybeard attacks. |
| 7 | **The Clocktower of Forever** | A long moonlit climb through the machinery that decides when midnight happens: spinning gear bridges, pendulum blades, a gear-wall kick shaft, a clock-face floor with sweeping hands, a bell bounce and a 19-gear spiral. At the top waits Lord Tick-Tock the Eternal, undefeated for 1,200 years. |
| 8 | **The Nursery of Doom** | Stax is toy-sized in a moonlit nursery where the floor is lava (house rules): alphabet blocks, a toy chest, a bouncy pillow, the crib rail, a spinning mobile and a toy plane on a string. Baby Bigbucks is teething on the eighth key, and when he wakes up he throws the biggest tantrum in the multiverse. Nobody hits the baby: squash Lullaby Stars until he falls asleep. |
| Finale | **The Last Vault** | The final boss. You'll see. |
| 9 | **The Frostfire Rift** | Half the world is frozen and half is on fire. Ice floes, basalt pistons, a giant avalanche run, a meteor shower, Moneybeard's ship as a bridge and Lord Tick-Tock slowing time, then the two-headed Twin Dragon. |
| 10 | **The Page After The End** | A placeholder world of grey boxes, loading platforms, missing textures and a pause menu you can stand on, with a shop selling a Double Jump Candy. THE END itself is the boss: it rips the floor into a slide, and its true final phase is THE CURSOR. Over 500 coins across the adventure unlocks the perfect ending. |

## Cinematics and voices

- Every chapter has a directed opening and closing cutscene. They use camera moves, handheld sway, auto-focus depth of field, letterbox bars, title cards and film grain. Press **Esc / Start twice** to skip one.
- **Spoken dialogue** uses your operating system's text-to-speech. Every character gets their own voice, pitch and speaking rate. On Linux this needs `speech-dispatcher`. If no system voices are found, characters talk in synthesized "babble", one blip per couple of letters with a pitch per character. You can switch the mode under **Settings → Voices**.
- Music is composed and rendered at runtime. Each chapter has its own track, with a separate drum layer that fades in and out.

## Controls

| Action | Keyboard | Gamepad |
|---|---|---|
| Move | WASD / arrows | Left stick |
| Jump | Space | A |
| Crouch / ground pound | Shift | LT / LB |
| Dive | E | B / X |
| Talk | F / Enter | Y |
| Camera orbit | Mouse (click to capture) | Right stick |
| Camera snap 45° | Q, L | D-pad left/right |
| Zoom | I / mouse wheel | RB |
| Pause (skip cutscene: twice) | Esc / P | Start |
| Reset to checkpoint | R | Back |
| Controls sheet | H / F1 | |

## Moveset

- **Jump chain**: land and jump again quickly. The third jump in a row is a high flip, but only if you're running.
- **Long jump**: run, crouch, then jump.
- **Backflip**: crouch while standing still, then jump.
- **Side flip**: reverse direction while running (Stax skids), then jump.
- **Wall kick**: jump into a wall and press jump right as you touch it.
- **Ground pound**: crouch in mid-air. Jump right after landing for a pound jump.
- **Dive / rollout**: press dive while running or in the air, then jump to roll back up.
- Jumps are buffered and you get a little coyote time, so a slightly early or late press still counts.

You have four health. Every 25 coins (or one big coin) restores one; golden ATMs are checkpoints and refill you completely. Stomp, dive into or ground-pound enemies.

## Graphics settings

**Settings → Graphics** offers Low, High (SSAO, volumetric fog, depth of field) and Ultra (adds SDFGI global illumination, SSIL and screen-space reflections). The change applies from the next chapter.

## Tests

```
godot --headless --path . -s tests/compile_check.gd   # every script parses
godot --headless --path . -s tests/move_test.gd       # the moveset (jump heights, wall kicks, ...)
godot --headless --path . -s tests/level_smoke.gd     # plays through every chapter, incl. the boss
godot --headless --path . -s tests/reachability.gd -- <chapter index>   # can the key be reached from spawn? (approximate: ignores walls)
godot --path . -s tests/screenshot.gd -- <chapter index, -1 = title> <out dir> [skip] [frames...]
```

## Layout

- `scripts/main.gd`: screen manager (title, chapters, credits), pause menu, persistent effects
- `scripts/core/`: `game.gd` (progress, settings, saving), `audio.gd` (synthesized SFX and music), `voice.gd` (the cast, text-to-speech and babble), `input_setup.gd`
- `scripts/cinema/director.gd`: the cutscene director
- `scripts/actors/`: `player.gd` (movement state machine), `stax_model.gd`, `puppet.gd` (every other character), `camera_rig.gd`, `boss_*.gd` (one per boss, including `boss_kilowatt.gd`)
- `scripts/world/`: `level_base.gd` (lighting, sky shader, builders), gameplay objects (coins, checkpoints, keys, movers, bouncers, zones, hazards, enemies, NPCs), `mats.gd`, `fx.gd`
- `scripts/levels/`: one script per chapter
- `scripts/ui/`: title screen, HUD, dialogue and post-processing, settings, pause, credits
