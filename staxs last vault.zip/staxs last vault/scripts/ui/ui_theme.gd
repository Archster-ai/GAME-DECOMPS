extends RefCounted
## The game's UI look: dark glassy panels, gold accents, chunky type.

const Mats := preload("res://scripts/world/mats.gd")

const GOLD := Color(1.0, 0.78, 0.22)
const INK := Color(0.06, 0.05, 0.08, 0.86)

static var _theme: Theme


static func get_theme() -> Theme:
	if _theme:
		return _theme
	var t := Theme.new()
	t.default_font_size = 20
	var normal := box(Color(0.1, 0.08, 0.12, 0.8), Color(1, 1, 1, 0.12), 2)
	var hover := box(Color(0.2, 0.15, 0.08, 0.92), GOLD, 3)
	var pressed := box(Color(0.35, 0.25, 0.05, 0.95), GOLD, 3)
	var disabled := box(Color(0.1, 0.1, 0.1, 0.5), Color(1, 1, 1, 0.05), 2)
	for s in [normal, hover, pressed, disabled]:
		s.content_margin_left = 22
		s.content_margin_right = 22
		s.content_margin_top = 10
		s.content_margin_bottom = 10
	t.set_stylebox("normal", "Button", normal)
	t.set_stylebox("hover", "Button", hover)
	t.set_stylebox("focus", "Button", hover)
	t.set_stylebox("pressed", "Button", pressed)
	t.set_stylebox("disabled", "Button", disabled)
	t.set_font("font", "Button", Mats.bold_font())
	t.set_font_size("font_size", "Button", 22)
	t.set_color("font_color", "Button", Color(0.92, 0.9, 0.86))
	t.set_color("font_hover_color", "Button", GOLD)
	t.set_color("font_focus_color", "Button", GOLD)
	t.set_color("font_pressed_color", "Button", Color.WHITE)
	t.set_color("font_disabled_color", "Button", Color(1, 1, 1, 0.3))
	t.set_stylebox("panel", "PanelContainer", box(INK, Color(1, 1, 1, 0.1), 2, 14))
	t.set_color("font_outline_color", "Label", Color(0, 0, 0, 0.9))
	t.set_constant("outline_size", "Label", 4)
	var grab := StyleBoxFlat.new()
	grab.bg_color = GOLD
	grab.set_corner_radius_all(6)
	t.set_stylebox("slider", "HSlider", box(Color(1, 1, 1, 0.15), Color(0, 0, 0, 0), 0, 4))
	t.set_stylebox("grabber_area", "HSlider", grab)
	t.set_stylebox("grabber_area_highlight", "HSlider", grab)
	_theme = t
	return t


static func box(bg: Color, border: Color, width: int, radius := 10) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(width)
	s.set_corner_radius_all(radius)
	s.anti_aliasing = true
	return s


static func label(text: String, size := 20, color := Color.WHITE, bold := false) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("outline_size", maxi(4, size / 6))
	if bold:
		l.add_theme_font_override("font", Mats.bold_font())
	return l
