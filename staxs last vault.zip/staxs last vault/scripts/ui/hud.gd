extends CanvasLayer
## In-level HUD: coins, health, radio-style "bark" lines from characters,
## interaction prompts, banners, a boss health bar and the controls sheet.

const UI := preload("res://scripts/ui/ui_theme.gd")

const HELP := """MOVE  WASD / left stick        JUMP  Space / A
CROUCH / GROUND POUND  Shift / LT        DIVE  E / B
TALK  F / Y        CAMERA  mouse (click to capture) / right stick
SNAP CAMERA  Q, L / d-pad        ZOOM  I, wheel / RB
RESET  R        PAUSE  Esc / Start        HIDE THIS  H

Jump chain: land and jump again quickly (x3 while running)
Long jump: run, crouch, jump        Backflip: crouch still, jump
Side flip: reverse while running, jump        Wall kick: jump into a wall, jump again
Ground pound: crouch in mid-air        Rollout: jump after a dive"""

var _root: Control
var _coins: Label
var _coin_icon: Label
var _pips: Array[Panel] = []
var _bark: PanelContainer
var _bark_name: Label
var _bark_text: Label
var _bark_time := 0.0
var _bark_speaker := ""
var _bark_pos := 0.0
var _prompt: Label
var _banner: Label
var _help: PanelContainer
var _hint: Label
var _boss: VBoxContainer
var _boss_bar: ProgressBar
var _boss_name: Label
var _chapter: Label
var _timer: Label


func _ready() -> void:
	layer = 10
	_root = Control.new()
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.theme = UI.get_theme()
	add_child(_root)

	# Coins.
	var coin_row := HBoxContainer.new()
	coin_row.position = Vector2(28, 20)
	coin_row.add_theme_constant_override("separation", 10)
	_root.add_child(coin_row)
	_coin_icon = UI.label("$", 44, UI.GOLD, true)
	_coin_icon.pivot_offset = Vector2(14, 28)
	coin_row.add_child(_coin_icon)
	_coins = UI.label("0", 40, Color.WHITE, true)
	coin_row.add_child(_coins)

	# Health: a row of little green bills.
	var pip_row := HBoxContainer.new()
	pip_row.position = Vector2(30, 82)
	pip_row.add_theme_constant_override("separation", 5)
	_root.add_child(pip_row)
	for i in 4:
		var p := Panel.new()
		p.custom_minimum_size = Vector2(44, 20)
		p.add_theme_stylebox_override("panel", UI.box(Color(0.35, 0.85, 0.4), Color(0.1, 0.3, 0.1), 2, 3))
		pip_row.add_child(p)
		_pips.append(p)

	_chapter = UI.label("", 16, Color(1, 1, 1, 0.55))
	_chapter.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	_chapter.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_chapter.offset_left = -420
	_chapter.offset_right = -24
	_chapter.offset_top = 20
	_root.add_child(_chapter)

	# Speedrun clock, under the chapter name.
	_timer = UI.label("", 30, Color.WHITE, true)
	_timer.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	_timer.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_timer.offset_left = -300
	_timer.offset_right = -24
	_timer.offset_top = 44
	_timer.visible = Game.timing()
	_root.add_child(_timer)

	# Bark box (non-blocking dialogue).
	_bark = PanelContainer.new()
	_bark.add_theme_stylebox_override("panel", UI.box(Color(0.03, 0.03, 0.05, 0.78), Color(1, 1, 1, 0.12), 2, 12))
	_bark.anchor_top = 1.0
	_bark.anchor_bottom = 1.0
	_bark.offset_left = 24
	_bark.offset_top = -150
	_bark.offset_right = 560
	_bark.offset_bottom = -24
	_bark.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_bark.visible = false
	_root.add_child(_bark)
	var m := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		m.add_theme_constant_override("margin_" + side, 14)
	_bark.add_child(m)
	var v := VBoxContainer.new()
	m.add_child(v)
	_bark_name = UI.label("", 18, UI.GOLD, true)
	v.add_child(_bark_name)
	_bark_text = UI.label("", 18)
	_bark_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_bark_text.custom_minimum_size = Vector2(500, 0)
	v.add_child(_bark_text)

	_prompt = UI.label("", 22, Color.WHITE, true)
	_prompt.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	_prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_prompt.offset_left = -300
	_prompt.offset_right = 300
	_prompt.offset_top = -210
	_prompt.visible = false
	_root.add_child(_prompt)

	_banner = UI.label("", 54, UI.GOLD, true)
	_banner.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_banner.offset_left = -500
	_banner.offset_right = 500
	_banner.offset_top = 130
	_banner.pivot_offset = Vector2(500, 30)
	_banner.visible = false
	_root.add_child(_banner)

	_help = PanelContainer.new()
	_help.position = Vector2(24, 120)
	_help.visible = false
	var hm := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		hm.add_theme_constant_override("margin_" + side, 16)
	_help.add_child(hm)
	hm.add_child(UI.label(HELP, 15, Color(1, 1, 1, 0.92)))
	_root.add_child(_help)

	_hint = UI.label("Press H for controls", 16, Color(1, 1, 1, 0.7))
	_hint.position = Vector2(30, 106)
	_root.add_child(_hint)
	get_tree().create_timer(8.0).timeout.connect(func(): if is_instance_valid(_hint): _hint.visible = false)

	_boss = VBoxContainer.new()
	_boss.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_boss.offset_left = -300
	_boss.offset_right = 300
	_boss.offset_top = 24
	_boss.visible = false
	_root.add_child(_boss)
	_boss_name = UI.label("", 24, Color(1, 0.35, 0.3), true)
	_boss_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_boss.add_child(_boss_name)
	_boss_bar = ProgressBar.new()
	_boss_bar.custom_minimum_size = Vector2(600, 22)
	_boss_bar.show_percentage = false
	_boss_bar.add_theme_stylebox_override("background", UI.box(Color(0, 0, 0, 0.6), Color(1, 1, 1, 0.3), 2, 6))
	_boss_bar.add_theme_stylebox_override("fill", UI.box(Color(0.95, 0.2, 0.15), Color(1, 0.6, 0.4), 2, 6))
	_boss.add_child(_boss_bar)


func set_chapter(text: String) -> void:
	_chapter.text = text


func set_coins(n: int) -> void:
	_coins.text = str(n)
	var t := create_tween()
	_coin_icon.scale = Vector2(1.4, 1.4)
	t.tween_property(_coin_icon, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK)


func set_health(hp: int) -> void:
	for i in _pips.size():
		_pips[i].modulate = Color.WHITE if i < hp else Color(0.25, 0.25, 0.25, 0.6)


## A radio-style line that plays while you keep moving.
func bark(speaker: String, text: String, seconds := 0.0) -> void:
	var c: Dictionary = Voice.info(speaker)
	_bark_speaker = speaker
	_bark_name.text = c.name
	_bark_name.add_theme_color_override("font_color", c.color)
	_bark_text.text = text
	_bark_text.visible_characters = 0
	_bark_pos = 0.0
	_bark_time = seconds if seconds > 0.0 else 2.5 + text.length() * 0.05
	_bark.visible = true
	_bark.modulate.a = 1.0
	Voice.start_line(speaker, text, true)


func prompt(text: String) -> void:
	_prompt.text = text
	_prompt.visible = text != ""


func banner(text: String, seconds := 2.0, color := UI.GOLD) -> void:
	_banner.text = text
	_banner.add_theme_color_override("font_color", color)
	_banner.visible = true
	_banner.scale = Vector2(0.4, 0.4)
	_banner.modulate.a = 1.0
	var t := create_tween()
	t.tween_property(_banner, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	t.tween_interval(seconds)
	t.tween_property(_banner, "modulate:a", 0.0, 0.4)
	t.tween_callback(func(): _banner.visible = false)


func show_boss(boss_name: String, max_hp: int) -> void:
	_boss_name.text = boss_name
	_boss_bar.max_value = max_hp
	_boss_bar.value = max_hp
	_boss.visible = true


func set_boss_hp(hp: int) -> void:
	create_tween().tween_property(_boss_bar, "value", float(hp), 0.4)


func hide_boss() -> void:
	_boss.visible = false


func set_gameplay_visible(on: bool) -> void:
	_root.visible = on
	if not on:
		_bark.visible = false


func _process(delta: float) -> void:
	if _timer.visible:
		_timer.text = Game.format_time(Game.run_time)
	if _bark.visible:
		var before := int(_bark_pos)
		_bark_pos += delta * 50.0
		var now := mini(int(_bark_pos), _bark_text.text.length())
		for i in range(before, now):
			Voice.typed(_bark_speaker, _bark_text.text[i], i)
		_bark_text.visible_characters = now
		_bark_time -= delta
		if _bark_time <= 0.0 and not Voice.busy():
			_bark.modulate.a -= delta * 3.0
			if _bark.modulate.a <= 0.0:
				_bark.visible = false


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("toggle_help"):
		_help.visible = not _help.visible
		_hint.visible = false
