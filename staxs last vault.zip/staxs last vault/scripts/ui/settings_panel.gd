extends PanelContainer
## Settings: graphics quality, voices, volumes, mouse, fullscreen.

signal closed

const UI := preload("res://scripts/ui/ui_theme.gd")

const QUALITY := ["Low", "High", "Ultra (SDFGI)"]
const VOICES := ["auto", "speech", "babble", "off"]
const VOICE_NAMES := ["Auto", "Spoken (text-to-speech)", "Character babble", "Off"]

var _first: Control


func _ready() -> void:
	theme = UI.get_theme()
	process_mode = Node.PROCESS_MODE_ALWAYS
	var m := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		m.add_theme_constant_override("margin_" + side, 28)
	add_child(m)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	m.add_child(v)
	v.add_child(UI.label("SETTINGS", 34, UI.GOLD, true))

	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 24)
	grid.add_theme_constant_override("v_separation", 12)
	v.add_child(grid)

	var q := OptionButton.new()
	for n in QUALITY:
		q.add_item(n)
	q.selected = Game.settings.quality
	q.item_selected.connect(func(i): Game.set_setting("quality", i))
	_row(grid, "Graphics (applies next chapter)", q)
	_first = q

	var vo := OptionButton.new()
	for n in VOICE_NAMES:
		vo.add_item(n)
	vo.selected = maxi(VOICES.find(Game.settings.voice), 0)
	vo.item_selected.connect(func(i): Game.set_setting("voice", VOICES[i]))
	_row(grid, "Voices", vo)

	_row(grid, "Music", _slider("music"))
	_row(grid, "Sound effects", _slider("sfx"))
	_row(grid, "Voice volume", _slider("voice_volume"))
	_row(grid, "Mouse sensitivity", _slider("mouse_sens", 0.2, 3.0))

	var fs := CheckButton.new()
	fs.button_pressed = Game.settings.fullscreen
	fs.toggled.connect(func(on): Game.set_setting("fullscreen", on))
	_row(grid, "Fullscreen", fs)

	var note := UI.label("Spoken voices use your system's text-to-speech. %s" %
		("Voices found." if Voice.has_speech() else "None found, so characters babble instead."), 15, Color(1, 1, 1, 0.6))
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.custom_minimum_size.x = 560
	v.add_child(note)

	var back := Button.new()
	back.text = "Back"
	back.pressed.connect(func():
		Audio.play("ui_ok")
		closed.emit())
	v.add_child(back)


func focus_first() -> void:
	_first.grab_focus()


func _row(grid: GridContainer, text: String, control: Control) -> void:
	grid.add_child(UI.label(text, 19))
	control.custom_minimum_size.x = 280
	grid.add_child(control)


func _slider(key: String, lo := 0.0, hi := 1.0) -> HSlider:
	var s := HSlider.new()
	s.min_value = lo
	s.max_value = hi
	s.step = 0.05
	s.value = Game.settings[key]
	s.custom_minimum_size.y = 28
	s.value_changed.connect(func(val): Game.set_setting(key, val))
	return s


func _unhandled_input(event: InputEvent) -> void:
	if visible and event.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		closed.emit()
