extends "res://scripts/world/level_base.gd"
## Title screen: Stax posing on a mountain of coins at sunset, with the menu.

const UI := preload("res://scripts/ui/ui_theme.gd")
const Settings := preload("res://scripts/ui/settings_panel.gd")
const StaxModel := preload("res://scripts/actors/stax_model.gd")

const EMOTES := ["cool", "", "wave", "", "point", "dance", "", "shrug"]

var _cam: Camera3D
var _stax: Node3D
var _dollar: Node3D
var _t := 0.0
var _emote_timer := 3.0
var _emote_i := 0
var _ui: Control
var _menu: VBoxContainer
var _chapters: VBoxContainer
var _chapter_result: Label
var _speedrun_buttons := {}   # level index -> its Speedrun button
var _header: Array[Control] = []
var _settings: PanelContainer
var _logo: Label


func env_config() -> Dictionary:
	return {
		"top": Color(0.16, 0.12, 0.35), "horizon": Color(1.0, 0.55, 0.3), "bottom": Color(0.2, 0.1, 0.12),
		"sun_color": Color(1.0, 0.6, 0.3), "sun_energy": 1.6, "sun_angle": Vector2(-12, 50),
		"sun_size": 3.0, "sun_glow": 1.2, "clouds": 0.5, "cloud_color": Color(1.0, 0.6, 0.45),
		"fog_color": Color(0.9, 0.5, 0.35), "fog_density": 0.006, "volumetric": 0.015,
		"vol_color": Color(1.0, 0.75, 0.55), "ambient": 0.7, "exposure": 1.05, "glow": 1.0,
		"tint": Color(1.03, 0.98, 0.92),
	}


func build() -> void:
	# The coin mountain.
	var hill := deco_ball(Vector3(0, -5.2, 0), 7.0, Mats.gold(), Vector3(1.4, 0.8, 1.4))
	hill.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	var coin_mesh := CylinderMesh.new()
	coin_mesh.top_radius = 0.42
	coin_mesh.bottom_radius = 0.42
	coin_mesh.height = 0.1
	coin_mesh.radial_segments = 14
	coin_mesh.material = Mats.gold()
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = coin_mesh
	mm.instance_count = 900
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	for i in mm.instance_count:
		var a := rng.randf() * TAU
		var r := 1.3 + sqrt(rng.randf()) * 8.2
		var x := cos(a) * r
		var z := sin(a) * r
		var nx := x / 9.8
		var nz := z / 9.8
		var y := -5.2 + 5.6 * sqrt(maxf(1.0 - nx * nx - nz * nz, 0.0)) + rng.randf_range(-0.05, 0.1)
		var basis := Basis.from_euler(Vector3(rng.randf_range(-0.6, 0.6), rng.randf() * TAU, rng.randf_range(-0.6, 0.6)))
		mm.set_instance_transform(i, Transform3D(basis, Vector3(x, y, z)))
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	add_child(mmi)

	# Skyline silhouettes.
	var windows := Mats.pattern("windows", [Color(0.08, 0.06, 0.1), Color(0.12, 0.1, 0.16), Color(1.0, 0.75, 0.4)], 0.08, 0.6, true, 3, 0.6)
	for i in 34:
		var a := float(i) / 34.0 * TAU
		var dist := rng.randf_range(80.0, 120.0)
		var h := rng.randf_range(20.0, 70.0)
		var w := rng.randf_range(8.0, 16.0)
		deco_box(Vector3(cos(a) * dist, h * 0.5 - 6.0, sin(a) * dist), Vector3(w, h, w), windows, Vector3(0, -a, 0))

	# A giant glowing dollar sign.
	_dollar = dollar(Vector3(0, 6, 16), PI, 10.0, Mats.glow(Color(1.0, 0.62, 0.15), 1.1), 0.15)
	omni(Vector3(0, 6, 13), Color(1.0, 0.7, 0.3), 16.0, 1.5)
	# Key and fill lights on Stax so he is not lost in the backlight.
	spot(Vector3(-2.5, 4.0, -4.5), Vector3(0, 1.4, 0), Color(1.0, 0.85, 0.7), 12.0, 25.0, 4.0)
	omni(Vector3(2.5, 2.0, -3.0), Color(0.6, 0.7, 1.0), 7.0, 0.8)

	# Coin rain.
	var p := GPUParticles3D.new()
	p.amount = 90
	p.lifetime = 5.0
	p.preprocess = 5.0
	p.visibility_aabb = AABB(Vector3(-20, -20, -20), Vector3(40, 40, 40))
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(14, 0.5, 14)
	pm.direction = Vector3.DOWN
	pm.initial_velocity_min = 2.0
	pm.initial_velocity_max = 4.0
	pm.gravity = Vector3(0, -3, 0)
	pm.angular_velocity_min = -300
	pm.angular_velocity_max = 300
	pm.particle_flag_rotate_y = true
	p.process_material = pm
	var cm := CylinderMesh.new()
	cm.top_radius = 0.25
	cm.bottom_radius = 0.25
	cm.height = 0.05
	cm.radial_segments = 10
	cm.material = Mats.gold()
	p.draw_pass_1 = cm
	p.position = Vector3(0, 16, 0)
	p.rotation.x = 0.4
	add_child(p)
	Fx.ambient(self, Vector3(0, 3, 0), Vector3(12, 4, 12), Color(1.0, 0.8, 0.5, 0.7), 80, 0.08)


func _spawn() -> void:
	_stax = StaxModel.new()
	_stax.position = Vector3(0, 0.75, 0)
	_stax.rotation.y = 0.3
	add_child(_stax)
	_cam = Camera3D.new()
	_cam.fov = 40.0
	var attrs := CameraAttributesPractical.new()
	attrs.dof_blur_far_enabled = Game.settings.quality >= 1
	attrs.dof_blur_far_distance = 12.0
	attrs.dof_blur_far_transition = 20.0
	attrs.dof_blur_amount = 0.05
	_cam.attributes = attrs
	add_child(_cam)
	_cam.current = true
	_build_ui()


func _run() -> void:
	Audio.play_music("title")
	Audio.set_drums(1.0)


func is_cinematic() -> bool:
	return true


func _process(delta: float) -> void:
	_t += delta
	# Slow orbit in front of Stax, framed so he stands to the right of the menu.
	var a := PI + 0.3 + sin(_t * 0.12) * 0.5
	var target := Vector3(0, 1.3, 0)
	var pos := Vector3(sin(a) * 5.2, 2.7 + sin(_t * 0.2) * 0.25, cos(a) * 5.2)
	var fwd := (target - pos).normalized()
	var right := fwd.cross(Vector3.UP).normalized()
	_cam.look_at_from_position(pos, target - right * 1.7)
	_stax.animate(delta, "idle", 0.0)
	_stax.head_yaw = sin(_t * 0.5) * 0.3
	_emote_timer -= delta
	if _emote_timer <= 0.0:
		_emote_i = (_emote_i + 1) % EMOTES.size()
		_stax.emote = EMOTES[_emote_i]
		_emote_timer = 3.5
	if _dollar:
		_dollar.rotation.y = PI + sin(_t * 0.6) * 0.5
	if _logo:
		_logo.pivot_offset = _logo.size * 0.5
		_logo.rotation = sin(_t * 1.3) * 0.015
		_logo.scale = Vector2.ONE * (1.0 + sin(_t * 2.0) * 0.012)


func _physics_process(_delta: float) -> void:
	pass


# ---------------------------------------------------------------- menu

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 10
	add_child(layer)
	_ui = Control.new()
	_ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	_ui.theme = UI.get_theme()
	layer.add_child(_ui)

	var grad := Gradient.new()
	grad.set_color(0, Color(0, 0, 0, 0.55))
	grad.set_color(1, Color(0, 0, 0, 0))
	var gt := GradientTexture2D.new()
	gt.gradient = grad
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(1, 0)
	var tr := TextureRect.new()
	tr.texture = gt
	tr.set_anchors_preset(Control.PRESET_LEFT_WIDE)
	tr.offset_right = 620
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ui.add_child(tr)

	var col := VBoxContainer.new()
	col.position = Vector2(70, 30)
	col.add_theme_constant_override("separation", 6)
	_ui.add_child(col)
	_logo = UI.label("STAX", 150, UI.GOLD, true)
	_logo.add_theme_constant_override("outline_size", 22)
	_logo.add_theme_color_override("font_outline_color", Color(0.25, 0.1, 0.02))
	_logo.add_theme_constant_override("shadow_offset_x", 6)
	_logo.add_theme_constant_override("shadow_offset_y", 8)
	_logo.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.5))
	col.add_child(_logo)
	var sub := UI.label("T H E   L A S T   V A U L T", 30, Color(1, 0.95, 0.88), true)
	col.add_child(sub)
	var spacer := Control.new()
	spacer.custom_minimum_size.y = 12
	col.add_child(spacer)
	_header = [_logo, sub, spacer]

	_menu = VBoxContainer.new()
	_menu.add_theme_constant_override("separation", 8)
	col.add_child(_menu)
	var has_save := Game.unlocked > 1
	var first: Button
	if has_save:
		first = _button(_menu, "Continue  ·  %s" % Game.level_info(Game.unlocked - 1).title, func(): Game.continue_game())
	var ng := _button(_menu, "New Game", func(): Game.new_game())
	if not first:
		first = ng
	_button(_menu, "Chapters", _show_chapters)
	var best := "  ·  Best %s" % Game.format_time(Game.best_run) if Game.best_run > 0.0 else ""
	_button(_menu, "Speedrun" + best, func(): Game.start_speedrun())
	_button(_menu, "Settings", _show_settings)
	if OS.get_name() != "Web":
		_button(_menu, "Quit", func(): get_tree().quit())

	# The chapter list scrolls, so it never runs off the screen however many
	# chapters there are (focusing a button scrolls it into view).
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.custom_minimum_size = Vector2(590, maxf(get_viewport().get_visible_rect().size.y - 70.0, 300.0))
	scroll.visible = false
	col.add_child(scroll)
	_chapters = VBoxContainer.new()
	_chapters.add_theme_constant_override("separation", 5)
	_chapters.visible = false
	_chapters.visibility_changed.connect(func(): scroll.visible = _chapters.visible)
	scroll.add_child(_chapters)
	_chapter_result = UI.label("", 18, UI.GOLD)
	_chapter_result.visible = false
	_chapters.add_child(_chapter_result)
	for i in Game.level_count():
		var li := Game.level_info(i)
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		_chapters.add_child(row)
		var b := _button(row, "%s  ·  %s" % [li.chapter, li.title], func(): Game.start_level(i))
		b.custom_minimum_size = Vector2(380, 42)
		var sr := _button(row, _speedrun_text(i), func(): Game.start_chapter_run(i))
		sr.custom_minimum_size = Vector2(170, 42)
		if i >= Game.unlocked:
			b.disabled = true
			b.text = "%s  ·  ???" % li.chapter
			sr.disabled = true
			sr.text = "Speedrun  ·  ???"
		_speedrun_buttons[i] = sr
	_button(_chapters, "Back", _show_menu).custom_minimum_size.y = 44

	_settings = Settings.new()
	_settings.visible = false
	_settings.position = Vector2(620, 90)
	_settings.closed.connect(_show_menu)
	_ui.add_child(_settings)

	var star := "   ·   ★ Perfect Ending" if Game.perfect_ending else ""
	var foot := UI.label("Keyboard + mouse or gamepad   ·   Press H in-game for controls   ·   Bank: $%d%s" % [Game.bank, star], 15, Color(1, 1, 1, 0.6))
	# Bottom right, clear of the menu column on the left.
	foot.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	foot.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	foot.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	foot.grow_vertical = Control.GROW_DIRECTION_BEGIN
	foot.offset_right = -28
	foot.offset_bottom = -20
	_ui.add_child(foot)
	first.call_deferred("grab_focus")
	if Game.return_to_chapters:
		# Back from a chapter speedrun: straight to the chapter list, with the result.
		Game.return_to_chapters = false
		_show_chapters.call_deferred()


func _button(parent: Control, text: String, fn: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.custom_minimum_size = Vector2(440, 50)
	b.pressed.connect(func():
		Audio.play("ui_ok")
		fn.call())
	b.focus_entered.connect(func(): Audio.play("ui_move", 1.0, 0.0, -8.0))
	b.mouse_entered.connect(b.grab_focus)
	parent.add_child(b)
	return b


func _set_header(on: bool) -> void:
	for h in _header:
		h.visible = on


func _show_menu() -> void:
	_set_header(true)
	_menu.visible = true
	_chapters.visible = false
	_settings.visible = false
	(_menu.get_child(0) as Button).grab_focus()


func _show_chapters() -> void:
	# The logo makes room so every chapter fits on screen.
	_set_header(false)
	_menu.visible = false
	_chapters.visible = true
	_refresh_speedrun_buttons()
	if Game.chapter_last.is_empty():
		_chapter_result.visible = false
	else:
		var r: Dictionary = Game.chapter_last
		var line := "%s  ·  %s" % [Game.level_info(r.index).title, Game.format_time(r.time)]
		line += "  ·  NEW BEST!" if r.new_best else "  ·  Best %s" % Game.format_time(r.best)
		_chapter_result.text = "Chapter speedrun finished: " + line
		_chapter_result.visible = true
	for row in _chapters.get_children():
		if row is HBoxContainer:
			for c in row.get_children():
				if c is Button and not c.disabled:
					c.grab_focus()
					return


## "Speedrun  ·  best 1:23.45", or just "Speedrun" if it hasn't been run yet.
func _speedrun_text(i: int) -> String:
	if Game.chapter_best.has(i):
		return "Speedrun  ·  %s" % Game.format_time(Game.chapter_best[i])
	return "Speedrun"


func _refresh_speedrun_buttons() -> void:
	for i in _speedrun_buttons:
		var sr: Button = _speedrun_buttons[i]
		if i < Game.unlocked:
			sr.text = _speedrun_text(i)


func _show_settings() -> void:
	_menu.visible = false
	_settings.visible = true
	_settings.focus_first()
