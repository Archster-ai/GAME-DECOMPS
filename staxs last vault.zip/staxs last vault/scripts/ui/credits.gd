extends Node
## End credits: a slow scroll over black, then back to the title.

const UI := preload("res://scripts/ui/ui_theme.gd")

const ROLL := [
	["h", "STAX: THE LAST VAULT"],
	["s", ""],
	["t", "STARRING"],
	["n", "Stax  ·  as himself, a kid with priorities"],
	["n", "Signpost Steve  ·  as a sign (method actor)"],
	["n", "Baron Von Bankrupt  ·  as the villain (briefly)"],
	["n", "Sir Waffleton  ·  as a waffle of noble birth"],
	["n", "Gary from Accounting  ·  as Gary from Accounting"],
	["n", "Lefty  ·  as one half of a pair"],
	["n", "Carl the Pigeon  ·  as a pigeon"],
	["n", "Doodle  ·  drawn by Timmy, age 7"],
	["n", "The Towel Camel  ·  folded by Linda, who had dreams"],
	["n", "Captain Moneybeard  ·  as three rubber ducks in a coat"],
	["n", "Lord Tick-Tock the Eternal  ·  undefeated (nobody did the stairs)"],
	["n", "The Cuckoo  ·  CUCKOO! Sorry."],
	["n", "Baby Bigbucks  ·  as the biggest baby (still hasn't shared)"],
	["n", "Sir Snuggles  ·  Knight of the Toy Chest, lives under the bed"],
	["s", ""],
	["t", "FEATURING"],
	["n", "The Repo Drones  ·  The Toast Legion"],
	["n", "The Staplers of Floor 9,000  ·  The Moths"],
	["n", "The Scribbles  ·  The Angry Ducks  ·  One Pirate Ship (origin unknown)"],
	["n", "The Tin Soldiers (wound far too tight)"],
	["s", ""],
	["t", "SPECIAL THANKS"],
	["n", "Every sock that never came back from the dryer"],
	["n", "The Breakfast Dimension Tourism Board"],
	["n", "The Infinite Tax Office (still processing your request)"],
	["n", "Timmy's crayons  ·  The bathtub, for hosting a desert"],
	["s", ""],
	["t", "NO SIGNS WERE HARMED"],
	["n", "Steve is fine. Steve is resting. Steve is plotting."],
	["s", ""],
	["t", "MADE WITH"],
	["n", "Godot Engine  ·  procedural everything  ·  zero stock assets"],
	["s", ""],
	["s", ""],
	["h", "THANKS FOR PLAYING"],
	["s", ""],
	["n", "Somewhere, in a quiet bedroom, a piggy bank blinks."],
]

var complete := true
var _scroll: VBoxContainer
var _speed := 42.0
var _done := false


func is_cinematic() -> bool:
	return true


func _ready() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 10
	add_child(layer)
	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.015, 0.03)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(bg)
	_scroll = VBoxContainer.new()
	_scroll.add_theme_constant_override("separation", 14)
	_scroll.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_scroll.offset_left = -500
	_scroll.offset_right = 500
	_scroll.offset_top = 760
	layer.add_child(_scroll)
	for row in _run_rows() + ROLL:
		var l: Label
		match row[0]:
			"h": l = UI.label(row[1], 58, UI.GOLD, true)
			"t": l = UI.label(row[1], 22, Color(0.55, 0.9, 0.45), true)
			"s":
				l = Label.new()
				l.custom_minimum_size.y = 40
			_: l = UI.label(row[1], 24, Color(0.95, 0.93, 0.9))
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_scroll.add_child(l)
	var hint := UI.label("Hold Jump to speed up  ·  Esc to skip", 15, Color(1, 1, 1, 0.4))
	hint.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	hint.position += Vector2(-340, -34)
	layer.add_child(hint)
	Audio.play_music("credits")
	Audio.set_drums(1.0)
	Game.fx.fade_in(1.5)


## A finished speedrun gets its results at the top of the roll.
func _run_rows() -> Array:
	var r: Dictionary = Game.last_run
	if r.is_empty():
		return []
	Game.last_run = {}
	var rows := [["t", "SPEEDRUN"], ["h", Game.format_time(r.time)]]
	if r.new_best:
		rows.append(["t", "NEW PERSONAL BEST!" if r.best > 0.0 else "FIRST FINISHED RUN!"])
		if r.best > 0.0:
			rows.append(["n", "Previous best  ·  %s  (-%s)" % [Game.format_time(r.best), Game.format_time(r.best - r.time)]])
	else:
		rows.append(["n", "Personal best  ·  %s  (+%s)" % [Game.format_time(r.best), Game.format_time(r.time - r.best)]])
	rows.append(["s", ""])
	var prev := 0.0
	for i in r.splits.size():
		var t: float = r.splits[i]
		rows.append(["n", "%s  ·  %s    %s" % [Game.level_info(i).title, Game.format_time(t - prev), Game.format_time(t)]])
		prev = t
	rows.append(["s", ""])
	rows.append(["s", ""])
	return rows


func _process(delta: float) -> void:
	if _done:
		return
	var fast := Input.is_action_pressed("jump") or Input.is_action_pressed("ui_accept")
	_scroll.offset_top -= delta * _speed * (5.0 if fast else 1.0)
	var end_y := _scroll.offset_top + _scroll.size.y
	if end_y < 360.0 or Input.is_action_just_pressed("pause"):
		_done = true
		await get_tree().create_timer(2.5 if end_y < 360.0 else 0.1).timeout
		Game.to_title()
