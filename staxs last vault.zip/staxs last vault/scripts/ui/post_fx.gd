extends Node
## Persistent screen effects shared by every scene: film grade (vignette,
## grain, chromatic aberration, flashes), cinematic letterbox bars, the
## dialogue box, chapter title cards and fades.

signal line_finished

const UI := preload("res://scripts/ui/ui_theme.gd")
const Mats := preload("res://scripts/world/mats.gd")

const POST_SHADER := """
shader_type canvas_item;
uniform sampler2D screen_tex : hint_screen_texture, filter_linear_mipmap;
uniform float vignette = 0.38;
uniform float grain = 0.035;
uniform float aberration = 0.0;
uniform vec4 flash_color : source_color = vec4(1.0, 1.0, 1.0, 0.0);
uniform vec3 tint = vec3(1.0);
uniform float saturation = 1.08;
uniform float contrast = 1.05;
void fragment() {
	vec2 uv = SCREEN_UV;
	vec2 d = uv - 0.5;
	float ab = aberration * 0.014 + 0.0012;
	vec3 col;
	col.r = texture(screen_tex, uv + d * ab).r;
	col.g = texture(screen_tex, uv).g;
	col.b = texture(screen_tex, uv - d * ab).b;
	float lum = dot(col, vec3(0.299, 0.587, 0.114));
	col = mix(vec3(lum), col, saturation) * tint;
	col = (col - 0.5) * contrast + 0.5;
	float v = smoothstep(0.9, 0.25, length(d * vec2(1.0, 0.85)));
	col *= mix(1.0 - vignette, 1.0, v);
	float n = fract(sin(dot(uv + fract(TIME * 0.37), vec2(12.9898, 78.233))) * 43758.5453);
	col += (n - 0.5) * grain;
	col = mix(col, flash_color.rgb, flash_color.a);
	COLOR = vec4(col, 1.0);
}
"""

var post: ShaderMaterial
var dialogue_open := false
var _bar_top: ColorRect
var _bar_bottom: ColorRect
var _fade: ColorRect
var _card: Control
var _card_chapter: Label
var _card_title: Label
var _card_sub: Label
var _card_line: ColorRect
var _skip_hint: Label
var _box: PanelContainer
var _name: Label
var _text: Label
var _arrow: Label
var _speaker := ""
var _typing := false
var _type_pos := 0.0
var _line_timer := 0.0
var _auto := true
var _waiting := false
var _idle := 0.0
var _t := 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

	var post_layer := _layer(5)
	var rect := ColorRect.new()
	rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh := Shader.new()
	sh.code = POST_SHADER
	post = ShaderMaterial.new()
	post.shader = sh
	rect.material = post
	post_layer.add_child(rect)

	var bars := _layer(20)
	_bar_top = _bar(bars, true)
	_bar_bottom = _bar(bars, false)

	var dlg := _layer(25)
	_build_dialogue(dlg)

	var cards := _layer(30)
	_build_card(cards)
	_skip_hint = UI.label("Press Esc / Start again to skip", 16, Color(1, 1, 1, 0.8))
	_skip_hint.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	_skip_hint.position += Vector2(-340, 18)
	_skip_hint.visible = false
	cards.add_child(_skip_hint)

	var fade_layer := _layer(50)
	_fade = ColorRect.new()
	_fade.color = Color(0, 0, 0, 0)
	_fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fade_layer.add_child(_fade)


func _layer(n: int) -> CanvasLayer:
	var l := CanvasLayer.new()
	l.layer = n
	add_child(l)
	return l


func _bar(parent: Node, top: bool) -> ColorRect:
	var r := ColorRect.new()
	r.color = Color.BLACK
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	r.anchor_right = 1.0
	if top:
		r.anchor_bottom = 0.0
		r.offset_bottom = 0.0
	else:
		r.anchor_top = 1.0
		r.anchor_bottom = 1.0
		r.offset_top = 0.0
	parent.add_child(r)
	return r


# ---------------------------------------------------------------- grade & flashes

func set_grade(tint: Color, saturation := 1.08, vignette := 0.38, grain := 0.035) -> void:
	post.set_shader_parameter("tint", Vector3(tint.r, tint.g, tint.b))
	post.set_shader_parameter("saturation", saturation)
	post.set_shader_parameter("vignette", vignette)
	post.set_shader_parameter("grain", grain)


func hit_flash() -> void:
	var t := create_tween()
	post.set_shader_parameter("aberration", 1.0)
	post.set_shader_parameter("flash_color", Color(1.0, 0.1, 0.05, 0.25))
	t.set_parallel()
	t.tween_method(func(v): post.set_shader_parameter("aberration", v), 1.0, 0.0, 0.45)
	t.tween_method(func(v): post.set_shader_parameter("flash_color", Color(1.0, 0.1, 0.05, v)), 0.25, 0.0, 0.35)


func flash(color := Color.WHITE, time := 0.4) -> void:
	var t := create_tween()
	t.tween_method(func(v): post.set_shader_parameter("flash_color", Color(color, v)), 0.9, 0.0, time)


func aberrate(amount: float, time := 0.6) -> void:
	var t := create_tween()
	t.tween_method(func(v): post.set_shader_parameter("aberration", v), amount, 0.0, time)


# ---------------------------------------------------------------- fades & bars

func fade_out(time := 0.5, color := Color.BLACK) -> Signal:
	var t := create_tween()
	_fade.color = Color(color, _fade.color.a)
	t.tween_property(_fade, "color:a", 1.0, time)
	return t.finished


func fade_in(time := 0.5) -> Signal:
	var t := create_tween()
	t.tween_property(_fade, "color:a", 0.0, time)
	return t.finished


func set_black(on: bool) -> void:
	_fade.color = Color(0, 0, 0, 1.0 if on else 0.0)


func letterbox(on: bool, time := 0.6) -> void:
	var h := 88.0 if on else 0.0
	var t := create_tween().set_parallel().set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	t.tween_property(_bar_top, "offset_bottom", h, time)
	t.tween_property(_bar_bottom, "offset_top", -h, time)


func show_skip_hint(on: bool) -> void:
	_skip_hint.visible = on


# ---------------------------------------------------------------- title card

func _build_card(parent: Node) -> void:
	_card = Control.new()
	_card.set_anchors_preset(Control.PRESET_FULL_RECT)
	_card.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_card.modulate.a = 0.0
	parent.add_child(_card)
	var box := VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_CENTER)
	box.grow_horizontal = Control.GROW_DIRECTION_BOTH
	box.grow_vertical = Control.GROW_DIRECTION_BOTH
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 6)
	_card.add_child(box)
	_card_chapter = UI.label("", 22, UI.GOLD, true)
	_card_title = UI.label("", 64, Color.WHITE, true)
	_card_sub = UI.label("", 22, Color(1, 1, 1, 0.8))
	_card_sub.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_card_sub.custom_minimum_size.x = 760
	_card_line = ColorRect.new()
	_card_line.color = UI.GOLD
	_card_line.custom_minimum_size = Vector2(0, 3)
	for l in [_card_chapter, _card_title, _card_sub]:
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var line_holder := CenterContainer.new()
	line_holder.add_child(_card_line)
	box.add_child(_card_chapter)
	box.add_child(_card_title)
	box.add_child(line_holder)
	box.add_child(_card_sub)


func title_card(chapter: String, title: String, subtitle: String, hold := 2.6) -> void:
	_card_chapter.text = chapter.to_upper()
	_card_title.text = title
	_card_sub.text = subtitle
	_card_line.custom_minimum_size.x = 0
	_card_title.add_theme_constant_override("outline_size", 12)
	Audio.play("whoosh", 0.8, 0.0, -6.0)
	var t := create_tween()
	t.tween_property(_card, "modulate:a", 1.0, 0.6)
	t.parallel().tween_property(_card_line, "custom_minimum_size:x", 520.0, 1.2).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	t.tween_interval(hold)
	t.tween_property(_card, "modulate:a", 0.0, 0.8)
	await t.finished


func hide_card() -> void:
	_card.modulate.a = 0.0


# ---------------------------------------------------------------- dialogue

func _build_dialogue(parent: Node) -> void:
	_box = PanelContainer.new()
	_box.add_theme_stylebox_override("panel", UI.box(Color(0.03, 0.03, 0.05, 0.82), Color(1, 1, 1, 0.15), 2, 16))
	_box.anchor_left = 0.5
	_box.anchor_right = 0.5
	_box.anchor_top = 1.0
	_box.anchor_bottom = 1.0
	_box.offset_left = -440
	_box.offset_right = 440
	_box.offset_top = -170
	_box.offset_bottom = -24
	# Long lines grow the box upward instead of off the bottom of the screen.
	_box.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_box.visible = false
	_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(_box)
	var margin := MarginContainer.new()
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 26)
	margin.add_theme_constant_override("margin_top", 12)
	margin.add_theme_constant_override("margin_bottom", 14)
	_box.add_child(margin)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	margin.add_child(v)
	_name = UI.label("", 22, UI.GOLD, true)
	v.add_child(_name)
	_text = UI.label("", 22, Color(0.96, 0.95, 0.92))
	_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_text.custom_minimum_size = Vector2(820, 64)
	_text.visible_characters_behavior = TextServer.VC_CHARS_AFTER_SHAPING
	v.add_child(_text)
	_arrow = UI.label("»", 22, UI.GOLD)
	_arrow.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_arrow.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	v.add_child(_arrow)


## Shows one line and waits until it is done: the voice has finished and the
## reading time has passed (auto), or the player presses a button.
func say(speaker: String, text: String, auto := true) -> void:
	var c: Dictionary = Voice.info(speaker)
	_speaker = speaker
	_name.text = c.name
	_name.visible = c.name != ""
	_name.add_theme_color_override("font_color", c.color)
	var style: StyleBoxFlat = _box.get_theme_stylebox("panel").duplicate()
	style.border_color = Color(c.color, 0.55)
	_box.add_theme_stylebox_override("panel", style)
	_text.text = text
	_text.visible_characters = 0
	_type_pos = 0.0
	_typing = true
	_auto = auto
	_waiting = true
	_line_timer = 0.9 + text.length() * 0.035
	_box.visible = true
	dialogue_open = true
	_idle = 0.0
	_box.modulate.a = 1.0
	Voice.start_line(speaker, text)
	await line_finished


func current_speaker() -> String:
	return _speaker if dialogue_open else ""


func close_dialogue() -> void:
	_box.visible = false
	dialogue_open = false
	Voice.stop()


## Ends the current line immediately (used when skipping a cutscene).
func abort_line() -> void:
	if _waiting:
		_waiting = false
		_typing = false
		Voice.stop()
		line_finished.emit()


func _process(delta: float) -> void:
	_t += delta
	if not _waiting:
		# Hide the box if no new line follows shortly after the last one.
		if dialogue_open:
			_idle += delta
			if _idle > 0.2:
				close_dialogue()
		return
	if _typing:
		var before := int(_type_pos)
		_type_pos += delta * 45.0
		var now := mini(int(_type_pos), _text.text.length())
		for i in range(before, now):
			Voice.typed(_speaker, _text.text[i], i)
		_text.visible_characters = now
		if now >= _text.text.length():
			_typing = false
	else:
		_line_timer -= delta
	_arrow.modulate.a = 0.0 if _typing else 0.5 + 0.5 * sin(_t * 6.0)
	if not _typing and _auto and _line_timer <= 0.0 and not Voice.busy():
		_finish_line()


func _unhandled_input(event: InputEvent) -> void:
	if not _waiting or get_tree().paused:
		return
	if event.is_action_pressed("jump") or event.is_action_pressed("talk") or event.is_action_pressed("ui_accept") or event.is_action_pressed("attack"):
		get_viewport().set_input_as_handled()
		if _typing:
			_typing = false
			_text.visible_characters = -1
			_line_timer = minf(_line_timer, 0.8)
		else:
			_finish_line()


func _finish_line() -> void:
	_waiting = false
	Voice.stop()
	line_finished.emit()
