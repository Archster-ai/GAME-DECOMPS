extends CanvasLayer
## Pause menu: resume, settings, restart chapter, quit to title.

const UI := preload("res://scripts/ui/ui_theme.gd")
const Settings := preload("res://scripts/ui/settings_panel.gd")

var _root: Control
var _menu: VBoxContainer
var _settings: PanelContainer
var _resume: Button
var _mouse_mode := Input.MOUSE_MODE_VISIBLE


func _ready() -> void:
	layer = 40
	process_mode = Node.PROCESS_MODE_ALWAYS
	_root = Control.new()
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.theme = UI.get_theme()
	_root.visible = false
	add_child(_root)
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.01, 0.03, 0.6)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.add_child(center)
	_menu = VBoxContainer.new()
	_menu.add_theme_constant_override("separation", 12)
	center.add_child(_menu)
	var title := UI.label("PAUSED", 56, UI.GOLD, true)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_menu.add_child(title)
	_resume = _button("Resume", close)
	_button("Settings", _open_settings)
	_button("Restart Chapter", func():
		close()
		Game.restart_level())
	_button("Quit to Title", func():
		close()
		Game.to_title())

	_settings = Settings.new()
	_settings.visible = false
	_settings.closed.connect(func():
		_settings.visible = false
		_menu.visible = true
		_resume.grab_focus())
	center.add_child(_settings)


func _button(text: String, fn: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(320, 52)
	b.pressed.connect(func():
		Audio.play("ui_ok")
		fn.call())
	b.focus_entered.connect(func(): Audio.play("ui_move", 1.0, 0.0, -8.0))
	_menu.add_child(b)
	return b


func _open_settings() -> void:
	_menu.visible = false
	_settings.visible = true
	_settings.focus_first()


func open() -> void:
	_mouse_mode = Input.mouse_mode
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	get_tree().paused = true
	_root.visible = true
	_menu.visible = true
	_settings.visible = false
	_resume.grab_focus()
	Audio.muffle(true)
	Voice.stop()


func close() -> void:
	get_tree().paused = false
	_root.visible = false
	Audio.muffle(false)
	Input.mouse_mode = _mouse_mode


func _unhandled_input(event: InputEvent) -> void:
	if _root.visible and event.is_action_pressed("pause") and not _settings.visible:
		get_viewport().set_input_as_handled()
		close()
