extends Node
## Root of the game. Owns the persistent screen effects and pause menu and
## swaps between the title screen, chapters and the credits.

const InputSetup := preload("res://scripts/core/input_setup.gd")
const PostFx := preload("res://scripts/ui/post_fx.gd")
const TitleScreen := preload("res://scripts/ui/title_screen.gd")
const PauseMenu := preload("res://scripts/ui/pause_menu.gd")
const Credits := preload("res://scripts/ui/credits.gd")

var current: Node
var pause_menu: CanvasLayer
var _swapping := false


func _ready() -> void:
	InputSetup.setup()
	var fx := PostFx.new()
	add_child(fx)
	Game.fx = fx
	Game.main = self
	pause_menu = PauseMenu.new()
	add_child(pause_menu)
	fx.set_black(true)
	show_title()


func show_title() -> void:
	await _swap(TitleScreen.new())
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	Game.fx.fade_in(1.0)


func start_level(i: int) -> void:
	var script: GDScript = load(Game.level_info(i).script)
	await _swap(script.new())


func show_credits() -> void:
	await _swap(Credits.new())
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _swap(node: Node) -> void:
	if _swapping:
		await get_tree().process_frame
	_swapping = true
	if current:
		await Game.fx.fade_out(0.6)
		current.queue_free()
		await get_tree().process_frame
	get_tree().paused = false
	Engine.time_scale = 1.0
	Voice.stop()
	Game.fx.close_dialogue()
	Game.fx.letterbox(false, 0.01)
	Game.fx.hide_card()
	Game.fx.show_skip_hint(false)
	Game.fx.set_black(true)
	current = node
	add_child(current)
	_swapping = false


func can_pause() -> bool:
	return current != null and current.has_method("is_cinematic") and not current.is_cinematic() \
		and not current.complete and not _swapping


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause") and not get_tree().paused and can_pause():
		get_viewport().set_input_as_handled()
		pause_menu.open()
