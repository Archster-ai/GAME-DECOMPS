extends "res://scripts/world/level_base.gd"
## Chapter 3: The Infinite Tax Office. An endless, fluorescent-lit office on
## floor 9,000. Route: elevator lobby -> cubicle maze (staplers) -> the
## PROCESSING tunnel (conveyor + APPROVED stamps) -> Gary's ledge -> the
## Archive atrium (paper stacks + sliding filing cabinets) -> wall-kick
## elevator shaft -> the Department of Keys.

const CEIL := 8.0
const PART_H := 1.9
const LAMP := Color(1.0, 0.93, 0.72)
const BELT_SPEED := 3.5
const STAMP_DROP := 4.2
const STAMP_Y := 4.82
const PAPER_FLOOR := -9.0
const ATRIUM_X := 4.0
const ATRIUM_Z := -125.5

var _carpet: Material
var _wall: Material
var _ceiling: Material
var _fabric: Material
var _trim: Material
var _beige: Material
var _metal: Material
var _wood: Material
var _desk: Material
var _archive: Material
var _dark: Material
var _panel_mat: Material
var _screens: Array[Material] = []
var _paper_mat: StandardMaterial3D
var _belt_mat: StandardMaterial3D
var _ding_mat: StandardMaterial3D
var _rng := RandomNumberGenerator.new()
var _panels: Array[Transform3D] = []
var _reams: Array[Transform3D] = []
var _ream_colors: Array[Color] = []
var _sheets: Array[Transform3D] = []
## [OmniLight3D, StandardMaterial3D, base energy, seed]
var _flickers: Array = []
var _forms: Array[Node3D] = []
var _stamps: Array[Area3D] = []
var _stamp_low: Array[bool] = []
var _doors: Array[StaticBody3D] = []
var _door_tween: Tween
var _steve: Node3D
var _gary: Node3D
var _t := 0.0


func _init() -> void:
	music = "office"
	spawn_point = Vector3(0, 0.1, -2.5)
	spawn_yaw = 0.0
	kill_y = -14.0


func env_config() -> Dictionary:
	return {
		"top": Color(0.14, 0.13, 0.08), "horizon": Color(0.22, 0.2, 0.12), "bottom": Color(0.1, 0.09, 0.06),
		"sun_color": Color(1.0, 0.92, 0.7), "sun_energy": 0.05, "sun_angle": Vector2(-85, 20),
		"sun_glow": 0.0, "sun_fog": 0.0, "ambient": 2.2,
		"fog_color": Color(0.52, 0.47, 0.3), "fog_density": 0.012, "fog_sky": 1.0,
		"volumetric": 0.022, "vol_color": Color(1.0, 0.95, 0.78),
		"exposure": 1.2, "glow": 1.0, "tint": Color(1.03, 0.99, 0.84), "saturation": 0.92,
		"env_saturation": 1.0, "vignette": 0.5, "player_light": 1.2,
	}


# ---------------------------------------------------------------- build

func build() -> void:
	_rng.seed = 9000
	_make_materials()
	_build_hall()
	_build_elevators()
	_build_lobby()
	_build_side_corridor()
	_build_maze()
	_build_tunnel()
	_build_ledge()
	_build_atrium()
	_build_shaft()
	_build_department()
	_scatter_sheets()
	var panel := BoxMesh.new()
	panel.size = Vector3(1.2, 0.06, 2.4)
	var lights := _multimesh(panel, _panel_mat, _panels)
	lights.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_multimesh(BoxMesh.new(), _paper_mat, _reams, _ream_colors)
	var sheet := BoxMesh.new()
	sheet.size = Vector3(0.6, 0.01, 0.8)
	var papers := _multimesh(sheet, Mats.solid(Color(0.93, 0.92, 0.86), 0.9), _sheets)
	papers.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	Fx.ambient(self, Vector3(0, 3.5, -30), Vector3(12, 3.5, 30), Color(1.0, 0.95, 0.8, 0.35), 90, 0.06, Vector3(0, 0.1, 0), 8.0)
	Fx.ambient(self, Vector3(ATRIUM_X, 14, ATRIUM_Z), Vector3(18, 14, 24), Color(1.0, 1.0, 0.95, 0.6), 70, 0.22, Vector3(0.2, -0.5, 0), 16.0)


func _make_materials() -> void:
	_carpet = Mats.pattern("carpet", [Color(0.56, 0.5, 0.3), Color(0.4, 0.35, 0.2)], 0.7, 0.95)
	_wall = Mats.pattern("stripes", [Color(0.8, 0.74, 0.5), Color(0.74, 0.68, 0.45)], 0.35, 0.9)
	_ceiling = Mats.pattern("grid", [Color(0.84, 0.82, 0.74), Color(0.52, 0.5, 0.44)], 0.8, 0.95)
	_fabric = Mats.rough_surface(Color(0.36, 0.4, 0.44), Color(0.44, 0.48, 0.52), 0.8, 0.95, 4, 0.3)
	_trim = Mats.solid(Color(0.62, 0.6, 0.56), 0.5, 0.2)
	_beige = Mats.solid(Color(0.78, 0.74, 0.63), 0.55)
	_metal = Mats.solid(Color(0.55, 0.57, 0.6), 0.35, 0.7)
	_wood = Mats.solid(Color(0.52, 0.37, 0.22), 0.7)
	_desk = Mats.solid(Color(0.7, 0.68, 0.62), 0.6)
	_archive = Mats.pattern("tiles", [Color(0.74, 0.71, 0.6), Color(0.46, 0.44, 0.38)], 0.25, 0.7)
	_dark = Mats.solid(Color(0.08, 0.08, 0.09), 0.5)
	_panel_mat = Mats.glow(LAMP, 3.0)
	_screens = [Mats.glow(Color(0.35, 1.0, 0.5), 1.4), Mats.glow(Color(0.35, 0.6, 1.0), 1.4), Mats.glow(Color(1.0, 0.7, 0.25), 1.4)]
	_paper_mat = StandardMaterial3D.new()
	_paper_mat.vertex_color_use_as_albedo = true
	_paper_mat.roughness = 0.9


func _build_hall() -> void:
	box(Vector3(0, -0.5, -47), Vector3(26, 1, 106), _carpet)
	box(Vector3(0, CEIL + 0.25, -47), Vector3(26, 0.5, 106), _ceiling)
	# Left wall, with an opening into the endless side corridor at z -10..-15.
	box(Vector3(-13.25, 4, -4.5), Vector3(0.5, 8, 11), _wall)
	box(Vector3(-13.25, 6, -12.5), Vector3(0.5, 4, 5), _wall)
	box(Vector3(-13.25, 4, -57.5), Vector3(0.5, 8, 85), _wall)
	box(Vector3(13.25, 4, -49.5), Vector3(0.5, 8, 101), _wall)
	# The elevator wall behind the spawn, with the real door in the middle.
	box(Vector3(-7.1, 4, 1), Vector3(11.8, 8, 0.4), _wall)
	box(Vector3(7.1, 4, 1), Vector3(11.8, 8, 0.4), _wall)
	box(Vector3(0, 5.5, 1), Vector3(2.4, 5, 0.4), _wall)
	for x in [-12.97, 12.97]:
		deco_box(Vector3(x, 0.1, -49.5), Vector3(0.06, 0.2, 101), _trim)
	# Ceiling panels every 6 m; some of them carry a real light.
	var lamps := {
		Vector2(0, -3): [16.0, 2.2, false], Vector2(-7, -15): [12.0, 1.4, true],
		Vector2(7, -27): [15.0, 2.0, false], Vector2(-7, -39): [15.0, 2.0, true],
		Vector2(7, -51): [15.0, 2.0, false], Vector2(0, -69): [12.0, 2.0, false],
		Vector2(0, -81): [12.0, 2.0, true], Vector2(0, -93): [15.0, 2.0, false],
	}
	for i in 17:
		var z := -3.0 - 6.0 * i
		for x in [-7.0, 0.0, 7.0]:
			if x != 0.0 and z < -60.0 and z > -91.0:
				continue
			var k := Vector2(x, z)
			if lamps.has(k):
				var l: Array = lamps[k]
				_lamp(Vector3(x, CEIL - 0.03, z), l[0], l[1], l[2])
			else:
				_panel(Vector3(x, CEIL - 0.03, z))


func _build_elevators() -> void:
	var brass := Mats.gold()
	var steel := Mats.solid(Color(0.66, 0.66, 0.64), 0.35, 0.35)
	for x in [-5.0, 0.0, 5.0]:
		deco_box(Vector3(x - 1.32, 1.55, 0.76), Vector3(0.16, 3.1, 0.1), brass)
		deco_box(Vector3(x + 1.32, 1.55, 0.76), Vector3(0.16, 3.1, 0.1), brass)
		deco_box(Vector3(x, 3.1, 0.76), Vector3(2.8, 0.16, 0.1), brass)
		deco_box(Vector3(x, 3.55, 0.77), Vector3(1.0, 0.36, 0.06), _dark)
		sign_text("9000", Vector3(x, 3.55, 0.73), 0.0, 26, Color(1.0, 0.55, 0.15), 1.5)
		if x != 0.0:
			for s in [-1.0, 1.0]:
				deco_box(Vector3(x + s * 0.6, 1.5, 0.77), Vector3(1.18, 3.0, 0.06), steel)
	var note := _poster("OUT OF\nORDER", Vector3(5, 1.7, 0.72), 0.0, Color(1.0, 0.95, 0.6), Color(0.2, 0.15, 0.1), 0.7, 0.5, 18)
	note.rotation.z = 0.08
	# The real elevator: sliding doors and a small wood-panelled car.
	for s in [-1.0, 1.0]:
		_doors.append(box(Vector3(s * 0.6, 1.5, 1.0), Vector3(1.2, 3.0, 0.1), steel))
	box(Vector3(-1.7, 1.6, 3.1), Vector3(0.2, 3.2, 3.8), _wood)
	box(Vector3(1.7, 1.6, 3.1), Vector3(0.2, 3.2, 3.8), _wood)
	box(Vector3(0, 1.6, 5.1), Vector3(3.6, 3.2, 0.2), _wood)
	box(Vector3(0, 3.3, 3.1), Vector3(3.6, 0.2, 3.8), _ceiling)
	deco_box(Vector3(0, 3.18, 3.1), Vector3(1.6, 0.04, 2.2), _panel_mat)
	omni(Vector3(0, 2.6, 3.4), LAMP, 5.0, 1.2)
	for s in [-1.0, 1.0]:
		deco_box(Vector3(s * 1.56, 1.0, 3.1), Vector3(0.05, 0.05, 3.4), brass)
	deco_box(Vector3(0, 1.0, 4.96), Vector3(3.1, 0.05, 0.05), brass)
	# A button panel with exactly one button.
	deco_box(Vector3(1.58, 1.4, 1.8), Vector3(0.04, 0.7, 0.35), steel)
	deco_ball(Vector3(1.55, 1.5, 1.8), 0.07, Mats.glow(Color(1.0, 0.6, 0.2), 2.0))
	var maybe := sign_text("MAYBE", Vector3(1.55, 1.32, 1.8), PI / 2, 16, Color(0.1, 0.1, 0.1))
	maybe.pixel_size = 0.006
	_ding_mat = StandardMaterial3D.new()
	_ding_mat.albedo_color = Color(0.3, 0.2, 0.1)
	_ding_mat.emission_enabled = true
	_ding_mat.emission = Color(1.0, 0.7, 0.3)
	_ding_mat.emission_energy_multiplier = 0.1
	deco_box(Vector3(0, 4.0, 0.76), Vector3(0.28, 0.28, 0.05), _ding_mat, Vector3(0, 0, PI / 4))
	deco_box(Vector3(0, 5.6, 0.78), Vector3(6.4, 1.4, 0.04), brass)
	sign_text("FLOOR 9,000", Vector3(0, 5.6, 0.74), 0.0, 110, Color(0.25, 0.18, 0.08))


func _build_lobby() -> void:
	var sp := Vector3(4, 0, -8)
	_steve = npc("steve", "steve", sp, _yaw_to(sp, spawn_point), [
		["steve", "Need a tip? Staplers stomp easy. Jump on 'em from above. Never shake hands with one."],
		["stax", "Stomp the stationery. Got it.", "cool"],
		["steve", "That tip was one coin. I put it on your tab."],
		["stax", "I don't HAVE a tab!", "shocked"],
		["steve", "Everyone has a tab, Stax. Some people just don't know it yet."],
	], [["steve", "Gary from Accounting knows where the key is. He's past the stamps. Past everything, really."]])
	_dress_steve(_steve)
	_ticket_machine(Vector3(-2.6, 0, -4.8))
	_cooler(Vector3(-5.5, 0, -3.2))
	_plant(Vector3(-12, 0, -0.2))
	_plant(Vector3(12, 0, -0.2))
	_plant(Vector3(-12, 0, -19))
	var seat := Mats.solid(Color(0.3, 0.36, 0.45), 0.8)
	box(Vector3(-7, 0.23, -9), Vector3(4.6, 0.46, 0.7), seat)
	deco_box(Vector3(-7, 0.85, -8.7), Vector3(4.6, 0.75, 0.1), seat)
	for i in 4:
		deco_box(Vector3(-8.72 + i * 1.15, 0.6, -9), Vector3(0.06, 0.25, 0.7), _metal)
	_serving_display(Vector3(0, 5.8, -12), PI, "NOW SERVING: 3")
	_filing_tower(Vector3(10.8, 0, -7), 4.5)
	coin(Vector3(10.8, 5.6, -7), 5)
	coin_line(Vector3(0, 1, -5.5), Vector3(0, 1, -17), 6)
	_poster("HANG IN\nTHERE", Vector3(-12.97, 3.2, -5), -PI / 2, Color(0.2, 0.45, 0.7), Color.WHITE)
	_poster("SYNERGY", Vector3(12.97, 3.4, -15), PI / 2, Color(0.8, 0.42, 0.15), Color.WHITE, 3.2, 1.4, 64)
	_poster("PLEASE TAKE\nA NUMBER", Vector3(12.97, 3.2, -3), PI / 2, Color(0.9, 0.9, 0.85), Color(0.6, 0.1, 0.1), 2.2, 1.6, 40)


func _build_side_corridor() -> void:
	box(Vector3(-36, -0.5, -12.5), Vector3(45, 1, 5), _carpet)
	box(Vector3(-36, 4.25, -12.5), Vector3(45, 0.5, 5), _ceiling)
	box(Vector3(-36, 2, -9.75), Vector3(45, 4, 0.5), _wall)
	box(Vector3(-36, 2, -15.25), Vector3(45, 4, 0.5), _wall)
	box(Vector3(-58.25, 2, -12.5), Vector3(0.5, 4, 5), _wall)
	for i in 11:
		var p := Vector3(-16.0 - 4.0 * i, 3.97, -12.5)
		if i == 2:
			_lamp(p, 12.0, 1.3, false, PI / 2)
		elif i == 9:
			_lamp(p, 10.0, 1.2, true, PI / 2)
		else:
			_panel(p, PI / 2)
	for i in 5:
		var x := -19.0 - i * 8.0
		var north := i % 2 == 0
		var zf := -10.03 if north else -14.97
		var yaw := 0.0 if north else PI
		deco_box(Vector3(x, 1.1, zf), Vector3(1.0, 2.2, 0.06), _wood)
		deco_box(Vector3(x + 0.35, 1.05, zf + (-0.04 if north else 0.04)), Vector3(0.1, 0.06, 0.06), Mats.gold())
		var num := sign_text("27-" + "BCDEF"[i], Vector3(x, 1.85, zf + (-0.04 if north else 0.04)), yaw, 24, Color(0.95, 0.85, 0.55))
		num.pixel_size = 0.008
	coin_line(Vector3(-17, 1, -12.5), Vector3(-50, 1, -12.5), 8)
	coin(Vector3(-55.8, 1.2, -12.5), 5)
	_poster("YOU HAVE REACHED\nTHE END OF INFINITY", Vector3(-57.97, 2.4, -12.5), -PI / 2, Color(0.9, 0.88, 0.8), Color(0.55, 0.08, 0.06), 3.6, 1.3, 30)
	var back := sign_text("PLEASE TURN BACK", Vector3(-57.95, 1.4, -12.5), -PI / 2, 22, Color(0.3, 0.25, 0.2))
	back.pixel_size = 0.008
	_chair(Vector3(-55.5, 0, -11.2), 2.2)
	tip(Vector3(-52, 1.5, -12.5), Vector3(6, 3, 5), "stax", "The end of infinity. Smaller than I expected. Kinda like my allowance.")


func _build_maze() -> void:
	# Three banks of cubicles make a readable zig-zag: right, left, right.
	var banks := [[-26.0, -13.0, 6.0], [-36.0, -6.0, 13.0], [-46.0, -13.0, 6.0]]
	for bi in banks.size():
		var bz: float = banks[bi][0]
		var x0: float = banks[bi][1]
		var x1: float = banks[bi][2]
		box(Vector3((x0 + x1) * 0.5, PART_H * 0.5, bz), Vector3(x1 - x0, PART_H, 0.2), _fabric)
		deco_box(Vector3((x0 + x1) * 0.5, PART_H + 0.02, bz), Vector3(x1 - x0, 0.04, 0.26), _trim)
		var n := 5
		var cell := (x1 - x0) / n
		for i in n + 1:
			var x := x0 + i * cell
			if absf(x) > 12.9:
				continue
			box(Vector3(x, PART_H * 0.5, bz), Vector3(0.2, PART_H, 4.8), _fabric)
			deco_box(Vector3(x, PART_H + 0.02, bz), Vector3(0.26, 0.04, 4.8), _trim)
		for i in n:
			var cx := x0 + (i + 0.5) * cell
			for side in [-1.0, 1.0]:
				if bi == 1 and i == 2 and side < 0.0:
					# A paper tower with a big coin on top.
					_ream_column(Vector3(cx + 0.9, 0, bz - 1.4), 1.2, 4.0, 0.0)
					_desk_set(Vector3(cx - 0.8, 0, bz), side)
					coin(Vector3(cx + 0.9, 5.1, bz - 1.4), 5)
				else:
					_cubicle(Vector3(cx, 0, bz), side)
	enemy("stapler", Vector3(9.5, 0, -21), Vector3(9.5, 0, -30))
	enemy("stapler", Vector3(-4, 0, -31), Vector3(6, 0, -31))
	enemy("stapler", Vector3(-9.5, 0, -32), Vector3(-9.5, 0, -40))
	enemy("stapler", Vector3(-10, 0, -41), Vector3(3, 0, -41))
	enemy("stapler", Vector3(-8, 0, -52), Vector3(8, 0, -52))
	coin_line(Vector3(9.5, 1, -21), Vector3(9.5, 1, -29), 4)
	coin_line(Vector3(5, 1, -31), Vector3(-6, 1, -31), 6)
	coin_line(Vector3(-9.5, 1, -33), Vector3(-9.5, 1, -39), 3)
	coin_line(Vector3(-6, 1, -41), Vector3(5, 1, -41), 6)
	coin_line(Vector3(9.5, 1, -43), Vector3(9.5, 1, -49), 3)
	_cooler(Vector3(-6, 0, -53))
	coin_ring(Vector3(-6, 1, -53), 1.8, 6)
	_plant(Vector3(12, 0, -55))
	_poster("TEAMWORK\nMAKES THE\nDREAM WORK", Vector3(-12.97, 3.8, -31), -PI / 2, Color(0.3, 0.55, 0.35), Color.WHITE, 2.4, 2.2, 44)
	_poster("HAVE YOU\nFILED\nTODAY?", Vector3(12.97, 3.8, -41), PI / 2, Color(0.55, 0.25, 0.5), Color.WHITE, 2.4, 2.2, 48)
	_poster("HANG IN\nTHERE", Vector3(-12.97, 3.8, -48), -PI / 2, Color(0.2, 0.45, 0.7), Color.WHITE)
	tip(Vector3(0, 1.5, -22), Vector3(26, 3, 3), "stax", "Evil staplers. Great. Even the office supplies want a piece of me.")


func _build_tunnel() -> void:
	# Solid blocks narrow the hall to a 5.5 m PROCESSING tunnel (z -62..-90).
	box(Vector3(7.875, 4, -76), Vector3(10.25, 8, 28), _wall)
	box(Vector3(-7.875, 4, -76), Vector3(10.25, 8, 28), _wall)
	var hazard := Mats.pattern("stripes", [Color(0.95, 0.75, 0.1), Color(0.1, 0.1, 0.1)], 1.0, 0.6)
	for s in [-1.0, 1.0]:
		deco_box(Vector3(s * 2.72, 0.35, -76), Vector3(0.06, 0.7, 28), hazard)
		deco_box(Vector3(s * 2.62, 0.04, -76), Vector3(0.26, 0.08, 28), _metal)
	# The belt: a scrolling striped plane, rollers, and forms riding along.
	var img := Mats.pattern_image("stripes", [Color(0.13, 0.13, 0.14), Color(0.24, 0.24, 0.26)])
	_belt_mat = StandardMaterial3D.new()
	_belt_mat.albedo_texture = ImageTexture.create_from_image(img)
	_belt_mat.roughness = 0.75
	_belt_mat.uv1_scale = Vector3(7, 1, 1)
	var plane := PlaneMesh.new()
	plane.size = Vector2(28, 5)
	deco(plane, _belt_mat, Vector3(0, 0.02, -76), Vector3(0, PI / 2, 0))
	for z in [-62.1, -89.9]:
		deco_cyl(Vector3(0, 0.1, z), 0.14, 5.2, _metal, Vector3(0, 0, PI / 2))
	var push = zone(Vector3(0, 0.8, -76), Vector3(5.4, 1.6, 28), "push")
	push.push = Vector3(0, 0, -BELT_SPEED)
	var form := Mats.solid(Color(0.96, 0.95, 0.9), 0.9)
	for i in 12:
		var f := deco_box(Vector3(_rng.randf_range(-1.9, 1.9), 0.035, -62.5 - i * 2.27), Vector3(0.55, 0.015, 0.75), form, Vector3(0, _rng.randf_range(-0.4, 0.4), 0))
		_forms.append(f)
	# APPROVED stamps. Staggered so a steady run meets each one just as it lifts.
	_stamp(-68.0, 0.0)
	_stamp(-75.0, 0.5)
	_stamp(-82.0, 1.0)
	for i in 14:
		var z := -63.5 - i * 1.9
		if absf(z + 68.0) > 1.6 and absf(z + 75.0) > 1.6 and absf(z + 82.0) > 1.6:
			coin(Vector3(0, 1, z))
	# Portal signs.
	deco_box(Vector3(0, 6.7, -62.2), Vector3(5.4, 1.1, 0.15), _dark)
	sign_text("PROCESSING", Vector3(0, 6.7, -62.0), PI, 72, Color(0.4, 1.0, 0.55), 1.8)
	_serving_display(Vector3(-7.5, 6.2, -61.85), PI, "NOW SERVING: 3", false)
	_poster("ALL VISITORS\nMUST BE\nAPPROVED", Vector3(7.5, 3.4, -61.97), PI, Color(0.85, 0.15, 0.1), Color.WHITE, 3.0, 2.4, 48)
	_poster("SMILE!\nYOU ARE BEING\nAUDITED", Vector3(-7.5, 3.0, -61.97), PI, Color(0.95, 0.9, 0.7), Color(0.2, 0.2, 0.25), 2.8, 2.2, 40)
	_poster("SYNERGY", Vector3(2.72, 4.2, -71.5), PI / 2, Color(0.8, 0.42, 0.15), Color.WHITE, 2.6, 1.2, 56)
	_poster("IT IS\nALWAYS\nMONDAY", Vector3(-2.72, 4.2, -78.5), -PI / 2, Color(0.25, 0.3, 0.45), Color.WHITE, 2.0, 2.0, 44)
	checkpoint(Vector3(-5.5, 0, -58.5), 0.0)
	tip(Vector3(0, 1.5, -57), Vector3(26, 3, 3), "steve", "Those APPROVED stamps slam fast and lift slow. Dash under right after one lifts!")
	tip(Vector3(0, 1.5, -86), Vector3(5, 3, 2), "steve", "See? The conveyor gives free speed. Only free thing in this building! Besides me. Mostly.")


func _build_ledge() -> void:
	var gp := Vector3(-6.5, 0, -95.5)
	_gary = npc("gary", "gary", gp, _yaw_to(gp, Vector3(0, 0, -90)), [
		["gary", "Oh. A visitor. First one since 1648."],
		["stax", "Uh, hi? Have you been filing that same form this whole time?", "think"],
		["gary", "Form 27-B. Page one. It's a very long page."],
		["stax", "I'm looking for a Golden Vault Key. Big, shiny, worth a fortune?"],
		["gary", "Department of Keys. Top of the elevator shaft. Over there. Glowing. Very pink."],
		["gary", "The elevator is out of order. It's been out of order since elevators were invented."],
		["stax", "So how do I get up there?", "shrug"],
		["gary", "Kick the walls. It's what I do every Monday. Emotionally."],
		["gary", "Oh. Your sign friend was here. Filed a permit for something called 'The Big Reveal'."],
		["stax", "Steve? Probably a surprise party. That guy LOVES paperwork.", "shrug"],
		["gary", "Mm. Permit approved. Everything gets approved eventually. Except my vacation."],
	], [["gary", "Top of the shaft. Kick the walls. I'd come with you, but it's not my department."]])
	box(Vector3(-8.3, 0.38, -97), Vector3(2.0, 0.76, 1.0), _desk)
	deco_box(Vector3(-8.0, 1.0, -97.1), Vector3(0.56, 0.48, 0.5), _beige)
	deco_box(Vector3(-8.0, 1.02, -96.84), Vector3(0.44, 0.34, 0.02), _screens[0], Vector3(0, 0, 0))
	var scr := sign_text("27-B\npg. 1", Vector3(-8.0, 1.02, -96.82), PI, 12, Color(0.1, 0.3, 0.12))
	scr.pixel_size = 0.008
	_ream_pile(Vector3(-9.0, 0.76, -97.1), 0.5, 7)
	_ream_pile(Vector3(-7.4, 0.76, -97.2), 0.45, 3)
	var plate := sign_text("GARY - ACCOUNTING - SINCE 1648", Vector3(-8.3, 0.5, -96.48), PI, 16, Color(0.95, 0.85, 0.5))
	plate.pixel_size = 0.008
	_chair(Vector3(-8.2, 0, -95.9), PI)
	var glass := Mats.glass(Color(0.75, 0.9, 1.0), 0.2)
	for s in [-1.0, 1.0]:
		box(Vector3(s * 7.75, 0.55, -99.75), Vector3(10.5, 1.1, 0.12), glass)
		deco_box(Vector3(s * 7.75, 1.12, -99.75), Vector3(10.5, 0.06, 0.16), _metal)
	checkpoint(Vector3(6, 0, -94.5), 0.0)
	_plant(Vector3(12, 0, -91.5))
	tip(Vector3(0, 1.5, -97.5), Vector3(26, 3, 3), "steve", "Ride the sliding filing cabinets across. Don't fall! Down there it's all unpaid invoices.")


func _build_atrium() -> void:
	# The Archive: a tall void (x -16..24, z -100..-151) over a sea of paper.
	box(Vector3(-16.25, 13, ATRIUM_Z), Vector3(0.5, 50, 51), _archive)
	box(Vector3(24.25, 13, ATRIUM_Z), Vector3(0.5, 50, 51), _archive)
	box(Vector3(ATRIUM_X, 13, -151.25), Vector3(40.5, 50, 0.5), _archive)
	box(Vector3(ATRIUM_X, 38.25, ATRIUM_Z), Vector3(40.5, 0.5, 51), _ceiling)
	box(Vector3(-14.5, 13, -100.25), Vector3(3, 50, 0.5), _archive)
	box(Vector3(18.5, 13, -100.25), Vector3(11, 50, 0.5), _archive)
	box(Vector3(0, 23, -100.25), Vector3(26, 30, 0.5), _archive)
	box(Vector3(0, -6.5, -100.25), Vector3(26, 11, 0.5), _archive)
	deco_box(Vector3(ATRIUM_X, PAPER_FLOOR - 0.3, ATRIUM_Z), Vector3(40, 0.6, 51),
		Mats.rough_surface(Color(0.82, 0.8, 0.72), Color(0.95, 0.93, 0.86), 0.3, 0.95, 8, 0.4))
	zone(Vector3(ATRIUM_X, -7.4, ATRIUM_Z), Vector3(40, 2.6, 51), "kill")
	# The route: paper stacks and sliding filing cabinets up to the shaft.
	var stacks := [
		[Vector3(0, 0.0, -104.5), 3.5], [Vector3(0, 1.6, -110), 3.0], [Vector3(-4.5, 3.2, -114.5), 3.0],
		[Vector3(-4.5, 3.2, -131), 3.5], [Vector3(-4.5, 4.8, -136.5), 3.0], [Vector3(10.5, 6.4, -136.5), 3.0],
	]
	for s in stacks:
		var top: Vector3 = s[0]
		_ream_column(top, s[1], top.y, PAPER_FLOOR)
	_cabinet(Vector3(-4.5, 2.2, -119.5), Vector3(0, 0, -8), 5.0, 0.0)
	_cabinet(Vector3(0, 3.8, -136.5), Vector3(6.5, 0, 0), 5.0, 0.5)
	coin_arc(Vector3(0, 1, -99.6), Vector3(0, 1, -103), 1.6, 3)
	coin_arc(Vector3(0, 1.0, -106.3), Vector3(0, 2.6, -108.8), 1.6, 3)
	coin_arc(Vector3(-1.2, 2.6, -111.6), Vector3(-3.6, 4.2, -113.4), 1.4, 3)
	coin_line(Vector3(-4.5, 4.4, -119.5), Vector3(-4.5, 4.4, -127.5), 4)
	coin_ring(Vector3(-4.5, 4.2, -131), 1.1, 5)
	coin_line(Vector3(-2.5, 6.0, -136.5), Vector3(6.5, 6.0, -136.5), 5)
	coin(Vector3(8.4, 7.8, -136.5))
	coin_arc(Vector3(10.5, 7.4, -137.4), Vector3(10.5, 9.0, -140), 1.2, 3)
	# Background clutter: towering paper piles against the walls.
	for p in [Vector3(-13.5, 0, -108), Vector3(-13.8, 0, -124), Vector3(-12.5, 0, -145), Vector3(21.5, 0, -110), Vector3(21, 0, -124)]:
		_ream_column(Vector3(p.x, _rng.randf_range(14.0, 22.0), p.z), _rng.randf_range(2.5, 4.0), 0.0, PAPER_FLOOR, false)
	# Lights: two big fills, two god-ray spots and hanging fixtures.
	omni(Vector3(-6, 22, -112), LAMP, 36.0, 3.2)
	omni(Vector3(8, 22, -132), LAMP, 36.0, 3.2)
	omni(Vector3(-2, 9, -122), LAMP, 22.0, 2.0)
	spot(Vector3(-12, 37.5, -103), Vector3(-3, 0, -118), LAMP, 55.0, 16.0, 7.0)
	spot(Vector3(20, 37.5, -106), Vector3(4, 4, -134), LAMP, 60.0, 14.0, 7.0)
	for i in 6:
		var p := Vector3(-9.0 + (i % 3) * 13.0, 26.5, -110.0 - int(i / 3.0) * 20.0)
		deco_box(p, Vector3(0.5, 0.14, 7.0), _panel_mat)
		deco_box(p + Vector3(0, 0.12, 0), Vector3(0.7, 0.1, 7.2), _metal)
		for dz in [-3.0, 3.0]:
			deco_cyl(p + Vector3(0, 6.0, dz), 0.02, 11.8, _dark)
	var big := sign_text("FLOOR\n9,000", Vector3(-15.97, 17, -121), -PI / 2, 520, Color(0.28, 0.26, 0.22))
	big.pixel_size = 0.012
	var wait := sign_text("PLEASE\nWAIT", Vector3(23.97, 18, -120), PI / 2, 420, Color(0.28, 0.26, 0.22))
	wait.pixel_size = 0.012
	deco_box(Vector3(-6, 20, -150.9), Vector3(12, 3, 0.4), _dark)
	sign_text("NOW SERVING: 3", Vector3(-6, 20, -150.65), PI, 150, Color(1.0, 0.18, 0.1), 2.2)


func _build_shaft() -> void:
	# The landing at the shaft base.
	box(Vector3(7.5, 7.25, -145.25), Vector3(11, 1.5, 11.5), _carpet)
	deco_box(Vector3(7.5, -1.2, -146), Vector3(7, 15.6, 7), _archive)
	checkpoint(Vector3(3.2, 8, -140.8), 0.0)
	# Two walls 4 m apart for wall kicks (inner faces x = 5 and x = 9).
	var steel := Mats.solid(Color(0.42, 0.45, 0.5), 0.55, 0.5)
	box(Vector3(4.75, 23, -147), Vector3(0.5, 30, 8), steel)
	box(Vector3(9.25, 18, -147), Vector3(0.5, 20, 8), steel)
	box(Vector3(8.5, 17.75, -149.75), Vector3(1.0, 0.5, 2.5), _metal)
	coin(Vector3(8.5, 19.2, -149.8), 5)
	var hazard := Mats.pattern("stripes", [Color(0.95, 0.75, 0.1), Color(0.1, 0.1, 0.1)], 1.0, 0.6)
	for i in 6:
		var y := 11.0 + i * 3.0
		deco_box(Vector3(5.03, y, -147), Vector3(0.06, 0.25, 8), hazard)
		if y < 28.0:
			deco_box(Vector3(8.97, y, -147), Vector3(0.06, 0.25, 8), hazard)
		var fl := sign_text("%d" % (9001 + i), Vector3(7, y + 1.2, -150.95), PI, 64, Color(0.95, 0.75, 0.2), 0.8)
		fl.pixel_size = 0.01
	for x in [6.0, 8.0]:
		deco_box(Vector3(x, 21.5, -150.9), Vector3(0.2, 27, 0.15), _metal)
	deco_cyl(Vector3(7, 30, -148), 0.04, 10, _dark)
	for i in 6:
		coin(Vector3(5.9 if i % 2 == 0 else 8.1, 11.0 + i * 3.0, -145.5))
	deco_box(Vector3(7, 11.2, -142.9), Vector3(4.0, 0.9, 0.08), Mats.solid(Color(0.95, 0.75, 0.1), 0.6))
	sign_text("OUT OF ORDER - USE WALLS", Vector3(7, 11.2, -142.84), PI, 30, Color(0.1, 0.1, 0.1))
	omni(Vector3(7, 14, -148), LAMP, 10.0, 1.4)
	omni(Vector3(7, 24, -148), LAMP, 10.0, 1.4)
	tip(Vector3(7, 9.5, -141.5), Vector3(11, 3, 3), "steve", "Wall kick time! Jump into a wall, then jump again the instant you touch it. Kick, kick, kick!")


func _build_department() -> void:
	# The Department of Keys: a glass-fronted office at the top of the shaft.
	var red := Mats.pattern("carpet", [Color(0.55, 0.1, 0.12), Color(0.38, 0.06, 0.08)], 0.7, 0.95)
	box(Vector3(16.75, 27.75, -147), Vector3(14.5, 0.5, 8), red)
	box(Vector3(14.5, 35.25, -147.25), Vector3(20, 0.5, 8.5), _ceiling)
	box(Vector3(16.75, 31.5, -143.1), Vector3(14.5, 7, 0.2), Mats.glass(Color(0.7, 0.9, 1.0), 0.16))
	deco_box(Vector3(20, 9.25, -147), Vector3(2, 36.5, 2), _archive)
	deco_box(Vector3(14.5, 36.6, -143.05), Vector3(20, 2.8, 0.3), _dark)
	sign_text("DEPARTMENT OF KEYS", Vector3(14.5, 36.75, -143.25), PI, 120, Color(1.0, 0.35, 0.75), 2.6)
	deco_box(Vector3(14.5, 35.75, -143.24), Vector3(15, 0.08, 0.04), Mats.glow(Color(1.0, 0.8, 0.3), 4.0))
	omni(Vector3(14.5, 35.5, -140), Color(1.0, 0.4, 0.75), 14.0, 2.0)
	omni(Vector3(15, 33.5, -147), LAMP, 14.0, 1.4)
	# The key on a gold dais under a spotlight, behind velvet ropes.
	deco_cyl(Vector3(19, 28.1, -147), 1.6, 0.2, Mats.gold())
	place_goal(Vector3(19, 28.2, -147))
	spot(Vector3(19, 34.9, -147), Vector3(19, 28, -147), Color(1.0, 0.85, 0.55), 12.0, 26.0, 8.0)
	var velvet := Mats.solid(Color(0.6, 0.05, 0.1), 0.8)
	var posts := [Vector3(16.6, 28, -144.6), Vector3(21.4, 28, -144.6), Vector3(21.4, 28, -149.4), Vector3(16.6, 28, -149.4)]
	for p in posts:
		deco_cyl(p + Vector3(0, 0.5, 0), 0.06, 1.0, Mats.gold())
		deco_ball(p + Vector3(0, 1.05, 0), 0.09, Mats.gold())
	deco_box(Vector3(19, 28.85, -144.6), Vector3(4.8, 0.08, 0.08), velvet)
	deco_box(Vector3(19, 28.85, -149.4), Vector3(4.8, 0.08, 0.08), velvet)
	deco_box(Vector3(21.4, 28.85, -147), Vector3(0.08, 0.08, 4.8), velvet)
	box(Vector3(13.5, 28.5, -150), Vector3(2.4, 1.0, 1.0), _desk)
	deco_ball(Vector3(13.0, 29.05, -150), 0.1, Mats.gold(), Vector3(1, 0.6, 1))
	var one := sign_text("KEYS: ONE PER CUSTOMER", Vector3(13.5, 28.55, -149.48), PI, 18, Color(0.2, 0.1, 0.05))
	one.pixel_size = 0.008
	_serving_display(Vector3(23.8, 32.4, -147), PI / 2, "NOW SERVING: YOU", false)
	_poster("EMPLOYEE OF THE MONTH\n(EVERY MONTH)", Vector3(16, 31.6, -150.97), PI, Color(0.95, 0.9, 0.75), Color(0.25, 0.15, 0.05), 3.4, 2.6, 22)
	# A tiny portrait of a very trustworthy wooden sign.
	var sign_wood := Mats.solid(Color(0.82, 0.62, 0.38), 0.7)
	deco_box(Vector3(16, 30.5, -150.92), Vector3(0.08, 0.5, 0.02), Mats.solid(Color(0.48, 0.3, 0.16), 0.7))
	deco_box(Vector3(16, 30.8, -150.91), Vector3(0.6, 0.3, 0.02), sign_wood)
	coin_line(Vector3(10.8, 29, -147), Vector3(14.5, 29, -147), 4)
	coin_ring(Vector3(19, 29, -147), 2.2, 6)
	tip(Vector3(12, 29.5, -147), Vector3(5, 3, 8), "steve", "You made it! Those radio tips were one coin per word, by the way. Kidding! ...It's two.")


# ---------------------------------------------------------------- props

func _yaw_to(from: Vector3, to: Vector3) -> float:
	return atan2(-(to.x - from.x), -(to.z - from.z))


func _part(parent: Node3D, pos: Vector3, size: Vector3, mat: Material, rot := Vector3.ZERO) -> MeshInstance3D:
	var b := BoxMesh.new()
	b.size = size
	return deco(b, mat, pos, rot, Vector3.ONE, parent)


func _panel(pos: Vector3, yaw := 0.0) -> void:
	_panels.append(Transform3D(Basis(Vector3.UP, yaw), pos))


## A ceiling panel with a real light under it. Flickering ones get their own
## material so the panel dims along with the light.
func _lamp(pos: Vector3, reach := 14.0, energy := 1.6, flicker := false, yaw := 0.0) -> OmniLight3D:
	var l := omni(pos - Vector3(0, 0.7, 0), LAMP, reach, energy)
	if flicker:
		var m := StandardMaterial3D.new()
		m.albedo_color = LAMP
		m.emission_enabled = true
		m.emission = LAMP
		m.emission_energy_multiplier = 3.0
		deco_box(pos, Vector3(1.2, 0.06, 2.4), m, Vector3(0, yaw, 0))
		_flickers.append([l, m, energy, _rng.randf() * 6.0])
	else:
		_panel(pos, yaw)
	return l


func _poster(text: String, pos: Vector3, yaw: float, bg: Color, fg: Color, w := 2.2, h := 2.6, size := 56) -> MeshInstance3D:
	var fwd := Vector3(-sin(yaw), 0, -cos(yaw))
	var board := deco_box(pos, Vector3(w, h, 0.05), Mats.solid(bg, 0.8), Vector3(0, yaw, 0))
	deco_box(pos - fwd * 0.012, Vector3(w + 0.12, h + 0.12, 0.03), _dark, Vector3(0, yaw, 0))
	var l := sign_text(text, Vector3.ZERO, 0.0, size, fg)
	l.reparent(board, false)
	l.position = Vector3(0, 0, -0.03)
	return board


func _serving_display(pos: Vector3, yaw: float, text: String, hang := true) -> void:
	var fwd := Vector3(-sin(yaw), 0, -cos(yaw))
	var right := Vector3(cos(yaw), 0, -sin(yaw))
	deco_box(pos, Vector3(4.6, 0.9, 0.3), _dark, Vector3(0, yaw, 0))
	sign_text(text, pos + fwd * 0.17, yaw, 40, Color(1.0, 0.18, 0.1), 2.0)
	if hang:
		var h := CEIL - pos.y - 0.45
		for s in [-1.0, 1.0]:
			deco_box(pos + right * s * 1.8 + Vector3(0, 0.45 + h * 0.5, 0), Vector3(0.04, h, 0.04), _metal)


func _dress_steve(n: Node3D) -> void:
	# A tiny tie. For business.
	var body: Node3D = n.puppet.body
	var tie := Mats.toon(Color(0.75, 0.1, 0.12))
	_part(body, Vector3(0, 1.3, -0.09), Vector3(0.14, 0.1, 0.05), tie)
	_part(body, Vector3(0, 1.06, -0.09), Vector3(0.11, 0.42, 0.04), tie)
	_part(body, Vector3(0, 0.85, -0.09), Vector3(0.11, 0.11, 0.04), tie, Vector3(0, 0, PI / 4))


func _ticket_machine(pos: Vector3) -> void:
	var red := Mats.solid(Color(0.8, 0.12, 0.1), 0.4)
	deco_cyl(pos + Vector3(0, 0.55, 0), 0.06, 1.1, _metal)
	deco_box(pos + Vector3(0, 1.25, 0), Vector3(0.45, 0.42, 0.35), red)
	deco_box(pos + Vector3(0, 1.08, 0.19), Vector3(0.1, 0.18, 0.01), Mats.solid(Color(0.95, 0.95, 0.9)), Vector3(0.2, 0, 0))
	var l := sign_text("TAKE A\nNUMBER", pos + Vector3(0, 1.3, 0.18), PI, 18, Color.WHITE)
	l.pixel_size = 0.006


func _cooler(pos: Vector3) -> void:
	box(pos + Vector3(0, 0.55, 0), Vector3(0.6, 1.1, 0.6), Mats.solid(Color(0.88, 0.88, 0.85), 0.4))
	deco_cyl(pos + Vector3(0, 1.48, 0), 0.28, 0.75, Mats.glass(Color(0.4, 0.7, 1.0), 0.55))
	deco_box(pos + Vector3(0.12, 0.85, -0.31), Vector3(0.08, 0.08, 0.06), Mats.solid(Color(0.2, 0.4, 0.9)))
	deco_box(pos + Vector3(-0.12, 0.85, -0.31), Vector3(0.08, 0.08, 0.06), Mats.solid(Color(0.9, 0.2, 0.2)))


func _plant(pos: Vector3) -> void:
	cylinder(pos + Vector3(0, 0.35, 0), 0.32, 0.7, Mats.solid(Color(0.6, 0.35, 0.22), 0.8), 12, 0.4)
	var leaf := Mats.solid(Color(0.3, 0.5, 0.22), 0.8)
	for i in 4:
		var a := i * TAU / 4.0 + _rng.randf()
		deco_ball(pos + Vector3(cos(a) * 0.2, 1.0 + i * 0.12, sin(a) * 0.2), 0.3, leaf, Vector3(1, 1.5, 1))


func _chair(pos: Vector3, yaw: float) -> void:
	var fwd := Vector3(-sin(yaw), 0, -cos(yaw))
	var fab := Mats.solid(Color(0.2, 0.22, 0.28), 0.8)
	deco_box(pos + Vector3(0, 0.48, 0), Vector3(0.55, 0.08, 0.55), fab, Vector3(0, yaw, 0))
	deco_box(pos - fwd * 0.27 + Vector3(0, 0.85, 0), Vector3(0.55, 0.6, 0.08), fab, Vector3(0, yaw, 0))
	deco_cyl(pos + Vector3(0, 0.24, 0), 0.04, 0.44, _metal)
	deco_cyl(pos + Vector3(0, 0.03, 0), 0.3, 0.05, _dark)


func _filing_tower(pos: Vector3, h: float) -> void:
	box(pos + Vector3(0, h * 0.5, 0), Vector3(1.6, h, 1.2), _beige)
	var drawers := int(h / 0.75)
	for i in drawers:
		var y := 0.4 + i * (h - 0.1) / drawers
		deco_box(pos + Vector3(-0.81, y, 0), Vector3(0.03, 0.6, 1.0), _trim)
		deco_box(pos + Vector3(-0.84, y + 0.1, 0), Vector3(0.05, 0.06, 0.35), _metal)


## A desk with a chunky CRT, keyboard and chair. `side` is the direction
## the cell opens toward (+1: +Z).
func _desk_set(pos: Vector3, side: float) -> void:
	var yaw := PI if side > 0.0 else 0.0
	box(pos + Vector3(0, 0.38, side * 0.55), Vector3(1.6, 0.76, 0.8), _desk)
	deco_box(pos + Vector3(-0.2, 1.0, side * 0.45), Vector3(0.56, 0.48, 0.5), _beige)
	deco_box(pos + Vector3(-0.2, 1.02, side * 0.71), Vector3(0.44, 0.34, 0.02), _screens[_rng.randi() % 3])
	deco_box(pos + Vector3(-0.2, 0.775, side * 0.82), Vector3(0.5, 0.03, 0.16), _beige)
	if _rng.randf() < 0.5:
		_ream_pile(pos + Vector3(0.5, 0.76, side * 0.5), 0.4, _rng.randi_range(2, 6))
	_chair(pos + Vector3(-0.2, 0, side * 1.55), yaw)


func _cubicle(bank: Vector3, side: float) -> void:
	var roll := _rng.randf()
	if roll < 0.65:
		_desk_set(bank, side)
	elif roll < 0.82:
		var p := bank + Vector3(_rng.randf_range(-0.8, 0.8), 0, side * 0.5)
		box(p + Vector3(0, 0.65, 0), Vector3(0.8, 1.3, 0.7), _beige)
		for i in 3:
			deco_box(p + Vector3(0, 0.25 + i * 0.4, side * 0.36), Vector3(0.7, 0.34, 0.02), _trim)
		_plant(bank + Vector3(1.2, 0, side * 1.6))
	else:
		_ream_column(bank + Vector3(_rng.randf_range(-0.6, 0.6), 0, side * 1.0), 0.9, _rng.randf_range(0.9, 1.8), 0.0)


## A stack of paper reams with a solid collision box, top at `top`.
func _ream_column(pos: Vector3, size: float, top: float, bottom: float, solid := true) -> void:
	if solid:
		var body := StaticBody3D.new()
		body.position = Vector3(pos.x, (top + bottom) * 0.5, pos.z)
		var cs := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = Vector3(size, top - bottom, size)
		cs.shape = shape
		body.add_child(cs)
		add_child(body)
	var y := top
	var i := 0
	while y > bottom + 0.01:
		var h := minf(0.45, y - bottom)
		var j := 0.0 if i == 0 else 0.06
		var off := Vector3(_rng.randf_range(-j, j), 0, _rng.randf_range(-j, j))
		var b := Basis(Vector3.UP, _rng.randf_range(-j, j) * 1.5) * Basis.from_scale(Vector3(size, h, size))
		_reams.append(Transform3D(b, Vector3(pos.x, y - h * 0.5, pos.z) + off))
		_ream_colors.append(_ream_color())
		y -= h
		i += 1


## Loose reams piled on a desk, no collision.
func _ream_pile(pos: Vector3, size: float, count: int) -> void:
	for i in count:
		var b := Basis(Vector3.UP, _rng.randf_range(-0.3, 0.3)) * Basis.from_scale(Vector3(size, 0.12, size * 1.3))
		_reams.append(Transform3D(b, pos + Vector3(_rng.randf_range(-0.04, 0.04), 0.06 + i * 0.12, 0)))
		_ream_colors.append(_ream_color())


func _ream_color() -> Color:
	var r := _rng.randf()
	if r < 0.08:
		return Color(1.0, 0.75, 0.75)
	if r < 0.16:
		return Color(0.7, 0.85, 1.0)
	if r < 0.24:
		return Color(1.0, 0.95, 0.6)
	var w := _rng.randf_range(0.82, 0.97)
	return Color(w, w * 0.99, w * 0.93)


func _scatter_sheets() -> void:
	for i in 260:
		var p := Vector3(_rng.randf_range(-15.5, 23.5), PAPER_FLOOR + 0.02, _rng.randf_range(-150.5, -101))
		var b := Basis(Vector3.UP, _rng.randf() * TAU) * Basis(Vector3.RIGHT, _rng.randf_range(-0.2, 0.2))
		_sheets.append(Transform3D(b, p))
	for i in 90:
		var p := Vector3(_rng.randf_range(-12.5, 12.5), 0.008, _rng.randf_range(-99, -2))
		if absf(p.x) < 2.8 and p.z < -61.0 and p.z > -91.0:
			continue
		_sheets.append(Transform3D(Basis(Vector3.UP, _rng.randf() * TAU), p))


func _multimesh(mesh: Mesh, mat: Material, xforms: Array[Transform3D], colors: Array = []) -> MultiMeshInstance3D:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = not colors.is_empty()
	mm.mesh = mesh
	mm.instance_count = xforms.size()
	for i in xforms.size():
		mm.set_instance_transform(i, xforms[i])
		if mm.use_colors:
			mm.set_instance_color(i, colors[i])
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	mmi.material_override = mat
	add_child(mmi)
	return mmi


## A sliding filing cabinet platform with drawers on two faces.
func _cabinet(pos: Vector3, travel: Vector3, period: float, phase: float) -> void:
	var m := mover(Vector3(2.4, 2.0, 2.4), _beige, pos, travel, period, phase)
	for i in 3:
		var y := 0.62 - i * 0.62
		_part(m, Vector3(0, y, 1.21), Vector3(2.1, 0.52, 0.04), _trim)
		_part(m, Vector3(0, y + 0.1, 1.25), Vector3(0.5, 0.07, 0.07), _metal)
		_part(m, Vector3(-1.21, y, 0), Vector3(0.04, 0.52, 2.1), _trim)
		_part(m, Vector3(-1.25, y + 0.1, 0), Vector3(0.07, 0.07, 0.5), _metal)
		_part(m, Vector3(0.5, y - 0.1, 1.24), Vector3(0.4, 0.14, 0.02), Mats.solid(Color(0.95, 0.93, 0.85)))


func _stamp(z: float, phase: float) -> void:
	var h := hazard_box(Vector3(0, STAMP_Y, z), Vector3(4.6, 1.2, 2.4), Mats.glow(Color(0.85, 0.12, 0.08), 0.35), 0.0, Vector3(0, -STAMP_DROP, 0), 0.5, phase)
	_part(h, Vector3(0, -0.66, 0), Vector3(4.4, 0.12, 2.2), Mats.solid(Color(0.35, 0.02, 0.05), 0.9))
	_part(h, Vector3(0, 0.7, 0), Vector3(3.8, 0.2, 1.8), _wood)
	deco_cyl(Vector3(0, 1.9, 0), 0.35, 2.6, _wood).reparent(h, false)
	for s in [-1.0, 1.0]:
		var l := sign_text("APPROVED", Vector3.ZERO, 0.0 if s < 0.0 else PI, 80, Color(1.0, 0.92, 0.85), 0.3)
		l.reparent(h, false)
		l.position = Vector3(0, 0, s * 1.22)
	deco_cyl(Vector3(0, 6.15, z), 0.2, 3.7, _metal)
	deco_box(Vector3(0, 7.8, z), Vector3(1.4, 0.4, 1.4), _dark)
	_stamps.append(h)
	_stamp_low.append(false)


func _set_doors(open_k: float) -> void:
	if _door_tween:
		_door_tween.kill()
	for i in _doors.size():
		_doors[i].position.x = (-1.0 if i == 0 else 1.0) * (0.6 + 1.2 * open_k)


func _slide_doors(open: bool, dur: float) -> void:
	if _door_tween:
		_door_tween.kill()
	_door_tween = create_tween().set_parallel().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	for i in _doors.size():
		var s := -1.0 if i == 0 else 1.0
		_door_tween.tween_property(_doors[i], "position:x", s * (1.8 if open else 0.6), dur)


func _ding() -> void:
	Audio.play("ui_ok", 2.0, 0.0)
	_ding_mat.emission_energy_multiplier = 4.0
	get_tree().create_timer(0.3).timeout.connect(func(): Audio.play("ui_ok", 1.6, 0.0))


# ---------------------------------------------------------------- animation

func _process(delta: float) -> void:
	_t += delta
	for f in _flickers:
		var k := 1.0 if _flicker_on(f[3]) else 0.06
		f[0].light_energy = f[2] * k
		f[1].emission_energy_multiplier = 3.0 * k
	if _belt_mat:
		_belt_mat.uv1_offset.x = fposmod(_belt_mat.uv1_offset.x - BELT_SPEED * 0.25 * delta, 1.0)
	for f in _forms:
		f.position.z -= BELT_SPEED * delta
		if f.position.z < -89.6:
			f.position.z += 27.2
	for i in _stamps.size():
		var low := _stamps[i].position.y < STAMP_Y - STAMP_DROP * 0.92
		if low and not _stamp_low[i]:
			_slam(_stamps[i])
		_stamp_low[i] = low


## Mostly on, with a stuttering flicker every few seconds.
func _flicker_on(off: float) -> bool:
	if fmod(_t + off, 6.5) < 5.0:
		return true
	return sin(_t * 47.0 + off * 3.0) + sin(_t * 23.0 + off) > 0.3


func _slam(s: Area3D) -> void:
	if player == null:
		return
	var d := s.global_position.distance_to(player.global_position)
	if d > 24.0:
		return
	Audio.play("stomp", 0.55, 0.06, -3.0 - d * 0.6)
	Fx.burst(self, s.global_position - Vector3(0, 0.5, 0), Color(1, 1, 1, 0.9), 10, 4.0, 0.2, 0.5, -6.0)
	if d < 8.0 and not is_cinematic():
		rig.shake(0.12)


# ---------------------------------------------------------------- story

func intro() -> void:
	director.begin()
	Game.fx.set_black(true)
	_set_doors(0.0)
	player.place(Vector3(0, 0.05, 3.4), 0.0)
	director.actors["steve"] = _steve.puppet

	# Fade in on closed elevator doors. Muzak. Fluorescent hum.
	director.shot(Vector3(0, 1.75, -7.0), Vector3(0, 1.7, 1.0), 38.0)
	Game.fx.fade_in(1.6)
	director.move(Vector3(0, 1.65, -4.6), Vector3(0, 1.6, 1.0), 5.0, 36.0)
	await director.wait(2.2)
	_ding()
	player.model.emote = "cool"
	await director.wait(0.5)
	_slide_doors(true, 1.3)
	await director.wait(1.4)
	await director.say("stax", "Floor nine thousand? That elevator had one button, and it just said 'MAYBE'.", "shrug")
	await director.settle()

	# Stax steps out; the doors close behind him.
	player.model.emote = ""
	director.shot(Vector3(2.8, 0.8, -4.4), Vector3(0, 1.2, 0.8), 44.0)
	await director.walk(Vector3(0, 0, -2.4), 3.0, 0.32)
	_slide_doors(false, 1.0)
	director.face(Vector3(0, 0, 4))
	await director.wait(1.0)
	Audio.play("clang", 0.8, 0.02, -6.0)
	await director.say("stax", "And there goes my ride. Cool. Cool cool cool.", "facepalm")
	director.face(Vector3(0, 0, -30))

	# The office goes on forever.
	director.shot(Vector3(0.6, 2.0, -3.8), Vector3(0, 1.9, -60), 50.0)
	director.move(Vector3(0.2, 2.8, -22.0), Vector3(0, 2.2, -70), 8.0, 46.0, "linear")
	await director.wait(1.0)
	await director.title(info.chapter, info.title, info.subtitle)
	await director.settle()
	director.shot(Vector3(-14.2, 1.6, -12.5), Vector3(-60, 1.6, -12.5), 42.0)
	director.move(Vector3(-24, 1.8, -12.3), Vector3(-60, 1.5, -12.5), 5.0)
	await director.say("stax", "Why does this hallway just keep going? Who's paying the electric bill?!", "shocked")
	await director.settle()

	# Steve is already here. Obviously.
	var a := player.global_position
	var b := _steve.global_position
	var dir := (b - a).normalized()
	var side := Vector3(-dir.z, 0, dir.x)
	var mid := (a + b) * 0.5 + Vector3(0, 1.3, 0)
	director.face(b)
	_steve.face_toward(a)
	director.shot(mid - side * 6.5 + Vector3(0, 0.5, 0), mid, 42.0)
	director.move(mid - side * 5.6 + Vector3(0, 0.4, 0), mid, 5.0)
	await director.lines([
		["steve", "Welcome to the Infinite Tax Office! Please take a number."],
		["stax", "Steve?! How are you here? You're a sign. You don't even have legs.", "shocked"],
		["steve", "I have a post. A post is basically one very committed leg."],
	])
	director.shot(a - dir * 1.6 - side * 0.7 + Vector3(0, 1.75, 0), b + Vector3(0, 1.7, 0), 34.0)
	await director.lines([
		["stax", "Okay. Where's the Golden Vault Key?", "point"],
		["steve", "Upstairs, somewhere. But first: they're now serving number three."],
	])
	director.shot(b + dir * 1.8 + side * 0.8 + Vector3(0, 1.5, 0), a + Vector3(0, 1.2, 0), 34.0)
	await director.lines([
		["stax", "My ticket says nine million and four.", "facepalm"],
		["steve", "Then hurry! I'll even waive the waiting fee. Mostly."],
		["stax", "There's a WAITING fee?!", "shocked"],
	])
	director.shot(mid - side * 5.0 + Vector3(0, 0.6, 0), mid, 44.0)
	await director.lines([
		["steve", "Tiny. Practically decorative. Now go! Time is money!"],
		["stax", "Finally. A language I speak.", "cool"],
	])
	_set_doors(0.0)
	player.place(spawn_point, spawn_yaw)
	director.end()
	bark("steve", "Talk to me with F for tips! First one's free. Second one's also free. Ish.")


func outro_lines() -> Array:
	return [
		["stax", "Vault Key number three! Department of Keys: five stars. Would get stamped again.", "cheer"],
		["steve", "Great work! Next stop: the Lost Sock Nebula. Pack a spare. Trust me on this one."],
		["stax", "Space. Full of socks. Sure. Why not.", "shrug"],
	]
