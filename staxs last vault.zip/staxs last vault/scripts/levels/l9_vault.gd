extends "res://scripts/world/level_base.gd"
## Finale: The Last Vault. Stax opens the Vault with all eight keys and
## finally faces Baron Von Bankrupt... for about four seconds. Then the real
## villain drops in: Signpost Steve, the helpful tutorial sign, giant-sized.

const BossScript := preload("res://scripts/actors/boss_steve.gd")

const C := Vector3(0, 0, -14)        # arena center
const DOOR := Vector3(0, 8.5, 9.4)   # vault door center
const THRONE := Vector3(0, 0, -30)

var boss: Node3D
var _door: Node3D
var _door_body: StaticBody3D
var _keyholes: Array[MeshInstance3D] = []
var _baron: Node3D
var _fountain: GPUParticles3D
var _told_pound := false


func _init() -> void:
	music = "vault"
	spawn_point = Vector3(0, 0.2, 2)
	spawn_yaw = 0.0
	kill_y = -20.0


func env_config() -> Dictionary:
	return {
		"top": Color(0.08, 0.04, 0.02), "horizon": Color(0.55, 0.32, 0.08), "bottom": Color(0.05, 0.03, 0.02),
		"sun_color": Color(1.0, 0.75, 0.4), "sun_energy": 0.9, "sun_angle": Vector2(-70, 20),
		"sun_size": 0.0, "sun_glow": 0.2, "stars": 0.6, "nebula": 0.35,
		"nebula_a": Color(0.9, 0.55, 0.1), "nebula_b": Color(0.6, 0.15, 0.1),
		"fog_color": Color(0.5, 0.3, 0.1), "fog_density": 0.006, "volumetric": 0.02,
		"vol_color": Color(1.0, 0.8, 0.5), "ambient": 0.6, "exposure": 1.05, "glow": 1.1,
		"tint": Color(1.04, 0.98, 0.9), "saturation": 1.12, "ssr": true, "vignette": 0.45, "player_light": 0.7,
	}


# ---------------------------------------------------------------- build

func build() -> void:
	var marble := Mats.rough_surface(Color(0.35, 0.08, 0.06), Color(0.18, 0.04, 0.04), 0.15, 0.35, 41, 0.4)
	var floor_mat := Mats.pattern("tiles", [Color(0.42, 0.3, 0.12), Color(0.16, 0.1, 0.05)], 0.25, 0.25)
	floor_mat.metallic = 0.5

	# Approach: a platform and a bridge to the vault door, floating in the void.
	box(Vector3(0, -0.5, 34), Vector3(10, 1, 10), floor_mat)
	box(Vector3(0, -0.5, 19), Vector3(5, 1, 20), floor_mat)
	for z in [14.0, 22.0, 30.0]:
		for x in [-2.8, 2.8]:
			deco_cyl(Vector3(x, 1.0, z), 0.15, 2.0, Mats.gold())
			deco_ball(Vector3(x, 2.2, z), 0.3, Mats.glow(Color(1.0, 0.8, 0.4), 3.0))
	omni(Vector3(0, 3, 30), Color(1.0, 0.8, 0.5), 12.0, 1.5)

	# The arena floor and walls.
	cylinder(C - Vector3(0, 1, 0), 23.5, 2.0, floor_mat, 64)
	deco_cyl(C + Vector3(0, 0.01, 0), 6.0, 0.02, Mats.glow(Color(0.9, 0.6, 0.15), 0.8))
	deco_cyl(C + Vector3(0, 0.02, 0), 5.5, 0.02, floor_mat)
	var segs := 40
	for i in segs:
		var a := TAU * i / segs
		var p := C + Vector3(sin(a), 0, cos(a)) * 23.5
		# Leave a gap where the door is (+Z side).
		if absf(wrapf(a, -PI, PI)) < 0.42:
			continue
		var wall := box(p + Vector3(0, 3, 0), Vector3(3.8, 6, 1.2), marble)
		wall.rotation.y = a
		if i % 4 == 0:
			cylinder(p + Vector3(0, 5, 0), 0.9, 10.0, Mats.gold(), 16)
			deco_ball(p + Vector3(0, 10.4, 0), 0.6, Mats.glow(Color(1.0, 0.75, 0.3), 3.0))
	# Door frame.
	var frame := MeshInstance3D.new()
	var tor := TorusMesh.new()
	tor.inner_radius = 8.6
	tor.outer_radius = 10.4
	tor.rings = 48
	tor.ring_segments = 12
	frame.mesh = tor
	frame.material_override = Mats.gold()
	frame.position = DOOR
	frame.rotation.x = PI / 2
	add_child(frame)
	box(Vector3(-9.5, 5, 9.4), Vector3(3, 10, 1.4), marble)
	box(Vector3(9.5, 5, 9.4), Vector3(3, 10, 1.4), marble)
	_build_door()

	# Treasure: mountains of coins beyond the walls, dollar statues, light shafts.
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	# A bed of gold under the whole hoard, so the loose coins have something to lie on.
	deco_cyl(C + Vector3(0, -0.7, 0), 64.0, 0.6, Mats.gold())
	var piles: Array[Vector4] = []   # xyz = center, w = radius
	for i in 14:
		var a := TAU * i / 14.0 + 0.2
		var d := rng.randf_range(32.0, 44.0)
		var r := rng.randf_range(8.0, 14.0)
		var pc := C + Vector3(sin(a) * d, -r * 0.35, cos(a) * d)
		piles.append(Vector4(pc.x, pc.y, pc.z, r))
		deco_ball(pc, r, Mats.gold(), Vector3(1, 0.7, 1))
	var coin_mesh := CylinderMesh.new()
	coin_mesh.top_radius = 0.5
	coin_mesh.bottom_radius = 0.5
	coin_mesh.height = 0.12
	coin_mesh.radial_segments = 12
	coin_mesh.material = Mats.gold()
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = coin_mesh
	mm.instance_count = 1400
	for i in mm.instance_count:
		var a := rng.randf() * TAU
		var d := rng.randf_range(25.5, 58.0)
		var p := C + Vector3(sin(a) * d, 0, cos(a) * d)
		p.y = _hoard_height(p, piles) + rng.randf_range(0.04, 0.12)
		# Lying (nearly) flat on the pile, the odd one propped on its edge.
		var tilt := rng.randf_range(-0.35, 0.35) if rng.randf() > 0.08 else 1.2
		var basis := Basis.from_euler(Vector3(tilt, rng.randf() * TAU, rng.randf_range(-0.35, 0.35)))
		mm.set_instance_transform(i, Transform3D(basis, p))
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	add_child(mmi)
	for i in 4:
		var a := TAU * i / 4.0 + PI / 4
		dollar(C + Vector3(sin(a) * 38, 14, cos(a) * 38), a, 12.0, Mats.glow(Color(1.0, 0.7, 0.2), 1.6), 0.2)
	for i in 5:
		var a := TAU * i / 5.0
		spot(C + Vector3(sin(a) * 10, 40, cos(a) * 10), C + Vector3(sin(a) * 4, 0, cos(a) * 4), Color(1.0, 0.85, 0.6), 60.0, 14.0, 6.0)
	omni(C + Vector3(0, 12, 0), Color(1.0, 0.75, 0.4), 30.0, 1.2)

	# The Baron's throne.
	for i in 3:
		deco_ball(THRONE + Vector3(0, -0.5 + i * 0.9, -2.0 - i * 0.6), 3.4 - i * 0.8, Mats.gold(), Vector3(1.3, 0.6, 1.0))
	_baron = Puppet.new()
	_baron.kind = "baron"
	_baron.speaker = "baron"
	_baron.position = THRONE
	_baron.scale = Vector3.ONE * 1.4
	add_child(_baron)

	boss = BossScript.new()
	boss.level = self
	boss.position = THRONE + Vector3(0, 60, 0)
	boss.visible = false
	add_child(boss)
	boss.hit.connect(_on_boss_hit)
	boss.defeated.connect(_on_boss_defeated)

	Fx.ambient(self, C + Vector3(0, 8, 0), Vector3(26, 8, 26), Color(1.0, 0.8, 0.4, 0.6), 200, 0.1)
	# A few coins in the arena to heal with.
	coin_ring(C + Vector3(0, 1, 0), 12.0, 10)


## Height of the hoard's surface at p: the gold bed, or the top of whichever
## squashed-sphere pile is highest there.
func _hoard_height(p: Vector3, piles: Array[Vector4]) -> float:
	var h := -0.4
	for pile in piles:
		var r := pile.w
		var dx := p.x - pile.x
		var dz := p.z - pile.z
		var q := 1.0 - (dx * dx + dz * dz) / (r * r)
		if q > 0.0:
			h = maxf(h, pile.y + 0.7 * r * sqrt(q))
	return h


func _build_door() -> void:
	_door = Node3D.new()
	_door.position = DOOR
	add_child(_door)
	var steel := Mats.solid(Color(0.55, 0.5, 0.45), 0.3, 0.9)
	var disc := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 8.5
	cm.bottom_radius = 8.5
	cm.height = 1.6
	cm.radial_segments = 48
	disc.mesh = cm
	disc.material_override = steel
	disc.rotation.x = PI / 2
	_door.add_child(disc)
	var hub := MeshInstance3D.new()
	var hm := CylinderMesh.new()
	hm.top_radius = 2.2
	hm.bottom_radius = 2.2
	hm.height = 2.0
	hub.mesh = hm
	hub.material_override = Mats.gold()
	hub.rotation.x = PI / 2
	_door.add_child(hub)
	for i in 8:
		var spoke := MeshInstance3D.new()
		var sb := BoxMesh.new()
		sb.size = Vector3(0.5, 6.5, 0.4)
		spoke.mesh = sb
		spoke.material_override = Mats.gold()
		spoke.position = Vector3(0, 0, 0.9)
		spoke.rotation.z = TAU * i / 8.0
		_door.add_child(spoke)
	for i in 8:
		var a := TAU * i / 8.0
		var hole := MeshInstance3D.new()
		var hb := BoxMesh.new()
		hb.size = Vector3(0.8, 1.6, 0.3)
		hole.mesh = hb
		hole.material_override = Mats.solid(Color(0.05, 0.04, 0.03), 0.8)
		hole.position = Vector3(sin(a) * 5.2, cos(a) * 5.2, 0.85)
		_door.add_child(hole)
		_keyholes.append(hole)
	_door_body = StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = 8.5
	shape.height = 1.6
	cs.shape = shape
	cs.rotation.x = PI / 2
	_door_body.add_child(cs)
	_door.add_child(_door_body)


# ---------------------------------------------------------------- story

func intro() -> void:
	director.begin()
	Game.fx.set_black(true)
	player.place(Vector3(0, 0.2, 36), 0.0)

	# The door, floating at the edge of reality.
	director.shot(Vector3(14, 4, 44), DOOR, 50.0)
	Game.fx.fade_in(2.5)
	director.move(Vector3(5, 3, 28), DOOR, 7.0, 42.0)
	await director.walk(Vector3(0, 0, 15), 7.0, 0.45)
	await director.settle()
	var sp := player.global_position
	director.shot(sp + Vector3(-2.2, 1.6, -2.4), sp + Vector3(0, 1.4, 0), 36.0)
	await director.say("stax", "Eight keys. One door. Let's get my money back.", "cool")

	# The keys fly into the door one by one.
	director.shot(DOOR + Vector3(6, -3, 14), DOOR, 42.0)
	for i in 8:
		if director.skipping:
			break
		var key := _key_mesh()
		add_child(key)
		key.global_position = player.global_position + Vector3(0, 2, 0)
		var hole: MeshInstance3D = _keyholes[i]
		var t := create_tween()
		t.tween_property(key, "global_position", hole.global_position + Vector3(0, 0, 0.5), 0.5).set_trans(Tween.TRANS_CUBIC)
		t.tween_callback(func():
			Audio.play("clang", 1.0 + i * 0.12)
			hole.material_override = Mats.glow(Color(1.0, 0.8, 0.3), 4.0)
			key.queue_free())
		await director.wait(0.5)
	for hole in _keyholes:
		hole.material_override = Mats.glow(Color(1.0, 0.8, 0.3), 4.0)

	# It rolls open.
	Audio.play("rumble")
	director.shake(0.4)
	var spin := create_tween()
	spin.tween_property(_door, "rotation:z", -PI, 2.0).set_trans(Tween.TRANS_SINE)
	spin.tween_property(_door, "position:x", -19.0, 1.6).set_trans(Tween.TRANS_CUBIC)
	await director.wait(2.0)
	Audio.play("boom", 0.8)
	Game.fx.flash(Color(1.0, 0.85, 0.5), 1.0)
	await director.wait(1.6)
	_door.rotation.z = -PI
	_door.position.x = -19.0
	Audio.play_music("vault")

	# Inside: the hoard, and the Baron.
	director.shot(Vector3(0, 3, 12), C, 55.0)
	director.move(Vector3(8, 10, -4), THRONE + Vector3(0, 2, 0), 6.0, 40.0)
	player.place(Vector3(0, 0.2, 4), 0.0)
	await director.wait(2.5)
	director.actors["baron"] = _baron
	director.shot(THRONE + Vector3(3.5, 3.0, 7.0), THRONE + Vector3(0, 2.4, 0), 34.0)
	_baron.emote = "laugh"
	await director.say("baron", "Well, well, well. The boy with the dollar eyes. You actually made it.")
	_baron.emote = ""
	director.two_shot(player, _baron, 1.0, 50.0)
	await director.say("stax", "Hand over the coins, Baron. Especially my forty-seven dollars.", "point")
	await director.say("stax", "And the button. I want the button back.", "point")
	director.shot(THRONE + Vector3(-2.5, 1.6, 5.0), THRONE + Vector3(0, 2.6, 0), 30.0)
	_baron.emote = "point"
	await director.say("baron", "Never! Behold the final boss! The ultimate villain! The one and only Baron Von B-")

	# The real villain arrives. From above. On top of the Baron.
	Audio.play("whoosh", 0.5)
	boss.visible = true
	boss.global_position = THRONE + Vector3(0, 40, 0)
	boss.rotation.y = PI
	director.shot(THRONE + Vector3(10, 2, 14), THRONE + Vector3(0, 6, 0), 50.0)
	var drop := create_tween()
	drop.tween_property(boss, "global_position", THRONE, 0.45).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	await director.wait(0.45)
	boss.global_position = THRONE
	_baron.scale = Vector3(2.6, 0.12, 2.6)
	_baron.position.y = 0.05
	Audio.play("boom")
	Audio.play("hit_low")
	director.shake(0.9)
	Fx.burst(self, THRONE + Vector3(0, 0.5, 0), Color(1.0, 0.9, 0.7, 0.9), 50, 12.0, 0.8, 1.0, -3.0)
	Audio.stop_music(0.2)
	await director.wait(1.4)
	director.actors["steve"] = boss.puppet
	director.shot(THRONE + Vector3(0, 1.0, 16), THRONE + Vector3(0, 1, 0), 40.0)
	director.move(THRONE + Vector3(0, 4, 18), THRONE + Vector3(0, 8.5, 0), 3.0, 36.0)
	await director.say("steve_evil", "Surprise.")
	director.two_shot(player, boss, -1.0, 55.0)
	await director.say("stax", "...STEVE?!", "shocked")
	director.shot(THRONE + Vector3(-4, 7, 12), THRONE + Vector3(0, 8.5, 0), 38.0)
	await director.lines([
		["steve_evil", "Howdy, partner. Who do you think built the Vault? Who scattered the keys across eight dimensions? Who hired a pirate? Who hired a very old clock? Who hired a BABY?"],
		["steve_evil", "Every tip. Every convenience fee. It was all to get you here, to open that door. For ME."],
		["steve_evil", "The Baron? Hired help. Great mustache. Terrible at math."],
		["baron", "I'm okay... I'm a pancake now, but I'm okay..."],
	])
	director.two_shot(player, boss, 1.0, 50.0)
	await director.lines([
		["stax", "But you're a SIGN! Signs can't be villains!", "shocked"],
		["steve_evil", "That is EXACTLY what I wanted you to think."],
		["stax", "...Okay, that's actually kind of genius.", "facepalm"],
		["steve_evil", "Now here's one last tip, kid. Totally free of charge."],
	])
	director.shot(THRONE + Vector3(0, 5, 8), THRONE + Vector3(0, 8.5, 0), 30.0)
	boss.puppet.emote = "evil"
	await director.say("steve_evil", "RUN.")
	# The door slams shut behind Stax.
	_door.position.x = 0.0
	_door.rotation.z = 0.0
	Audio.play("boom", 0.7)
	director.shake(0.6)
	Audio.play_music("boss", 0.2)
	Audio.set_drums(1.0)
	director.shot(Vector3(0, 14, 16), C, 60.0)
	director.move(Vector3(0, 6, 12), C + Vector3(0, 3, 0), 3.5)
	await director.title("FINAL BOSS", "Signpost Steve", "He was helpful. Too helpful.", 1.8)
	await director.settle()
	boss.puppet.emote = ""
	player.place(spawn_point, spawn_yaw)
	director.end()


func _start_play() -> void:
	super()
	boss.player = player
	boss.global_position = THRONE
	boss.visible = true
	hud.show_boss("SIGNPOST STEVE", boss.MAX_HP)
	boss.start()
	player.died.connect(_restart_fight)
	bark("stax", "Jump the shockwaves! When he falls over... ground pound him!")


## Dying restarts the fight: Steve is back to full health.
func _restart_fight() -> void:
	if complete or boss.state == boss.B.DEAD:
		return
	boss.reset(THRONE)
	hud.set_boss_hp(boss.MAX_HP)
	await get_tree().create_timer(1.2).timeout
	bark("steve_evil", "Back for more? The fight starts over. No refunds!")


func on_boss_fallen() -> void:
	if not _told_pound:
		_told_pound = true
		bark("stax", "He's down! Jump on his back and ground pound (crouch in mid-air)!")


func _on_boss_hit(hp: int) -> void:
	hud.set_boss_hp(hp)
	if hp == 3:
		Audio.set_drums(1.0)
		bark("steve_evil", "Fine! No more Mister Nice Sign!")
	elif hp == 1:
		bark("steve_evil", "Okay, NOW I'm annoyed. Arrow storm!")


func _on_boss_defeated() -> void:
	boss_beaten()
	if complete:
		return
	complete = true
	hud.hide_boss()
	await get_tree().create_timer(0.8).timeout
	await _ending()
	Game.complete_level(player.coins)


func _ending() -> void:
	director.begin()
	Audio.stop_music(1.0)
	player.velocity = Vector3.ZERO
	var bp: Vector3 = boss.global_position
	director.actors["steve"] = boss.puppet
	director.shot(bp + Vector3(8, 6, 14), bp + Vector3(0, 5, 0), 45.0)
	Audio.play("whoosh", 0.4)
	boss.shrink(2.4)
	await director.wait(2.4)
	player.place(bp + Vector3(0, 0.2, 4.5), 0.0)
	director.face(bp)
	director.two_shot(player, boss, 1.0, 38.0)
	await director.lines([
		["steve", "Okay! Okay! Truce! You win! Ow. Splinters everywhere."],
		["stax", "Give everyone their coins back, Steve.", "point"],
		["steve", "Fine. Fine! The Vault releases on voice command. Ahem."],
		["steve", "Vault? Open all the accounts. Refund everyone. No fees."],
	])
	# The hoard erupts back to the world.
	Audio.play("rumble")
	Audio.play("fanfare")
	Audio.play_music("credits", 0.5)
	director.shake(0.5)
	_start_fountain()
	director.shot(C + Vector3(0, 4, 20), C + Vector3(0, 14, -10), 60.0)
	director.move(C + Vector3(0, 2, 12), C + Vector3(0, 30, -20), 6.0, 55.0)
	await director.say("news", "Breaking news! Coins are raining from the sky all over Goldhaven!")
	await director.say("news", "Every coin, returned. And sources say a local kid in money glasses is responsible.")
	await director.settle()
	# The button.
	var button := _button_mesh()
	add_child(button)
	button.global_position = player.global_position + Vector3(0, 6, -1.2).rotated(Vector3.UP, player.facing)
	create_tween().tween_property(button, "global_position", player.global_position + Vector3(0, 0.1, -1.2).rotated(Vector3.UP, player.facing), 1.2).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	var sp := player.global_position
	director.shot(sp + Vector3(0, 1.0, -3.2).rotated(Vector3.UP, player.facing), sp + Vector3(0, 0.8, 0), 34.0)
	await director.wait(1.2)
	Audio.play("coin")
	await director.say("stax", "Forty-seven dollars. And the button.", "cheer")
	_baron.scale = Vector3.ONE * 1.4
	_baron.position.y = 0.0
	director.actors["baron"] = _baron
	director.shot(THRONE + Vector3(3, 2, 7), THRONE + Vector3(0, 2, 0), 38.0)
	await director.lines([
		["baron", "So... does this mean I'm not the villain anymore?"],
		["stax", "You owe the whole city an apology. And your mustache owes me one too.", "point"],
	])
	director.two_shot(player, boss, 1.0, 40.0)
	await director.lines([
		["steve", "Hey, kid. Want one last tip? The real treasure was the friends we made along the—"],
		["stax", "Don't.", "facepalm"],
		["steve", "...The coins. The real treasure was the coins."],
		["stax", "Yeah. Okay. That's fair.", "shrug"],
		["steve", "So... sequel?"],
		["stax", "Don't push it, Steve.", "cool"],
	])
	director.orbit(sp + Vector3(0, 1.2, 0), 6.0, 1.5, player.facing + PI / 2, player.facing + PI / 2 + 1.2, 5.0)
	player.model.emote = "dance"
	await director.title("", "THE END", "Thanks for playing", 2.0)
	await Game.fx.fade_out(1.5)
	director.end()


func _start_fountain() -> void:
	_fountain = GPUParticles3D.new()
	_fountain.amount = 300
	_fountain.lifetime = 4.0
	_fountain.visibility_aabb = AABB(Vector3(-60, -10, -60), Vector3(120, 80, 120))
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	pm.emission_sphere_radius = 30.0
	pm.direction = Vector3.UP
	pm.spread = 25.0
	pm.initial_velocity_min = 18.0
	pm.initial_velocity_max = 30.0
	pm.gravity = Vector3(0, -12, 0)
	pm.angular_velocity_min = -400
	pm.angular_velocity_max = 400
	pm.particle_flag_rotate_y = true
	_fountain.process_material = pm
	var cm := CylinderMesh.new()
	cm.top_radius = 0.35
	cm.bottom_radius = 0.35
	cm.height = 0.08
	cm.radial_segments = 10
	cm.material = Mats.gold()
	_fountain.draw_pass_1 = cm
	_fountain.position = C
	add_child(_fountain)


func _key_mesh() -> Node3D:
	var k := Node3D.new()
	var ring := MeshInstance3D.new()
	var tor := TorusMesh.new()
	tor.inner_radius = 0.2
	tor.outer_radius = 0.36
	ring.mesh = tor
	ring.material_override = Mats.gold()
	ring.rotation.x = PI / 2
	ring.position.y = 0.5
	k.add_child(ring)
	var shaft := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = Vector3(0.14, 1.0, 0.12)
	shaft.mesh = b
	shaft.material_override = Mats.gold()
	shaft.position.y = -0.1
	k.add_child(shaft)
	return k


func _button_mesh() -> Node3D:
	var root := Node3D.new()
	var disc := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.22
	cm.bottom_radius = 0.22
	cm.height = 0.06
	disc.mesh = cm
	disc.material_override = Mats.toon(Color(0.2, 0.5, 0.9))
	root.add_child(disc)
	for i in 4:
		var hole := MeshInstance3D.new()
		var hm := CylinderMesh.new()
		hm.top_radius = 0.03
		hm.bottom_radius = 0.03
		hm.height = 0.07
		hole.mesh = hm
		hole.material_override = Mats.solid(Color(0.05, 0.1, 0.2))
		hole.position = Vector3(0.06 * (1 if i % 2 == 0 else -1), 0, 0.06 * (1 if i < 2 else -1))
		root.add_child(hole)
	return root


## Used by tests/level_smoke.gd: beats the boss (the test then waits for
## the ending to hand over to the credits).
func test_hook(tree: SceneTree) -> bool:
	for i in boss.MAX_HP:
		boss.take_hit()
		for n in 10:
			await tree.physics_frame
	return boss.hp <= 0
