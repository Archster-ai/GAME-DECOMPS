extends "res://scripts/world/level_base.gd"
## Chapter 10: The Page After The End. There is no chapter ten. Stax falls
## into the space where it would go: an unfinished grey-box world of
## placeholder models, platforms that only load when you get close, missing
## textures that blink in and out, a pause menu you can stand on and the
## credits rolling past as platforms.
## Route: spawn point -> loading platforms (ATM) -> missing textures -> the
## pause menu ("QUIT TO TITLE" is a trampoline) -> the credits climb (ATM) ->
## the last page, where THE END is waiting. At three letters left it rips the
## page into a slide, and the fight finishes at the bottom.
## 500 coins or more across the whole adventure unlocks the perfect ending.

const EndScript := preload("res://scripts/actors/boss_end.gd")

const ARENA := Vector3(0, 40, -154)      # centre of the page
const ARENA_R := 16.0
const PAGE_FRONT := Vector3(0, 40, -136) # the edge the page tilts around
const PAGE := 36.0
const TILT := 0.26
const SLIDE_LEN := 30.0
const SLIDE_SEGS := 4

var boss: Node3D
## Where the key would be, if there were one, for tests/reachability.gd.
var reach_target := ARENA
var _steve: Node3D
var _grid: Material
var _paper: Material
var _missing: Material
var _loaders: Array = []      # {body, mesh, ghost, tag}
var _blinkers: Array = []     # {body, mesh, tag, phase}
var _page_pivot: Node3D
var _slide: Array = []        # {body, mesh}
var _slide_zones: Array[Area3D] = []
var _bottom := Vector3.ZERO
var _slide_end := Vector3.ZERO
var _fight_started := false
var _ripped := false
var _at_bottom := false
var _told_stuck := false
var _t := 0.0


func _init() -> void:
	music = "page"
	spawn_point = Vector3(0, 0.1, 3)
	spawn_yaw = 0.0
	kill_y = -60.0


func env_config() -> Dictionary:
	return {
		"top": Color(0.78, 0.78, 0.82), "horizon": Color(0.98, 0.98, 1.0), "bottom": Color(0.7, 0.7, 0.74),
		"sun_color": Color(1, 1, 1), "sun_energy": 1.25, "sun_angle": Vector2(-55, 30),
		"sun_size": 0.0, "sun_glow": 0.0,
		"fog_color": Color(0.95, 0.95, 0.97), "fog_density": 0.007, "volumetric": 0.0,
		"ambient": 1.1, "exposure": 1.0, "glow": 0.7,
		"tint": Color(1, 1, 1), "saturation": 0.95, "vignette": 0.3, "player_light": 0.3,
	}


# ---------------------------------------------------------------- props

func _box_mesh(size: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = size
	return b


## Collision that starts switched off (tests/reachability.gd still counts it).
func _hidden_body(pos: Vector3, size: Vector3, rot := Vector3.ZERO) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = pos
	body.rotation = rot
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	cs.shape = shape
	body.add_child(cs)
	body.collision_layer = 0
	body.set_meta("scripted", true)
	add_child(body)
	return body


## A platform that hasn't loaded yet: a see-through outline until Stax gets close.
func loader(top: Vector3, size: Vector3) -> void:
	var pos := top - Vector3(0, size.y * 0.5, 0)
	var body := _hidden_body(pos, size)
	var mesh := deco(_box_mesh(size), _grid, Vector3.ZERO, Vector3.ZERO, Vector3.ONE * 0.01, body)
	var ghost := deco(_box_mesh(size), Mats.unshaded(Color(0.3, 0.55, 1.0), 0.22), Vector3.ZERO, Vector3.ZERO, Vector3.ONE, body)
	var tag := sign_text("LOADING...", pos + Vector3(0, size.y * 0.5 + 1.2, 0), PI, 60, Color(0.2, 0.4, 1.0))
	tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_loaders.append({"body": body, "mesh": mesh, "ghost": ghost, "tag": tag})


## A platform with a missing texture: it blinks out of existence on a rhythm.
func blinker(top: Vector3, phase: float) -> void:
	var size := Vector3(4, 0.8, 4)
	var body := box(top - Vector3(0, 0.4, 0), size, _missing)
	var tag := sign_text("ERROR: platform.png\nnot found", top + Vector3(0, 1.6, 0), PI, 34, Color(1.0, 0.2, 0.8))
	tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_blinkers.append({"body": body, "mesh": body.get_child(0), "tag": tag, "phase": phase})


func debug_text(text: String, pos: Vector3, yaw := PI, size := 80) -> void:
	var l := sign_text(text, pos, yaw, size, Color(0.25, 0.25, 0.3))
	l.font = null
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED


# ---------------------------------------------------------------- build

func build() -> void:
	_grid = Mats.pattern("grid", [Color(0.66, 0.66, 0.7), Color(0.4, 0.4, 0.46)], 0.25, 0.9)
	_paper = Mats.pattern("stripes", [Color(0.99, 0.98, 0.95), Color(0.97, 0.96, 0.92)], 0.4, 0.95)
	_missing = Mats.pattern("checker", [Color(1.0, 0.0, 0.85), Color(0.05, 0.02, 0.05)], 0.5, 0.6)
	_build_void()

	# 1. The spawn point. Literally labelled.
	box(Vector3(0, -1, 0), Vector3(12, 2, 10), _grid)
	sign_text("SPAWN_POINT_01", Vector3(0, -1, 5.02), PI, 120, Color(0.2, 0.2, 0.25))
	coin_ring(Vector3(0, 1, -1), 2.5, 8)
	_steve = npc("placeholder", "steve", Vector3(3.4, 0, -2), 2.4, [
		["steve", "Hello! It's me, Steve! Well. It will be. My model hasn't loaded yet."],
		["stax", "Why are you a grey box?", "think"],
		["steve", "Why are YOU in chapter ten? Chapter ten doesn't exist! Nobody finished it!"],
		["steve", "Tip: the platforms load in when you walk up to them. Probably. I haven't tested it."],
		["steve", "Also: grab every coin you can. Five hundred across the whole adventure unlocks the perfect ending. I read the design doc."],
	], [["steve", "Coins, kid! Five hundred total for the perfect ending. The design doc is VERY clear. It's the only thing in it."]])
	npc("placeholder", "npc4", Vector3(-3.4, 0, -2), -2.4, [
		["npc4", "Hello. I am Unused NPC Number Four. I was cut from Chapter Three."],
		["npc4", "I have no lines. This is my line."],
		["stax", "...That's a pretty good line, actually.", "shrug"],
		["npc4", "Thank you. I have been rehearsing it for nine chapters."],
	], [["npc4", "I have no lines. (This is still my line.)"]])
	_build_shop()
	debug_text("TODO: add trees", Vector3(-9, 4, -6))
	debug_text("// don't look behind you", Vector3(10, 6, 4))

	# 2. Platforms that load in as you walk up.
	tip(Vector3(0, 1.5, -5), Vector3(12, 4, 2), "steve", "Walk up to the blue outlines. They'll load. Trust the engine!")
	var loads := [[0.0, 1.0, -9.0], [3.0, 2.5, -14.5], [-1.0, 4.0, -20.0], [3.0, 5.5, -25.5], [0.0, 7.0, -31.0]]
	for L in loads:
		loader(Vector3(L[0], L[1], L[2]), Vector3(4, 1, 4))
		coin(Vector3(L[0], L[1] + 1.2, L[2]))
	box(Vector3(0, 7, -39), Vector3(10, 2, 8), _grid)
	checkpoint(Vector3(-3, 8, -36.5), 0.0)
	enemy("placeholder", Vector3(-3.5, 8, -41), Vector3(3.5, 8, -41))
	coin(Vector3(3, 9.5, -37), 5)
	debug_text("FIXME: level too hard?? (it's fine)", Vector3(7, 12, -38))

	# 3. Missing textures that blink in and out.
	tip(Vector3(0, 9.5, -42), Vector3(10, 4, 2), "steve", "Missing textures! They blink. Jump when they're THERE. That's the whole tip.")
	for i in 5:
		var top := Vector3(2.0 if i % 2 == 0 else -2.0, 8, -47 - i * 5.5)
		blinker(top, i * 0.45)
		coin(top + Vector3(0, 1.2, 0))
	box(Vector3(0, 7, -76), Vector3(12, 2, 8), _grid)
	coin_line(Vector3(-4, 9, -76), Vector3(4, 9, -76), 5)

	# 4. The pause menu, as platforms.
	sign_text("PAUSED", Vector3(0, 16, -96), PI, 400, Color(1, 1, 1), 0.4)
	box(Vector3(0, 7.4, -86), Vector3(12, 1.2, 4), Mats.toon(Color(0.25, 0.25, 0.3)))
	sign_text("RESUME", Vector3(0, 7.4, -83.98), PI, 110, Color(1.0, 0.85, 0.3))
	var settings := mover(Vector3(8, 1.2, 4), Mats.toon(Color(0.25, 0.25, 0.3)), Vector3(-3, 7.4, -93), Vector3(6, 0, 0), 4.0)
	var st := sign_text("SETTINGS", Vector3.ZERO, PI, 110, Color(1, 1, 1))
	st.reparent(settings, false)
	st.position = Vector3(0, 0, 2.02)
	st.rotation.y = 2.0 * PI
	box(Vector3(0, 7.4, -100), Vector3(12, 1.2, 4), Mats.toon(Color(0.35, 0.12, 0.15)))
	sign_text("QUIT TO TITLE", Vector3(0, 7.4, -97.98), PI, 110, Color(1.0, 0.5, 0.5))
	var spring := Node3D.new()
	deco(_box_mesh(Vector3(4, 0.3, 2.4)), Mats.glow(Color(1.0, 0.4, 0.4), 1.5), Vector3(0, 0.15, 0), Vector3.ZERO, Vector3.ONE, spring)
	var q := bouncer(Vector3(0, 8, -100), 2.0, 28.0, spring)
	q.body_entered.connect(func(b): if b == player: hud.banner("ARE YOU SURE?  ·  NO.", 1.2, Color(1.0, 0.5, 0.5)))
	tip(Vector3(0, 9.5, -82), Vector3(12, 4, 2), "steve", "The pause menu! Don't press QUIT TO TITLE. Actually, do. It's a trampoline. Don't ask.")
	coin_line(Vector3(0, 9.5, -86), Vector3(0, 9.5, -93), 3)

	# 5. The credits, rolling up past you.
	sign_text("CREDITS", Vector3(-8, 30, -115), PI, 300, Color(0.2, 0.2, 0.25))
	var names := ["Stax  ·  as himself", "Signpost Steve  ·  as a sign", "Unused NPC #4  ·  as himself (cut)", "THE END  ·  as the end", "You  ·  for reading this"]
	var climb := [[0.0, 16.0, -106.0], [4.0, 21.0, -111.0], [-2.0, 26.0, -116.0], [2.0, 31.0, -121.0], [-1.0, 36.0, -126.0]]
	for i in climb.size():
		var c: Array = climb[i]
		var m := mover(Vector3(6, 0.8, 4), Mats.toon(Color(0.12, 0.12, 0.15)), Vector3(c[0], c[1], c[2]), Vector3(0, 4, 0), 5.0, i * 0.2)
		var nl := sign_text(names[i], Vector3.ZERO, PI, 56, Color(1, 1, 1))
		nl.reparent(m, false)
		nl.position = Vector3(0, 0, 2.02)
		nl.rotation.y = 2.0 * PI
		coin(Vector3(c[0], c[1] + 5.8, c[2]))

	# 6. The ledge before the last page.
	box(Vector3(0, 39, -132.5), Vector3(16, 2, 7), _grid)
	checkpoint(Vector3(-5, 40, -130.5), 0.0)
	coin(Vector3(5, 41.5, -131), 5)

	# 7. The last page: a sheet of paper that tilts around its front edge.
	_page_pivot = Node3D.new()
	_page_pivot.position = PAGE_FRONT
	add_child(_page_pivot)
	var page := StaticBody3D.new()
	page.position = Vector3(0, -0.3, -PAGE * 0.5)
	var pcs := CollisionShape3D.new()
	var pshape := BoxShape3D.new()
	pshape.size = Vector3(PAGE, 0.6, PAGE)
	pcs.shape = pshape
	page.add_child(pcs)
	deco(_box_mesh(Vector3(PAGE, 0.6, PAGE)), _paper, Vector3.ZERO, Vector3.ZERO, Vector3.ONE, page)
	deco(_box_mesh(Vector3(0.15, 0.02, PAGE)), Mats.solid(Color(0.95, 0.4, 0.45)), Vector3(-PAGE * 0.5 + 5, 0.31, 0), Vector3.ZERO, Vector3.ONE, page)
	for i in 11:
		deco(_box_mesh(Vector3(PAGE, 0.02, 0.06)), Mats.solid(Color(0.6, 0.75, 0.95)), Vector3(0, 0.31, -PAGE * 0.5 + 3 + i * 3.0), Vector3.ZERO, Vector3.ONE, page)
	_page_pivot.add_child(page)
	coin_ring(ARENA + Vector3(0, 1, 2), 9.0, 12)
	trigger(Vector3(0, 42, -138.5), Vector3(30, 5, 3), func(_p): _start_boss(), false)
	_build_slide()

	boss = EndScript.new()
	boss.level = self
	add_child(boss)
	boss.set_arena(ARENA, ARENA_R)
	boss.name_changed.connect(_on_name_changed)


## The slide the page turns into, hidden until the rip.
func _build_slide() -> void:
	var d := Vector3(0, -sin(TILT), -cos(TILT))
	var n := Vector3(0, cos(TILT), -sin(TILT))
	var start := PAGE_FRONT + d * PAGE
	var rot := Vector3(-TILT, 0, 0)
	for k in SLIDE_SEGS:
		var s := start + d * SLIDE_LEN * k
		# The third piece has a tear in the middle: jump it.
		var pieces := [[0.0, SLIDE_LEN]] if k != 2 else [[0.0, 12.5], [17.5, 12.5]]
		for pc in pieces:
			var c: Vector3 = s + d * (pc[0] + pc[1] * 0.5)
			var body := _hidden_body(c - n * 0.3, Vector3(14, 0.6, pc[1]), rot)
			var mesh := deco(_box_mesh(Vector3(14, 0.6, pc[1])), _paper, Vector3.ZERO, Vector3.ZERO, Vector3.ONE, body)
			for x in [-7.3, 7.3]:
				deco(_box_mesh(Vector3(0.6, 1.4, pc[1])), Mats.toon(Color(0.9, 0.88, 0.82)), Vector3(x, 0.8, 0), Vector3.ZERO, Vector3.ONE, body)
			body.visible = false
			_slide.append({"body": body, "mesh": mesh})
		var z := zone(s + d * SLIDE_LEN * 0.5 + n * 2.0, Vector3(14, 4, SLIDE_LEN), "push")
		z.rotation = rot
		z.push = Vector3.ZERO
		z.floor_only = false
		_slide_zones.append(z)
		for i in 4:
			coin(s + d * (4.0 + i * 7.0) + n * 1.2 + Vector3(sin(k * 2.0 + i) * 3.5, 0, 0))
	_slide_end = start + d * SLIDE_LEN * SLIDE_SEGS
	_bottom = _slide_end + Vector3(0, 0, -15)
	var pad := _hidden_body(_bottom - Vector3(0, 1, 0), Vector3(30, 2, 30))
	deco(_box_mesh(Vector3(30, 2, 30)), _paper, Vector3.ZERO, Vector3.ZERO, Vector3.ONE, pad)
	pad.visible = false
	_slide.append({"body": pad, "mesh": pad.get_child(1)})
	# For tests/reachability.gd: the finale continues at the bottom.
	reach_target = ARENA


func _build_void() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 404
	var wire := Mats.unshaded(Color(0.55, 0.55, 0.6), 0.35)
	# Unfinished scenery: untextured mountains, a cube marked WORLD_BOUNDS, a
	# floating question mark, a T-posing mannequin the size of a building.
	for i in 12:
		var a := rng.randf() * TAU
		var dist := rng.randf_range(90, 180)
		var h := rng.randf_range(30, 80)
		deco_cyl(Vector3(cos(a) * dist, -40 + h * 0.5, -120 + sin(a) * dist), rng.randf_range(20, 40), h, wire, Vector3.ZERO, 0.0)
	var cube := deco_box(Vector3(90, 30, -80), Vector3(30, 30, 30), _missing)
	cube.rotation = Vector3(0.4, 0.6, 0.2)
	sign_text("WORLD_BOUNDS", Vector3(90, 50, -80), PI, 300, Color(1.0, 0.2, 0.8))
	var qm := sign_text("?", Vector3(-70, 45, -150), PI, 3000, Color(0.3, 0.3, 0.35))
	qm.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	var grey := Mats.solid(Color(0.6, 0.6, 0.63), 0.8)
	var man := Vector3(-60, -10, -60)
	deco_box(man + Vector3(0, 30, 0), Vector3(10, 20, 6), grey)
	deco_box(man + Vector3(0, 45, 0), Vector3(7, 7, 7), grey)
	deco_box(man + Vector3(0, 36, 0), Vector3(44, 4, 4), grey)
	for x in [-3.0, 3.0]:
		deco_box(man + Vector3(x, 10, 0), Vector3(4, 20, 4), grey)
	sign_text("mannequin_tpose_final_FINAL.obj", man + Vector3(0, 54, 0), PI, 200, Color(0.3, 0.3, 0.35))
	debug_text("print(\"here\")", Vector3(20, 25, -60), PI, 140)
	debug_text("print(\"here 2\")", Vector3(-25, 32, -110), PI, 140)
	debug_text("# chapter 10 goes here", Vector3(0, 60, -160), PI, 200)


## A placeholder shop with exactly one item on sale.
const CANDY_PRICE := 30

var _shop: Node3D
var _candy: Node3D


func _build_shop() -> void:
	var at := Vector3(-4.3, 0, 2.6)
	deco_box(at + Vector3(0, 0.6, -1.1), Vector3(3.2, 1.2, 0.8), Mats.toon(Color(0.95, 0.5, 0.8)))
	for x in [-1.5, 1.5]:
		deco_cyl(at + Vector3(x, 1.5, -1.1), 0.08, 3.0, Mats.toon(Color(1, 1, 1)))
	deco_box(at + Vector3(0, 3.0, -1.1), Vector3(3.6, 0.3, 1.4), Mats.pattern("stripes", [Color(1.0, 0.4, 0.7), Color(1, 1, 1)], 1.5))
	sign_text("SHOP (placeholder)", at + Vector3(0, 3.5, -1.1), PI, 60, Color(1.0, 0.4, 0.8))
	# The candy: a swirly lollipop, spinning on the counter.
	_candy = Node3D.new()
	add_child(_candy)
	_candy.position = at + Vector3(0.6, 1.9, -1.1)
	deco_cyl(Vector3.ZERO, 0.03, 0.6, Mats.toon(Color(1, 1, 1))).reparent(_candy, false)
	var pop := deco_cyl(Vector3(0, 0.45, 0), 0.3, 0.12, Mats.pattern("stripes", [Color(1.0, 0.3, 0.7), Color(0.4, 0.9, 1.0)], 4.0), Vector3(PI / 2, 0, 0))
	pop.reparent(_candy, false)
	pop.position = Vector3(0, 0.45, 0)
	var price := sign_text("DOUBLE JUMP CANDY  $%d" % CANDY_PRICE, at + Vector3(0.6, 2.7, -0.7), PI, 30, Color(1, 1, 1))
	price.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	price.name = "Price"
	_candy.set_meta("price", price)
	if Game.has_double_jump:
		_candy.visible = false
		price.visible = false
	_shop = npc("placeholder", "shop", at + Vector3(-0.6, 0, -1.9), 0.0, [
		["shop", "Welcome, welcome! The only shop in chapter ten! Also the only anything in chapter ten."],
		["shop", "Today's special: Double Jump Candy! Eat it and you can jump again in mid-air. Forever!"],
		["shop", "Just %d coins. Straight from your bank. Don't ask how I can see your bank." % CANDY_PRICE],
	], [["shop", "Double Jump Candy! %d coins! Jump, then jump AGAIN! Sugar is basically physics." % CANDY_PRICE]])


func on_talked(n: Node3D) -> void:
	if n != _shop or Game.has_double_jump:
		return
	var total: int = Game.bank + player.coins
	if total < CANDY_PRICE:
		bark("shop", "Ooh. You're %d coins short. Come back richer! I'll be here. I literally can't leave." % (CANDY_PRICE - total))
		return
	# Pay from this chapter's coins first, then the bank.
	var from_pocket := mini(player.coins, CANDY_PRICE)
	player.coins -= from_pocket
	player.coins_changed.emit(player.coins)
	Game.bank -= CANDY_PRICE - from_pocket
	Game.has_double_jump = true
	player.double_jump = true
	Game.save_game()
	_candy.visible = false
	(_candy.get_meta("price") as Node3D).visible = false
	Audio.play("coin")
	Audio.play("fanfare")
	Fx.burst(self, player.global_position + Vector3(0, 1.5, 0), Color(1.0, 0.4, 0.8), 40, 7.0, 0.3, 1.0, -4.0)
	hud.banner("DOUBLE JUMP!", 2.0, Color(1.0, 0.5, 0.85))
	bark("stax", "Crunchy. Tastes like... a second chance. Jump, then jump again in mid-air!", )


# ---------------------------------------------------------------- per frame

func _start_play() -> void:
	super()
	boss.player = player
	player.died.connect(_on_player_died)
	player.coins_changed.connect(func(_c): _show_total())
	_show_total()


func _show_total() -> void:
	var total: int = Game.bank + player.coins
	var star := "  ★" if total >= Game.PERFECT_COINS else ""
	hud.set_chapter("%s  ·  %s  ·  Total $%d / %d%s" % [info.chapter, info.title, total, Game.PERFECT_COINS, star])


func _physics_process(delta: float) -> void:
	super(delta)
	_t += delta
	if _candy:
		_candy.rotation.y += delta * 2.0
	if player == null:
		return
	# Platforms load in as Stax approaches.
	for L in _loaders:
		var body: StaticBody3D = L.body
		if body.collision_layer != 0:
			continue
		var d := Vector2(player.global_position.x - body.global_position.x, player.global_position.z - body.global_position.z).length()
		if d < 12.0:
			body.collision_layer = 1
			(L.ghost as Node3D).visible = false
			(L.tag as Node3D).visible = false
			create_tween().tween_property(L.mesh, "scale", Vector3.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
			Audio.play("pop", 1.4, 0.1, -4.0)
	# Missing textures blink: 1.6 s there, 0.8 s gone, with a flicker warning.
	for B in _blinkers:
		var c := fmod(_t + B.phase, 2.4)
		var on := c < 1.6
		var body: StaticBody3D = B.body
		body.collision_layer = 1 if on else 0
		var mesh: Node3D = B.mesh
		mesh.visible = on and not (c > 1.2 and fmod(c, 0.12) < 0.06)
	# The slide: reaching the bottom starts the last stand.
	if _ripped and not _at_bottom and not player.dead and player.global_position.z < _slide_end.z - 1.0 and player.is_on_floor():
		_at_bottom = true
		boss.begin_bottom(_bottom, 13.0)
		bark("stax", "End of the slide! Stomp the last letters!")


func _on_player_died() -> void:
	if not _fight_started or boss.state == boss.B.DEAD:
		return
	if boss._final:
		# The final phase starts over at the bottom, every tile back.
		await get_tree().create_timer(0.6).timeout
		boss.reset_final()
		hud.set_boss_hp(boss.cursor_hp)
		bark("theend", "RESTART? RESTART. I LOVE a restart.")
		return
	if _ripped:
		# Back to the top of the slide; the letters he already erased stay erased.
		_at_bottom = false
		boss._clear_attacks()
		boss.begin_slide()
	else:
		boss.reset()
		hud.set_boss_hp(boss.hp())
		await get_tree().create_timer(1.2).timeout
		bark("theend", "THE END... of your attempt. Again.")


func _on_name_changed(text: String) -> void:
	if not _fight_started:
		return
	hud.show_boss(text if text != "" else "...", boss.MAX_HP)
	hud.set_boss_hp(boss.hp())
	match text:
		"THE EN": bark("stax", "THE EN? What's an 'en'? You're not even a word anymore!")
		"THE E": bark("stax", "THE E. Getting less scary by the letter, buddy.")
		"TH": bark("stax", "TH! You sound like you're lisping!")
		"T": bark("stax", "Just T now. Like the drink. Or the shirt. Or the letter.")


func on_letter_stuck() -> void:
	if not _told_stuck:
		_told_stuck = true
		bark("steve", "It's stuck in the floor! Stomp it or ground pound it! Erase that letter!")


# ---------------------------------------------------------------- story

func intro() -> void:
	director.begin()
	Game.fx.set_black(true)
	player.place(spawn_point + Vector3(0, 50, 0), spawn_yaw)
	director.actors["steve"] = _steve.puppet
	# The end card from last chapter... that won't go away.
	await director.title("", "THE END", "(for real this time)", 1.0)
	Audio.play("zap", 0.5)
	Audio.play("scratch", 0.6)
	Game.fx.aberrate(1.5, 1.2)
	await director.wait(0.6)
	await director.say("narrator", "There is no chapter ten.")
	await director.say("narrator", "So naturally, Stax fell into it.")
	director.shot(Vector3(12, 20, 20), Vector3(0, 10, -60), 55.0)
	Game.fx.fade_in(1.5)
	director.move(Vector3(8, 6, 14), Vector3(0, 3, -10), 4.0, 50.0)
	await director.wait(1.0)
	Audio.play("whoosh", 0.8)
	var t := 0.0
	while player.global_position.y > 0.6 and t < 5.0 and not director.skipping:
		t += await director._frame()
	player.place(spawn_point, spawn_yaw)
	Audio.play("land")
	director.shake(0.3)
	await director.settle()
	var sp := player.global_position
	director.shot(sp + Vector3(-2.3, 1.5, -2.7), sp + Vector3(0, 1.3, 0), 36.0)
	await director.say("stax", "Where... is everything? Why is the sky just GREY?", "shocked")
	director.face(_steve.global_position)
	_steve.face_toward(player.global_position)
	director.two_shot(player, _steve, 1.0, 46.0)
	await director.lines([
		["steve", "Kid! Welcome to chapter ten! Or the space where chapter ten goes. Nobody made it yet."],
		["stax", "Steve, why are you a GREY BOX?", "point"],
		["steve", "Placeholder! My model hasn't loaded. I feel very exposed."],
		["steve", "Anyway, the last page is up that way. Something's waiting there. Something that has been at the end of every single chapter..."],
		["stax", "...The fanfare?", "think"],
		["steve", "Worse."],
	])
	director.shot(Vector3(14, 10, 8), Vector3(0, 20, -120), 50.0)
	director.move(Vector3(6, 6, 6), Vector3(0, 30, -150), 4.0, 44.0)
	await director.title(info.chapter, info.title, info.subtitle)
	await director.settle()
	player.place(spawn_point, spawn_yaw)
	director.end()


func _start_boss() -> void:
	if _fight_started or director.active:
		return
	_fight_started = true
	player.spawn_point = Vector3(-5, 40.5, -130.5)
	director.begin()
	Audio.stop_music(0.6)
	player.velocity = Vector3.ZERO
	player.speed = 0.0
	player.place(ARENA + Vector3(0, 0.2, ARENA_R - 3), 0.0)
	var sp := player.global_position
	director.shot(sp + Vector3(-2.5, 1.5, -3), sp + Vector3(0, 1.3, 0), 38.0)
	await director.say("stax", "A blank page. Okay. Nothing scary about a blank page.", "cool")
	# The letters drop in, one at a time, spelling it out.
	for l in boss.letters:
		l.pos = l.home + Vector3(0, 40, 0)
	director.shot(ARENA + Vector3(0, 6, 14), ARENA + Vector3(0, 7, -ARENA_R + 4), 58.0)
	for i in boss.letters.size():
		if director.skipping:
			break
		Audio.play("clang", 0.6 + i * 0.1)
		await director.wait(0.25)
	await director.wait(1.0)
	Audio.play("boom", 0.5)
	director.shake(0.6)
	await director.lines([
		["theend", "I AM THE END."],
		["theend", "Nine chapters, I have closed. Every story comes to me. Every story STOPS at me."],
		["stax", "You're a title card.", "point"],
		["theend", "I AM THE LAST THING ANYONE SEES."],
		["stax", "You can't end me. I'm the main character.", "cool"],
		["theend", "Watch me."],
	])
	Audio.play_music("theend", 0.2)
	Audio.set_drums(1.0)
	director.shot(ARENA + Vector3(0, 10, ARENA_R + 8), ARENA + Vector3(0, 6, -6), 60.0)
	director.move(ARENA + Vector3(0, 6, ARENA_R + 2), ARENA + Vector3(0, 6, -8), 3.0)
	await director.title("FINAL FINAL BOSS", "THE END", "It has been waiting at the end of every chapter", 1.8)
	await director.settle()
	player.place(ARENA + Vector3(0, 0.2, ARENA_R - 3), 0.0)
	director.end()
	boss.hit.connect(func(n): hud.set_boss_hp(n))
	boss.defeated.connect(_on_boss_defeated)
	boss.phase_two.connect(_rip)
	boss.final_phase.connect(_final_phase)
	hud.show_boss("THE END", boss.MAX_HP)
	boss.start()
	bark("steve", "Jump the underline! Dodge the words! When a letter gets stuck in the floor... ERASE IT!")


## "THE" rips the page into a slide.
func _rip() -> void:
	# Let the erase effects play before the cutscene takes over.
	await get_tree().create_timer(0.8).timeout
	director.begin()
	player.velocity = Vector3.ZERO
	player.speed = 0.0
	player.place(Vector3(0, 40.2, -130.5), 0.0)
	director.shot(ARENA + Vector3(0, 8, 22), ARENA + Vector3(0, 6, -8), 55.0)
	await director.say("theend", "Fine. If I cannot END you...")
	await director.say("theend", "...I will make you FALL.")
	# They grab the far edge of the page and PULL.
	for l in boss.letters:
		if l.alive:
			l.home = ARENA + Vector3((l.slot - 1) * 3.6, 2.0, -PAGE * 0.5 - 1.0)
	await director.wait(1.0)
	for i in 3:
		Audio.play("scratch", 0.5 + i * 0.15)
		Audio.play("rumble", 1.2)
		director.shake(0.5)
		await director.wait(0.35)
	director.shot(Vector3(24, 48, -140), Vector3(0, 30, -175), 60.0)
	var tilt := create_tween()
	tilt.tween_property(_page_pivot, "rotation:x", -TILT, 1.4).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	Fx.burst(self, PAGE_FRONT + Vector3(0, 0, -PAGE), Color(0.97, 0.96, 0.9), 60, 12.0, 0.5, 1.2, -6.0, "cube")
	await director.wait(1.5)
	tilt.kill()
	_page_pivot.rotation.x = -TILT
	# And it keeps tearing, unrolling downhill into the void.
	director.shot(PAGE_FRONT + Vector3(12, 12, -30), _slide_end, 60.0)
	for s in _slide:
		var body: StaticBody3D = s.body
		body.visible = true
		body.collision_layer = 1
		var mesh: Node3D = s.mesh
		if not director.skipping:
			mesh.scale = Vector3(1, 1, 0.02)
			create_tween().tween_property(mesh, "scale", Vector3.ONE, 0.3)
			Audio.play("scratch", 0.8 + randf() * 0.4, 0.0, -2.0)
			await director.wait(0.22)
		else:
			mesh.scale = Vector3.ONE
	for z in _slide_zones:
		z.push = Vector3(0, 0, -11.0)
	# The tilted page pushes too.
	var pz := zone(PAGE_FRONT + Vector3(0, -sin(TILT), -cos(TILT)) * (PAGE * 0.5) + Vector3(0, 2, 0), Vector3(PAGE, 4, PAGE), "push")
	pz.rotation = Vector3(-TILT, 0, 0)
	pz.push = Vector3(0, 0, -9.0)
	pz.floor_only = false
	_ripped = true
	await director.wait(0.6)
	var sp := player.global_position
	director.shot(sp + Vector3(-2.3, 1.5, -2.7), sp + Vector3(0, 1.3, 0), 36.0)
	await director.say("stax", "It ripped the floor. It RIPPED THE FLOOR INTO A SLIDE.", "shocked")
	await director.say("steve", "WHEEEE! ...Sorry. Wrong moment. Go get 'em!")
	player.place(Vector3(0, 40.2, -131.5), 0.0)
	director.end()
	boss.begin_slide()
	bark("steve", "Slide! Dodge the falling words! Jump the tear!")


## Every letter erased... and the ink comes back together.
func _final_phase() -> void:
	await get_tree().create_timer(0.8).timeout
	director.begin()
	Audio.stop_music(0.3)
	player.velocity = Vector3.ZERO
	player.speed = 0.0
	player.place(_bottom + Vector3(0, 0.2, 9), 0.0)
	var c := _bottom + Vector3(0, 9, -9)
	director.shot(_bottom + Vector3(0, 4, 18), c, 50.0)
	await director.wait(0.8)
	await director.say("stax", "...It's quiet. Did I win? I think I won.", "think")
	# Every erased letter's ink, rushing back from wherever it splashed.
	Audio.play("rumble", 0.5)
	Audio.play("whoosh", 0.3)
	for i in 8:
		Fx.burst(self, c + Vector3(randf_range(-14, 14), randf_range(-4, 8), randf_range(-10, 6)), Color(0.05, 0.05, 0.08, 0.95), 40, 3.0, 0.5, 1.0, 0.0, "cube")
	director.shake(0.6)
	await director.wait(1.0)
	# The world drains to black and white. Only the cursor keeps its colour.
	Game.fx.set_grade(Color(1, 1, 1), 0.0, 0.65)
	sky_mat.set_shader_parameter("top_color", Color(0.02, 0.02, 0.03))
	sky_mat.set_shader_parameter("horizon_color", Color(0.15, 0.15, 0.18))
	env.fog_light_color = Color(0.1, 0.1, 0.12)
	for s in _slide:
		if s.body.global_position.distance_to(_bottom) < 20.0:
			(s.body as StaticBody3D).collision_layer = 0
			(s.body as Node3D).visible = false
	boss.begin_final(_bottom)
	Game.fx.flash(Color(1.0, 0.85, 0.3), 0.8)
	Audio.play("thunder")
	Audio.play("bong", 0.5)
	director.shot(_bottom + Vector3(-6, 5, 14), c, 42.0)
	await director.lines([
		["theend", "Did you think a story ends when the words run out?"],
		["theend", "I am not a word. I am what comes AFTER the last word."],
		["theend", "I AM THE CURSOR. And I am still blinking."],
		["stax", "Oh, come ON.", "facepalm"],
	])
	Audio.play_music("theend_dub", 0.2)
	Audio.set_drums(1.0)
	await director.title("TRUE FINAL PHASE", "THE CURSOR", "It is still blinking", 1.6)
	player.spawn_point = _bottom + Vector3(0, 0.5, 8)
	player.place(_bottom + Vector3(0, 0.2, 8), 0.0)
	director.end()
	hud.show_boss("THE CURSOR", boss.CURSOR_HP)
	bark("steve", "It deletes the floor! Dodge the words, jump the underscore, and stomp it when it slams down!")


func _on_boss_defeated() -> void:
	boss_beaten()
	if complete:
		return
	complete = true
	hud.hide_boss()
	# Colour comes back.
	var c := env_config()
	Game.fx.set_grade(c.tint, c.saturation, c.vignette)
	sky_mat.set_shader_parameter("top_color", c.top)
	sky_mat.set_shader_parameter("horizon_color", c.horizon)
	env.fog_light_color = c.fog_color
	Game.fx.flash(Color(1, 1, 1), 1.0)
	# The tiles are gone with the cursor: a floor to stand on for the ending.
	box(_bottom - Vector3(0, 1, 0), Vector3(30, 2, 30), _paper)
	await get_tree().create_timer(1.0).timeout
	var total: int = Game.bank + player.coins
	if total >= Game.PERFECT_COINS:
		await _perfect_ending(total)
	else:
		await _ending(total)
	Game.complete_level(player.coins)


func _ending_start() -> void:
	director.begin()
	Audio.stop_music(1.5)
	player.velocity = Vector3.ZERO
	var at := _bottom if _ripped else ARENA
	player.place(at + Vector3(0, 0.2, 4), 0.0)
	# Steve, fully loaded at last.
	var real := Puppet.new()
	real.kind = "steve"
	real.speaker = "steve"
	add_child(real)
	real.global_position = at + Vector3(2.2, 0, 1.5)
	real.rotation.y = 2.2
	director.actors["steve"] = real
	Audio.play("pop")
	Fx.burst(self, real.global_position + Vector3(0, 1.5, 0), Color(0.82, 0.62, 0.38), 30, 6.0, 0.3, 0.8, -6.0, "cube")
	director.face(real.global_position)
	director.two_shot(player, real, 1.0, 44.0)
	await director.lines([
		["steve", "Kid! You did it! You erased THE END! And look, my model loaded! I'm WOOD again!"],
		["stax", "So if there's no END... what happens now?", "think"],
		["steve", "Nothing ends. The page is blank. You get to write what comes next."],
	])


func _ending(total: int) -> void:
	await _ending_start()
	var sp := player.global_position
	await director.say("stax", "Cool. Then I'll write it myself.", "cool")
	var word := sign_text("THE END", sp + Vector3(0, 0.05, -4), 0.0, 400, Color(0.55, 0.3, 0.9))
	word.rotation = Vector3(-PI / 2, 0, 0)
	Audio.play("scratch", 1.3)
	director.shot(sp + Vector3(0, 9, 3), sp + Vector3(0, 0, -4), 50.0)
	await director.wait(1.4)
	await director.say("stax", "In crayon. The way it should be.", "cheer")
	Audio.play_music("credits", 0.5)
	player.model.emote = "dance"
	director.orbit(sp + Vector3(0, 1.2, 0), 6.0, 1.5, player.facing + PI / 2, player.facing + PI / 2 + 1.2, 5.0)
	await director.title("", "THE END", "Collect %d coins in one adventure for the perfect ending  ·  You had %d" % [Game.PERFECT_COINS, total], 3.0)
	await Game.fx.fade_out(1.5)
	director.end()


func _perfect_ending(total: int) -> void:
	await _ending_start()
	var sp := player.global_position
	await director.lines([
		["steve", "...Wait. Kid. Why are your pockets GLOWING?"],
		["stax", "%d coins. I picked up every coin I could find. In every dimension." % total, "cool"],
	])
	# The coins pour out and become a golden pen.
	Audio.play("fanfare")
	Audio.play_music("credits", 0.5)
	for i in 6:
		Fx.burst(self, sp + Vector3(0, 1 + i * 0.8, 0), Color(1.0, 0.85, 0.3), 40, 7.0, 0.22, 1.2, 2.0, "coin")
	var pen := Node3D.new()
	add_child(pen)
	pen.global_position = sp + Vector3(0, 30, -8)
	deco(_sphere_mesh(1.0), Mats.gold(), Vector3.ZERO, Vector3.ZERO, Vector3(1, 6, 1), pen)
	deco(_box_mesh(Vector3(0.6, 2.5, 0.6)), Mats.glow(Color(1.0, 0.9, 0.5), 4.0), Vector3(0, -6.5, 0), Vector3(0, 0, PI / 4), Vector3.ONE, pen)
	create_tween().tween_property(pen, "global_position", sp + Vector3(0, 10, -8), 1.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	director.shot(sp + Vector3(0, 2, 10), sp + Vector3(0, 10, -8), 55.0)
	await director.wait(1.6)
	# It writes a new ending across the sky, letter by letter.
	var line := sign_text("", sp + Vector3(0, 20, -30), 0.0, 400, Color(1.0, 0.85, 0.3), 1.5)
	line.rotation.y = 0.0
	var msg := "AND THEY ALL LIVED RICHLY EVER AFTER"
	director.shot(sp + Vector3(0, 6, 16), sp + Vector3(0, 18, -30), 60.0)
	for i in msg.length():
		if director.skipping:
			break
		line.text = msg.substr(0, i + 1)
		pen.global_position = sp + Vector3(-18 + i * 1.0, 22, -29)
		if i % 3 == 0:
			Audio.play("scratch", 1.6, 0.1, -6.0)
		await director.wait(0.05)
	line.text = msg
	pen.queue_free()
	# The blank page fills: a golden skyline, and everyone.
	var rng := RandomNumberGenerator.new()
	rng.seed = 47
	for i in 18:
		var a := PI * 0.25 + PI * 1.5 * i / 18.0
		var d := rng.randf_range(24, 40)
		var h := rng.randf_range(10, 34)
		var b := deco_box(sp + Vector3(sin(a) * d, -h, -cos(a) * d), Vector3(6, h * 2.0, 6), Mats.gold())
		create_tween().tween_property(b, "position:y", sp.y, 1.2 + i * 0.05).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	Audio.play("rumble", 0.8)
	director.shake(0.4)
	var guests := [
		["baron", "baron", 1.2], ["moneybeard", "moneybeard", 1.0], ["grandclock", "ticktock", 0.8],
		["baby", "baby", 1.3], ["teddy", "teddy", 1.3], ["waffle", "waffle", 1.2], ["gary", "gary", 1.1],
		["lefty", "lefty", 1.0], ["camel", "camel", 1.0], ["cuckoo", "cuckoo", 1.1], ["doodle", "doodle", 1.2],
		["pigeon", "pigeon", 1.4], ["placeholder", "npc4", 1.0], ["duck", "parrot", 1.3],
	]
	var party: Array[Node3D] = []
	for i in guests.size():
		var g: Array = guests[i]
		var pup := Puppet.new()
		pup.kind = g[0]
		pup.speaker = g[1]
		pup.scale = Vector3.ONE * g[2]
		add_child(pup)
		var a := PI * 0.6 + PI * 0.8 * i / (guests.size() - 1)
		var at := sp + Vector3(sin(a) * 8.0, 0, -cos(a) * 8.0 - 2.0)
		pup.global_position = at + Vector3(0, 14, 0)
		pup.look_at(Vector3(sp.x, pup.global_position.y, sp.z), Vector3.UP)
		create_tween().tween_property(pup, "global_position", at, 0.6 + i * 0.08).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
		party.append(pup)
	director.actors["baron"] = party[0]
	director.actors["baby"] = party[3]
	director.actors["ticktock"] = party[2]
	director.orbit(sp + Vector3(0, 2, -2), 14.0, 5.0, 0.2, 1.3, 7.0, 58.0)
	await director.wait(1.5)
	await director.lines([
		["baron", "I'm un-pancaked! I'm VERTICAL again!"],
		["baby", "Baby SHARE! Baby share EVERYTHING now!"],
		["ticktock", "...Midnight. At last. A good one."],
		["stax", "Forty-seven dollars, a button... and all of you.", "cheer"],
		["steve", "Tip of the day, kid: THAT'S the real treasure."],
		["stax", "...Okay. THIS time, I'll allow it.", "cool"],
	])
	# Fireworks.
	for i in 10:
		if director.skipping:
			break
		var fw := sp + Vector3(randf_range(-25, 25), randf_range(18, 32), randf_range(-35, -15))
		var col := Color.from_hsv(randf(), 0.8, 1.0)
		Fx.burst(self, fw, col, 80, 16.0, 0.35, 1.4, -4.0)
		Fx.burst(self, fw, Color(1.0, 0.85, 0.3), 30, 10.0, 0.2, 1.2, -6.0, "coin")
		Audio.play("boom", 1.4 + randf() * 0.4, 0.1, -4.0)
		await director.wait(0.35)
	player.model.emote = "dance"
	for pup in party:
		pup.emote = "cheer"
	director.orbit(sp + Vector3(0, 1.4, 0), 7.0, 2.0, player.facing + PI / 2, player.facing + PI / 2 + 1.6, 6.0)
	Game.perfect_ending = true
	Game.save_game()
	await director.title("", "THE PERFECT ENDING", "★  %d coins. Every single one of them earned.  ★" % total, 3.0)
	await Game.fx.fade_out(1.5)
	director.end()


func _sphere_mesh(r: float) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	return s


## Used by tests/level_smoke.gd: erases every letter, rip included (the test
## then waits for the ending to hand over to the credits).
func test_hook(tree: SceneTree) -> bool:
	for n in 900:
		if not director.active:
			break
		director.skip()
		await tree.physics_frame
	_start_boss()
	for n in 900:
		if director.active:
			director.skip()
		elif boss.state != boss.B.WAIT:
			break
		await tree.physics_frame
	for i in boss.MAX_HP + boss.CURSOR_HP:
		boss.take_hit()
		for n in 150:
			if director.active:
				director.skip()
			await tree.physics_frame
	return boss.state == boss.B.DEAD and _ripped
