extends "res://scripts/world/level_base.gd"
## Chapter 9: The Frostfire Rift. Three days after the Vault, the sky over
## Goldhaven cracks open and drops Stax into a world split down the middle:
## everything left of the seam is frozen, everything right of it is on fire.
## When the Vault refunded the multiverse, every coin came out of one hoard,
## and its owners would like a word.
## Route: the seam -> ice floes and basalt pistons (ATM) -> fire geyser ->
## AVALANCHE RUN (a giant snowball, downhill, no brakes) -> the Twin Dragon
## flies over (ATM) -> meteor shower over the rising ice pillars (ATM) ->
## Captain Moneybeard's ship crashes out of the sky to bridge the chasm ->
## Lord Tick-Tock slows time for the firewall gauntlet -> the split arena:
## Cold Hard Cash & Burn Rate. And then the craziest hot tub party ever.

const DragonScript := preload("res://scripts/actors/boss_dragon.gd")

const FLOOR_Y := -6.0
const SLOPE_TOP_Z := -45.5
const SLOPE_END_Z := -105.5
const ARENA := Vector3(0, 11, -254)
const ARENA_R := 20.0
const DRAGON_AT := Vector3(0, 11, -288)
const SHIP_AT := Vector3(0, 11.0, -166)
const RIFT_Y := 120.0

var boss: Node3D
## Where the finale happens, for tests/reachability.gd.
var reach_target := ARENA
var _steve: Node3D
var _snow: Material
var _ice: Material
var _basalt: Material
var _lava: Material
# Avalanche.
var _avalanche_armed := true
var _ball: Node3D
var _ball_z := 0.0
var _ball_x := 0.0
var _ball_trail := 0.0
# Meteor field.
var _meteor_t := 0.0
# Set pieces.
var _flyover_done := false
var _ship: Node3D
var _ship_deck: StaticBody3D
var _ship_done := false
var _firewalls: Array = []
var _time_done := false
var _clock_ghost: Node3D
var _fight_started := false
var _told_rest := false


func _init() -> void:
	music = "frostfire"
	spawn_point = Vector3(0, 0.1, 3)
	spawn_yaw = 0.0
	kill_y = -20.0


func env_config() -> Dictionary:
	return {
		"top": Color(0.08, 0.04, 0.18), "horizon": Color(0.7, 0.32, 0.5), "bottom": Color(0.12, 0.05, 0.1),
		"sun_color": Color(0.85, 0.85, 1.0), "sun_energy": 1.3, "sun_angle": Vector2(-50, -35),
		"sun_size": 0.0, "sun_glow": 0.0, "stars": 0.7, "nebula": 0.55,
		"nebula_a": Color(0.3, 0.8, 1.0), "nebula_b": Color(1.0, 0.35, 0.1),
		"fog_color": Color(0.5, 0.3, 0.55), "fog_density": 0.004, "volumetric": 0.015,
		"vol_color": Color(0.9, 0.8, 1.0), "ambient": 0.85, "exposure": 1.05, "glow": 1.25,
		"tint": Color(1.0, 0.98, 1.03), "saturation": 1.18, "vignette": 0.45, "player_light": 0.6,
	}


# ---------------------------------------------------------------- props

## A block split down the seam: snow on the left, basalt on the right.
## `top` is the centre of its top face.
func seam_block(top: Vector3, size: Vector3) -> void:
	var half := Vector3(size.x * 0.5, size.y, size.z)
	box(top + Vector3(-size.x * 0.25, -size.y * 0.5, 0), half, _snow)
	box(top + Vector3(size.x * 0.25, -size.y * 0.5, 0), half, _basalt)
	deco_box(top + Vector3(0, -size.y * 0.5 + 0.01, 0), Vector3(0.25, size.y + 0.04, size.z + 0.04), Mats.glow(Color(0.85, 0.6, 1.0), 2.5))


func slope_y(z: float) -> float:
	var k := (z - SLOPE_END_Z) / (SLOPE_TOP_Z - SLOPE_END_Z)
	return lerpf(1.0, 11.0, k)


func geyser(pos: Vector3, strength: float) -> void:
	var v := Node3D.new()
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 1.2
	cm.bottom_radius = 1.5
	cm.height = 0.5
	mi.mesh = cm
	mi.material_override = Mats.glow(Color(1.0, 0.45, 0.1), 2.5)
	mi.position.y = 0.25
	v.add_child(mi)
	bouncer(pos, 1.4, strength, v)
	Fx.ambient(self, pos + Vector3(0, 2.5, 0), Vector3(0.6, 2.0, 0.6), Color(1.0, 0.6, 0.2, 0.8), 40, 0.25, Vector3(0, 5, 0), 0.8)


## A flat half of a disc (for the arena floor): side -1 is x < 0, +1 is x > 0.
func half_disc(center: Vector3, r: float, side: float, mat: Material) -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var n := 32
	for i in n:
		var a0 := PI * i / n - PI * 0.5
		var a1 := PI * (i + 1) / n - PI * 0.5
		st.set_normal(Vector3.UP)
		st.set_uv(Vector2(0.5, 0.5))
		st.add_vertex(Vector3.ZERO)
		st.set_uv(Vector2(0.5 + cos(a1) * 0.5, 0.5 + sin(a1) * 0.5))
		st.add_vertex(Vector3(side * cos(a1) * r, 0, sin(a1) * r))
		st.set_uv(Vector2(0.5 + cos(a0) * 0.5, 0.5 + sin(a0) * 0.5))
		st.add_vertex(Vector3(side * cos(a0) * r, 0, sin(a0) * r))
	var mesh := st.commit()
	var mi := deco(mesh, mat, center)
	# Winding flips with the side; draw both faces rather than fuss.
	if mat is StandardMaterial3D:
		var m := (mat as StandardMaterial3D).duplicate()
		m.cull_mode = BaseMaterial3D.CULL_DISABLED
		mi.material_override = m


# ---------------------------------------------------------------- build

func build() -> void:
	_snow = Mats.rough_surface(Color(0.92, 0.96, 1.0), Color(0.75, 0.85, 0.95), 0.2, 0.6, 91, 0.4)
	_ice = Mats.toon(Color(0.65, 0.88, 1.0), 0.15, 0.5)
	_basalt = Mats.rough_surface(Color(0.2, 0.16, 0.16), Color(0.45, 0.12, 0.06), 0.25, 0.9, 92, 0.8)
	_lava = Mats.glow(Color(1.0, 0.38, 0.06), 2.2)

	# Below everything: a freezing sea on the left, a lava sea on the right.
	box(Vector3(-150, FLOOR_Y - 1, -150), Vector3(300, 2, 520), Mats.glass(Color(0.3, 0.55, 0.85), 0.9))
	box(Vector3(150, FLOOR_Y - 1, -150), Vector3(300, 2, 520), _lava)
	zone(Vector3(0, FLOOR_Y + 0.5, -150), Vector3(600, 1.2, 520), "hurt")
	Fx.ambient(self, Vector3(-40, 20, -140), Vector3(40, 25, 160), Color(1, 1, 1, 0.8), 400, 0.12, Vector3(0.5, -2.0, 0), 8.0)
	Fx.ambient(self, Vector3(40, 10, -140), Vector3(40, 15, 160), Color(1.0, 0.55, 0.15, 0.9), 300, 0.1, Vector3(-0.3, 2.5, 0), 5.0)
	_build_backdrop()

	# 1. The seam.
	seam_block(Vector3(0, 0, 0), Vector3(12, 4, 10))
	coin_ring(Vector3(0, 1, -1), 2.5, 6)
	_steve = npc("steve", "steve", Vector3(3.2, 0, -2.5), 2.4, [
		["steve", "Tips! Left side: freezing. Right side: burning. Middle: I honestly don't know. Nobody's checked."],
		["stax", "Why are YOU here, Steve?", "think"],
		["steve", "Moral support! Also I fell through the rift too. Also I'm scared of dragons. Mostly the moral support."],
	], [["steve", "Snowmen on the left, fire blobs on the right. Stomp both! Equal opportunity stomping."]])
	npc("camel", "camel", Vector3(-3.4, 0, -2.2), -2.2, [
		["camel", "Greetings, friend. It is I. The camel folded from towels."],
		["stax", "How are YOU here?!", "shocked"],
		["camel", "Linda folded me a tiny parka. And tiny oven mitts. Linda thinks of everything."],
		["camel", "Heed me: when the mountain rumbles, do not stop running. Not even to look back."],
		["stax", "What happens if I look back?", "think"],
		["camel", "You see a snowball the size of a house, friend. And then you stop being a person and start being a pancake."],
	], [["camel", "When the mountain rumbles: run. Linda would want you to run."]])

	# 2. Ice floes on the left, basalt pistons on the right.
	tip(Vector3(0, 1.5, -5), Vector3(12, 4, 2), "steve", "Hop the floes and ride the pistons! Try not to touch the sea. Either sea.")
	mover(Vector3(4, 0.6, 4), _ice, Vector3(-3, 0.2, -9), Vector3(0, -0.6, 0), 3.0)
	mover(Vector3(4, 0.8, 4), _basalt, Vector3(3, 1.1, -14.5), Vector3(0, 1.6, 0), 4.0, 0.3)
	mover(Vector3(4, 0.6, 4), _ice, Vector3(-4, 2.2, -20), Vector3(3, 0, 0), 5.0)
	mover(Vector3(4, 0.8, 4), _basalt, Vector3(3, 3.1, -25.5), Vector3(0, 1.4, 0), 3.5, 0.6)
	coin_arc(Vector3(-3, 1.5, -9), Vector3(3, 3, -14.5), 1.5, 3)
	coin_arc(Vector3(3, 3.5, -14.5), Vector3(-3, 4, -20), 1.5, 3)
	coin_arc(Vector3(-3, 4, -20), Vector3(3, 5, -25.5), 1.5, 3)
	coin(Vector3(3, 8, -25.5), 5)
	seam_block(Vector3(0, 4, -33), Vector3(12, 10, 8))
	checkpoint(Vector3(-3.2, 4, -30), 0.0)
	enemy("snowman", Vector3(-4.8, 4, -34), Vector3(-1.2, 4, -34))
	enemy("ember", Vector3(1.2, 4, -34.2), Vector3(4.8, 4, -34.2))

	# 3. A fire geyser up to the top of the mountain, and the avalanche run.
	geyser(Vector3(3, 4, -35.5), 26.0)
	tip(Vector3(0, 5.5, -31), Vector3(12, 4, 2), "steve", "Fire geyser! It's like a trampoline, but angrier.")
	box(Vector3(0, 10.5, -42.5), Vector3(14, 1, 6), _snow)
	var theta := atan2(10.0, 60.0)
	var mid_z := (SLOPE_TOP_Z + SLOPE_END_Z) * 0.5
	box(Vector3(0, 6.0 - 0.5 * cos(theta), mid_z), Vector3(14, 1, 60.0 / cos(theta)), _snow, Vector3(-theta, 0, 0))
	for x in [-7.3, 7.3]:
		box(Vector3(x, 6.6, mid_z), Vector3(0.6, 1.4, 60.0 / cos(theta)), _ice if x < 0.0 else _basalt, Vector3(-theta, 0, 0))
	for sp in [[-3.5, -56.0], [3.5, -70.0], [-1.0, -84.0], [4.0, -96.0]]:
		var z: float = sp[1]
		hazard_box(Vector3(sp[0], slope_y(z) + 0.8, z), Vector3(2.2, 1.6, 1.6), Mats.glass(Color(0.7, 0.92, 1.0), 0.85))
	var gi := 0
	for gp in [[2.0, -62.0], [-4.0, -77.0], [1.5, -90.0]]:
		var z: float = gp[1]
		hazard_box(Vector3(gp[0], slope_y(z) - 1.6, z), Vector3(1.6, 3.0, 1.6), _lava, 0.0, Vector3(0, 3.2, 0), 0.7, gi * 0.33)
		gi += 1
	for i in 8:
		var z := -50.0 - i * 7.0
		coin(Vector3(sin(i * 1.3) * 3.0, slope_y(z) + 1.2, z))

	# 4. The bottom of the mountain, where the dragon flies over.
	seam_block(Vector3(0, 1, -113.5), Vector3(16, 7, 16))
	checkpoint(Vector3(-4.5, 1, -108.5), 0.0)
	trigger(Vector3(0, 2.5, -110), Vector3(16, 4, 4), func(_p): _flyover(), false)

	# 5. Meteor shower over the rising ice pillars.
	tip(Vector3(0, 2.5, -118), Vector3(16, 4, 2), "steve", "Is the volcano... throwing rocks at us? Watch the red circles! Up the ice pillars, go go go!")
	mover(Vector3(3.5, 1, 3.5), _ice, Vector3(-4, 2.0, -125), Vector3(0, 4, 0), 4.5)
	mover(Vector3(3.5, 1, 3.5), _ice, Vector3(1, 5.0, -130.5), Vector3(0, 4, 0), 4.5, 0.5)
	mover(Vector3(3.5, 1, 3.5), _ice, Vector3(5, 8.0, -136), Vector3(0, 4, 0), 4.5)
	coin_line(Vector3(-4, 8, -125), Vector3(5, 14, -136), 5)
	seam_block(Vector3(0, 11, -145), Vector3(14, 17, 10))
	checkpoint(Vector3(-4, 11, -142), 0.0)
	coin(Vector3(4, 12.5, -146), 5)
	trigger(Vector3(0, 12.5, -148.5), Vector3(14, 4, 2), func(_p): _ship_crash(), false)

	# 6. The chasm (the ship will fill it) and the far cliff.
	seam_block(Vector3(0, 11, -188), Vector3(14, 17, 12))
	checkpoint(Vector3(-4, 11, -185), 0.0)
	_build_ship()
	trigger(Vector3(0, 12.5, -191), Vector3(14, 4, 3), func(_p): _time_freeze(), false)

	# 7. The firewall gauntlet.
	box(Vector3(0, 10.6, -214.25), Vector3(3.5, 0.8, 40.5), Mats.solid(Color(0.08, 0.06, 0.1), 0.2, 0.3))
	for i in 5:
		var z := -200.0 - i * 7.0
		var fw := hazard_box(Vector3(0, 6.5, z), Vector3(7, 4, 0.8), Mats.glow(Color(1.0, 0.35, 0.05), 3.0), 0.0, Vector3(0, 6, 0), 0.9, i * 0.23)
		_firewalls.append(fw)
		coin(Vector3(0, 12.2, z - 3.5))

	# 8. The split arena, and the dragon who owns all this.
	var rock := Mats.rough_surface(Color(0.25, 0.22, 0.28), Color(0.15, 0.12, 0.18), 0.2, 0.8, 93, 0.6)
	cylinder(ARENA - Vector3(0, 1, 0), ARENA_R, 2.0, rock, 64)
	half_disc(ARENA + Vector3(0, 0.02, 0), ARENA_R - 0.4, -1.0, Mats.pattern("tiles", [Color(0.8, 0.92, 1.0), Color(0.55, 0.75, 0.95)], 0.12, 0.2))
	half_disc(ARENA + Vector3(0, 0.02, 0), ARENA_R - 0.4, 1.0, Mats.pattern("tiles", [Color(0.25, 0.1, 0.08), Color(1.0, 0.4, 0.08)], 0.12, 0.8, true, 7, 0.6))
	deco_cylinder_under(ARENA, ARENA_R)
	for i in 24:
		var a := TAU * i / 24.0
		if absf(wrapf(a, -PI, PI)) < 0.3:
			continue
		var p := ARENA + Vector3(sin(a), 0, cos(a)) * (ARENA_R + 0.4)
		if p.x < ARENA.x:
			deco_cyl(p + Vector3(0, 1.6, 0), 0.7, 3.2, Mats.glass(Color(0.7, 0.92, 1.0), 0.8), Vector3.ZERO, 0.0)
		else:
			deco_cyl(p + Vector3(0, 0.6, 0), 0.6, 1.2, _basalt)
			deco_ball(p + Vector3(0, 1.4, 0), 0.5, _lava)
	omni(ARENA + Vector3(-12, 8, 0), Color(0.5, 0.8, 1.0), 30.0, 1.8)
	omni(ARENA + Vector3(12, 8, 0), Color(1.0, 0.5, 0.15), 30.0, 2.2)
	checkpoint(ARENA + Vector3(-4, 0, ARENA_R - 4), 0.0)
	coin_ring(ARENA + Vector3(0, 1, 2), 10.0, 12)
	trigger(ARENA + Vector3(0, 2, ARENA_R - 3.5), Vector3(20, 5, 3), func(_p): _start_boss(), false)
	# The dragon's perch.
	cylinder(DRAGON_AT - Vector3(0, 8, 0), 16.0, 16.0, _basalt, 32)
	boss = DragonScript.new()
	boss.level = self
	boss.arena_center = ARENA
	boss.arena_radius = ARENA_R
	boss.position = DRAGON_AT
	add_child(boss)


## A stone column under the arena, down into the seas.
func deco_cylinder_under(c: Vector3, r: float) -> void:
	deco_cyl(Vector3(c.x, (c.y - 2.0 + FLOOR_Y) * 0.5, c.z), r * 0.7, c.y - 2.0 - FLOOR_Y, _basalt, Vector3.ZERO, r * 0.95)


func _build_backdrop() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 29
	# Ice spires on the left.
	var spire := Mats.glass(Color(0.7, 0.9, 1.0), 0.75)
	for i in 18:
		var x := rng.randf_range(-150, -30)
		var z := rng.randf_range(-320, 40)
		var h := rng.randf_range(30, 110)
		deco_cyl(Vector3(x, FLOOR_Y + h * 0.5, z), rng.randf_range(4, 10), h, spire, Vector3(0, 0, rng.randf_range(-0.1, 0.1)), 0.0)
	# The aurora.
	for i in 16:
		var a := -0.9 + i * 0.12
		var col := Color(0.3, 1.0, 0.7).lerp(Color(0.4, 0.6, 1.0), i / 16.0)
		var m := Mats.unshaded(col, 0.28)
		deco_box(Vector3(-120 + sin(a) * 60, 85 + sin(i * 0.7) * 6, -150 + cos(a) * 120), Vector3(18, 34, 0.3), m, Vector3(0, a + PI / 2, 0))
	# A volcano on the right.
	var vol := Vector3(130, FLOOR_Y, -210)
	deco_cyl(vol + Vector3(0, 45, 0), 80.0, 90.0, _basalt, Vector3.ZERO, 14.0)
	deco_cyl(vol + Vector3(0, 90.5, 0), 13.0, 1.0, _lava)
	omni(vol + Vector3(0, 100, 0), Color(1.0, 0.45, 0.1), 120.0, 3.0)
	Fx.ambient(self, vol + Vector3(0, 110, 0), Vector3(10, 15, 10), Color(1.0, 0.5, 0.1, 0.9), 160, 1.2, Vector3(0, 12, 0), 2.5)
	for i in 5:
		var a := -2.0 + i * 0.4
		deco_box(vol + Vector3(cos(a) * 45, 45, sin(a) * 45), Vector3(4, 90, 2), _lava, Vector3(0, -a, 0.5))
	# The rift itself, a crack in the sky running the length of the world.
	var crack := Mats.glow(Color(0.95, 0.8, 1.0), 5.0)
	var p := Vector3(0, RIFT_Y, 80)
	for i in 14:
		var q := Vector3(rng.randf_range(-14, 14), RIFT_Y + rng.randf_range(-8, 8), 80 - (i + 1) * 30.0)
		var d := q - p
		var seg := deco_box((p + q) * 0.5, Vector3(3.0, 1.2, d.length()), crack)
		seg.look_at_from_position((p + q) * 0.5, q, Vector3.UP)
		p = q
	omni(Vector3(0, RIFT_Y - 20, -100), Color(0.9, 0.7, 1.0), 200.0, 1.5)


func _build_ship() -> void:
	_ship = Node3D.new()
	add_child(_ship)
	var wood := Mats.toon(Color(0.42, 0.26, 0.14), 0.8, 0.15)
	var dark := Mats.toon(Color(0.25, 0.14, 0.08), 0.8, 0.1)
	var parts := [
		[Vector3(0, -2.2, 0), Vector3(9, 4.4, 30), wood],
		[Vector3(0, -4.8, 0), Vector3(6, 2.0, 24), dark],
		[Vector3(0, -1.0, -17), Vector3(6.4, 5, 6.4), wood],
		[Vector3(0, 2.0, 12.5), Vector3(9.2, 3.5, 6), wood],
		[Vector3(4.55, 0.6, 0), Vector3(0.2, 0.5, 30), Mats.gold()],
		[Vector3(-4.55, 0.6, 0), Vector3(0.2, 0.5, 30), Mats.gold()],
	]
	for pt in parts:
		var b := BoxMesh.new()
		b.size = pt[1]
		deco(b, pt[2], pt[0], Vector3.ZERO, Vector3.ONE, _ship)
	for mz in [-6.0, 6.0]:
		var mast := CylinderMesh.new()
		mast.top_radius = 0.3
		mast.bottom_radius = 0.45
		mast.height = 20.0
		deco(mast, dark, Vector3(0, 10, mz), Vector3(0, 0, 0.12), Vector3.ONE, _ship)
		var sail := BoxMesh.new()
		sail.size = Vector3(9.0, 7.0, 0.25)
		deco(sail, Mats.toon(Color(0.95, 0.92, 0.82)), Vector3(0.8, 11, mz), Vector3(0, 0, 0.12), Vector3.ONE, _ship)
	var nm := sign_text("THE GOLDEN GOOSE II", Vector3.ZERO, PI / 2, 150, Color(1.0, 0.8, 0.3), 0.6)
	nm.reparent(_ship, false)
	nm.position = Vector3(4.65, -1.5, 0)
	nm.rotation = Vector3(0, PI / 2, 0)
	# The deck, which only becomes solid once the ship has landed.
	_ship_deck = StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(8.6, 0.8, 34)
	cs.shape = shape
	cs.position.y = -0.4
	_ship_deck.add_child(cs)
	# For tests/reachability.gd: where the deck ends up once the ship lands.
	_ship_deck.set_meta("scripted", Transform3D(Basis(), SHIP_AT))
	_ship_deck.collision_layer = 0
	_ship.add_child(_ship_deck)
	# Parked in the sky until it's needed.
	_ship.position = SHIP_AT + Vector3(30, 90, 40)
	_ship.rotation = Vector3(0.5, 0.6, -0.4)
	_ship.visible = false


# ---------------------------------------------------------------- per-frame set pieces

func _start_play() -> void:
	super()
	boss.player = player
	player.died.connect(_on_player_died)


func _physics_process(delta: float) -> void:
	super(delta)
	if player == null:
		return
	_update_avalanche(delta)
	_update_meteors(delta)
	if _clock_ghost:
		_clock_ghost.rotation.z -= delta * 0.4


func _on_player_died() -> void:
	# A fresh start on the mountain: the snowball goes back up top.
	if _ball:
		_ball.queue_free()
		_ball = null
	_avalanche_armed = true
	if _fight_started and boss.state != boss.B.DEAD:
		boss.reset()
		hud.set_boss_hp(boss.MAX_HP)
		await get_tree().create_timer(1.2).timeout
		bark("burnrate", "HA! Back to full! Money never dies, it just gets REINVESTED!")


func _update_avalanche(delta: float) -> void:
	var p := player.global_position
	if _avalanche_armed and not director.active and p.z < -40.0 and p.z > -45.5 and p.y > 10.5 and p.y < 14.0:
		_avalanche_armed = false
		_start_avalanche()
	if _ball == null:
		return
	_ball_z -= delta * 7.6
	# Near the bottom it swerves off the side of the mountain, into the lava.
	if _ball_z < -90.0:
		_ball_x = move_toward(_ball_x, 20.0, delta * 12.0)
	var ground := slope_y(clampf(_ball_z, SLOPE_END_Z, SLOPE_TOP_Z)) if _ball_z < SLOPE_TOP_Z else 11.0
	if _ball_x > 7.0:
		ground = lerpf(ground, FLOOR_Y - 8.0, clampf((_ball_x - 7.0) / 8.0, 0.0, 1.0))
	_ball.global_position = Vector3(_ball_x, ground + 4.5, _ball_z)
	_ball.rotation.x -= delta * 7.6 / 4.5
	_ball_trail -= delta
	if _ball_trail <= 0.0:
		_ball_trail = 0.12
		Fx.burst(self, _ball.global_position + Vector3(randf_range(-4, 4), -4.0, 3.5), Color(1, 1, 1, 0.9), 12, 6.0, 0.6, 0.8, -4.0)
	if not player.dead:
		var d := p - _ball.global_position
		if absf(d.x) < 4.8 and absf(d.z) < 4.4 and d.y < 4.0:
			player.take_damage(1, _ball.global_position)
	if _ball_x >= 16.0:
		# Into the lava sea: the biggest cloud of steam you've ever seen.
		var at := _ball.global_position
		Fx.burst(self, at, Color(1, 1, 1, 0.9), 120, 18.0, 2.5, 2.5, 2.0)
		Fx.burst(self, at, Color(1.0, 0.6, 0.2, 0.9), 40, 12.0, 0.6, 1.2, -8.0)
		Audio.play("boom", 0.6)
		Audio.play("zap", 0.3)
		rig.shake(0.8)
		_ball.queue_free()
		_ball = null
		bark("steve", "...Did the snowball just hit the lava and turn into a CLOUD? Is that allowed?!")


func _start_avalanche() -> void:
	Audio.play("rumble", 0.5)
	Audio.play("thunder", 0.7)
	rig.shake(0.9)
	bark("stax", "Why is the mountain rumbling... AVALANCHE!! RUN!!")
	_ball = Node3D.new()
	add_child(_ball)
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 4.5
	sm.height = 9.0
	mi.mesh = sm
	mi.material_override = _snow
	_ball.add_child(mi)
	# Lumps, rocks and one very unlucky snowman stuck in it.
	for i in 14:
		var dir := Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)).normalized()
		var lump := deco(_sphere(randf_range(0.8, 1.6)), _snow if i % 4 else _basalt, dir * 4.2)
		lump.reparent(_ball, false)
		lump.position = dir * 4.2
	var face := Puppet.new()
	face.kind = "snowman"
	_ball.add_child(face)
	face.position = Vector3(0, 4.3, 0)
	face.rotation.x = -0.3
	_ball_z = -30.0
	_ball_x = 0.0


func _sphere(r: float) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	return s


func _update_meteors(delta: float) -> void:
	var p := player.global_position
	if director.active or player.dead or p.z > -114.0 or p.z < -150.0 or p.y > 15.0:
		return
	_meteor_t -= delta
	if _meteor_t <= 0.0:
		_meteor_t = 1.5
		var target := p + Vector3(randf_range(-2.5, 2.5), 0, randf_range(-2.5, 2.5))
		# Land the meteor on whatever is under Stax.
		var hit := get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(target + Vector3(0, 3, 0), target + Vector3(0, -30, 0), 1, [player.get_rid()]))
		if hit:
			boss.drop(hit.position, true)


# ---------------------------------------------------------------- story

func intro() -> void:
	director.begin()
	Game.fx.set_black(true)
	player.place(spawn_point + Vector3(0, 60, 0), spawn_yaw)
	director.actors["steve"] = _steve.puppet
	director.actors["coldcash"] = boss.heads[0]
	director.actors["burnrate"] = boss.heads[1]
	# The crack in the sky.
	director.shot(Vector3(-20, 30, 40), Vector3(0, RIFT_Y, -60), 50.0)
	Game.fx.fade_in(2.0)
	director.move(Vector3(15, 40, 20), Vector3(0, RIFT_Y, -120), 7.0, 45.0)
	await director.wait(1.0)
	await director.say("narrator", "Three days after the Vault opened, Goldhaven was rich again. Then the sky cracked.")
	Audio.play("thunder")
	Game.fx.flash(Color(0.9, 0.8, 1.0), 0.6)
	director.shake(0.5)
	await director.say("narrator", "And out of the crack fell one kid, one bowl of cereal, and absolutely no warning.")
	await director.settle()
	# Stax drops onto the seam.
	director.shot(Vector3(8, 3, 14), Vector3(0, 3, 1), 50.0)
	Audio.play("whoosh", 0.9)
	var t := 0.0
	while player.global_position.y > 0.6 and t < 5.0 and not director.skipping:
		t += await director._frame()
	player.place(spawn_point, spawn_yaw)
	Audio.play("land")
	director.shake(0.4)
	Fx.burst(self, spawn_point, Color(1, 1, 1, 0.9), 30, 6.0, 0.6, 0.8, -6.0)
	var sp := player.global_position
	director.shot(sp + Vector3(-2.3, 1.5, -2.7), sp + Vector3(0, 1.3, 0), 36.0)
	await director.say("stax", "I was HOME. I was eating CEREAL. It was a SEQUEL-FREE MORNING.", "shocked")
	director.face(_steve.global_position)
	_steve.face_toward(player.global_position)
	director.two_shot(player, _steve, 1.0, 46.0)
	await director.lines([
		["steve", "Sooo... remember when I said 'sequel'?"],
		["stax", "STEVE.", "facepalm"],
		["steve", "Not my fault! When the Vault refunded everybody, all that money had to come from somewhere."],
		["steve", "It came from HERE. The Frostfire Rift. And the owners would like... a word."],
	])
	# Far off, two heads rise over the arena.
	Audio.play("hit_low", 0.5)
	Audio.play("rumble", 0.7)
	director.shake(0.6)
	for h in boss.heads:
		h.emote = "roar"
	director.shot(Vector3(0, 30, -170), DRAGON_AT + Vector3(0, 30, 0), 34.0)
	director.move(Vector3(0, 26, -200), DRAGON_AT + Vector3(0, 28, 0), 4.0, 30.0)
	await director.wait(0.8)
	await director.say("coldcash", "Who. Took. Our. Money.")
	await director.say("burnrate", "WHO TOOK OUR MONEY?!")
	for h in boss.heads:
		h.emote = ""
	director.shot(sp + Vector3(-2.3, 1.5, -2.7), sp + Vector3(0, 1.3, 0), 36.0)
	await director.say("stax", "...Technically? Everyone.", "shrug")
	director.shot(Vector3(14, 8, 14), Vector3(0, 6, -60), 50.0)
	director.move(Vector3(6, 5, 10), Vector3(0, 10, -120), 4.0, 44.0)
	await director.title(info.chapter, info.title, info.subtitle)
	await director.settle()
	player.place(spawn_point, spawn_yaw)
	director.end()


## Halfway down the mountain, the Twin Dragon comes to have a look.
func _flyover() -> void:
	# Set pieces never start on top of another cutscene; their triggers stay
	# armed and fire the next time Stax walks in.
	if _flyover_done or director.active:
		return
	_flyover_done = true
	player.spawn_point = Vector3(-4.5, 1.5, -108.5)
	director.begin()
	player.velocity = Vector3.ZERO
	player.speed = 0.0
	director.actors["coldcash"] = boss.heads[0]
	director.actors["burnrate"] = boss.heads[1]
	var home: Vector3 = boss.global_position
	var sp := player.global_position
	boss.set_flap(3.5)
	boss.global_position = Vector3(0, 30, -230)
	director.shot(sp + Vector3(-3, 1.2, 4), sp + Vector3(0, 14, -30), 60.0)
	Audio.play("whoosh", 0.4)
	Audio.play("rumble", 0.8)
	var fly := create_tween()
	fly.tween_property(boss, "global_position", Vector3(0, 34, -110), 2.2).set_trans(Tween.TRANS_SINE)
	await director.wait(1.6)
	for h in boss.heads:
		h.emote = "roar"
	Audio.play("thunder", 1.2)
	director.shake(0.8)
	Fx.burst(self, Vector3(-8, 30, -115), Color(0.8, 0.95, 1.0), 80, 18.0, 0.5, 1.5, -6.0, "cube")
	Fx.burst(self, Vector3(8, 30, -115), Color(1.0, 0.5, 0.1), 80, 18.0, 0.6, 1.5, -6.0)
	await director.say("burnrate", "HEY, LITTLE GUY!")
	await director.say("coldcash", "We see you.")
	director.shot(sp + Vector3(-3, 1.2, -4), sp + Vector3(0, 12, 20), 60.0)
	var away := create_tween()
	away.tween_property(boss, "global_position", Vector3(0, 40, 40), 2.0).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
	await director.say("burnrate", "We'll be waiting at our arena! It's the big round one! Past the chasm! You can't miss it!")
	await director.say("coldcash", "...Stop giving him directions.")
	for h in boss.heads:
		h.emote = ""
	director.shot(sp + Vector3(-2.3, 1.5, -2.7), sp + Vector3(0, 1.3, 0), 36.0)
	await director.say("stax", "Did a two-headed dragon just fly over me and give me directions?", "shocked")
	await director.say("steve", "Friendliest apocalypse I've ever been in!")
	fly.kill()
	away.kill()
	boss.global_position = home
	boss.set_flap(1.0)
	director.end()


## The chasm. Nobody could have predicted what fills it.
func _ship_crash() -> void:
	if _ship_done or director.active:
		return
	_ship_done = true
	player.spawn_point = Vector3(-4, 11.5, -142)
	director.begin()
	player.velocity = Vector3.ZERO
	player.speed = 0.0
	player.place(Vector3(0, 11.2, -148), 0.0)
	var sp := player.global_position
	director.shot(sp + Vector3(-2.5, 1.5, -3), sp + Vector3(0, 1.3, 0), 38.0)
	await director.say("stax", "A chasm. Of course there's a chasm. I don't suppose anybody has a—", "facepalm")
	Audio.play("hit_low", 0.4)
	await director.wait(0.5)
	await director.say("parrot", "SQUAWK! INCOMING! INCOMING!")
	# Out of the sky, sideways, on fire, and very late.
	_ship.visible = true
	director.shot(Vector3(26, 20, -150), SHIP_AT + Vector3(0, 12, 0), 60.0)
	Audio.play("whoosh", 0.4)
	Game.fx.flash(Color(0.8, 0.9, 1.0), 0.5)
	var fall := create_tween().set_parallel()
	fall.tween_property(_ship, "position", SHIP_AT, 1.4).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	fall.tween_property(_ship, "rotation", Vector3(0, 0, 0.03), 1.4)
	await director.wait(1.4)
	fall.kill()
	_ship.position = SHIP_AT
	_ship.rotation = Vector3(0, 0, 0.03)
	_ship_deck.collision_layer = 1
	Audio.play("boom")
	Audio.play("hit_low")
	Audio.play("clang", 0.6)
	director.shake(1.0)
	Fx.burst(self, SHIP_AT + Vector3(0, 1, -16), Color(0.95, 0.9, 1.0, 0.9), 80, 16.0, 1.2, 1.4, -6.0)
	Fx.burst(self, SHIP_AT + Vector3(0, 1, 16), Color(1.0, 0.5, 0.2, 0.9), 60, 14.0, 1.0, 1.2, -6.0)
	var cap := Puppet.new()
	cap.kind = "moneybeard"
	cap.speaker = "moneybeard"
	cap.scale = Vector3.ONE * 1.3
	add_child(cap)
	cap.global_position = SHIP_AT + Vector3(0, 0, 6)
	director.actors["moneybeard"] = cap
	director.shot(SHIP_AT + Vector3(6, 3.5, 12), SHIP_AT + Vector3(0, 2.4, 6), 40.0)
	cap.emote = "laugh"
	await director.lines([
		["moneybeard", "ARRR! Ahoy, landlubber! Remember me?"],
		["stax", "You were three rubber ducks in a coat!", "point"],
		["moneybeard", "And I'm STILL three rubber ducks in a coat! Plus a new ship! Plus a bridge now, apparently!"],
		["stax", "How did you even get here?!", "shrug"],
		["moneybeard", "Pirates don't explain, lad. We ARRIVE."],
		["parrot", "SQUAWK! Also we can't steer! Can't steer!"],
	])
	cap.emote = ""
	cap.queue_free()
	npc("moneybeard", "moneybeard", SHIP_AT + Vector3(-2.5, 0, 6), 0.4, [
		["moneybeard", "Cross, lad! The Golden Goose II holds! Mostly! Don't jump too hard near the back!"],
		["parrot", "SQUAWK! Insurance won't cover this! Won't cover this!"],
	], [["moneybeard", "Arr. Go get 'em. And tell that sign he still owes me a convenience fee."]])
	player.place(Vector3(0, 11.2, -148), 0.0)
	director.end()


## Lord Tick-Tock the Eternal makes a guest appearance.
func _time_freeze() -> void:
	if _time_done or director.active:
		return
	_time_done = true
	player.spawn_point = Vector3(-4, 11.5, -185)
	director.begin()
	player.velocity = Vector3.ZERO
	player.speed = 0.0
	player.place(Vector3(0, 11.2, -191.5), 0.0)
	var sp := player.global_position
	director.shot(sp + Vector3(3, 3, 5), Vector3(0, 12, -214), 45.0)
	await director.say("stax", "Walls of fire. Very fast walls of fire. That's... not possible. That is not a possible thing.", "shocked")
	Audio.play("bong", 0.5)
	var tt := Puppet.new()
	tt.kind = "grandclock"
	tt.speaker = "ticktock"
	add_child(tt)
	tt.global_position = Vector3(3.5, 11, -189)
	tt.rotation.y = -0.6
	director.actors["ticktock"] = tt
	Fx.burst(self, tt.global_position + Vector3(0, 2, 0), Color(0.8, 0.9, 1.0), 40, 6.0, 0.4, 1.0, 0.0)
	director.two_shot(player, tt, -1.0, 48.0)
	await director.lines([
		["ticktock", "Ahem. Young one. Twelve hundred years I guarded midnight. And then you beat me in eleven seconds."],
		["stax", "Lord Tick-Tock! I'm sorry about your back.", "shrug"],
		["ticktock", "My back is fine. My PRIDE is not. But a debt is a debt. Allow me... a moment."],
	])
	# Time slows down. Everything but Stax.
	tt.emote = "attack"
	Audio.play("bong", 0.35)
	Audio.play("whoosh", 0.3)
	Game.fx.flash(Color(0.6, 0.8, 1.0), 1.0)
	director.shake(0.3)
	_slow_firewalls()
	director.shot(Vector3(8, 16, -200), Vector3(0, 12, -218), 55.0)
	await director.wait(1.4)
	await director.say("ticktock", "There. The walls will dawdle now. Like me on a staircase.")
	await director.say("stax", "Thank you! You're the best! Well. Second best. I beat you.", "cheer")
	await director.say("ticktock", "...Go.")
	tt.emote = ""
	tt.queue_free()
	npc("grandclock", "ticktock", Vector3(3.5, 11, -189), -0.6, [
		["ticktock", "The walls are slowed, young one. Run between them. Do not dawdle. Dawdling is MY thing."],
	], [["ticktock", "Tick... tock... Go on. I shall hold the moment."]])
	player.place(Vector3(0, 11.2, -191.5), 0.0)
	director.end()


func _slow_firewalls() -> void:
	for fw in _firewalls:
		# Keep each wall where it is in its cycle while it slows down.
		var old: float = fw.bob_speed
		fw.bob_speed = 0.28
		fw._t = fw._t * old / fw.bob_speed
	# A ghostly clock face hangs over the gauntlet while time is slow.
	_clock_ghost = Node3D.new()
	add_child(_clock_ghost)
	_clock_ghost.global_position = Vector3(0, 30, -214)
	var disc := CylinderMesh.new()
	disc.top_radius = 14.0
	disc.bottom_radius = 14.0
	disc.height = 0.2
	deco(disc, Mats.unshaded(Color(0.6, 0.8, 1.0), 0.15), Vector3.ZERO, Vector3(PI / 2, 0, 0), Vector3.ONE, _clock_ghost)
	for i in 12:
		var a := TAU * i / 12.0
		deco(_box_mesh(Vector3(0.6, 2.0, 0.3)), Mats.unshaded(Color(0.8, 0.9, 1.0), 0.5), Vector3(sin(a) * 12.0, cos(a) * 12.0, 0.2), Vector3(0, 0, -a), Vector3.ONE, _clock_ghost)
	deco(_box_mesh(Vector3(0.6, 10.0, 0.3)), Mats.unshaded(Color(0.9, 0.95, 1.0), 0.6), Vector3(0, 5.0, 0.3), Vector3.ZERO, Vector3.ONE, _clock_ghost)


func _box_mesh(size: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = size
	return b


func _start_boss() -> void:
	if _fight_started or director.active:
		return
	_fight_started = true
	player.spawn_point = ARENA + Vector3(-4, 0.5, ARENA_R - 3)
	director.begin()
	Audio.stop_music(0.6)
	player.velocity = Vector3.ZERO
	player.speed = 0.0
	player.place(ARENA + Vector3(0, 0.2, ARENA_R - 6), 0.0)
	var ice: Node3D = boss.heads[0]
	var fire: Node3D = boss.heads[1]
	director.actors["coldcash"] = ice
	director.actors["burnrate"] = fire
	director.shot(ARENA + Vector3(0, 6, ARENA_R + 6), DRAGON_AT + Vector3(0, 18, 0), 55.0)
	director.move(ARENA + Vector3(0, 3, 4), DRAGON_AT + Vector3(0, 22, 0), 4.0, 48.0)
	Audio.play("rumble", 0.6)
	await director.wait(1.5)
	director.shot(ice.global_position + Vector3(-7, -2, 12), ice.global_position, 40.0)
	await director.say("coldcash", "So. You're the one who opened the Vault.")
	director.shot(fire.global_position + Vector3(7, -2, 12), fire.global_position, 40.0)
	fire.emote = "roar"
	await director.say("burnrate", "EVERY COIN in the multiverse came out of OUR HOARD!")
	fire.emote = ""
	director.two_shot(player, boss, 1.0, 62.0)
	await director.lines([
		["coldcash", "I am Cold Hard Cash."],
		["burnrate", "And I'm the BURN RATE! Money goes in, money goes out, WHOOSH!"],
		["stax", "Wait. You two are... a metaphor?", "think"],
		["coldcash", "We're a dragon, kid."],
		["burnrate", "We're ALSO a metaphor!"],
		["coldcash", "Don't tell him that."],
		["stax", "Okay. I beat a sign, a baby and a pirate made of ducks. Let's do this.", "cool"],
	])
	for h in boss.heads:
		h.emote = "roar"
	Audio.play("thunder")
	Audio.play("boom", 0.7)
	Game.fx.flash(Color(1.0, 0.9, 1.0), 0.6)
	director.shake(1.0)
	Audio.play_music("dragon", 0.2)
	Audio.set_drums(1.0)
	director.shot(ARENA + Vector3(0, 10, ARENA_R + 8), DRAGON_AT + Vector3(0, 16, 0), 62.0)
	director.move(ARENA + Vector3(0, 6, ARENA_R + 2), DRAGON_AT + Vector3(0, 18, 0), 3.0)
	await director.title("FINAL BOSS (FOR REAL THIS TIME)", "Cold Hard Cash & Burn Rate", "The Twin Dragon of the Frostfire Rift", 1.8)
	await director.settle()
	for h in boss.heads:
		h.emote = ""
	player.place(ARENA + Vector3(0, 0.2, ARENA_R - 6), 0.0)
	director.end()
	boss.player = player
	boss.hit.connect(func(hp): hud.set_boss_hp(hp))
	boss.defeated.connect(_on_boss_defeated)
	boss.phase_two.connect(_on_phase_two)
	hud.show_boss("COLD HARD CASH & BURN RATE", boss.MAX_HP)
	boss.start()
	bark("steve", "Jump the fire! Dodge the icicles! When a head flops down... STOMP IT!")


func on_boss_rest() -> void:
	if not _told_rest:
		_told_rest = true
		bark("stax", "His head's down! Stomp it or ground pound it!")


## Half health: the sky catches fire and freezes at the same time.
func _on_phase_two() -> void:
	sky_mat.set_shader_parameter("top_color", Color(0.25, 0.02, 0.1))
	sky_mat.set_shader_parameter("horizon_color", Color(1.0, 0.35, 0.2))
	sky_mat.set_shader_parameter("nebula", 1.0)
	env.fog_light_color = Color(0.8, 0.3, 0.4)
	Game.fx.aberrate(1.0, 1.5)
	bark("burnrate", "FROSTFIRE! Both of us! AT THE SAME TIME!")
	await get_tree().create_timer(2.2).timeout
	if boss.state != boss.B.DEAD:
		bark("coldcash", "...Fine. FROSTFIRE. And tell the volcano to start throwing things.")


func _on_boss_defeated() -> void:
	boss_beaten()
	if complete:
		return
	complete = true
	hud.hide_boss()
	await get_tree().create_timer(1.0).timeout
	await _ending()
	Game.complete_level(player.coins)


func _ending() -> void:
	director.begin()
	Audio.stop_music(1.5)
	player.velocity = Vector3.ZERO
	var ice: Node3D = boss.heads[0]
	var fire: Node3D = boss.heads[1]
	director.actors["coldcash"] = ice
	director.actors["burnrate"] = fire
	player.place(ARENA + Vector3(0, 0.2, -4), 0.0)
	director.face(ARENA + Vector3(0, 0, -ARENA_R))
	await director.wait(1.2)
	director.shot(ARENA + Vector3(0, 3, 6), ARENA + Vector3(0, 2, -ARENA_R + 5), 50.0)
	await director.lines([
		["burnrate", "Okay. Okay. Truce. Ow. My everything."],
		["coldcash", "We only ever wanted... balance."],
		["burnrate", "Half of us freezing, half of us on fire. For a thousand years. Just ONCE, we wanted to feel..."],
		["coldcash", "...Lukewarm."],
		["stax", "That is the saddest thing I have ever heard.", "shrug"],
		["stax", "Hey. What if you breathed on EACH OTHER?", "think"],
		["burnrate", "..."],
		["coldcash", "...Huh."],
	])
	# Fire meets ice. STEAM.
	for h in boss.heads:
		h.emote = "roar"
	Audio.play("zap", 0.4)
	Audio.play("rumble", 0.5)
	director.shake(0.8)
	var mid := ARENA + Vector3(0, 3, -6)
	Fx.burst(self, mid, Color(1, 1, 1, 0.95), 200, 20.0, 3.0, 3.0, 3.0)
	Fx.burst(self, mid, Color(0.8, 0.9, 1.0, 0.8), 80, 14.0, 0.6, 1.5, -2.0, "cube")
	Fx.burst(self, mid, Color(1.0, 0.6, 0.2, 0.8), 80, 14.0, 0.6, 1.5, -2.0)
	Game.fx.flash(Color(1, 1, 1), 1.2)
	director.shot(ARENA + Vector3(10, 8, 16), mid, 60.0)
	await director.wait(1.5)
	# ...and when the steam clears, the arena is a hot tub.
	var spring := deco_cyl(ARENA + Vector3(0, 0.1, -3), 9.0, 0.3, Mats.glow(Color(0.4, 0.95, 0.95), 0.9))
	spring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	Fx.ambient(self, ARENA + Vector3(0, 2, -3), Vector3(8, 1.5, 8), Color(1, 1, 1, 0.5), 160, 0.6, Vector3(0, 1.2, 0), 3.0)
	for h in boss.heads:
		h.emote = ""
	await director.say("coldcash", "...Lukewarm.")
	fire.emote = "roar"
	await director.say("burnrate", "LUKEWARM!!! IT'S BEAUTIFUL!!!")
	fire.emote = ""
	# Everyone shows up. Nobody explains how.
	Audio.play_music("credits", 0.5)
	Audio.play("fanfare")
	var guests := [
		["steve", "steve", 1.0], ["moneybeard", "moneybeard", 1.0], ["grandclock", "ticktock", 0.8],
		["baby", "baby", 1.3], ["teddy", "teddy", 1.3], ["baron", "baron", 1.0], ["waffle", "waffle", 1.2],
		["gary", "gary", 1.1], ["lefty", "lefty", 1.0], ["camel", "camel", 1.0], ["duck", "parrot", 1.3],
		["cuckoo", "cuckoo", 1.1], ["doodle", "doodle", 1.2], ["pigeon", "pigeon", 1.4],
	]
	var party: Array[Node3D] = []
	for i in guests.size():
		var g: Array = guests[i]
		var pup := Puppet.new()
		pup.kind = g[0]
		pup.speaker = g[1]
		pup.scale = Vector3.ONE * g[2]
		add_child(pup)
		var a := PI + TAU * i / guests.size()
		var at := ARENA + Vector3(sin(a) * 7.0, 0, -3 + cos(a) * 7.0)
		pup.global_position = at + Vector3(0, 12, 0)
		pup.look_at(ARENA + Vector3(0, pup.global_position.y, -3), Vector3.UP)
		create_tween().tween_property(pup, "global_position", at, 0.6 + i * 0.08).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
		party.append(pup)
	director.actors["steve"] = party[0]
	director.actors["baby"] = party[3]
	director.actors["moneybeard"] = party[1]
	director.orbit(ARENA + Vector3(0, 2, -3), 16.0, 6.0, 0.3, 1.4, 6.0, 55.0)
	await director.wait(2.0)
	await director.lines([
		["stax", "Is... is EVERYONE here?!", "shocked"],
		["steve", "Hot tub party! It's a sequel tradition!"],
		["baby", "SPLASH! Baby SHARE the hot tub! Baby learned sharing!"],
		["moneybeard", "Arr! Nobody asked how I got here, and I'm not telling!"],
		["burnrate", "Can we come to the next one?"],
		["coldcash", "...We'll bring the ice. And the fire. Obviously."],
	])
	var sp := player.global_position
	player.model.emote = "dance"
	for pup in party:
		pup.emote = "cheer"
	director.orbit(sp + Vector3(0, 1.4, 0), 6.0, 1.5, player.facing + PI / 2, player.facing + PI / 2 + 1.4, 5.0)
	await director.title("", "THE END", "(for real this time)", 2.0)
	director.shot(party[0].global_position + Vector3(0, 2.0, 3.2).rotated(Vector3.UP, party[0].rotation.y), party[0].global_position + Vector3(0, 1.8, 0), 34.0)
	await director.say("steve", "Chapter ten?")
	director.shot(sp + Vector3(0, 1.0, -3.2).rotated(Vector3.UP, player.facing), sp + Vector3(0, 0.9, 0), 34.0)
	await director.say("stax", "STEVE.", "facepalm")
	await Game.fx.fade_out(1.5)
	director.end()


## Used by tests/level_smoke.gd: fights the dragon to the end (the test then
## waits for the ending to hand over to the credits).
func test_hook(tree: SceneTree) -> bool:
	for n in 900:
		if not director.active:
			break
		director.skip()
		await tree.physics_frame
	_start_boss()
	for n in 900:
		if director.active:
			director.skip()
		elif boss.state != boss.B.WAIT:
			break
		await tree.physics_frame
	for i in boss.MAX_HP:
		boss.take_hit()
		for n in 90:
			if director.active:
				director.skip()
			await tree.physics_frame
	return boss.hp <= 0
