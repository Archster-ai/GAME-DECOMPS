extends "res://scripts/world/level_base.gd"
## Chapter 2: The Breakfast Dimension. Stax falls out of a pastel morning sky
## onto a giant pancake and climbs to the top of the Great Pancake Tower.
## Route: landing pancake -> butter stepping stones -> egg bounce -> bacon
## bridge -> spinning plate -> strawberries -> brunch plate (Sir Waffleton)
## -> waffle wall-kick shaft -> toaster lifts -> juice terrace -> bacon ->
## spiral climb around the Great Pancake Tower.

const LAYER := 1.1
const TOWER := Vector3(-12, 0, -178)
const TOWER_TOP := 60.0
const TOWER_R := 8.0
const ORBIT_R := 13.0
const TERRACE := Vector3(10, 33, -154.5)
const TOASTER := Vector3(10, 21, -143)
const PLATE := Vector3(0, 10, -86)
const PLATEAU := Vector3(0, 10, -119)
const FALLS := Vector3(28, 0, -154.5)
const SEA_Y := -4.0

const PANCAKE_SHADER := """
shader_type spatial;
uniform vec3 side_color : source_color = vec3(0.98, 0.76, 0.42);
uniform vec3 top_light : source_color = vec3(0.88, 0.52, 0.18);
uniform vec3 top_dark : source_color = vec3(0.55, 0.26, 0.06);
varying vec3 wp;
varying vec3 wn;
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}
void vertex() {
	wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	wn = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
}
void fragment() {
	float n = noise(wp.xz * 0.7) * 0.6 + noise(wp.xz * 2.6) * 0.4;
	float spots = smoothstep(0.62, 0.85, noise(wp.xz * 1.9 + 11.0));
	vec3 top = mix(top_light, top_dark, clamp(n * 0.7 + spots * 0.6, 0.0, 1.0));
	float up = smoothstep(0.5, 0.92, abs(normalize(wn).y));
	float band = noise(vec2((wp.x + wp.z) * 1.4, wp.y * 7.0));
	vec3 side = side_color * (0.88 + 0.16 * band);
	ALBEDO = mix(side, top, up);
	ROUGHNESS = mix(0.85, 0.62, up);
}
"""

const BERRY_SHADER := """
shader_type spatial;
uniform vec3 base : source_color = vec3(0.92, 0.1, 0.16);
uniform vec3 seed : source_color = vec3(1.0, 0.86, 0.4);
varying vec3 lp;
void vertex() { lp = normalize(VERTEX); }
void fragment() {
	vec2 uv = vec2(atan(lp.z, lp.x) / 6.2832 * 16.0, acos(clamp(lp.y, -1.0, 1.0)) / 3.1416 * 9.0);
	vec2 g = fract(uv + vec2(floor(uv.y) * 0.5, 0.0)) - 0.5;
	float s = 1.0 - smoothstep(0.09, 0.15, length(g * vec2(1.0, 1.5)));
	s *= smoothstep(0.92, 0.7, lp.y);
	ALBEDO = mix(base * (0.85 + 0.25 * lp.y), seed, s);
	ROUGHNESS = mix(0.22, 0.6, s);
	CLEARCOAT = 0.6;
}
"""

const SEA_SHADER := """
shader_type spatial;
uniform vec3 deep : source_color = vec3(0.3, 0.12, 0.02);
uniform vec3 shallow : source_color = vec3(0.82, 0.44, 0.08);
varying vec3 wp;
void vertex() { wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
void fragment() {
	vec2 p = wp.xz;
	float t = TIME * 0.35;
	float a = p.x * 0.07 + t * 2.0 + sin(p.y * 0.045) * 2.0;
	float b = p.y * 0.09 - t * 1.6 + sin(p.x * 0.035) * 3.0;
	float w = sin(a) + sin(b);
	float c = sin(p.x * 0.6 + p.y * 0.4 + t * 5.0) * sin(p.y * 0.5 - p.x * 0.2 - t * 4.0);
	vec3 n = normalize(vec3(cos(a) * 0.12 + c * 0.05, 1.0, cos(b) * 0.12 + c * 0.05));
	NORMAL = normalize((VIEW_MATRIX * vec4(n, 0.0)).xyz);
	float fres = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), 3.0);
	ALBEDO = mix(deep, shallow, 0.4 + 0.2 * w);
	ROUGHNESS = 0.05;
	SPECULAR = 0.6;
	CLEARCOAT = 0.5;
	EMISSION = shallow * (0.2 + fres * 0.2);
}
"""

const FALL_SHADER := """
shader_type spatial;
render_mode cull_disabled;
uniform vec4 color : source_color = vec4(1.0, 0.6, 0.1, 0.8);
uniform vec3 foam : source_color = vec3(1.0, 0.92, 0.6);
uniform float speed = 1.0;
uniform float glow = 0.8;
void fragment() {
	float f = sin(UV.y * 90.0 - TIME * speed * 12.0 + sin(UV.x * 37.7) * 2.0) * 0.5 + 0.5;
	float g = sin(UV.x * 62.8 + sin(UV.y * 20.0 - TIME * 3.0)) * 0.5 + 0.5;
	vec3 c = mix(color.rgb, foam, f * g * 0.5);
	ALBEDO = c;
	EMISSION = c * glow;
	ROUGHNESS = 0.08;
	//ALPHA
}
"""

var _rng := RandomNumberGenerator.new()
var _m_pancake: ShaderMaterial
var _m_core: Material
var _m_syrup: StandardMaterial3D
var _m_butter: StandardMaterial3D
var _m_white: Material
var _m_yolk: Material
var _m_berry: ShaderMaterial
var _m_blue: Material
var _m_leaf: Material
var _m_bacon: StandardMaterial3D
var _m_waffle: StandardMaterial3D
var _m_toast: Material
var _m_crust: Material
var _m_chrome: Material
var _m_plate: Material
var _m_rim: Material
var _m_cream: Material
var _steve: Node3D
var _waffle: Node3D
var _gate: StaticBody3D
var _gate_open := false


func _init() -> void:
	music = "breakfast"
	spawn_point = Vector3(0, 4.3, 5)
	spawn_yaw = 0.0
	kill_y = -12.0


func env_config() -> Dictionary:
	return {
		"top": Color(0.42, 0.58, 1.0), "horizon": Color(1.0, 0.76, 0.66), "bottom": Color(0.95, 0.6, 0.42),
		"sun_color": Color(1.0, 0.86, 0.66), "sun_energy": 1.5, "sun_angle": Vector2(-26, 150),
		"sun_size": 3.0, "sun_glow": 1.0, "clouds": 0.6, "cloud_color": Color(1.0, 0.9, 0.95),
		"fog_color": Color(1.0, 0.8, 0.76), "fog_density": 0.0018, "fog_sky": 0.08, "volumetric": 0.002,
		"vol_color": Color(1.0, 0.9, 0.85), "ambient": 0.9, "exposure": 0.95, "glow": 0.6,
		"tint": Color(1.0, 0.99, 0.98), "saturation": 1.2, "env_saturation": 1.15, "vignette": 0.3,
	}


# ---------------------------------------------------------------- build

func build() -> void:
	_rng.seed = 2024
	_make_materials()
	_build_sea()
	_build_start()
	_build_bacon_run()
	_build_plateau()
	_build_waffle_shaft()
	_build_toaster()
	_build_terrace()
	_build_tower()
	_build_scenery()
	Fx.ambient(self, Vector3(5, 22, -90), Vector3(45, 22, 110), Color(1.0, 0.95, 0.85, 0.5), 220, 0.12)


func _make_materials() -> void:
	var sh := Shader.new()
	sh.code = PANCAKE_SHADER
	_m_pancake = ShaderMaterial.new()
	_m_pancake.shader = sh
	_m_core = Mats.solid(Color(0.45, 0.24, 0.08), 0.9)
	_m_syrup = StandardMaterial3D.new()
	_m_syrup.albedo_color = Color(0.68, 0.37, 0.06)
	_m_syrup.roughness = 0.14
	_m_syrup.clearcoat_enabled = true
	_m_syrup.clearcoat_roughness = 0.05
	_m_syrup.emission_enabled = true
	_m_syrup.emission = Color(0.55, 0.28, 0.03)
	_m_syrup.emission_energy_multiplier = 0.3
	_m_butter = StandardMaterial3D.new()
	_m_butter.albedo_color = Color(1.0, 0.9, 0.5)
	_m_butter.roughness = 0.3
	_m_butter.emission_enabled = true
	_m_butter.emission = Color(0.4, 0.33, 0.08)
	_m_butter.emission_energy_multiplier = 0.35
	_m_white = Mats.solid(Color(0.98, 0.97, 0.93), 0.35)
	_m_yolk = Mats.glow(Color(1.0, 0.68, 0.08), 0.35)
	var bs := Shader.new()
	bs.code = BERRY_SHADER
	_m_berry = ShaderMaterial.new()
	_m_berry.shader = bs
	_m_blue = Mats.solid(Color(0.24, 0.28, 0.62), 0.55)
	_m_leaf = Mats.solid(Color(0.3, 0.7, 0.25), 0.6)
	_m_bacon = _bacon_mat()
	_m_waffle = _waffle_mat()
	_m_toast = Mats.rough_surface(Color(0.97, 0.82, 0.52), Color(0.86, 0.58, 0.26), 0.5, 0.9, 3, 0.8)
	_m_crust = Mats.solid(Color(0.5, 0.28, 0.1), 0.8)
	_m_chrome = Mats.solid(Color(0.72, 0.78, 0.88), 0.22, 1.0)
	_m_plate = Mats.solid(Color(0.97, 0.97, 1.0), 0.15)
	_m_rim = Mats.solid(Color(0.4, 0.6, 0.95), 0.2)
	_m_cream = Mats.solid(Color(1.0, 0.98, 0.95), 0.5)


## Wavy streaks of meat and fat, tiling seamlessly.
func _bacon_mat() -> StandardMaterial3D:
	var img := Image.create(64, 64, false, Image.FORMAT_RGBA8)
	var meat := Color(0.62, 0.22, 0.12)
	var dark := Color(0.4, 0.13, 0.06)
	var fat := Color(0.93, 0.72, 0.55)
	for y in 64:
		for x in 64:
			var v := sin((x + sin(y * TAU / 32.0) * 3.0) * TAU / 64.0 * 3.0)
			var d := sin((x * 2.0 + y) * TAU / 64.0) * 0.5 + 0.5
			var c := fat.lerp(meat.lerp(dark, d * 0.6), smoothstep(-0.25, 0.25, v))
			img.set_pixel(x, y, c)
	img.generate_mipmaps()
	var m := StandardMaterial3D.new()
	m.albedo_texture = ImageTexture.create_from_image(img)
	m.roughness = 0.4
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	m.uv1_scale = Vector3.ONE * 0.26
	return m


## Golden waffle pockets with a matching normal map.
func _waffle_mat() -> StandardMaterial3D:
	var col := Image.create(64, 64, false, Image.FORMAT_RGBA8)
	var hgt := Image.create(64, 64, false, Image.FORMAT_RGBA8)
	var ridge := Color(0.96, 0.74, 0.4)
	var pocket := Color(0.72, 0.44, 0.17)
	for y in 64:
		for x in 64:
			var lx := x % 32
			var ly := y % 32
			var e := mini(mini(lx, 31 - lx), mini(ly, 31 - ly))
			var h := 1.0 - smoothstep(3.0, 7.0, float(e))
			var n := float((x * 13 + y * 7 + (x * y) % 11) % 17) / 17.0
			var cc := pocket.lerp(ridge, h) * (0.94 + n * 0.1)
			cc.a = 1.0
			col.set_pixel(x, y, cc)
			hgt.set_pixel(x, y, Color(h, h, h))
	hgt.bump_map_to_normal_map(8.0)
	col.generate_mipmaps()
	hgt.generate_mipmaps()
	var m := StandardMaterial3D.new()
	m.albedo_texture = ImageTexture.create_from_image(col)
	m.normal_enabled = true
	m.normal_texture = ImageTexture.create_from_image(hgt)
	m.normal_scale = 1.2
	m.roughness = 0.7
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	m.uv1_scale = Vector3.ONE * 0.6
	return m


func _fall_mat(color: Color, alpha: float, glow: float, speed := 1.0, foam := Color(1.0, 0.92, 0.6)) -> ShaderMaterial:
	var sh := Shader.new()
	sh.code = FALL_SHADER.replace("//ALPHA", "ALPHA = color.a;") if alpha < 1.0 else FALL_SHADER
	var m := ShaderMaterial.new()
	m.shader = sh
	m.set_shader_parameter("color", Color(color, alpha))
	m.set_shader_parameter("glow", glow)
	m.set_shader_parameter("speed", speed)
	m.set_shader_parameter("foam", foam)
	return m


# ---------------------------------------------------------------- food builders

## Bakes [PrimitiveMesh, Transform3D] pairs into one mesh (one draw call).
func _merge(parts: Array) -> ArrayMesh:
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var uvs := PackedVector2Array()
	var idx := PackedInt32Array()
	for p in parts:
		var arr: Array = (p[0] as PrimitiveMesh).get_mesh_arrays()
		var xf: Transform3D = p[1]
		var base := verts.size()
		for v in arr[Mesh.ARRAY_VERTEX]:
			verts.append(xf * v)
		for n in arr[Mesh.ARRAY_NORMAL]:
			norms.append((xf.basis * n).normalized())
		uvs.append_array(arr[Mesh.ARRAY_TEX_UV])
		for i in arr[Mesh.ARRAY_INDEX]:
			idx.append(base + i)
	var out := []
	out.resize(Mesh.ARRAY_MAX)
	out[Mesh.ARRAY_VERTEX] = verts
	out[Mesh.ARRAY_NORMAL] = norms
	out[Mesh.ARRAY_TEX_UV] = uvs
	out[Mesh.ARRAY_INDEX] = idx
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, out)
	return m


## One pancake: a flat cylinder with a rounded torus rim.
func _pancake_parts(r: float, xf: Transform3D, out: Array) -> void:
	var c := CylinderMesh.new()
	c.top_radius = r - LAYER * 0.5
	c.bottom_radius = r - LAYER * 0.5
	c.height = LAYER
	c.radial_segments = 36
	c.rings = 1
	var t := TorusMesh.new()
	t.inner_radius = r - LAYER
	t.outer_radius = r
	t.rings = 44
	t.ring_segments = 10
	out.append([c, xf])
	out.append([t, xf])


## A floating stack of pancakes with its top at `top`, syrup and a butter pat.
func stack(x: float, z: float, top: float, radius: float, layers: int, butter := true, drips := 4, solid := true) -> Node3D:
	var h := layers * LAYER
	var root: Node3D
	if solid:
		root = StaticBody3D.new()
	else:
		root = Node3D.new()
	root.position = Vector3(x, top - h * 0.5, z)
	add_child(root)
	if solid:
		var cs := CollisionShape3D.new()
		var shape := CylinderShape3D.new()
		shape.radius = radius - 0.15
		shape.height = h
		cs.shape = shape
		root.add_child(cs)
	var parts := []
	for i in layers:
		var r := radius if i == 0 else radius * _rng.randf_range(0.95, 1.035)
		var off := Vector3.ZERO if i == 0 else Vector3(_rng.randf_range(-0.25, 0.25), 0, _rng.randf_range(-0.25, 0.25))
		_pancake_parts(r, Transform3D(Basis(), off + Vector3(0, h * 0.5 - LAYER * (i + 0.5), 0)), parts)
	deco(_merge(parts), _m_pancake, Vector3.ZERO, Vector3.ZERO, Vector3.ONE, root)
	var core := CylinderMesh.new()
	core.top_radius = radius * 0.86
	core.bottom_radius = radius * 0.86
	core.height = h - 0.3
	deco(core, _m_core, Vector3.ZERO, Vector3.ZERO, Vector3.ONE, root)
	if drips > 0:
		_syrup_top(root, radius, h * 0.5, drips, minf(h, 4.5))
	if butter:
		var a := _rng.randf() * TAU
		var bp := Vector3(cos(a), 0, sin(a)) * radius * 0.3
		var bs := clampf(radius * 0.32, 1.6, 3.2)
		if solid:
			box(Vector3(x + bp.x, top + 0.3, z + bp.z), Vector3(bs, 0.6, bs), _m_butter, Vector3(0, a, 0))
		else:
			deco_box(Vector3(x + bp.x, top + 0.3, z + bp.z), Vector3(bs, 0.6, bs), _m_butter, Vector3(0, a, 0))
	return root


## A glossy syrup puddle on top of a stack, spilling over the rim in drips.
func _syrup_top(parent: Node3D, radius: float, top_y: float, drips: int, max_len: float) -> void:
	var a := _rng.randf() * TAU
	var dir := Vector3(cos(a), 0, sin(a))
	var pr := radius * _rng.randf_range(0.5, 0.62)
	var parts := []
	var pool := CylinderMesh.new()
	pool.top_radius = pr
	pool.bottom_radius = pr
	pool.height = 0.06
	pool.radial_segments = 32
	parts.append([pool, Transform3D(Basis(), dir * (radius - pr - 0.15) + Vector3(0, top_y + 0.03, 0))])
	var blob := CylinderMesh.new()
	blob.top_radius = pr * 0.55
	blob.bottom_radius = pr * 0.55
	blob.height = 0.06
	var side := Vector3(-dir.z, 0, dir.x)
	parts.append([blob, Transform3D(Basis(), dir * (radius - pr * 1.4) + side * pr * 0.7 + Vector3(0, top_y + 0.035, 0))])
	for i in drips:
		var da := a + (float(i) / maxf(drips - 1, 1) - 0.5) * 0.9 * clampf(pr / radius * 2.0, 0.6, 1.4)
		var d := Vector3(cos(da), 0, sin(da))
		var ln := _rng.randf_range(0.6, max_len)
		var dr := _rng.randf_range(0.13, 0.2)
		var c := CylinderMesh.new()
		c.top_radius = dr
		c.bottom_radius = dr
		c.height = ln
		c.radial_segments = 8
		parts.append([c, Transform3D(Basis(), d * (radius + 0.02) + Vector3(0, top_y - ln * 0.5, 0))])
		var s := SphereMesh.new()
		s.radius = dr * 1.45
		s.height = dr * 3.4
		s.radial_segments = 10
		s.rings = 6
		parts.append([s, Transform3D(Basis(), d * (radius + 0.02) + Vector3(0, top_y - ln, 0))])
		var lip := SphereMesh.new()
		lip.radius = 0.35
		lip.height = 0.24
		lip.radial_segments = 10
		lip.rings = 4
		parts.append([lip, Transform3D(Basis(), d * (radius - 0.25) + Vector3(0, top_y, 0))])
	deco(_merge(parts), _m_syrup, Vector3.ZERO, Vector3.ZERO, Vector3.ONE, parent)


## A fried egg bounce pad.
func egg(pos: Vector3, strength := 24.0) -> Area3D:
	var v := Node3D.new()
	var s := SphereMesh.new()
	s.radius = 1.0
	s.height = 2.0
	s.radial_segments = 24
	s.rings = 10
	for i in 4:
		var a := i * TAU / 4.0 + _rng.randf_range(-0.3, 0.3)
		var off := Vector3(cos(a), 0, sin(a)) * _rng.randf_range(0.4, 0.7)
		deco(s, _m_white, off + Vector3(0, 0.08, 0), Vector3.ZERO, Vector3(1.4, 0.12, 1.4) * _rng.randf_range(0.9, 1.1), v)
	deco(s, _m_yolk, Vector3(0, 0.25, 0), Vector3.ZERO, Vector3(0.75, 0.42, 0.75), v)
	deco(s, Mats.unshaded(Color(1, 1, 1), 0.6), Vector3(-0.22, 0.52, -0.2), Vector3.ZERO, Vector3(0.16, 0.06, 0.12), v)
	return bouncer(pos, 1.5, strength, v)


func strawberry(pos: Vector3, r: float, solid := true) -> void:
	var node: Node3D
	if solid:
		node = ball(pos, r, _m_berry)
		var mi: MeshInstance3D = node.get_child(0)
		mi.scale = Vector3(1, 1.18, 1)
		mi.position.y = -r * 0.18
	else:
		node = deco_ball(pos, r, _m_berry, Vector3(1, 1.18, 1))
	for i in 6:
		var a := i * TAU / 6.0
		var leaf := deco_box(Vector3(cos(a) * r * 0.28, r * 0.97, sin(a) * r * 0.28), Vector3(r * 0.2, 0.06, r * 0.55), _m_leaf, Vector3(0.25, -a + PI / 2, 0))
		leaf.reparent(node, false)
		if solid:
			leaf.position.y -= 0.02
	var stem := deco_cyl(Vector3(0, r * 1.08, 0), r * 0.05, r * 0.25, _m_leaf)
	stem.reparent(node, false)
	if solid:
		stem.position.y = r - 0.1


func blueberry(pos: Vector3, r: float, solid := false) -> void:
	var node: Node3D
	if solid:
		node = ball(pos, r, _m_blue)
	else:
		node = deco_ball(pos, r, _m_blue, Vector3(1, 0.88, 1))
	var crown := deco_cyl(Vector3(0, r * 0.86, 0), r * 0.26, r * 0.12, Mats.solid(Color(0.12, 0.12, 0.28), 0.8), Vector3.ZERO, r * 0.18)
	crown.reparent(node, false)


## A wavy bacon bridge between two top points. Returns the surface points.
func bacon(a: Vector3, b: Vector3, n: int, wave := 0.7, sway := 1.5) -> Array:
	var pts := []
	var across := b - a
	across.y = 0
	var side := Vector3(-across.z, 0, across.x).normalized()
	for i in n + 1:
		var t := float(i) / n
		pts.append(a.lerp(b, t) + Vector3(0, sin(t * TAU * 1.5) * wave * sin(t * PI), 0) + side * sin(t * TAU) * sway)
	for i in n:
		var p0: Vector3 = pts[i]
		var p1: Vector3 = pts[i + 1]
		var d := p1 - p0
		var basis := Basis.looking_at(d, Vector3.UP)
		box((p0 + p1) * 0.5 - basis.y * 0.2, Vector3(2.6, 0.4, d.length() + 0.4), _m_bacon, basis.get_euler())
	return pts


func whipped_cream(pos: Vector3, s := 1.0, cherry := true) -> void:
	for i in 4:
		deco_cyl(pos + Vector3(0, (0.3 + i * 0.5) * s, 0), (1.3 - i * 0.3) * s, 0.7 * s, _m_cream, Vector3(0, i * 0.7, 0), (1.0 - i * 0.3) * s)
	if cherry:
		strawberry(pos + Vector3(0, 2.5 * s, 0), 0.55 * s, false)


# ---------------------------------------------------------------- the route

func _build_sea() -> void:
	var sea := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(1400, 1400)
	sea.mesh = pm
	var sh := Shader.new()
	sh.code = SEA_SHADER
	var m := ShaderMaterial.new()
	m.shader = sh
	sea.material_override = m
	sea.position = Vector3(0, SEA_Y, -100)
	sea.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(sea)
	zone(Vector3(0, SEA_Y - 0.6, -100), Vector3(1400, 1.5, 1400), "hurt")


func _build_start() -> void:
	# The landing pancake.
	stack(0, 0, 4.0, 9.0, 4, false, 6)
	box(Vector3(-3, 4.3, 0.5), Vector3(2.6, 0.6, 2.6), _m_butter, Vector3(0, 0.4, 0))
	deco_cyl(Vector3(-3, 4.02, 0.5), 2.2, 0.04, Mats.solid(Color(1.0, 0.94, 0.62), 0.2))
	coin(Vector3(-3, 10.6, 0.5), 5)
	coin_ring(Vector3(2, 5, -2), 4.0, 8)
	strawberry(Vector3(6.2, 5.3, 3.5), 1.4, false)
	blueberry(Vector3(-6.5, 4.7, -3.5), 0.9)
	blueberry(Vector3(-5.6, 4.6, -5.2), 0.75)
	_steve = npc("steve", "steve", Vector3(3.6, 4, -2.4), 2.65, [
		["steve", "Quick tips! Fried eggs are bounce pads. Land on one and up you go!"],
		["steve", "Syrup is hot and sticky. Don't touch it. Butter pats are safe to stand on."],
		["stax", "Eggs good, syrup bad, butter safe. What about the pancakes?", "think"],
		["steve", "The pancakes are the floor, Stax. Keep up."],
		["steve", "Key's on top of the Great Pancake Tower. Directions: free! Portal fee: pending."],
		["stax", "Portal fee?! I fell through that thing by accident!", "shocked"],
		["steve", "Accidents are billable! Kidding. Ha ha. ...Mostly."],
	], [["steve", "Eggs bounce, syrup burns, butter's safe. And tips are always appreciated!"]])
	# Welcome board.
	var wood := Mats.solid(Color(0.62, 0.42, 0.24), 0.85)
	deco_box(Vector3(-5.2, 5.1, -4.2), Vector3(0.25, 2.2, 0.25), wood)
	deco_box(Vector3(-2.2, 5.1, -4.2), Vector3(0.25, 2.2, 0.25), wood)
	deco_box(Vector3(-3.7, 6.5, -4.2), Vector3(4.4, 1.6, 0.2), wood)
	sign_text("WELCOME TO THE\nBREAKFAST DIMENSION\npop. delicious", Vector3(-3.7, 6.5, -4.08), PI, 36, Color(0.3, 0.15, 0.05))

	# Butter stepping stones over the syrup.
	var stones := [Vector3(0, 4.5, -13), Vector3(2, 5.3, -18), Vector3(-1, 4.8, -23)]
	for s in stones:
		box(s - Vector3(0, 0.5, 0), Vector3(2.6, 1.0, 2.6), _m_butter, Vector3(0, _rng.randf_range(-0.3, 0.3), 0))
		coin(s + Vector3(0, 1.1, 0))
	coin_arc(Vector3(0, 5.2, -9.5), Vector3(1.4, 5.8, -15.5), 1.2, 3)
	tip(Vector3(0, 5.5, -9), Vector3(10, 4, 3), "steve", "Tip: Butter pats are safe. Syrup is hot, sticky, and voids your warranty.")

	# Second stack with a toast soldier and the first egg.
	stack(0, -33, 4.0, 7.5, 4, true, 5)
	enemy("toast", Vector3(-4, 4, -31), Vector3(4, 4, -35))
	coin_line(Vector3(-3, 5, -29), Vector3(3, 5, -29), 4)
	egg(Vector3(0, 4, -38.5))
	coin_line(Vector3(0, 6.5, -39), Vector3(0, 11.5, -42), 5)
	blueberry(Vector3(5.5, 4.6, -37), 1.0)
	strawberry(Vector3(-5.8, 5.2, -35), 1.3, false)

	# High stack where the egg lands.
	stack(0, -48, 10.0, 6.0, 3, false, 4)
	whipped_cream(Vector3(-3.2, 10, -47), 1.0)
	enemy("toast", Vector3(-3, 10, -50.5), Vector3(3, 10, -50.5))
	coin_ring(Vector3(0, 11, -47), 2.2, 6)


func _build_bacon_run() -> void:
	var pts := bacon(Vector3(0, 10, -53.4), Vector3(0, 10, -80.6), 12, 0.9, 3.0)
	for i in range(1, pts.size() - 1):
		coin(pts[i] + Vector3(0, 1.1, 0))
	tip(Vector3(0, 11.5, -53), Vector3(8, 4, 3), "steve", "Tip: Bacon bridge! Crispy, wobbly, and only slightly structurally questionable.")
	for i in 4:
		var p: Vector3 = pts[2 + i * 3]
		blueberry(p + Vector3(-6 + i * 4, -7 - i, 0), 1.3)

	# The spinning plate.
	var plate := mover(Vector3(12, 0.8, 12), _m_plate, PLATE - Vector3(0, 0.4, 0), Vector3.ZERO, 4.0, 0.0, 0.55, "cylinder")
	var rim := TorusMesh.new()
	rim.inner_radius = 5.6
	rim.outer_radius = 6.3
	rim.rings = 48
	rim.ring_segments = 8
	deco(rim, _m_rim, Vector3(0, 0.35, 0), Vector3.ZERO, Vector3(1, 0.5, 1), plate)
	var ring := TorusMesh.new()
	ring.inner_radius = 4.3
	ring.outer_radius = 4.5
	ring.rings = 48
	ring.ring_segments = 4
	deco(ring, _m_rim, Vector3(0, 0.41, 0), Vector3.ZERO, Vector3(1, 0.1, 1), plate)
	var yolkish := SphereMesh.new()
	yolkish.radius = 0.6
	yolkish.height = 1.2
	for i in 3:
		var a := i * TAU / 3.0
		deco(yolkish, _m_blue, Vector3(cos(a) * 3.2, 0.7, sin(a) * 3.2), Vector3.ZERO, Vector3(1, 0.85, 1), plate)
	coin_ring(PLATE + Vector3(0, 1, 0), 2.0, 6)
	# Side ledge for daredevils.
	box(Vector3(13.5, 9.6, -86), Vector3(3, 1, 3), _m_butter, Vector3(0, 0.3, 0))
	coin(Vector3(13.5, 11.3, -86), 5)
	# Strawberry hop to the brunch plate.
	strawberry(Vector3(3, 7.8, -96.5), 2.4)
	strawberry(Vector3(-1.5, 8.6, -101.5), 2.4)
	coin(Vector3(3, 11.4, -96.5))
	coin(Vector3(-1.5, 12.2, -101.5))


func _build_plateau() -> void:
	# The brunch plate.
	cylinder(PLATEAU - Vector3(0, 0.6, 0), 15.0, 1.2, _m_plate, 64)
	var rim := TorusMesh.new()
	rim.inner_radius = 14.2
	rim.outer_radius = 15.4
	rim.rings = 64
	rim.ring_segments = 10
	deco(rim, _m_rim, PLATEAU - Vector3(0, 0.25, 0), Vector3.ZERO, Vector3(1, 0.45, 1))
	var inner := TorusMesh.new()
	inner.inner_radius = 11.6
	inner.outer_radius = 11.9
	inner.rings = 64
	inner.ring_segments = 4
	deco(inner, _m_rim, PLATEAU + Vector3(0, 0.01, 0), Vector3.ZERO, Vector3(1, 0.05, 1))
	checkpoint(Vector3(4, 10, -108), 0.0)

	# A river of hot syrup with melting butter pats.
	var sz := -118.0
	deco_box(Vector3(0, 10.06, sz), Vector3(28.2, 0.12, 8), _m_syrup)
	for x in [-13.0, -6.0, 5.0, 12.0]:
		deco_ball(Vector3(x, 10.1, sz + 4.0), 0.9, _m_syrup, Vector3(1.4, 0.15, 1))
		deco_ball(Vector3(x + 2.0, 10.1, sz - 4.0), 0.8, _m_syrup, Vector3(1.3, 0.15, 1))
	zone(Vector3(0, 10.35, sz), Vector3(28.2, 0.7, 8), "hurt")
	mover(Vector3(2.2, 0.8, 2.2), _m_butter, Vector3(0, 10.5, sz + 2.0), Vector3(0, -0.9, 0), 4.0, 0.0)
	mover(Vector3(2.2, 0.8, 2.2), _m_butter, Vector3(1.5, 10.5, sz - 2.0), Vector3(0, -0.9, 0), 4.0, 0.5)
	coin_line(Vector3(0, 12, sz + 2.0), Vector3(1.5, 12, sz - 2.0), 3)
	sign_text("CAUTION\nHOT SYRUP", Vector3(-7, 10.9, sz + 4.6), PI, 48, Color(0.75, 0.25, 0.05))
	deco_box(Vector3(-7, 10.9, sz + 4.5), Vector3(2.6, 1.0, 0.1), _m_butter)

	enemy("toast", Vector3(-10, 10, -127), Vector3(-3, 10, -127))
	enemy("toast", Vector3(3, 10, -126), Vector3(10, 10, -126))
	coin_arc(Vector3(-9, 11, -110), Vector3(-9, 11, -130), 1.2, 5)
	blueberry(Vector3(-8, 10.8, -108), 0.9)
	blueberry(Vector3(-6.6, 10.7, -106.8), 0.75)
	strawberry(Vector3(10.5, 11.3, -113), 1.4, false)
	whipped_cream(Vector3(7.5, 10, -129.5), 1.1)

	_waffle = npc("waffle", "waffle", Vector3(-1.2, 10, -131), PI, [
		["waffle", "HALT, traveler! None shall pass the Waffle Gate without answering my riddle!", "point"],
		["stax", "Cool fork. Is this gonna take long?", "shrug"],
		["waffle", "Riddle me this: what hath many holes, yet holdeth syrup most faithfully?"],
		["stax", "...A waffle. You're describing yourself, dude.", "facepalm"],
		["waffle", "Curses! Thou art wise beyond thy crumbs!", "shocked"],
		["waffle", "Then hear the legend! Atop the Great Pancake Tower gleameth a key of purest gold."],
		["waffle", "Many a knight hath climbed it. All returned... sticky."],
		["waffle", "And heed this, squire: beware the sign that asketh for tips."],
		["stax", "Steve? Pfft. He's a plank with eyebrows.", "shrug"],
		["waffle", "Very well! The gate is thine. Kick betwixt the waffle walls to ascend!", "cheer"],
	], [["waffle", "Kick betwixt the walls, good squire! Onward, to glory and brunch!", "cheer"]])


func _build_waffle_shaft() -> void:
	# Two waffle walls 4 m apart. The right one is the mesa the toaster sits on.
	box(Vector3(-4, 17, -137.5), Vector3(4, 14, 9), _m_waffle)
	box(Vector3(10, 15, -141), Vector3(16, 12, 16), _m_waffle)
	box(Vector3(0, 9.5, -137.5), Vector3(4, 1, 9), _m_waffle)
	box(Vector3(0, 17, -142.5), Vector3(4, 14, 1), _m_waffle)
	coin_line(Vector3(0, 12, -137.5), Vector3(0, 19.5, -137.5), 6)
	coin(Vector3(-4, 25.4, -137.5), 5)
	tip(Vector3(0, 11.5, -137), Vector3(4, 3, 4), "steve", "Tip: Jump at a wall, then jump again as you touch it. Waffles have great grip!")
	# The Waffle Gate, lowered once Sir Waffleton is satisfied.
	_gate = box(Vector3(0, 16, -133.6), Vector3(4, 12, 0.8), _m_waffle)
	var bar := Mats.solid(Color(0.85, 0.85, 0.9), 0.25, 0.9)
	for x in [-1.2, 0.0, 1.2]:
		var tine := deco_box(Vector3(x, 0, 0.5), Vector3(0.2, 12, 0.2), bar)
		tine.reparent(_gate, false)
	var halt := sign_text("HALT!\nRIDDLE\nREQUIRED", Vector3(0, 16.4, -132.85), PI, 64, Color(0.6, 0.08, 0.1))
	halt.reparent(_gate, true)
	for x in [-2.6, 2.6]:
		deco_cyl(Vector3(x, 12, -132.6), 0.35, 4.0, _m_crust)
		deco_ball(Vector3(x, 14.3, -132.6), 0.6, Mats.solid(Color(0.7, 0.1, 0.15), 0.6))


func _build_toaster() -> void:
	var c := TOASTER
	box(c + Vector3(0, 3, 0), Vector3(8, 6, 6), _m_chrome)
	deco_box(c + Vector3(0, 0.15, 0), Vector3(8.4, 0.3, 6.4), Mats.solid(Color(0.12, 0.12, 0.14), 0.5))
	for z in [-1.4, 1.4]:
		deco_cyl(c + Vector3(0, 6, z * 2.0), 0.5, 8, _m_chrome, Vector3(0, 0, PI / 2))
	var slot := Mats.solid(Color(0.08, 0.06, 0.05), 0.8)
	var hot := Mats.glow(Color(1.0, 0.4, 0.1), 3.0)
	for z in [-1.4, 1.4]:
		deco_box(c + Vector3(0, 6.01, z), Vector3(4.2, 0.04, 1.8), slot)
		deco_box(c + Vector3(0, 5.9, z), Vector3(3.9, 0.1, 1.5), hot)
	omni(c + Vector3(0, 7.5, 0), Color(1.0, 0.5, 0.2), 8.0, 1.5)
	# Lever and dial on the side.
	deco_box(c + Vector3(4.1, 3.5, 0), Vector3(0.3, 3.5, 0.5), slot)
	box(c + Vector3(4.5, 4.6, 0), Vector3(0.8, 0.5, 1.2), Mats.solid(Color(0.85, 0.15, 0.15), 0.4))
	deco_cyl(c + Vector3(4.05, 1.6, 1.6), 0.6, 0.2, slot, Vector3(0, 0, PI / 2))
	sign_text("LIGHT  ·  DARK  ·  CHAOS", c + Vector3(0, 1.5, 3.02), PI, 40, Color(0.2, 0.2, 0.25))
	# Toast lifts popping up out of the slots.
	for i in 2:
		var z := -1.4 if i == 0 else 1.4
		var t := mover(Vector3(3.6, 3.6, 1.4), _m_crust, c + Vector3(0, 4.5, -z), Vector3(0, 6.5, 0), 5.0, i * 0.5)
		for s in [-1.0, 1.0]:
			deco_box(Vector3(0, -0.05, s * 0.71), Vector3(3.1, 3.1, 0.02), _m_toast).reparent(t, false)
	coin(c + Vector3(0, 16.0, 1.4), 5)
	coin_line(c + Vector3(0, 8, 1.4), c + Vector3(0, 11, 1.4), 2)
	coin_line(c + Vector3(0, 8, -1.4), c + Vector3(0, 11, -1.4), 2)
	egg(c + Vector3(0, 0, 6))
	coin_line(c + Vector3(0, 2.5, 6), c + Vector3(0, 7, 4.4), 4)
	coin_line(c + Vector3(-6, 1, 7), c + Vector3(-6, 1, 1), 3)
	enemy("toast", Vector3(4, 21, -147.6), Vector3(16, 21, -147.6))
	tip(c + Vector3(0, 7, 0), Vector3(8, 3, 6), "steve", "Tip: Ride the toast up! The toaster's set to light. I checked. Mostly.")


func _build_terrace() -> void:
	var tr := TERRACE
	stack(tr.x, tr.z, tr.y, 9.0, 3, false, 6)
	box(Vector3(tr.x + 3.5, tr.y + 0.3, tr.z + 4.5), Vector3(2.6, 0.6, 2.6), _m_butter, Vector3(0, 0.5, 0))
	var dir := Vector2(TOWER.x - tr.x, TOWER.z - tr.z).normalized()
	var d3 := Vector3(dir.x, 0, dir.y)
	checkpoint(tr + d3 * 4.0, atan2(-d3.x, -d3.z))
	enemy("toast", Vector3(11, tr.y, -161.5), Vector3(16, tr.y, -156))
	coin_ring(tr + Vector3(0, 1, 0), 3.0, 8)
	whipped_cream(tr + Vector3(-4.5, 0, 2.5), 1.2)
	strawberry(tr + Vector3(6.0, 1.1, 3.0), 1.2, false)
	# Juice falls and the daredevil ledge beside them.
	box(Vector3(23.5, tr.y - 0.5, tr.z), Vector3(3, 1, 3), _m_butter, Vector3(0, 0.2, 0))
	coin(Vector3(23.5, tr.y + 1.2, tr.z), 5)
	_build_juice_falls()

	# Bacon bridge to the tower climb.
	var s0 := _orbit(_theta0(), ORBIT_R)
	var start := tr + d3 * 8.6
	var end := Vector3(s0.x, 34, s0.z) - d3 * 2.4
	var pts := bacon(start, end, 5, 0.4, 1.0)
	for i in range(1, pts.size() - 1):
		coin(pts[i] + Vector3(0, 1.1, 0))
	tip(start + Vector3(0, 1.5, 0) - d3 * 1.5, Vector3(6, 4, 6), "steve", "Tip: The Great Pancake Tower! I'd climb it with you, but... no legs. Tips welcome!")


func _build_juice_falls() -> void:
	var f := FALLS
	var col := CylinderMesh.new()
	col.top_radius = 1.9
	col.bottom_radius = 2.4
	col.height = 80.0
	col.radial_segments = 24
	col.cap_top = false
	col.cap_bottom = false
	var falls := deco(col, _fall_mat(Color(1.0, 0.5, 0.04), 0.85, 0.8), Vector3(f.x, 36, f.z))
	falls.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var splash := TorusMesh.new()
	splash.inner_radius = 2.0
	splash.outer_radius = 4.5
	deco(splash, Mats.glow(Color(1.0, 0.8, 0.4), 1.2), Vector3(f.x, SEA_Y + 0.1, f.z), Vector3.ZERO, Vector3(1, 0.25, 1))
	Fx.ambient(self, Vector3(f.x, SEA_Y + 1.5, f.z), Vector3(3.5, 1.5, 3.5), Color(1.0, 0.85, 0.5, 0.7), 60, 0.5, Vector3(0, 2.5, 0), 2.0)
	omni(Vector3(f.x - 3, 30, f.z), Color(1.0, 0.65, 0.25), 14.0, 1.4)
	# The giant carton pouring it.
	var carton := Node3D.new()
	carton.position = Vector3(f.x + 4.6, 78.5, f.z)
	carton.rotation.z = 2.05
	add_child(carton)
	var body := BoxMesh.new()
	body.size = Vector3(6, 9, 6)
	deco(body, Mats.solid(Color(0.98, 0.97, 0.94), 0.5), Vector3.ZERO, Vector3.ZERO, Vector3.ONE, carton)
	var band := BoxMesh.new()
	band.size = Vector3(6.1, 3.5, 6.1)
	deco(band, Mats.solid(Color(1.0, 0.55, 0.1), 0.5), Vector3(0, -0.8, 0), Vector3.ZERO, Vector3.ONE, carton)
	var gable := BoxMesh.new()
	gable.size = Vector3(4.24, 4.24, 5.9)
	deco(gable, Mats.solid(Color(0.98, 0.97, 0.94), 0.5), Vector3(0, 4.5, 0), Vector3(0, 0, PI / 4), Vector3.ONE, carton)
	for s in [-1.0, 1.0]:
		var l := sign_text("O.J.", Vector3(0, -0.8, s * 3.08), 0.0 if s < 0 else PI, 200, Color(1.0, 1.0, 1.0))
		l.reparent(carton, false)


func _theta0() -> float:
	return atan2(TERRACE.z - TOWER.z, TERRACE.x - TOWER.x)


func _orbit(theta: float, r: float) -> Vector3:
	return TOWER + Vector3(cos(theta) * r, 0, sin(theta) * r)


func _build_tower() -> void:
	# The Great Pancake Tower, rising out of the syrup sea.
	var layers := int(ceil((TOWER_TOP - SEA_Y + 1.0) / LAYER))
	stack(TOWER.x, TOWER.z, TOWER_TOP, TOWER_R, layers, false, 12)
	box(Vector3(TOWER.x, TOWER_TOP + 0.8, TOWER.z), Vector3(7, 1.6, 7), _m_butter, Vector3(0, 0.3, 0))
	deco_cyl(Vector3(TOWER.x, TOWER_TOP + 0.03, TOWER.z), 5.6, 0.06, Mats.solid(Color(1.0, 0.93, 0.6), 0.2))
	place_goal(Vector3(TOWER.x, TOWER_TOP + 1.6, TOWER.z))
	coin_ring(Vector3(TOWER.x, TOWER_TOP + 1.1, TOWER.z), 6.2, 8)
	omni(Vector3(TOWER.x, TOWER_TOP + 6, TOWER.z), Color(1.0, 0.85, 0.5), 16.0, 1.2)
	# A syrup waterfall pouring down one side.
	var th := _theta0() + 0.45
	var fp := _orbit(th, TOWER_R + 0.2)
	var col := CylinderMesh.new()
	col.top_radius = 0.9
	col.bottom_radius = 1.3
	col.height = TOWER_TOP - SEA_Y
	col.radial_segments = 16
	col.cap_top = false
	col.cap_bottom = false
	deco(col, _fall_mat(Color(0.6, 0.31, 0.05), 1.0, 0.35, 0.6, Color(0.85, 0.55, 0.16)), Vector3(fp.x, (TOWER_TOP + SEA_Y) * 0.5 - 0.05, fp.z))
	var tongue := (fp - TOWER).normalized()
	var lip := deco_ball(Vector3(fp.x, TOWER_TOP, fp.z) - tongue * 1.2, 1.3, _m_syrup, Vector3(1.0, 0.12, 1.6))
	lip.rotation.y = atan2(tongue.x, tongue.z)
	var splash := TorusMesh.new()
	splash.inner_radius = 1.2
	splash.outer_radius = 3.2
	deco(splash, _m_syrup, Vector3(fp.x, SEA_Y + 0.05, fp.z), Vector3.ZERO, Vector3(1, 0.25, 1))

	# Spiral climb: [angle offset, top, radius].
	var t0 := _theta0()
	var steps := [[0.0, 34.0, 2.8], [-0.56, 35.5, 2.6], [-1.12, 37.0, 2.6], [-1.68, 38.5, 2.8],
		[-2.36, 44.0, 4.2], [-3.64, 57.5, 2.6], [-4.2, 59.0, 2.6]]
	for i in steps.size():
		var s: Array = steps[i]
		var p := _orbit(t0 + s[0], ORBIT_R)
		stack(p.x, p.z, s[1], s[2], 2 if s[2] < 4.0 else 3, false, 3)
		if i != 4:
			coin(Vector3(p.x, s[1] + 1.1, p.z))
	# Egg up to the checkpoint ledge.
	var e := _orbit(t0 - 1.68, ORBIT_R)
	var nxt := _orbit(t0 - 2.36, ORBIT_R)
	egg(Vector3(e.x, 38.5, e.z) + (nxt - e).normalized() * 1.0)
	coin_line(Vector3(e.x, 41.5, e.z), Vector3(e.x, 45.5, e.z).lerp(Vector3(nxt.x, 45.5, nxt.z), 0.3), 3)
	var lift := _orbit(t0 - 3.04, ORBIT_R)
	checkpoint(Vector3(nxt.x, 44, nxt.z), atan2(-(lift - nxt).x, -(lift - nxt).z))
	coin_ring(Vector3(nxt.x, 45, nxt.z), 2.6, 5)
	# A flying flapjack lift.
	var fj := mover(Vector3(5.2, 0.8, 5.2), _m_toast, Vector3(lift.x, 43.6, lift.z), Vector3(0, 12, 0), 8.0, 0.0, 0.0, "cylinder")
	var rim := TorusMesh.new()
	rim.inner_radius = 2.2
	rim.outer_radius = 2.8
	rim.rings = 32
	rim.ring_segments = 8
	deco(rim, _m_crust, Vector3.ZERO, Vector3.ZERO, Vector3(1, 1.2, 1), fj)
	deco_box(Vector3(0, 0.42, 0), Vector3(1.4, 0.3, 1.4), _m_butter).reparent(fj, false)
	coin_line(Vector3(lift.x, 47, lift.z), Vector3(lift.x, 55, lift.z), 4)


func _build_scenery() -> void:
	# Distant floating stacks and fruit.
	var spots := [[-60.0, 20.0, 30.0, 12.0, 6], [70.0, -30.0, 18.0, 10.0, 5], [-85.0, -120.0, 45.0, 14.0, 8],
		[90.0, -110.0, 10.0, 9.0, 4], [65.0, -210.0, 38.0, 13.0, 7], [-70.0, -230.0, 20.0, 11.0, 6],
		[-20.0, -290.0, 55.0, 16.0, 9], [40.0, 60.0, 6.0, 8.0, 3], [-120.0, -30.0, 12.0, 15.0, 5],
		[130.0, -180.0, 50.0, 12.0, 7], [10.0, -330.0, 25.0, 18.0, 6], [-150.0, -170.0, 30.0, 12.0, 5]]
	for s in spots:
		stack(s[0], s[1], s[2], s[3], s[4], true, 5, false)
	strawberry(Vector3(-45, 8, -70), 6.0, false)
	strawberry(Vector3(55, 14, -150), 7.0, false)
	blueberry(Vector3(48, 0, -60), 5.0)
	blueberry(Vector3(-40, -1.5, -190), 6.0)
	blueberry(Vector3(35, 22, -250), 4.5)
	whipped_cream(Vector3(72, 18, -28), 3.0)

	# A giant fork stuck in the syrup sea.
	var fork := Node3D.new()
	fork.position = Vector3(-95, SEA_Y, -80)
	fork.rotation = Vector3(0.2, 0.6, -0.35)
	add_child(fork)
	var steel := Mats.solid(Color(0.86, 0.87, 0.9), 0.2, 0.9)
	var handle := BoxMesh.new()
	handle.size = Vector3(4, 70, 1.4)
	deco(handle, steel, Vector3(0, 55, 0), Vector3.ZERO, Vector3.ONE, fork)
	var neck := BoxMesh.new()
	neck.size = Vector3(10, 3, 1.2)
	deco(neck, steel, Vector3(0, 19, 0), Vector3.ZERO, Vector3.ONE, fork)
	var tine := BoxMesh.new()
	tine.size = Vector3(1.2, 22, 1.0)
	for i in 4:
		deco(tine, steel, Vector3(-4.2 + i * 2.8, 7, 0), Vector3.ZERO, Vector3.ONE, fork)

	# A steaming coffee mug on the horizon.
	var mug := Vector3(150, SEA_Y, -300)
	deco_cyl(mug + Vector3(0, 22, 0), 28, 44, Mats.solid(Color(0.95, 0.55, 0.6), 0.3))
	deco_cyl(mug + Vector3(0, 43.8, 0), 26, 0.5, Mats.solid(Color(0.35, 0.18, 0.08), 0.1))
	var handle_t := TorusMesh.new()
	handle_t.inner_radius = 9
	handle_t.outer_radius = 15
	deco(handle_t, Mats.solid(Color(0.95, 0.55, 0.6), 0.3), mug + Vector3(-28, 24, 0), Vector3(PI / 2, 0, 0))
	Fx.ambient(self, mug + Vector3(0, 60, 0), Vector3(16, 16, 16), Color(1, 1, 1, 0.25), 60, 9.0, Vector3(0, 3, 0), 8.0)

	# Cereal loops bobbing in the syrup and drifting through the sky.
	var loops := [Color(1.0, 0.45, 0.6), Color(1.0, 0.65, 0.25), Color(1.0, 0.9, 0.35),
		Color(0.55, 0.85, 0.4), Color(0.65, 0.5, 0.95), Color(0.95, 0.3, 0.3)]
	var tor := TorusMesh.new()
	tor.inner_radius = 0.5
	tor.outer_radius = 1.0
	tor.rings = 16
	tor.ring_segments = 8
	var xforms := []
	var colors := []
	while xforms.size() < 360:
		var p := Vector3(_rng.randf_range(-260, 260), 0, _rng.randf_range(-400, 120))
		var sky := xforms.size() >= 260
		if not sky and p.x > -30 and p.x < 40 and p.z > -200 and p.z < 20:
			continue
		var sc := _rng.randf_range(1.4, 3.0)
		var basis := Basis.from_euler(Vector3(_rng.randf_range(-0.2, 0.2), _rng.randf() * TAU, _rng.randf_range(-0.2, 0.2)))
		if sky:
			if p.x > -40 and p.x < 50 and p.z > -210 and p.z < 25:
				continue
			p.y = _rng.randf_range(15, 90)
			basis = Basis.from_euler(Vector3(_rng.randf() * TAU, _rng.randf() * TAU, 0))
			sc *= 1.6
		else:
			p.y = SEA_Y + 0.1
		xforms.append(Transform3D(basis.scaled(Vector3.ONE * sc), p))
		colors.append(loops[_rng.randi() % loops.size()])
	var cereal := StandardMaterial3D.new()
	cereal.vertex_color_use_as_albedo = true
	cereal.roughness = 0.85
	_scatter(tor, cereal, xforms, colors)


func _scatter(mesh: Mesh, mat: Material, xforms: Array, colors: Array = []) -> MultiMeshInstance3D:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = not colors.is_empty()
	mm.mesh = mesh
	mm.instance_count = xforms.size()
	for i in xforms.size():
		mm.set_instance_transform(i, xforms[i])
		if mm.use_colors:
			mm.set_instance_color(i, colors[i])
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	mmi.material_override = mat
	add_child(mmi)
	return mmi


# ---------------------------------------------------------------- story

func intro() -> void:
	director.begin()
	Game.fx.set_black(true)
	player.place(spawn_point, spawn_yaw)
	player.process_mode = Node.PROCESS_MODE_DISABLED
	player.visible = false

	# Past the Great Pancake Tower.
	var top := Vector3(TOWER.x, TOWER_TOP, TOWER.z)
	director.shot(top + Vector3(48, -14, -34), top + Vector3(0, -8, 0), 58.0)
	Game.fx.fade_in(2.0)
	director.move(top + Vector3(30, 8, 26), top + Vector3(0, 2, 0), 5.0, 46.0)
	await director.wait(4.6)
	# The toaster and the juice falls.
	director.shot(Vector3(40, 26, -118), TOASTER + Vector3(4, 8, -6), 52.0)
	director.move(Vector3(26, 36, -112), Vector3(14, 32, -150), 3.6, 44.0)
	await director.wait(3.3)
	# Low over the bacon bridge toward the landing pancake.
	director.shot(Vector3(8, 15, -76), Vector3(0, 9, -50), 55.0)
	director.move(Vector3(6, 9, -26), Vector3(0, 6, -2), 3.2, 50.0)
	await director.wait(3.0)

	# Stax drops out of the sky.
	director.shot(Vector3(7.5, 5.6, 14.5), Vector3(0, 9.5, 3.0), 64.0)
	player.process_mode = Node.PROCESS_MODE_INHERIT
	player.visible = true
	player.place(spawn_point + Vector3(0, 36, 0), spawn_yaw)
	Audio.play("whoosh", 0.6)
	var t := 0.0
	while t < 1.0 or (t < 4.0 and not player.is_on_floor()):
		if director.skipping:
			break
		await get_tree().process_frame
		t += get_process_delta_time()
	if not director.skipping:
		Audio.play("boom")
		director.shake(0.8)
		var feet := player.global_position + Vector3(0, 0.2, 0)
		Fx.burst(self, feet, Color(1.0, 0.9, 0.65, 0.9), 40, 9.0, 0.5, 0.8, -6.0)
		Fx.burst(self, feet, Color(0.85, 0.55, 0.2), 16, 8.0, 0.18, 1.0, -18.0, "cube")
		player.model.emote = "shocked"
	await director.wait(0.6)

	var sp := player.global_position
	var c := sp + Vector3(0, 1.1, 0)
	director.shot(c + Vector3(0.8, 0.3, -3.2), c, 40.0)
	director.orbit(c, 5.5, 1.2, -PI / 2 - 0.9, -PI / 2 + 0.5, 6.0, 50.0)
	await director.title(info.chapter, info.title, info.subtitle)
	await director.settle()
	director.shot(c + Vector3(-1.4, 0.4, -2.4), c + Vector3(0, 0.2, 0), 38.0)
	await director.say("stax", "Ow. Okay. Soft. Warm. Smells like... pancakes?", "shocked")

	director.actors["steve"] = _steve.puppet
	director.face(_steve.global_position)
	_steve.face_toward(sp)
	director.two_shot(player, _steve, -1.0, 44.0)
	await director.lines([
		["steve", "That's because you're standing on one! Morning, sunshine!"],
		["stax", "STEVE?! I just fell out of the sky! How are you here first?", "shocked"],
		["steve", "Signs don't travel, kid. We're just... already there."],
		["stax", "That is the creepiest thing you've ever said.", "facepalm"],
		["steve", "Welcome to the Breakfast Dimension! The next key's atop the Great Pancake Tower."],
		["stax", "A tower made of pancakes? Finally, a dimension that gets me.", "cool"],
	])
	player.process_mode = Node.PROCESS_MODE_INHERIT
	player.visible = true
	player.place(spawn_point, spawn_yaw)
	director.end()
	bark("steve", "Talk to me with F for breakfast tips! Tipping the tipster is optional. Ish.")


func on_talked(n: Node3D) -> void:
	if n != _waffle or _gate_open:
		return
	_gate_open = true
	Audio.play("rumble")
	Audio.play("clang", 0.7)
	if rig and rig.has_method("shake"):
		rig.shake(0.3)
	var t := create_tween()
	t.tween_property(_gate, "position:y", _gate.position.y - 12.5, 2.0).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	bark("waffle", "Raise the gate! Er, lower it! Whichever! Huzzah!")


func outro_lines() -> Array:
	return [
		["stax", "Key number two! Breakfast: defeated. Tummy: confused.", "cheer"],
		["steve", "Great job! Next stop: The Infinite Tax Office. Bring receipts!"],
		["stax", "Taxes?! Nooo! My one true weakness!", "shocked"],
	]
