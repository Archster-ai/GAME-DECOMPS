extends "res://scripts/world/level_base.gd"
## Chapter 8: The Nursery of Doom. Stax is toy-sized in a moonlit nursery
## where the floor is lava (house rules). The fine print says the Vault needs
## an eighth key, and Baby Bigbucks is teething on it.
## Route: storybook -> alphabet blocks -> toy chest (ATM) -> pillow bounce ->
## crib rail -> the spinning mobile -> toy shelf (ATM) -> toy plane -> the
## play-mat arena, where the giant baby wakes up. Nobody hits the baby: Stax
## squashes Lullaby Stars until he falls asleep.

const BabyScript := preload("res://scripts/actors/boss_baby.gd")
const OrbiterScript := preload("res://scripts/world/orbiter.gd")

const FLOOR_Y := -4.0
const ARENA := Vector3(0, 11, -122)
const ARENA_R := 18.0
const BABY_AT := Vector3(0, 11, -134)
const MOBILE_HUB := Vector3(0, 12, -68.5)
const MOBILE_R := 6.5
const MOBILE_SPEED := 0.45

var boss: Node3D
## Where the key will appear, for tests/reachability.gd.
var reach_target := ARENA
var _steve: Node3D
var _mobile: Array[AnimatableBody3D] = []   # orbiter.gd platforms
var _mobile_arms: Node3D
var _mobile_t := 0.0
var _zzz: Label3D
var _fight_started := false
var _told_star := false
var _wood: Material
var _soft: Material


func _init() -> void:
	music = "nursery"
	spawn_point = Vector3(0, 0.1, 2.5)
	spawn_yaw = 0.0
	kill_y = -14.0


func env_config() -> Dictionary:
	return {
		"top": Color(0.08, 0.07, 0.2), "horizon": Color(0.45, 0.36, 0.62), "bottom": Color(0.2, 0.15, 0.3),
		"sun_color": Color(0.8, 0.78, 1.0), "sun_energy": 1.05, "sun_angle": Vector2(-58, 28),
		"sun_size": 0.0, "sun_glow": 0.0, "stars": 0.8,
		"fog_color": Color(0.55, 0.46, 0.75), "fog_density": 0.004, "volumetric": 0.012,
		"vol_color": Color(0.85, 0.8, 1.0), "ambient": 0.95, "exposure": 1.05, "glow": 1.0,
		"tint": Color(1.02, 0.98, 1.05), "saturation": 1.12, "vignette": 0.42, "player_light": 0.5,
	}


# ---------------------------------------------------------------- props

## Collision with no mesh, for props built from several decorative pieces.
func solid(pos: Vector3, size: Vector3) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = pos
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	cs.shape = shape
	body.add_child(cs)
	add_child(body)
	return body


## A column of stacked alphabet blocks rising from the carpet to `top`.
func block_stack(x: float, z: float, top: float, size: float, letters: String, seed_i: int) -> void:
	var cols := [Color(0.95, 0.32, 0.32), Color(0.3, 0.6, 1.0), Color(1.0, 0.8, 0.2), Color(0.35, 0.8, 0.45)]
	var h := top - FLOOR_Y
	solid(Vector3(x, FLOOR_Y + h * 0.5, z), Vector3(size, h, size))
	var n := maxi(1, roundi(h / size))
	var cube := h / n
	for k in n:
		var c: Color = cols[(seed_i + k) % cols.size()]
		var y := FLOOR_Y + cube * (k + 0.5)
		deco_box(Vector3(x, y, z), Vector3(size, cube, size) * 0.995, Mats.toon(c, 0.6, 0.2))
		var ch := letters[(seed_i + k) % letters.length()]
		sign_text(ch, Vector3(x, y, z + size * 0.5 + 0.02), PI, int(cube * 80), Color(1, 1, 1))
		sign_text(ch, Vector3(x + size * 0.5 + 0.02, y, z), -PI / 2, int(cube * 80), Color(1, 1, 1))


func soldier(a: Vector3, b: Vector3) -> void:
	var e := enemy("soldier", a, b)
	e.speed = 2.0
	e.chase_speed = 4.0


# ---------------------------------------------------------------- build

func build() -> void:
	_wood = Mats.toon(Color(0.95, 0.85, 0.7), 0.7, 0.15)
	_soft = Mats.toon(Color(0.98, 0.95, 1.0), 0.9, 0.3)
	_build_room()

	# The floor is lava. House rules.
	var carpet := Mats.pattern("carpet", [Color(0.62, 0.5, 0.85), Color(0.9, 0.6, 0.8)], 0.08, 0.95)
	box(Vector3(0, FLOOR_Y - 1, -75), Vector3(180, 2, 260), carpet)
	zone(Vector3(0, FLOOR_Y + 0.5, -75), Vector3(180, 1.2, 260), "hurt")
	Fx.ambient(self, Vector3(0, 6, -60), Vector3(30, 10, 70), Color(1.0, 0.9, 1.0, 0.45), 160, 0.1, Vector3(0, 0.15, 0), 8.0)

	# 1. A storybook to start on.
	box(Vector3(0, -2, 0), Vector3(12, 4, 9), Mats.toon(Color(0.8, 0.2, 0.25), 0.7, 0.2))
	deco_box(Vector3(0, -2, 0), Vector3(11.4, 3.2, 9.3), Mats.pattern("stripes", [Color(0.98, 0.95, 0.85), Color(0.85, 0.8, 0.7)], 1.2))
	sign_text("GOODNIGHT, VAULT", Vector3(0, -2, 4.72), PI, 90, Color(1.0, 0.85, 0.3))
	coin_ring(Vector3(0, 1, -1), 2.5, 6)
	_steve = npc("steve", "steve", Vector3(3.6, 0, -1.8), 2.2, [
		["steve", "Tips! Tin soldiers can be stomped. Pillows are bouncy. And babies do NOT like sharing."],
		["stax", "Anything else?", "think"],
		["steve", "Whatever you do, don't wake him up. He gets fussy. Very, very large and fussy."],
	], [["steve", "Blocks, chest, pillow, crib, mobile, shelf, plane, baby. Easy! Mostly! Kind of!"]])
	npc("teddy", "teddy", Vector3(-3.6, 0, -1.5), -2.3, [
		["teddy", "Halt! Who goes there? Oh. A tiny fellow. I am Sir Snuggles, Knight of the Toy Chest."],
		["teddy", "I was the baby's favorite. Then he got a gold rattle, a gold pacifier and a gold KEY. Now I live under the bed."],
		["stax", "That's... honestly really sad.", "shrug"],
		["teddy", "Heed me, small one. Beware the Tin Soldiers. And the floor is lava."],
		["stax", "The floor is carpet.", "think"],
		["teddy", "The floor. Is. LAVA. House rules."],
		["teddy", "When the baby yawns, a Lullaby Star appears. Squash it and the music box plays. Three songs and he's out like a light!"],
	], [["teddy", "When he yawns, squash the Lullaby Star! Three lullabies, and it's naptime."]])

	# 2. Alphabet blocks.
	tip(Vector3(0, 1.5, -5), Vector3(12, 4, 2), "steve", "Alphabet blocks! Hop from A to D. Skip E through Z. Trust me.")
	block_stack(0, -8, 1.0, 3.0, "ABCD", 0)
	block_stack(3, -12.5, 2.5, 3.0, "EFGH", 1)
	block_stack(0, -17, 4.0, 3.0, "IJKL", 2)
	block_stack(-3, -21.5, 5.5, 3.0, "MNOP", 3)
	coin_arc(Vector3(0, 2, -8), Vector3(3, 3.5, -12.5), 1.2, 3)
	coin_arc(Vector3(3, 3.5, -12.5), Vector3(0, 5, -17), 1.2, 3)
	coin_arc(Vector3(0, 5, -17), Vector3(-3, 6.5, -21.5), 1.2, 3)
	coin(Vector3(-3, 9.5, -21.5), 5)

	# 3. The toy chest, with a checkpoint and a patrolling tin soldier.
	box(Vector3(0, 1, -30), Vector3(10, 10, 8), Mats.toon(Color(0.55, 0.75, 0.95), 0.7, 0.2))
	deco_box(Vector3(0, 5.6, -30), Vector3(10.4, 0.9, 8.4), Mats.toon(Color(0.4, 0.6, 0.9), 0.7, 0.2))
	deco_box(Vector3(0, 4.6, -25.9), Vector3(1.2, 1.4, 0.3), Mats.gold())
	sign_text("TOYS", Vector3(0, 1.5, -25.95), PI, 260, Color(1.0, 0.95, 0.6))
	checkpoint(Vector3(-3.2, 6, -27.5), 0.0)
	soldier(Vector3(-3.5, 6, -31.5), Vector3(3.5, 6, -31.5))
	coin_line(Vector3(-2, 7, -29), Vector3(2, 7, -29), 3)

	# 4. A pillow with a bouncy middle, up to the crib.
	box(Vector3(0, 0, -39.5), Vector3(7, 8, 5), _soft)
	deco_ball(Vector3(0, 2.9, -39.5), 3.8, _soft, Vector3(1, 0.33, 0.72))
	var puff := Node3D.new()
	var pm := MeshInstance3D.new()
	var ps := SphereMesh.new()
	ps.radius = 1.4
	ps.height = 2.8
	pm.mesh = ps
	pm.material_override = Mats.toon(Color(1.0, 0.7, 0.85), 0.9, 0.3)
	pm.scale = Vector3(1, 0.3, 1)
	pm.position.y = 0.25
	puff.add_child(pm)
	bouncer(Vector3(0, 4, -39.5), 1.5, 27.0, puff)
	tip(Vector3(0, 7, -35), Vector3(10, 4, 2), "steve", "Bounce on the pillow and steer for the crib!")
	coin_line(Vector3(0, 6.5, -39.5), Vector3(0, 12, -42.5), 4)

	# 5. The crib: a headboard ledge, then a long narrow rail.
	box(Vector3(0, 11.6, -45.5), Vector3(8, 0.8, 3), _wood)
	deco_box(Vector3(0, (11.2 + FLOOR_Y) * 0.5, -45.5), Vector3(7.6, 11.2 - FLOOR_Y, 0.8), _wood)
	for x in [-3.6, 3.6]:
		deco_ball(Vector3(x, 12.4, -45.5), 0.6, _wood)
	box(Vector3(0, 11.6, -53.5), Vector3(1.4, 0.8, 13), _wood)
	deco_box(Vector3(0, 0.5, -53.5), Vector3(1.0, 0.6, 13), _wood)
	for i in 11:
		deco_cyl(Vector3(0, (11.2 + FLOOR_Y) * 0.5, -47.6 - i * 1.2), 0.16, 11.2 - FLOOR_Y, _wood)
	tip(Vector3(0, 13, -47), Vector3(4, 4, 2), "steve", "Careful on the crib rail. It's narrow. Like my profit margins.")
	coin_line(Vector3(0, 13, -49), Vector3(0, 13, -58), 5)

	# 6. The mobile: moon, stars, a cloud and a heart, spinning slowly.
	_build_mobile()
	tip(Vector3(0, 13, -58), Vector3(4, 4, 2), "steve", "The mobile spins! Ride the moon and stars across.")

	# 7. The toy shelf, with a checkpoint.
	box(Vector3(0, 4.1, -80), Vector3(8, 16.2, 5), Mats.toon(Color(0.98, 0.9, 0.95), 0.8, 0.2))
	for i in 5:
		var bc: Color = [Color(0.9, 0.3, 0.3), Color(0.3, 0.7, 0.5), Color(0.35, 0.45, 0.9), Color(1.0, 0.75, 0.3), Color(0.7, 0.4, 0.8)][i]
		deco_box(Vector3(-3.1 + i * 1.5, 5.5, -77.4), Vector3(1.2, 3.2 + (i % 2) * 0.6, 0.2), Mats.toon(bc))
	checkpoint(Vector3(-2.6, 12.2, -78.6), 0.0)
	soldier(Vector3(-3, 12.2, -81.2), Vector3(3, 12.2, -81.2))
	coin(Vector3(2.8, 13.2, -78.6), 5)

	# 8. A toy plane on a string, shuttling to the play mat.
	var plane := mover(Vector3(7, 0.5, 3), Mats.toon(Color(0.95, 0.35, 0.35), 0.7, 0.2), Vector3(0, 11.95, -88.5), Vector3(0, 0, -10), 6.0)
	deco(_box_mesh(Vector3(1.6, 1.4, 5.5)), Mats.toon(Color(0.3, 0.55, 0.95)), Vector3(0, -0.9, -0.6), Vector3.ZERO, Vector3.ONE, plane)
	deco(_box_mesh(Vector3(3.2, 0.3, 1.1)), Mats.toon(Color(0.95, 0.35, 0.35)), Vector3(0, -0.5, 2.0), Vector3.ZERO, Vector3.ONE, plane)
	deco(_box_mesh(Vector3(0.3, 2.4, 0.3)), Mats.toon(Color(1.0, 0.85, 0.3)), Vector3(0, -0.9, -3.45), Vector3.ZERO, Vector3.ONE, plane)
	var string := deco_cyl(Vector3.ZERO, 0.04, 60.0, Mats.solid(Color(0.95, 0.95, 0.95)))
	string.reparent(plane, false)
	string.position = Vector3(0, 30.25, 0)
	tip(Vector3(0, 13, -82), Vector3(8, 4, 2), "steve", "Hop on the toy plane. It knows where the baby is. Everything knows where the baby is.")
	coin_line(Vector3(0, 13.5, -89), Vector3(0, 13.5, -99), 4)

	# 9. The play-mat arena, on a giant round play table.
	var mat := Mats.pattern("checker", [Color(1.0, 0.78, 0.84), Color(0.76, 0.86, 1.0)], 0.06, 0.9)
	cylinder(ARENA - Vector3(0, 1, 0), ARENA_R + 1.0, 2.0, mat, 48)
	for i in 4:
		var a := TAU * i / 4.0 + PI / 4
		deco_cyl(ARENA + Vector3(sin(a) * 12, (FLOOR_Y - ARENA.y) * 0.5 - 1.0, cos(a) * 12), 1.2, ARENA.y - FLOOR_Y - 2.0, _wood)
	var foam := [Mats.toon(Color(1.0, 0.6, 0.7), 0.9, 0.2), Mats.toon(Color(0.6, 0.8, 1.0), 0.9, 0.2), Mats.toon(Color(1.0, 0.9, 0.5), 0.9, 0.2)]
	for i in 30:
		var a := TAU * i / 30.0
		if absf(wrapf(a, -PI, PI)) < 0.33:
			continue  # the entrance on the +Z side
		var p := ARENA + Vector3(sin(a), 0, cos(a)) * (ARENA_R + 0.6)
		var w := box(p + Vector3(0, 0.75, 0), Vector3(3.9, 1.5, 1.2), foam[i % 3])
		w.rotation.y = a
	checkpoint(ARENA + Vector3(-4, 0, 14), 0.0)
	coin_ring(ARENA + Vector3(0, 1, 2), 8.0, 10)
	trigger(ARENA + Vector3(0, 2, 11), Vector3(20, 6, 4), func(_p): _start_boss())
	omni(ARENA + Vector3(0, 10, 4), Color(1.0, 0.85, 0.7), 26.0, 1.3)

	# Baby Bigbucks, asleep. For now.
	boss = BabyScript.new()
	boss.level = self
	boss.arena_center = ARENA
	boss.arena_radius = ARENA_R
	add_child(boss)
	boss.global_position = BABY_AT
	boss.rotation.y = PI
	boss.puppet.emote = "asleep"
	_zzz = Label3D.new()
	_zzz.text = "Z z z"
	_zzz.font = Mats.bold_font()
	_zzz.font_size = 200
	_zzz.pixel_size = 0.012
	_zzz.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_zzz.modulate = Color(0.8, 0.85, 1.0)
	_zzz.position = BABY_AT + Vector3(2.5, 13.5, 0)
	add_child(_zzz)


func _box_mesh(size: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = size
	return b


func _build_mobile() -> void:
	var looks := [
		[Color(1.0, 0.9, 0.4), "moon"], [Color(1.0, 0.8, 0.3), "star"],
		[Color(0.95, 0.97, 1.0), "cloud"], [Color(1.0, 0.5, 0.65), "heart"],
	]
	_mobile_arms = Node3D.new()
	_mobile_arms.position = MOBILE_HUB + Vector3(0, 6, 0)
	add_child(_mobile_arms)
	var rod := Mats.solid(Color(0.95, 0.9, 1.0), 0.4, 0.3)
	deco_cyl(MOBILE_HUB + Vector3(0, 40, 0), 0.25, 68.0, rod)
	deco_ball(MOBILE_HUB + Vector3(0, 6, 0), 0.8, Mats.toon(Color(1.0, 0.8, 0.9)))
	for i in looks.size():
		var a := TAU * i / looks.size()
		var dir := Vector3(sin(a), 0, cos(a))
		deco(_box_mesh(Vector3(0.25, 0.25, MOBILE_R)), rod, dir * MOBILE_R * 0.5, Vector3(0, a, 0), Vector3.ONE, _mobile_arms)
		var s := CylinderMesh.new()
		s.top_radius = 0.03
		s.bottom_radius = 0.03
		s.height = 5.7
		deco(s, Mats.solid(Color(1, 1, 1)), dir * MOBILE_R + Vector3(0, -2.85, 0), Vector3.ZERO, Vector3.ONE, _mobile_arms)
		var col: Color = looks[i][0]
		var body := OrbiterScript.new()
		body.center = MOBILE_HUB
		body.radius = MOBILE_R
		body.speed = MOBILE_SPEED
		body.angle = a
		var cs := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = Vector3(3.4, 0.6, 3.4)
		cs.shape = shape
		body.add_child(cs)
		deco(_box_mesh(Vector3(3.4, 0.6, 3.4)), Mats.toon(col, 0.6, 0.3), Vector3.ZERO, Vector3.ZERO, Vector3.ONE, body)
		match looks[i][1]:
			"moon":
				deco(_sphere(1.4), Mats.glow(col, 1.2), Vector3(0, -1.2, 0), Vector3.ZERO, Vector3(1, 0.8, 0.5), body)
			"star":
				deco(_sphere(1.1), Mats.glow(col, 2.0), Vector3(0, -1.0, 0), Vector3.ZERO, Vector3.ONE, body)
			"cloud":
				for k in 3:
					deco(_sphere(0.9), _soft, Vector3(-1.0 + k, -0.8, 0), Vector3.ZERO, Vector3.ONE, body)
			"heart":
				for k in [-0.5, 0.5]:
					deco(_sphere(0.8), Mats.toon(col), Vector3(k, -0.9, 0), Vector3.ZERO, Vector3.ONE, body)
		# A coin that rides along.
		var c := PickupScript.new()
		c.position = Vector3(0, 1.3, 0)
		body.add_child(c)
		add_child(body)
		_mobile.append(body)


func _sphere(r: float) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	return s


func _physics_process(delta: float) -> void:
	super(delta)
	_mobile_t += delta
	if not _mobile.is_empty():
		_mobile_arms.rotation.y = _mobile[0].angle
	if _zzz and _zzz.visible:
		_zzz.position.y = BABY_AT.y + 13.5 + sin(_mobile_t * 1.8) * 0.4


## Walls, a window with the real moon, and toys the size of buildings.
func _build_room() -> void:
	var paper := Mats.pattern("stripes", [Color(0.98, 0.85, 0.9), Color(0.95, 0.93, 0.85)], 0.05, 0.9)
	var walls := [
		[Vector3(0, 60, -205), Vector3(200, 140, 2)],
		[Vector3(0, 60, 55), Vector3(200, 140, 2)],
		[Vector3(-90, 60, -75), Vector3(2, 140, 262)],
		[Vector3(90, 60, -75), Vector3(2, 140, 262)],
	]
	for w in walls:
		var m := deco_box(w[0], w[1], paper)
		m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	# The window behind the arena, and the moon outside it.
	var frame := _wood
	deco_box(Vector3(0, 55, -203.7), Vector3(62, 52, 0.4), Mats.unshaded(Color(0.08, 0.08, 0.25)))
	deco_box(Vector3(0, 55, -203), Vector3(64, 3, 2), frame)
	deco_box(Vector3(0, 28, -203), Vector3(66, 3, 3), frame)
	deco_box(Vector3(0, 82, -203), Vector3(66, 3, 3), frame)
	for x in [-32.0, 32.0]:
		deco_box(Vector3(x, 55, -203), Vector3(3, 56, 3), frame)
	deco_box(Vector3(0, 55, -203), Vector3(2, 52, 2), frame)
	deco_ball(Vector3(14, 66, -203.3), 8.0, Mats.glow(Color(1.0, 0.95, 0.8), 3.0), Vector3(1, 1, 0.05))
	var rng := RandomNumberGenerator.new()
	rng.seed = 18
	for i in 30:
		deco_ball(Vector3(rng.randf_range(-29, 29), rng.randf_range(31, 79), -203.3), rng.randf_range(0.2, 0.5), Mats.glow(Color(1, 1, 0.9), 3.0))
	for x in [-34.0, 34.0]:
		deco_box(Vector3(x * 1.25, 55, -202), Vector3(14, 60, 1), Mats.pattern("stripes", [Color(0.7, 0.6, 0.95), Color(0.6, 0.5, 0.85)], 0.2))
	# A night-light and a giant beach ball, a block tower and a rocking horse.
	deco_ball(Vector3(-60, FLOOR_Y + 8, -150), 8.0, Mats.glow(Color(1.0, 0.8, 0.5), 1.4))
	omni(Vector3(-50, FLOOR_Y + 12, -140), Color(1.0, 0.75, 0.45), 60.0, 2.0)
	var beach := Mats.pattern("stripes", [Color(1.0, 0.35, 0.35), Color(1.0, 0.95, 0.9)], 0.1)
	deco_ball(Vector3(55, FLOOR_Y + 14, -40), 14.0, beach)
	for i in 5:
		var c: Color = [Color(0.95, 0.3, 0.3), Color(0.3, 0.6, 1.0), Color(1.0, 0.8, 0.2), Color(0.35, 0.8, 0.45), Color(0.7, 0.4, 0.8)][i]
		deco_box(Vector3(-45 + (i % 2) * 2, FLOOR_Y + 6 + i * 12, 10), Vector3(12, 12, 12), Mats.toon(c), Vector3(0, i * 0.3, 0))
	var horse := Mats.toon(Color(0.95, 0.9, 0.8))
	deco_box(Vector3(50, FLOOR_Y + 18, -120), Vector3(8, 9, 24), horse)
	deco_box(Vector3(50, FLOOR_Y + 28, -132), Vector3(6, 16, 7), horse, Vector3(0.3, 0, 0))
	deco_box(Vector3(50, FLOOR_Y + 36, -136), Vector3(6, 7, 11), horse)
	for x in [46.0, 54.0]:
		deco_box(Vector3(x, FLOOR_Y + 8, -120), Vector3(1.5, 14, 2), horse)
		deco_box(Vector3(x, FLOOR_Y + 1, -120), Vector3(2, 2, 40), Mats.toon(Color(0.9, 0.4, 0.4)))
	omni(Vector3(0, 30, -40), Color(0.9, 0.85, 1.0), 70.0, 0.8)


# ---------------------------------------------------------------- story

func intro() -> void:
	director.begin()
	Game.fx.set_black(true)
	player.place(spawn_point + Vector3(0, 28, 0), spawn_yaw)
	director.actors["steve"] = _steve.puppet
	director.actors["baby"] = boss.puppet
	# The moon through the window, then down to the sleeping giant.
	director.shot(Vector3(20, 40, -150), Vector3(14, 66, -204), 45.0)
	Game.fx.fade_in(2.0)
	director.move(Vector3(18, 22, -100), BABY_AT + Vector3(0, 9, 0), 6.0, 40.0)
	await director.wait(1.5)
	await director.say("narrator", "At the edge of the multiverse there is a nursery. And in it, the richest baby who ever lived is taking a nap.")
	await director.settle()
	director.shot(BABY_AT + Vector3(-8, 11, 14), BABY_AT + Vector3(0, 9.5, 0), 38.0)
	await director.say("baby", "Mmmh... mine... all mine... *snore*")
	# Stax drops in onto the storybook.
	director.shot(Vector3(7, 3, 12), Vector3(0, 3, 1), 50.0)
	Audio.play("whoosh", 1.1)
	var t := 0.0
	while player.global_position.y > 0.6 and t < 4.0 and not director.skipping:
		t += await director._frame()
	player.place(spawn_point, spawn_yaw)
	Audio.play("land")
	director.shake(0.3)
	var sp := player.global_position
	director.shot(sp + Vector3(-2.3, 1.5, -2.7), sp + Vector3(0, 1.3, 0), 36.0)
	await director.say("stax", "Seven keys. Next stop, the Vault. So why am I in a NURSERY?", "think")
	director.face(_steve.global_position)
	_steve.face_toward(player.global_position)
	director.two_shot(player, _steve, 1.0, 46.0)
	await director.lines([
		["steve", "Riiight. About that. Small thing. Teeny. The Vault needs EIGHT keys."],
		["stax", "EIGHT?! Since WHEN?!", "shocked"],
		["steve", "Since always! It's in the fine print. Page nine hundred. Font size two."],
		["steve", "Key number eight belongs to Baby Bigbucks. He's been teething on it."],
		["stax", "You want me to take a key... from a BABY?", "facepalm"],
		["steve", "A very, very big baby. Just don't wake him up and you'll be fine!"],
	])
	director.shot(Vector3(10, 6, 12), Vector3(0, 6, -40), 48.0)
	director.move(Vector3(4, 4, 10), Vector3(0, 8, -60), 4.0, 44.0)
	await director.title(info.chapter, info.title, info.subtitle)
	await director.settle()
	player.place(spawn_point, spawn_yaw)
	director.end()


func _start_boss() -> void:
	if _fight_started:
		return
	_fight_started = true
	player.spawn_point = ARENA + Vector3(-4, 0.5, 12)
	director.begin()
	Audio.stop_music(0.8)
	player.velocity = Vector3.ZERO
	player.speed = 0.0
	player.place(ARENA + Vector3(0, 0.2, 9), 0.0)
	director.actors["baby"] = boss.puppet
	var sp := player.global_position
	director.shot(sp + Vector3(-2.5, 1.5, -3.0), sp + Vector3(0, 1.3, 0), 36.0)
	await director.say("stax", "Okay. Giant baby. Sleeping. Key in his fist. Just... tiptoe...", "think")
	# Squeak.
	Audio.play("boing", 1.8)
	Audio.play("pop", 2.0)
	director.shake(0.1)
	await director.wait(0.6)
	await director.say("stax", "...Why is the play mat SQUEAKY?!", "shocked")
	# He wakes up.
	director.shot(BABY_AT + Vector3(6, 4, 16), BABY_AT + Vector3(0, 9, 0), 50.0)
	director.move(BABY_AT + Vector3(3, 6, 14), BABY_AT + Vector3(0, 9.5, 0), 3.0, 42.0)
	_zzz.visible = false
	boss.puppet.emote = ""
	Audio.play("whoosh", 0.5)
	await director.wait(1.0)
	await director.say("baby", "...Gah?")
	director.two_shot(player, boss, -1.0, 58.0)
	await director.lines([
		["stax", "Hi! Hi there, little buddy. Could I maybe borrow the shiny key?", "wave"],
		["baby", "NO. MINE. Nice wooden man gave it. He said NEVER SHARE."],
		["stax", "...Steve.", "facepalm"],
		["stax", "Look, it's late. Isn't it naptime?", "shrug"],
		["baby", "NAPS ARE FOR BABIES!"],
		["stax", "You ARE a baby!", "point"],
	])
	director.shot(BABY_AT + Vector3(0, 5, 12), BABY_AT + Vector3(0, 9.5, 0), 34.0)
	boss.puppet.emote = "tantrum"
	Audio.play("rumble", 1.2)
	director.shake(0.7)
	await director.say("baby", "WAAAAAAAAAH!")
	Audio.play_music("tantrum", 0.2)
	Audio.set_drums(1.0)
	director.shot(ARENA + Vector3(0, 8, 22), BABY_AT + Vector3(0, 6, 0), 55.0)
	director.move(ARENA + Vector3(0, 5, 16), BABY_AT + Vector3(0, 7, 0), 3.0)
	await director.title("BOSS", "Baby Bigbucks", "Richest baby in the multiverse. Has never once shared.", 1.6)
	await director.settle()
	boss.puppet.emote = ""
	player.place(ARENA + Vector3(0, 0.2, 10), 0.0)
	director.end()
	boss.player = player
	boss.hit.connect(func(hp): hud.set_boss_hp(hp))
	boss.defeated.connect(_on_boss_defeated)
	hud.show_boss("BABY BIGBUCKS  ·  FUSSINESS", boss.MAX_HP)
	boss.start()
	player.died.connect(_restart_fight)
	bark("teddy", "Dodge the blocks and jump the bounces! When he yawns, squash the Lullaby Star!")


## Getting knocked out starts the tantrum over.
func _restart_fight() -> void:
	if boss == null or boss.state == boss.B.DEAD:
		return
	boss.reset(BABY_AT)
	hud.set_boss_hp(boss.MAX_HP)
	await get_tree().create_timer(1.2).timeout
	bark("baby", "Again! AGAIN! Hee hee!")


func on_boss_tired() -> void:
	if not _told_star:
		_told_star = true
		bark("teddy", "He's yawning! Stomp the Lullaby Star, or ground pound it! Quickly!")


func _on_boss_defeated() -> void:
	boss_beaten()
	hud.hide_boss()
	await get_tree().create_timer(0.8).timeout
	director.begin()
	Audio.stop_music(1.5)
	Audio.set_drums(0.0)
	var bp: Vector3 = boss.global_position
	player.place(ARENA + Vector3(0, 0.2, -2), 0.0)
	director.face(bp)
	director.actors["baby"] = boss.puppet
	director.shot(bp + Vector3(7, 6, 15), bp + Vector3(0, 9, 0), 40.0)
	await director.wait(0.8)
	await director.say("baby", "Mmmh... lullaby... nice... *yawn*")
	Audio.play_music("nursery", 1.0)
	_zzz.visible = true
	await director.say("baby", "Nigh-night... Stax... *snore*")
	director.two_shot(player, boss, 1.0, 55.0)
	await director.say("stax", "Sleep tight, big guy.", "shrug")
	# His fist opens, and the eighth key tumbles out.
	var hand: Vector3 = boss.puppet.parts.rattle.global_position
	place_goal(ARENA + Vector3(0, 0, -3))
	var goal_pos := goal.global_position
	goal.global_position = hand
	create_tween().tween_property(goal, "global_position", goal_pos, 1.2).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	Audio.play("checkpoint", 0.8)
	director.shot(goal_pos + Vector3(4, 3, 7), goal_pos + Vector3(0, 1.6, 0), 45.0)
	await director.wait(1.4)
	goal.global_position = goal_pos
	await director.say("stax", "Key number eight. Tiptoeing out now. Very, very quietly.", "cool")
	player.place(ARENA + Vector3(0, 0.2, 4), 0.0)
	director.end()


func outro_lines() -> Array:
	return [
		["stax", "Eight keys. EIGHT. If there's a ninth key, I'm retiring.", "cheer"],
		["steve", "No ninth key! Promise! The Vault is right through the nursery door. Totally normal vault. Nothing weird."],
		["stax", "Why do you keep saying 'nothing weird'?", "think"],
		["steve", "No reason!"],
	]


## Used by tests/level_smoke.gd: starts the fight and sings the baby to sleep.
func test_hook(tree: SceneTree) -> bool:
	_start_boss()
	for n in 900:
		if director.active:
			director.skip()
		elif boss.state != boss.B.WAIT:
			break
		await tree.physics_frame
	for i in boss.MAX_HP:
		boss.take_hit()
		for n in 15:
			await tree.physics_frame
	for n in 900:
		if director.active:
			director.skip()
		elif goal != null:
			break
		await tree.physics_frame
	return goal != null and not director.active
