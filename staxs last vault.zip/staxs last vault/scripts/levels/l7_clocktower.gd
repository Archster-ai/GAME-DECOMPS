extends "res://scripts/world/level_base.gd"
## Chapter 7: The Clocktower of Forever. A long moonlit climb through the
## machinery that decides when midnight happens, everywhere.
## Route: courtyard -> spinning gear bridge (ATM) -> pendulum walkway ->
## brass lift -> gear-wall kick shaft (ATM) -> the clock-face floor with
## sweeping hands (ATM) -> bell bounce -> a 19-gear spiral around the great
## axle -> the summit, where the most feared guardian in all dimensions waits.

const AXLE := Vector3(0, 0, -162)
const ARENA := Vector3(0, 59.9, -192)
const ARENA_R := 13.0
const FACE := Vector3(0, 76, -210)

var reach_target := ARENA
var boss: Node3D
var _brass: Material
var _iron: Material
var _stone: Material
var _wood: Material
var _pendulums: Array = []    # [pivot, speed, amp, phase]
var _spinners: Array = []     # [node, speed] purely decorative
var _face_hands: Array[Node3D] = []
var _tick := 0.0
var _t := 0.0
var _fight := false


func _init() -> void:
	music = "clocktower"
	spawn_point = Vector3(0, 0.1, 6)
	spawn_yaw = 0.0
	kill_y = -15.0


func env_config() -> Dictionary:
	return {
		"top": Color(0.03, 0.04, 0.12), "horizon": Color(0.25, 0.22, 0.4), "bottom": Color(0.04, 0.04, 0.08),
		"sun_color": Color(0.7, 0.8, 1.0), "sun_energy": 0.9, "sun_angle": Vector2(-35, 170),
		"sun_size": 6.0, "sun_glow": 0.7, "stars": 1.0, "clouds": 0.25, "cloud_color": Color(0.35, 0.35, 0.5),
		"fog_color": Color(0.2, 0.22, 0.38), "fog_density": 0.006, "volumetric": 0.02,
		"vol_color": Color(0.7, 0.75, 1.0), "ambient": 0.9, "exposure": 1.1, "glow": 1.1,
		"tint": Color(0.95, 0.97, 1.05), "saturation": 1.05, "vignette": 0.45, "player_light": 0.8,
	}


# ---------------------------------------------------------------- props

## A flat spinning gear platform with teeth.
func gear(top: Vector3, r: float, spin: float) -> void:
	if spin == 0.0:
		cylinder(top - Vector3(0, 0.3, 0), r, 0.6, _brass, 28)
		_teeth(self, top - Vector3(0, 0.3, 0), r)
		return
	var m := mover(Vector3(r * 2.0, 0.6, r * 2.0), _brass, top - Vector3(0, 0.3, 0), Vector3.ZERO, 4.0, 0.0, spin, "cylinder")
	_teeth(m, Vector3.ZERO, r)


func _teeth(parent: Node3D, center: Vector3, r: float) -> void:
	var n := int(r * 5.0)
	for i in n:
		var a := TAU * i / n
		var t := deco_box(center + Vector3(cos(a) * (r + 0.2), 0, sin(a) * (r + 0.2)), Vector3(0.5, 0.5, 0.45), _brass, Vector3(0, -a, 0))
		if parent != self:
			t.reparent(parent, false)
	var hub := deco_cyl(center + Vector3(0, 0.32, 0), r * 0.25, 0.1, _iron)
	if parent != self:
		hub.reparent(parent, false)


## A big decorative gear standing upright, turning slowly.
func wall_gear(pos: Vector3, r: float, speed: float, yaw := 0.0) -> void:
	var root := Node3D.new()
	root.position = pos
	root.rotation.y = yaw
	add_child(root)
	var wheel := Node3D.new()
	root.add_child(wheel)
	var disc := CylinderMesh.new()
	disc.top_radius = r
	disc.bottom_radius = r
	disc.height = 0.6
	disc.radial_segments = 32
	deco(disc, _brass, Vector3.ZERO, Vector3(PI / 2, 0, 0), Vector3.ONE, wheel)
	var n := int(r * 4.0)
	for i in n:
		var a := TAU * i / n
		var tb := BoxMesh.new()
		tb.size = Vector3(0.7, 0.8, 0.6)
		deco(tb, _brass, Vector3(cos(a) * (r + 0.3), sin(a) * (r + 0.3), 0), Vector3(0, 0, a), Vector3.ONE, wheel)
	for i in 4:
		var sb := BoxMesh.new()
		sb.size = Vector3(r * 1.8, 0.4, 0.7)
		deco(sb, _iron, Vector3.ZERO, Vector3(0, 0, PI * i / 4.0), Vector3.ONE, wheel)
	_spinners.append([wheel, speed])


## A pendulum hanging from `pivot`, its blade swinging across the path.
func pendulum(pivot: Vector3, length: float, speed: float, amp: float, phase: float) -> void:
	var p := Node3D.new()
	p.position = pivot
	add_child(p)
	var arm := deco_cyl(Vector3(0, -length * 0.5, 0), 0.12, length, _iron)
	arm.reparent(p, false)
	var blade := hazard_box(Vector3.ZERO, Vector3(3.2, 1.1, 0.8), _brass)
	blade.reparent(p, false)
	blade.position = Vector3(0, -length, 0)
	var edge := deco_box(Vector3(0, -length - 0.6, 0), Vector3(3.4, 0.15, 0.3), Mats.glow(Color(1.0, 0.5, 0.2), 2.0))
	edge.reparent(p, false)
	var bob := deco_ball(Vector3(0, -length, 0), 1.0, _brass, Vector3(1.0, 0.8, 0.5))
	bob.reparent(p, false)
	_pendulums.append([p, speed, amp, phase])


func lamp(pos: Vector3) -> void:
	deco_cyl(pos + Vector3(0, 1.6, 0), 0.08, 3.2, _iron)
	deco_ball(pos + Vector3(0, 3.3, 0), 0.3, Mats.glow(Color(1.0, 0.75, 0.4), 3.0))
	omni(pos + Vector3(0, 3.3, 0), Color(1.0, 0.72, 0.4), 9.0, 1.4)


# ---------------------------------------------------------------- build

func build() -> void:
	_brass = Mats.solid(Color(0.85, 0.62, 0.28), 0.3, 0.9)
	_iron = Mats.solid(Color(0.22, 0.22, 0.25), 0.5, 0.7)
	_stone = Mats.pattern("bricks", [Color(0.42, 0.4, 0.45), Color(0.25, 0.24, 0.28), Color(0.5, 0.47, 0.52)], 0.35, 0.9)
	_wood = Mats.rough_surface(Color(0.35, 0.22, 0.12), Color(0.25, 0.15, 0.08), 0.3, 0.8, 71, 0.5)
	_build_courtyard()
	_build_gear_bridge()
	_build_pendulums()
	_build_lift_and_shaft()
	_build_clock_floor()
	_build_spiral()
	_build_summit()
	_build_backdrop()
	Fx.ambient(self, Vector3(0, 30, -100), Vector3(40, 30, 100), Color(0.8, 0.85, 1.0, 0.5), 200, 0.08)


func _build_courtyard() -> void:
	box(Vector3(0, -0.5, 0), Vector3(24, 1, 24), _stone)
	for x in [-9.0, 9.0]:
		for z in [-9.0, 7.0]:
			lamp(Vector3(x, 0, z))
	coin_ring(Vector3(0, 1, -3), 3.2, 8)
	npc("steve", "steve", Vector3(4, 0, 1), 2.5, [
		["steve", "The Clocktower of Forever! It decides when midnight happens. Everywhere. All at once."],
		["steve", "Tips! Gears spin, pendulums swing, clock hands sweep. Time your jumps. Get it? TIME?"],
		["stax", "I hate that I laughed.", "facepalm"],
		["steve", "And whatever you do, don't anger the Guardian of Midnight. He's never lost. Ever."],
	], [["steve", "Up, up, up! Midnight's at the top. So is the Guardian. Good luck! Genuinely!"]])
	npc("cuckoo", "cuckoo", Vector3(-5, 0, -2), 0.6, [
		["cuckoo", "CUCKOO! CUCKOO! Sorry. Reflex. I've been stuck in a clock for three hundred years."],
		["stax", "You're a cuckoo. From a clock. You're talking.", "think"],
		["cuckoo", "Everybody's talking in this game, buddy. The toast talked. Get over it."],
		["cuckoo", "Listen: the Guardian at the top? Lord Tick-Tock the Eternal. Undefeated for twelve hundred years!"],
		["cuckoo", "Some say he's the most fearsome foe in all the dimensions. CUCKOO! Sorry."],
		["stax", "Great. Love that for me.", "shrug"],
	], [["cuckoo", "Undefeated! Twelve hundred years! CUCKOO! ...It's the stairs. Nobody does the stairs."]])
	wall_gear(Vector3(-13, 8, -6), 5.0, 0.3, PI / 2)
	wall_gear(Vector3(13, 6, -8), 3.5, -0.5, -PI / 2)
	sign_text("CLOCKTOWER\nOF FOREVER", Vector3(0, 6.5, -12.2), PI, 150, Color(1.0, 0.8, 0.45), 1.3)
	tip(Vector3(0, 1.5, -10), Vector3(24, 4, 3), "steve", "Spinning gears ahead! They carry you round, so jump toward the next one.")


func _build_gear_bridge() -> void:
	var gears := [[Vector3(1.5, 0.5, -17), 0.7], [Vector3(-1.5, 1.0, -24.5), -0.8], [Vector3(1.5, 1.5, -32), 0.9], [Vector3(-1.5, 2.0, -39.5), -1.0]]
	for g in gears:
		gear(g[0], 3.0, g[1])
		coin(g[0] + Vector3(0, 1.2, 0))
	coin(Vector3(0, 4.5, -28), 5)
	box(Vector3(0, 0.5, -50), Vector3(10, 4, 8), _stone)
	checkpoint(Vector3(-3, 2.5, -47.5), 0.0)
	enemy("gearbot", Vector3(-3.5, 2.5, -52), Vector3(3.5, 2.5, -52))
	lamp(Vector3(4, 2.5, -47))
	tip(Vector3(0, 3.5, -52), Vector3(10, 4, 3), "steve", "Pendulums! Wait for the blade to swing past, then dash. Tick, tock, GO!")


func _build_pendulums() -> void:
	box(Vector3(0, 2.3, -69), Vector3(3, 0.4, 30), _wood)
	for s in [-1.0, 1.0]:
		box(Vector3(s * 1.6, 3.0, -69), Vector3(0.1, 1.0, 30), _iron)
	deco_box(Vector3(0, 15, -69), Vector3(10, 1, 32), _iron)
	pendulum(Vector3(0, 14, -60), 10.2, 1.7, 0.95, 0.0)
	pendulum(Vector3(0, 14, -69), 10.2, 2.0, 0.95, 1.6)
	pendulum(Vector3(0, 14, -78), 10.2, 2.4, 0.95, 3.1)
	for i in 8:
		coin(Vector3(0, 3.5, -56 - i * 3.6))
	box(Vector3(0, 1.0, -90), Vector3(10, 3, 10), _stone)
	coin_ring(Vector3(0, 3.5, -90), 2.5, 6)
	lamp(Vector3(-4, 2.5, -87))
	enemy("gearbot", Vector3(-3.5, 2.5, -92), Vector3(3.5, 2.5, -92))


func _build_lift_and_shaft() -> void:
	var lift := mover(Vector3(4, 0.8, 4), _brass, Vector3(0, 2.1, -99), Vector3(0, 8, 0), 6.0)
	for s in [-1.0, 1.0]:
		deco_box(Vector3(s * 1.9, 0.8, 0), Vector3(0.1, 0.8, 4), _iron).reparent(lift, false)
	for s in [-1.0, 1.0]:
		box(Vector3(s * 2.3, 14, -99), Vector3(0.2, 24, 0.2), _iron)
	tip(Vector3(0, 3.5, -95), Vector3(8, 4, 2), "steve", "Brass lift! Going up. Please enjoy the elevator music. It's just ticking.")
	box(Vector3(0, 10, -106), Vector3(8, 1, 6), _stone)
	coin_line(Vector3(0, 11.5, -104), Vector3(0, 11.5, -108), 3)
	# Two gear-covered walls to kick between.
	for s in [-1.0, 1.0]:
		box(Vector3(s * 3.0, 17.25, -112), Vector3(2, 14.5, 6), _stone)
		wall_gear(Vector3(s * 2.32, 17, -112), 2.2, 0.8 * s, s * PI / 2)
	box(Vector3(0, 10.25, -112), Vector3(4, 0.5, 6), _stone)
	coin_line(Vector3(0, 13, -112), Vector3(0, 23, -112), 5)
	tip(Vector3(0, 12, -110), Vector3(4, 3, 3), "steve", "Wall kicks! Jump into a wall, jump again as you touch it. Clockwork precision!")
	box(Vector3(0, 23.5, -121), Vector3(10, 1, 8), _stone)
	checkpoint(Vector3(-3, 24, -118.5), 0.0)
	lamp(Vector3(4, 24, -119))
	coin(Vector3(4, 25.5, -123), 5)


func _build_clock_floor() -> void:
	var c := Vector3(0, 23.5, -138)
	var face_mat := Mats.solid(Color(0.95, 0.92, 0.82), 0.4)
	cylinder(c, 11.0, 1.0, face_mat, 48)
	deco_cyl(c + Vector3(0, 0.51, 0), 11.2, 0.04, _brass)
	deco_cyl(c + Vector3(0, 0.52, 0), 10.6, 0.04, face_mat)
	var numerals := ["XII", "I", "II", "III", "IIII", "V", "VI", "VII", "VIII", "IX", "X", "XI"]
	for i in 12:
		var a := TAU * i / 12.0
		var l := sign_text(numerals[i], c + Vector3(sin(a) * 9.0, 0.56, -cos(a) * 9.0), 0.0, 160, Color(0.1, 0.08, 0.06))
		l.rotation = Vector3(-PI / 2, 0, -a)
	# Minute hand sweeps fast, hour hand slow and the other way. Jump them.
	hazard_box(c + Vector3(0, 1.2, 0), Vector3(19, 0.5, 0.7), Mats.solid(Color(0.08, 0.08, 0.1), 0.3, 0.6), 0.9)
	hazard_box(c + Vector3(0, 1.3, 0), Vector3(11, 0.9, 1.0), Mats.solid(Color(0.08, 0.08, 0.1), 0.3, 0.6), -0.35)
	deco_cyl(c + Vector3(0, 1.4, 0), 0.8, 0.8, _brass)
	coin_ring(c + Vector3(0, 1.8, 0), 6.0, 10)
	tip(c + Vector3(0, 1.5, 9), Vector3(10, 4, 3), "steve", "The clock floor! Jump over the hands. The minute hand is fast. The hour hand is... emotionally fast.")
	# The bell: land on it to bounce up to the gear spiral.
	var bell := Node3D.new()
	var bm := CylinderMesh.new()
	bm.top_radius = 0.6
	bm.bottom_radius = 1.5
	bm.height = 1.6
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = _brass
	mi.position.y = 0.8
	bell.add_child(mi)
	var b := bouncer(Vector3(0, 24, -148.3), 1.4, 26.0, bell)
	b.body_entered.connect(func(_x): Audio.play("bong", 1.0, 0.03, -4.0))
	box(Vector3(0, 31.5, -151.5), Vector3(6, 1, 5), _stone)
	checkpoint(Vector3(-2, 32, -150), 0.0)
	coin_line(Vector3(0, 27, -148.3), Vector3(0, 32.5, -151), 3)
	tip(Vector3(0, 25.5, -145), Vector3(4, 3, 3), "steve", "Ring the bell! Land on it and it'll launch you up. BONG!")


func _build_spiral() -> void:
	# The great axle, and nineteen gears winding up around it.
	cylinder(AXLE + Vector3(0, 47, 0), 2.0, 46.0, _iron, 24)
	for y in [30.0, 45.0, 60.0]:
		deco_cyl(AXLE + Vector3(0, y, 0), 2.4, 0.8, _brass)
	for i in 19:
		var a := deg_to_rad(i * 50.0)
		var top := 33.8 + i * 1.45
		var p := AXLE + Vector3(sin(a) * 6.0, top, cos(a) * 6.0)
		gear(p, 1.8, 0.0 if i % 3 != 1 else (1.2 if i % 2 == 0 else -1.2))
		if i % 2 == 0:
			coin(p + Vector3(0, 1.1, 0))
	coin(AXLE + Vector3(0, 60.5, -6), 5)
	# Scaffolding around the spiral.
	for cx in [-9.0, 9.0]:
		for cz in [-9.0, 9.0]:
			box(AXLE + Vector3(cx, 40, cz), Vector3(0.6, 44, 0.6), _iron)
	omni(AXLE + Vector3(0, 40, 8), Color(1.0, 0.72, 0.4), 16.0, 1.6)
	omni(AXLE + Vector3(0, 55, -8), Color(1.0, 0.72, 0.4), 16.0, 1.6)
	tip(AXLE + Vector3(0, 34, 7), Vector3(4, 3, 4), "steve", "Round and round and up! The summit's right above. Midnight is so close I can smell it.")


func _build_summit() -> void:
	# Bridge from the top of the spiral to the summit.
	box(Vector3(0, 59.7, -174), Vector3(3, 0.4, 9), _wood)
	cylinder(ARENA - Vector3(0, 1, 0), ARENA_R, 2.0, Mats.pattern("tiles", [Color(0.4, 0.38, 0.45), Color(0.25, 0.24, 0.3)], 0.3, 0.6), 48)
	deco_cyl(ARENA + Vector3(0, 0.02, 0), ARENA_R - 1.0, 0.04, Mats.glow(Color(0.5, 0.6, 1.0), 0.6))
	deco_cyl(ARENA + Vector3(0, 0.03, 0), ARENA_R - 1.4, 0.04, Mats.solid(Color(0.3, 0.28, 0.35), 0.6))
	for i in 20:
		var a := TAU * i / 20.0
		if absf(wrapf(a, -PI, PI)) < 0.3:
			continue
		var p := ARENA + Vector3(sin(a), 0, cos(a)) * ARENA_R
		deco_cyl(p + Vector3(0, 0.6, 0), 0.12, 1.2, _brass)
		deco_ball(p + Vector3(0, 1.3, 0), 0.2, Mats.glow(Color(1.0, 0.75, 0.4), 2.5))
	checkpoint(ARENA + Vector3(-3, 0, 10.5), 0.0)
	# Key light on the guardian, so he isn't a silhouette against the clock.
	spot(ARENA + Vector3(3, 14, 12), ARENA + Vector3(0, 4, -4), Color(1.0, 0.9, 0.75), 40.0, 25.0, 6.0)
	omni(ARENA + Vector3(0, 5, 4), Color(0.8, 0.85, 1.0), 14.0, 1.0)
	trigger(ARENA + Vector3(0, 2, 9), Vector3(10, 5, 3), func(_p): _start_boss())


func _build_backdrop() -> void:
	# The giant glowing clock face behind the summit.
	var ring := TorusMesh.new()
	ring.inner_radius = 13.0
	ring.outer_radius = 14.5
	ring.rings = 64
	deco(ring, _brass, FACE, Vector3(PI / 2, 0, 0))
	var disc := CylinderMesh.new()
	disc.top_radius = 13.0
	disc.bottom_radius = 13.0
	disc.height = 0.5
	disc.radial_segments = 64
	deco(disc, Mats.glow(Color(0.95, 0.9, 0.7), 1.3), FACE - Vector3(0, 0, 0.3), Vector3(PI / 2, 0, 0))
	for i in 12:
		var a := TAU * i / 12.0
		var mark := BoxMesh.new()
		mark.size = Vector3(0.6, 2.2 if i % 3 == 0 else 1.2, 0.3)
		deco(mark, Mats.solid(Color(0.1, 0.08, 0.06), 0.5), FACE + Vector3(sin(a) * 11.0, cos(a) * 11.0, 0.1), Vector3(0, 0, -a))
	for hl in [9.0, 6.0]:
		var hand := Node3D.new()
		hand.position = FACE + Vector3(0, 0, 0.3)
		add_child(hand)
		var hm := BoxMesh.new()
		hm.size = Vector3(0.8 if hl < 8.0 else 0.5, hl, 0.2)
		deco(hm, Mats.solid(Color(0.08, 0.06, 0.05), 0.5), Vector3(0, hl * 0.45, 0), Vector3.ZERO, Vector3.ONE, hand)
		_face_hands.append(hand)
	omni(FACE + Vector3(0, 0, 8), Color(1.0, 0.9, 0.7), 30.0, 1.5)
	box(FACE + Vector3(0, -36, -3), Vector3(34, 60, 4), _stone)
	# Distant towers and gears in the night.
	var rng := RandomNumberGenerator.new()
	rng.seed = 12
	for i in 16:
		var a := rng.randf() * TAU
		var d := rng.randf_range(90.0, 180.0)
		var h := rng.randf_range(40.0, 110.0)
		var p := Vector3(cos(a) * d, h * 0.5 - 30.0, -100 + sin(a) * d)
		deco_box(p, Vector3(10, h, 10), _stone)
		deco_cyl(p + Vector3(0, h * 0.5 + 5, 0), 7.0, 10.0, _iron, Vector3.ZERO, 0.2)
		if i % 3 == 0:
			wall_gear(p + Vector3(0, h * 0.2, 5.5), 4.0, rng.randf_range(-0.4, 0.4))


# ---------------------------------------------------------------- animation

func _process(delta: float) -> void:
	_t += delta
	for p in _pendulums:
		(p[0] as Node3D).rotation.z = sin(_t * p[1] + p[3]) * p[2]
	for s in _spinners:
		(s[0] as Node3D).rotation.z += s[1] * delta
	if _face_hands.size() == 2:
		# The big clock creeps toward midnight as you climb.
		var progress := clampf((player.global_position.y if player else 0.0) / 60.0, 0.0, 1.0)
		_face_hands[0].rotation.z = lerp_angle(_face_hands[0].rotation.z, -TAU * (0.75 + 0.25 * progress), delta)
		_face_hands[1].rotation.z = lerp_angle(_face_hands[1].rotation.z, -TAU * (0.97 + 0.03 * progress), delta)
	_tick -= delta
	if _tick <= 0.0:
		_tick = 1.0
		Audio.play("tick", 1.0 if int(_t) % 2 == 0 else 0.8, 0.0, -18.0)


# ---------------------------------------------------------------- the guardian

func _start_boss() -> void:
	if _fight:
		return
	_fight = true
	player.spawn_point = ARENA + Vector3(0, 0.5, 9)
	director.begin()
	Audio.stop_music(0.8)
	player.place(ARENA + Vector3(0, 0.2, 9), 0.0)
	boss = Puppet.new()
	boss.kind = "grandclock"
	boss.speaker = "ticktock"
	boss.scale = Vector3.ONE * 2.2
	add_child(boss)
	boss.global_position = ARENA + Vector3(0, 0, -4)
	boss.rotation.y = PI
	director.actors["ticktock"] = boss

	# Thunder, lightning, a silhouette against the great clock.
	director.shot(ARENA + Vector3(0, 3, 16), boss.global_position + Vector3(0, 6, 0), 45.0)
	Game.fx.flash(Color(0.8, 0.85, 1.0), 0.5)
	Audio.play("thunder")
	director.shake(0.4)
	await director.wait(1.0)
	Audio.play("bong", 0.5)
	director.move(ARENA + Vector3(3, 4, 6), boss.global_position + Vector3(0, 7.5, 0), 3.0, 38.0)
	await director.say("ticktock", "HALT! Who dares climb the Clocktower of Forever?!")
	director.two_shot(player, boss, 1.0, 50.0)
	await director.say("stax", "Me. Stax. I need midnight. It's a whole thing.", "cool")
	director.shot(boss.global_position + Vector3(2.5, 4, 8), boss.global_position + Vector3(0, 7.5, 0), 36.0)
	Game.fx.flash(Color(0.8, 0.85, 1.0), 0.3)
	Audio.play("thunder", 1.2)
	boss.emote = "attack"
	await director.lines([
		["ticktock", "I am Lord Tick-Tock the Eternal! Guardian of Midnight! Undefeated for twelve hundred years!"],
		["ticktock", "Many have challenged me. All have failed. Prepare yourself, whippersnapper!"],
	])
	boss.emote = ""
	Audio.play_music("boss", 0.2)
	Audio.set_drums(1.0)
	director.shot(ARENA + Vector3(0, 6, 17), boss.global_position + Vector3(0, 4, 0), 55.0)
	director.move(ARENA + Vector3(0, 4, 14), boss.global_position + Vector3(0, 5, 0), 3.0)
	await director.title("FINAL GUARDIAN", "Lord Tick-Tock the Eternal", "Undefeated for 1,200 years", 1.6)
	await director.settle()
	player.place(ARENA + Vector3(0, 0.2, 9), 0.0)
	director.end()
	hud.show_boss("LORD TICK-TOCK THE ETERNAL", 100)

	# The battle of the ages begins. Briefly.
	await _battle()


func _battle() -> void:
	var t := 0.0
	bark("ticktock", "Have at thee! En garde! Hup! ...Hup.")
	while t < 3.2 and is_instance_valid(boss):
		var dt := get_physics_process_delta_time()
		await get_tree().physics_frame
		t += dt
		var to := player.global_position - boss.global_position
		to.y = 0.0
		if to.length() > 2.5:
			boss.global_position += to.normalized() * 0.35 * dt
		boss.rotation.y = lerp_angle(boss.rotation.y, atan2(-to.x, -to.z), 2.0 * dt)
		boss.emote = "attack" if fmod(t, 1.2) < 0.5 else ""
	boss.emote = "tired"
	bark("ticktock", "Oh. Oh dear. Oh, my back. Oh, my EVERYTHING.")
	await get_tree().create_timer(1.6).timeout
	await _collapse()


func _collapse() -> void:
	Audio.stop_music(0.05)
	Audio.play("scratch")
	hud.set_boss_hp(0)
	director.begin()
	var bp := boss.global_position
	director.shot(bp + Vector3(7, 3, 7), bp + Vector3(0, 3, 0), 45.0)
	await director.wait(0.4)
	# Timber!
	var fall := create_tween()
	fall.tween_property(boss, "rotation:x", PI / 2, 1.4).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	await director.wait(0.7)
	Audio.play("boom")
	Audio.play("bong", 0.4)
	director.shake(0.7)
	Fx.burst(self, bp + Vector3(0, 0.5, -4), Color(0.9, 0.85, 0.8, 0.8), 50, 8.0, 0.7, 1.0, -3.0)
	await director.wait(1.0)
	boss.rotation.x = PI / 2
	hud.hide_boss()
	director.shot(bp + Vector3(-3, 2.2, -3), bp + Vector3(0, 1, -7), 40.0)
	await director.say("ticktock", "Zzzz... hm? Oh. You win, sonny. I'm twelve hundred and six. I need a nap.")
	director.two_shot(player, boss, 1.0, 50.0)
	await director.lines([
		["stax", "...That's it? No epic battle? I did a WHOLE spiral staircase!", "shrug"],
		["ticktock", "Undefeated for twelve hundred years, because nobody ever climbed all those stairs."],
		["ticktock", "The Midnight Key is in my pendulum. Help yourself. Mind the cobwebs. Zzzz..."],
		["stax", "...Honestly? Respect.", "cool"],
	])
	place_goal(ARENA + Vector3(0, 0, 3))
	var target := goal.global_position
	goal.global_position = bp + Vector3(0, 1.5, -2)
	create_tween().tween_property(goal, "global_position", target, 1.0).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	Audio.play("checkpoint", 0.9)
	director.shot(target + Vector3(3, 2.5, 6), target + Vector3(0, 1.5, 0), 42.0)
	await director.wait(1.2)
	goal.global_position = target
	player.place(ARENA + Vector3(0, 0.2, 9), 0.0)
	director.end()
	Audio.play_music("clocktower", 1.0)
	bark("ticktock", "Zzzzzz... cuckoo... zzzz...")


func intro() -> void:
	director.begin()
	Game.fx.set_black(true)
	player.place(spawn_point + Vector3(0, 26, 0), spawn_yaw)
	# Up the tower to the great clock, as lightning flickers.
	director.shot(Vector3(26, 6, 10), AXLE + Vector3(0, 20, 0), 55.0)
	Game.fx.fade_in(2.0)
	director.move(Vector3(18, 60, -150), FACE, 7.0, 45.0)
	await director.wait(1.5)
	await director.say("narrator", "At the edge of every dimension stands the Clocktower of Forever.")
	Game.fx.flash(Color(0.8, 0.85, 1.0), 0.4)
	Audio.play("thunder")
	await director.say("narrator", "It decides when midnight happens. Everywhere. For everyone.")
	await director.settle()
	Audio.play("bong", 0.6)
	director.shot(Vector3(7, 3, 15), Vector3(0, 4, 4), 50.0)
	Audio.play("whoosh", 1.1)
	var t := 0.0
	while player.global_position.y > 0.6 and t < 4.0 and not director.skipping:
		t += await director._frame()
	player.place(spawn_point, spawn_yaw)
	Audio.play("land")
	director.shake(0.3)
	var sp := player.global_position
	director.shot(sp + Vector3(-2.3, 1.5, -2.7), sp + Vector3(0, 1.3, 0), 36.0)
	await director.say("stax", "Okay. Giant spooky clocktower. Lightning. Totally normal Tuesday.", "cool")
	director.shot(Vector3(10, 5, 14), Vector3(0, 12, -40), 50.0)
	director.move(Vector3(4, 3, 10), Vector3(0, 20, -60), 4.0, 44.0)
	await director.title(info.chapter, info.title, info.subtitle)
	await director.settle()
	player.place(spawn_point, spawn_yaw)
	director.end()


func outro_lines() -> Array:
	return [
		["stax", "The Midnight Key! Seventh key. The Vault opens at midnight, and midnight's in my pocket.", "cheer"],
		["steve", "Now THAT'S what I call good timing. Get it? Timing? ...To the Vault! Well. Almost."],
		["stax", "Almost?", "think"],
		["steve", "One tiny stop first. You're good with kids, right?"],
	]


## Used by tests/level_smoke.gd: runs the whole "battle".
func test_hook(tree: SceneTree) -> bool:
	_start_boss()
	for n in 2400:
		if director.active:
			director.skip()
		elif goal != null:
			break
		await tree.physics_frame
	return goal != null and not director.active
