extends "res://scripts/world/level_base.gd"
## Chapter 6: The Rubber Duck Desert. Scorching sand, giant rubber ducks,
## pickle cacti and soap-bubble bounce pads... and on the horizon, a faucet:
## the whole desert is the bottom of a colossal bathtub.
## Route: dune -> duck hop -> sandstone shelf (ATM) -> soap bubble -> mesa ->
## plank bridge -> drifting slabs -> the salt-flat arena, where a pirate ship
## crashes out of the sky and Captain Moneybeard attacks.

const PirateScript := preload("res://scripts/actors/boss_pirate.gd")

const ARENA := Vector3(0, 8, -116)
const ARENA_R := 18.0
const SHIP_AT := Vector3(0, 5.5, -146)
const HOT_SAND_Y := -4.0

var boss: Node3D
## Where the key will appear, for tests/reachability.gd.
var reach_target := ARENA
var _ship: Node3D
var _sand: Material
var _stone: Material
var _rubber: Material
var _pickle: Material
var _fight_started := false
var _told_stomp := false


func _init() -> void:
	music = "desert"
	spawn_point = Vector3(0, 0.1, 4)
	spawn_yaw = 0.0
	kill_y = -10.0


func env_config() -> Dictionary:
	return {
		"top": Color(0.35, 0.55, 0.9), "horizon": Color(1.0, 0.82, 0.55), "bottom": Color(0.9, 0.7, 0.45),
		"sun_color": Color(1.0, 0.9, 0.7), "sun_energy": 1.8, "sun_angle": Vector2(-62, -20),
		"sun_size": 2.0, "sun_glow": 0.8, "clouds": 0.15, "cloud_color": Color(1.0, 0.95, 0.85),
		"fog_color": Color(1.0, 0.82, 0.6), "fog_density": 0.003, "volumetric": 0.008,
		"vol_color": Color(1.0, 0.9, 0.7), "ambient": 0.9, "exposure": 1.0, "glow": 0.8,
		"tint": Color(1.05, 1.0, 0.9), "saturation": 1.12,
	}


# ---------------------------------------------------------------- props

func duck_platform(pos: Vector3, r: float, top: float, yaw := 0.0) -> void:
	# Body: a flat-topped cylinder hidden inside a squashed yellow ball.
	cylinder(Vector3(pos.x, top - 1.0, pos.z), r, 2.0, _rubber, 24)
	deco_ball(Vector3(pos.x, top - r * 0.55, pos.z), r * 1.15, _rubber, Vector3(1.0, 0.6, 1.25))
	var fwd := Vector3(-sin(yaw), 0, -cos(yaw))
	var head := pos + fwd * r * 0.75
	ball(Vector3(head.x, top + r * 0.35, head.z), r * 0.5, _rubber)
	var beak := deco_box(Vector3(head.x, top + r * 0.3, head.z) + fwd * r * 0.5, Vector3(r * 0.5, r * 0.16, r * 0.45), Mats.toon(Color(1.0, 0.45, 0.05)), Vector3(0, yaw, 0))
	beak.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	for s in [-1.0, 1.0]:
		var side: Vector3 = Vector3(cos(yaw), 0, -sin(yaw)) * s * r * 0.22
		deco_ball(Vector3(head.x, top + r * 0.5, head.z) + fwd * r * 0.38 + side, r * 0.1, Mats.solid(Color(0.05, 0.05, 0.05), 0.2))
	# Its tail sticks up behind.
	deco_ball(Vector3(pos.x, top + 0.2, pos.z) - fwd * r * 0.9, r * 0.35, _rubber, Vector3(0.8, 1.2, 0.6))


func pickle_cactus(pos: Vector3, h: float, hurts := true) -> void:
	if hurts:
		hazard_box(pos + Vector3(0, h * 0.5, 0), Vector3(1.2, h, 1.2), _pickle)
	else:
		deco_cyl(pos + Vector3(0, h * 0.5, 0), 0.6, h, _pickle)
	deco_cyl(pos + Vector3(0, h * 0.5, 0), 0.65, h, _pickle)
	deco_ball(pos + Vector3(0, h, 0), 0.65, _pickle)
	for i in 6:
		var a := i * 1.7
		deco_ball(pos + Vector3(cos(a) * 0.62, 0.4 + i * h / 6.0, sin(a) * 0.62), 0.14, Mats.solid(Color(0.3, 0.5, 0.15), 0.6))
	var arm := deco_cyl(pos + Vector3(0.9, h * 0.6, 0), 0.4, 1.4, _pickle, Vector3(0, 0, PI / 2))
	arm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	deco_cyl(pos + Vector3(1.55, h * 0.6 + 0.5, 0), 0.4, 1.2, _pickle)


func soap_bubble(pos: Vector3, strength: float) -> void:
	var v := Node3D.new()
	var mi := MeshInstance3D.new()
	var s := SphereMesh.new()
	s.radius = 1.3
	s.height = 2.6
	mi.mesh = s
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.8, 0.9, 1.0, 0.35)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.roughness = 0.0
	m.metallic = 0.4
	m.rim_enabled = true
	m.rim = 1.0
	m.emission_enabled = true
	m.emission = Color(0.6, 0.4, 1.0)
	m.emission_energy_multiplier = 0.4
	mi.material_override = m
	mi.position.y = 1.0
	mi.scale = Vector3(1, 0.7, 1)
	v.add_child(mi)
	bouncer(pos, 1.5, strength, v)


# ---------------------------------------------------------------- build

func build() -> void:
	_sand = Mats.rough_surface(Color(0.95, 0.78, 0.5), Color(0.85, 0.65, 0.38), 0.12, 0.95, 61, 0.5)
	_stone = Mats.rough_surface(Color(0.85, 0.5, 0.3), Color(0.7, 0.38, 0.22), 0.2, 0.9, 62, 0.8)
	_rubber = Mats.toon(Color(1.0, 0.86, 0.12), 0.25, 0.4)
	_pickle = Mats.toon(Color(0.4, 0.62, 0.2), 0.6, 0.2)

	# Hot sand below everything.
	box(Vector3(0, HOT_SAND_Y - 1, -80), Vector3(600, 2, 600), Mats.rough_surface(Color(1.0, 0.6, 0.3), Color(0.95, 0.45, 0.2), 0.08, 0.9, 63, 0.4))
	zone(Vector3(0, HOT_SAND_Y + 0.5, -80), Vector3(600, 1.2, 600), "hurt")
	Fx.ambient(self, Vector3(0, HOT_SAND_Y + 1.5, -60), Vector3(60, 1.5, 80), Color(1.0, 0.7, 0.4, 0.5), 150, 0.25, Vector3(0, 1.0, 0), 3.0)
	_build_bathtub()

	# 1. The starting dune.
	cylinder(Vector3(0, -3, 0), 10.0, 6.0, _sand, 32)
	deco_ball(Vector3(-6, -1.2, 5), 5.0, _sand, Vector3(1.2, 0.35, 1.0))
	pickle_cactus(Vector3(-7, 0, -3), 3.0, false)
	pickle_cactus(Vector3(7.5, 0, 2), 2.4, false)
	coin_ring(Vector3(0, 1, -3), 3.0, 8)
	npc("steve", "steve", Vector3(4, 0, -1), 2.4, [
		["steve", "Welcome to the Rubber Duck Desert! Don't touch the low sand. It's basically lava, but beige."],
		["steve", "Soap bubbles bounce you up. Pickle cacti are prickly. Ducks are... ducks."],
		["stax", "Anything ELSE I should know about, Steve?", "think"],
		["steve", "Nope! Nothing! Definitely no surprises at the end of this level. Why do you ask?"],
	], [["steve", "Bubbles bounce, pickles prick, sand burns. And absolutely nothing weird happens later!"]])
	npc("camel", "camel", Vector3(-4, 0, -4), 0.8, [
		["camel", "Greetings. I am a camel. I was folded from towels by a hotel housekeeper named Linda."],
		["camel", "Linda had dreams."],
		["stax", "...Cool. Hey, why is this desert so weird?", "shrug"],
		["camel", "Friend. This is no desert. Look to the horizon."],
		["stax", "Is that... a FAUCET?!", "shocked"],
		["camel", "We live at the bottom of a bathtub. At night, the drain gurgles."],
		["stax", "I'm gonna need a minute.", "facepalm"],
		["camel", "Also, a pirate ship sails these sands. It has no business being here. It never explains itself."],
	], [["camel", "The drain gurgles, friend. The drain always gurgles."]])

	# 2. Duck hop over the hot sand.
	tip(Vector3(0, 1.5, -9), Vector3(14, 4, 3), "steve", "Hop across the rubber ducks! Squeaky, bouncy, and very judgmental.")
	duck_platform(Vector3(0, 0, -17), 3.5, 1.0, 0.3)
	duck_platform(Vector3(3, 0, -27), 3.5, 2.0, -0.4)
	duck_platform(Vector3(-1, 0, -37.5), 3.5, 3.0, 0.2)
	coin_arc(Vector3(0, 1.2, -10.5), Vector3(0, 2.2, -14), 1.3, 3)
	coin_arc(Vector3(0.8, 2.2, -20.5), Vector3(2.4, 3.2, -24), 1.3, 3)
	coin_arc(Vector3(2.2, 3.2, -30.5), Vector3(0, 4.2, -34.5), 1.3, 3)
	coin(Vector3(3, 6.2, -27.5), 5)

	# 3. Sandstone shelf with a checkpoint and angry ducks.
	box(Vector3(0, -0.25, -50), Vector3(12, 7.5, 12), _stone)
	checkpoint(Vector3(-3.5, 3.5, -46), 0.0)
	enemy("duck", Vector3(-4, 3.5, -52), Vector3(4, 3.5, -52))
	pickle_cactus(Vector3(4.5, 3.5, -45.5), 2.5)
	coin_line(Vector3(-3, 4.5, -49), Vector3(3, 4.5, -49), 4)
	tip(Vector3(0, 5, -46), Vector3(12, 4, 3), "steve", "Soap bubble ahead! Land on it and you'll float right up. Squeaky clean!")

	# 4. A soap bubble up onto the mesa.
	soap_bubble(Vector3(0, 3.5, -54.5), 26.0)
	box(Vector3(0, 3.5, -66), Vector3(12, 15, 12), _stone)
	deco_box(Vector3(0, 11.1, -66), Vector3(12.2, 0.2, 12.2), _sand)
	coin_line(Vector3(0, 6, -54.5), Vector3(0, 12.5, -59), 4)
	enemy("duck", Vector3(-4, 11, -64), Vector3(4, 11, -68))
	pickle_cactus(Vector3(-4.5, 11, -69.5), 2.2)
	pickle_cactus(Vector3(4.2, 11, -62), 2.8)
	coin(Vector3(-4.5, 14.8, -61.5), 5)

	# 5. A plank bridge with a spinning towel rack.
	box(Vector3(0, 10.8, -78), Vector3(2.4, 0.4, 12), Mats.solid(Color(0.55, 0.38, 0.22), 0.8))
	hazard_box(Vector3(0, 11.6, -78), Vector3(7, 0.5, 0.5), Mats.glow(Color(1.0, 0.3, 0.3), 1.0), 1.4)
	deco_cyl(Vector3(0, 15, -78), 0.06, 6.5, Mats.solid(Color(0.8, 0.8, 0.85), 0.2, 0.9))
	coin_line(Vector3(0, 12, -73.5), Vector3(0, 12, -82.5), 5)
	tip(Vector3(0, 12, -73), Vector3(3, 4, 2), "steve", "Jump the spinning towel rack! It's heated. Obviously.")

	# 6. Drifting sandstone slabs down to the arena.
	mover(Vector3(4, 0.8, 4), _stone, Vector3(-3, 9.6, -87), Vector3(6, 0, 0), 5.0, 0.0)
	mover(Vector3(4, 0.8, 4), _stone, Vector3(3, 8.8, -93.5), Vector3(-6, 0, 0), 5.0, 0.5)
	coin_line(Vector3(0, 11.5, -87), Vector3(0, 10.5, -93.5), 3)

	# 7. The salt-flat arena, ringed by low dunes.
	cylinder(ARENA - Vector3(0, 1, 0), ARENA_R + 1.0, 2.0, Mats.rough_surface(Color(0.97, 0.95, 0.9), Color(0.88, 0.85, 0.8), 0.15, 0.7, 64, 0.3), 48)
	for i in 28:
		var a := TAU * i / 28.0
		if absf(wrapf(a, -PI, PI)) < 0.35:
			continue  # the entrance on the +Z side
		var p := ARENA + Vector3(sin(a), 0, cos(a)) * (ARENA_R + 1.0)
		var w := box(p + Vector3(0, 1.0, 0), Vector3(4.4, 2.0, 1.5), _sand)
		w.rotation.y = a
		deco_ball(p + Vector3(0, 1.2, 0), 2.2, _sand, Vector3(1.4, 0.6, 1.0))
	checkpoint(ARENA + Vector3(-4, 0, 14), 0.0)
	coin_ring(ARENA + Vector3(0, 1, 0), 9.0, 10)
	trigger(ARENA + Vector3(0, 2, 12), Vector3(20, 6, 4), func(_p): _start_boss())


## The horizon: porcelain walls, a faucet the size of a skyscraper, and a
## rubber duck the size of a mountain.
func _build_bathtub() -> void:
	var wall := MeshInstance3D.new()
	var c := CylinderMesh.new()
	c.top_radius = 300.0
	c.bottom_radius = 280.0
	c.height = 140.0
	c.cap_top = false
	c.cap_bottom = false
	c.radial_segments = 96
	wall.mesh = c
	var porcelain := StandardMaterial3D.new()
	porcelain.albedo_color = Color(0.97, 0.97, 0.98)
	porcelain.roughness = 0.15
	porcelain.cull_mode = BaseMaterial3D.CULL_DISABLED
	wall.material_override = porcelain
	wall.position = Vector3(0, 60, -80)
	wall.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(wall)
	var rim := TorusMesh.new()
	rim.inner_radius = 296.0
	rim.outer_radius = 312.0
	rim.rings = 128
	deco(rim, porcelain, Vector3(0, 130, -80), Vector3.ZERO, Vector3(1, 0.5, 1))
	var chrome := Mats.solid(Color(0.85, 0.87, 0.92), 0.1, 1.0)
	var faucet := Vector3(0, 100, -370)
	deco_cyl(faucet + Vector3(0, 20, 0), 9.0, 40.0, chrome)
	deco_cyl(faucet + Vector3(0, 36, 22), 7.0, 50.0, chrome, Vector3(PI / 2, 0, 0))
	deco_cyl(faucet + Vector3(0, 30, 45), 7.5, 14.0, chrome)
	for x in [-30.0, 30.0]:
		deco_cyl(faucet + Vector3(x, 10, 0), 8.0, 10.0, chrome)
		deco_box(faucet + Vector3(x, 18, 0), Vector3(22, 4, 4), chrome)
	# A drip that never lands.
	deco_ball(faucet + Vector3(0, 20, 45), 3.0, Mats.glass(Color(0.6, 0.8, 1.0), 0.5), Vector3(1, 1.4, 1))
	# The mountain-sized rubber duck.
	var big := Vector3(-160, -20, -230)
	deco_ball(big, 60.0, _rubber, Vector3(1.0, 0.6, 1.3))
	deco_ball(big + Vector3(0, 55, -45), 32.0, _rubber)
	deco_box(big + Vector3(0, 50, -80), Vector3(26, 9, 24), Mats.toon(Color(1.0, 0.45, 0.05)))
	# Dunes all around.
	var rng := RandomNumberGenerator.new()
	rng.seed = 8
	for i in 24:
		var a := rng.randf() * TAU
		var d := rng.randf_range(60.0, 220.0)
		var r := rng.randf_range(14.0, 34.0)
		deco_ball(Vector3(cos(a) * d, HOT_SAND_Y - r * 0.6, -80 + sin(a) * d), r, _sand, Vector3(1.4, 0.8, 1.0))


func _build_ship() -> Node3D:
	var ship := Node3D.new()
	add_child(ship)
	var wood := Mats.toon(Color(0.42, 0.26, 0.14), 0.8, 0.15)
	var dark := Mats.toon(Color(0.25, 0.14, 0.08), 0.8, 0.1)
	var deck := Mats.solid(Color(0.62, 0.45, 0.28), 0.85)
	var gold := Mats.gold()
	var cream := Mats.toon(Color(0.95, 0.92, 0.82), 0.9, 0.2)
	var parts := [
		[Vector3(0, 0, 0), Vector3(30, 5, 9), wood, Vector3.ZERO],
		[Vector3(0, -3, 0), Vector3(24, 2.5, 6), dark, Vector3.ZERO],
		[Vector3(16, 0.5, 0), Vector3(6.4, 5, 6.4), wood, Vector3(0, PI / 4, 0)],
		[Vector3(-12.5, 4, 0), Vector3(7, 4, 9.2), wood, Vector3.ZERO],
		[Vector3(0, 2.55, 0), Vector3(29, 0.2, 8.6), deck, Vector3.ZERO],
		[Vector3(0, 1.8, 4.55), Vector3(30, 0.4, 0.2), gold, Vector3.ZERO],
		[Vector3(0, 1.8, -4.55), Vector3(30, 0.4, 0.2), gold, Vector3.ZERO],
		[Vector3(20, 3.5, 0), Vector3(8, 0.5, 0.5), wood, Vector3(0, 0, 0.35)],
	]
	for p in parts:
		var b := BoxMesh.new()
		b.size = p[1]
		deco(b, p[2], p[0], p[3], Vector3.ONE, ship)
	for x in [-10.0, -4.0, 2.0, 8.0]:
		var port := BoxMesh.new()
		port.size = Vector3(1.6, 1.4, 0.2)
		deco(port, Mats.solid(Color(0.05, 0.04, 0.03)), Vector3(x, 0.8, 4.52), Vector3.ZERO, Vector3.ONE, ship)
		var cn := CylinderMesh.new()
		cn.top_radius = 0.45
		cn.bottom_radius = 0.55
		cn.height = 2.0
		deco(cn, Mats.solid(Color(0.1, 0.1, 0.11), 0.3, 0.9), Vector3(x, 0.8, 5.2), Vector3(PI / 2, 0, 0), Vector3.ONE, ship)
	for mx in [-4.0, 6.0]:
		var mast := CylinderMesh.new()
		mast.top_radius = 0.35
		mast.bottom_radius = 0.5
		mast.height = 24.0
		deco(mast, dark, Vector3(mx, 14, 0), Vector3.ZERO, Vector3.ONE, ship)
		for i in 2:
			var y := 10.0 + i * 8.0
			var yard := CylinderMesh.new()
			yard.top_radius = 0.2
			yard.bottom_radius = 0.2
			yard.height = 12.0 - i * 3.0
			deco(yard, dark, Vector3(mx, y + 3.4, 0), Vector3(PI / 2, 0, 0), Vector3.ONE, ship)
			var sail := BoxMesh.new()
			sail.size = Vector3(0.25, 6.5, 11.0 - i * 3.0)
			var sm := deco(sail, cream, Vector3(mx + 0.4, y, 0), Vector3(0, 0, 0.05), Vector3.ONE, ship)
			sm.scale = Vector3(1, 1, 1)
			var emblem := MeshInstance3D.new()
			emblem.mesh = Mats.dollar_mesh()
			emblem.material_override = Mats.solid(Color(0.1, 0.08, 0.08), 0.6)
			emblem.scale = Vector3.ONE * (4.0 - i)
			emblem.position = Vector3(mx + 0.6, y, 0)
			emblem.rotation.y = PI / 2
			ship.add_child(emblem)
	var nest := CylinderMesh.new()
	nest.top_radius = 1.4
	nest.bottom_radius = 1.0
	nest.height = 1.4
	deco(nest, wood, Vector3(-4, 24, 0), Vector3.ZERO, Vector3.ONE, ship)
	var flag := BoxMesh.new()
	flag.size = Vector3(4, 2.6, 0.1)
	deco(flag, Mats.solid(Color(0.06, 0.06, 0.07), 0.8), Vector3(-2, 27, 0), Vector3.ZERO, Vector3.ONE, ship)
	var fe := MeshInstance3D.new()
	fe.mesh = Mats.dollar_mesh()
	fe.material_override = Mats.solid(Color.WHITE, 0.5)
	fe.scale = Vector3.ONE * 1.8
	fe.position = Vector3(-2, 27, 0.12)
	ship.add_child(fe)
	var wheel := TorusMesh.new()
	wheel.inner_radius = 0.8
	wheel.outer_radius = 1.0
	deco(wheel, gold, Vector3(-12.5, 7.2, 0), Vector3(0, 0, PI / 2), Vector3.ONE, ship)
	var lantern := omni(Vector3.ZERO, Color(1.0, 0.7, 0.3), 12.0, 2.0)
	lantern.reparent(ship, false)
	lantern.position = Vector3(-15, 8, 0)
	var nm := sign_text("THE GOLDEN GOOSE", Vector3(0, 1.0, 4.7), PI, 150, Color(1.0, 0.8, 0.3), 0.6)
	nm.reparent(ship, false)
	nm.position = Vector3(-8, 1.0, 4.7)
	return ship


# ---------------------------------------------------------------- the boss

func _start_boss() -> void:
	if _fight_started:
		return
	_fight_started = true
	player.spawn_point = ARENA + Vector3(-4, 0.5, 12)
	director.begin()
	Audio.stop_music(0.6)
	player.velocity = Vector3.ZERO
	player.speed = 0.0
	player.place(ARENA + Vector3(0, 0.2, 9), 0.0)
	var sp := player.global_position
	director.shot(sp + Vector3(-2.5, 1.5, -3.0), sp + Vector3(0, 1.3, 0), 36.0)
	await director.say("stax", "Okay. Key number six should be right... about... here.", "think")
	Audio.play("rumble", 0.5)
	Audio.play("hit_low", 0.4)
	await director.wait(0.8)
	await director.say("stax", "...Was that a FOGHORN? In a DESERT?", "shocked")

	# A pirate ship tears out of the sky.
	var portal_at := SHIP_AT + Vector3(0, 42, 6)
	director.shot(ARENA + Vector3(14, 4, 16), portal_at, 55.0)
	var portal := _portal(portal_at)
	Audio.play("whoosh", 0.5)
	Game.fx.flash(Color(0.8, 0.9, 1.0), 0.5)
	await director.wait(0.6)
	_ship = _build_ship()
	_ship.global_position = portal_at
	_ship.rotation = Vector3(0.35, 0.3, -0.25)
	var fall := create_tween().set_parallel()
	fall.tween_property(_ship, "global_position", SHIP_AT, 1.1).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	fall.tween_property(_ship, "rotation", Vector3(0, 0, 0.04), 1.1)
	await director.wait(1.1)
	_ship.global_position = SHIP_AT
	_ship.rotation = Vector3(0, 0, 0.04)
	portal.queue_free()
	Audio.play("boom")
	Audio.play("hit_low")
	director.shake(1.0)
	Fx.burst(self, SHIP_AT + Vector3(0, 1, 5), Color(0.95, 0.8, 0.55, 0.9), 80, 16.0, 1.4, 1.4, -6.0)
	Fx.burst(self, SHIP_AT + Vector3(10, 1, 5), Color(0.95, 0.8, 0.55, 0.9), 40, 12.0, 1.2, 1.2, -6.0)

	# The captain.
	boss = PirateScript.new()
	boss.level = self
	boss.arena_center = ARENA
	boss.arena_radius = ARENA_R
	for x in [-10.0, -4.0, 2.0, 8.0]:
		boss.cannons.append(SHIP_AT + Vector3(x, 0.8, 6.2))
	add_child(boss)
	boss.global_position = SHIP_AT + Vector3(12, 2.7, 2)
	boss.rotation.y = PI - 0.5
	director.actors["moneybeard"] = boss.puppet
	await director.wait(0.8)
	director.shot(SHIP_AT + Vector3(19, 6.0, 14), SHIP_AT + Vector3(12, 4.6, 2), 40.0)
	boss.puppet.emote = "laugh"
	await director.say("moneybeard", "ARRR! Ahoy there, landlubber!")
	director.two_shot(player, boss, 1.0, 55.0)
	await director.say("stax", "A PIRATE SHIP?! We are in a DESERT!", "shocked")
	director.shot(SHIP_AT + Vector3(16, 5.5, 10), SHIP_AT + Vector3(12, 4.8, 2), 38.0)
	boss.puppet.emote = "point"
	await director.lines([
		["moneybeard", "Captain Moneybeard! Scourge of the seven seas and one very large bathtub!"],
		["parrot", "SQUAWK! Bathtub! Bathtub!"],
		["moneybeard", "I've plundered yer sixth key, lad. A wooden fellow sold me yer location."],
		["moneybeard", "Charged me a convenience fee, he did."],
	])
	director.two_shot(player, boss, -1.0, 55.0)
	await director.lines([
		["stax", "...Steve.", "facepalm"],
		["moneybeard", "Now hand over the other five, or walk the plank!"],
		["stax", "There's no plank. There's no WATER. Where did you even come from?!", "shrug"],
		["moneybeard", "Pirates don't explain, lad. We ARRIVE."],
	])
	# He leaps down into the arena.
	boss.puppet.emote = "laugh"
	var from: Vector3 = boss.global_position
	var land := ARENA + Vector3(0, 0, -6)
	director.shot(ARENA + Vector3(12, 5, 8), land + Vector3(0, 3, 0), 50.0)
	var t := 0.0
	while t < 1.0 and not director.skipping:
		t += await director._frame()
		var k := clampf(t, 0.0, 1.0)
		boss.global_position = from.lerp(land, k) + Vector3(0, sin(k * PI) * 10.0, 0)
	boss.global_position = land
	Audio.play("boom")
	director.shake(0.6)
	Fx.burst(self, land + Vector3(0, 0.3, 0), Color(1.0, 0.9, 0.7, 0.9), 40, 10.0, 0.8, 0.8, -4.0)
	Audio.play_music("pirate", 0.2)
	Audio.set_drums(1.0)
	director.shot(ARENA + Vector3(0, 7, 20), land + Vector3(0, 2, 0), 55.0)
	director.move(ARENA + Vector3(0, 4, 15), land + Vector3(0, 2.5, 0), 3.0)
	await director.title("BOSS", "Captain Moneybeard", "Arrived out of nowhere. Refuses to explain.", 1.6)
	await director.settle()
	boss.puppet.emote = ""
	player.place(ARENA + Vector3(0, 0.2, 10), 0.0)
	director.end()
	boss.player = player
	boss.hit.connect(func(hp): hud.set_boss_hp(hp))
	boss.defeated.connect(_on_boss_defeated)
	hud.show_boss("CAPTAIN MONEYBEARD", boss.MAX_HP)
	boss.start()
	player.died.connect(_restart_fight)
	bark("stax", "Dodge the red rings! When his anchor gets stuck... stomp his hat!")


## Dying restarts the fight: Moneybeard is back to full health.
func _restart_fight() -> void:
	if boss == null or boss.state == boss.B.DEAD:
		return
	boss.reset(ARENA + Vector3(0, 0, -6))
	hud.set_boss_hp(boss.MAX_HP)
	await get_tree().create_timer(1.2).timeout
	bark("moneybeard", "Har! Back from Davy Jones' bathtub? We start again from the top!")


func on_boss_stuck() -> void:
	if not _told_stomp:
		_told_stomp = true
		bark("parrot", "SQUAWK! Anchor's stuck! Anchor's stuck! Don't jump on his hat!")


func _on_boss_defeated() -> void:
	boss_beaten()
	hud.hide_boss()
	await get_tree().create_timer(0.6).timeout
	director.begin()
	Audio.stop_music(1.0)
	var bp: Vector3 = boss.global_position
	player.place(bp + Vector3(0, 0.2, 5.0), 0.0)
	director.face(bp)
	director.actors["moneybeard"] = boss.puppet
	director.two_shot(player, boss, 1.0, 42.0)
	boss.puppet.emote = "shocked"
	await director.say("moneybeard", "Arr... ye've bested me, lad. Fair and square. Mostly square.")
	# The coat falls... and there were never a captain at all.
	Audio.play("pop")
	Audio.play("whoosh", 1.4)
	Fx.burst(self, bp + Vector3(0, 2, 0), Color(0.62, 0.08, 0.08), 30, 6.0, 0.4, 0.8, -8.0, "cube")
	boss.puppet.visible = false
	var ducks: Array[Node3D] = []
	for i in 3:
		var d := Puppet.new()
		d.kind = "duck"
		d.speaker = "parrot"
		add_child(d)
		d.global_position = bp + Vector3(-1.0 + i, 0, 0)
		d.scale = Vector3.ONE * 0.8
		ducks.append(d)
	director.shot(bp + Vector3(0, 1.6, 4.5), bp + Vector3(0, 0.6, 0), 40.0)
	await director.wait(1.0)
	await director.say("stax", "...Were you THREE RUBBER DUCKS in a coat this whole time?!", "shocked")
	await director.say("parrot", "SQUAWK! Don't tell anyone! Don't tell anyone!")
	for i in ducks.size():
		var d := ducks[i]
		d.create_tween().tween_property(d, "global_position", d.global_position + Vector3(-12 + i * 12, 0, -14), 3.0)
	Audio.play("rumble", 0.7)
	if _ship:
		create_tween().tween_property(_ship, "global_position", SHIP_AT + Vector3(0, -14, 0), 4.0).set_trans(Tween.TRANS_SINE)
	director.shot(ARENA + Vector3(10, 6, 18), SHIP_AT + Vector3(0, 6, 0), 45.0)
	await director.say("stax", "And the ship's just... sinking into the sand. Sure. Why not.", "shrug")
	# The sixth key drops out of the sky.
	place_goal(ARENA + Vector3(0, 0, 0))
	var drop_from := goal.global_position + Vector3(0, 14, 0)
	var goal_pos := goal.global_position
	goal.global_position = drop_from
	create_tween().tween_property(goal, "global_position", goal_pos, 1.2).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	Audio.play("checkpoint", 0.8)
	director.shot(goal_pos + Vector3(4, 3, 7), goal_pos + Vector3(0, 1.6, 0), 45.0)
	await director.wait(1.4)
	goal.global_position = goal_pos
	for d in ducks:
		if is_instance_valid(d):
			d.queue_free()
	player.place(ARENA + Vector3(0, 0.2, 7), 0.0)
	director.end()


func _portal(pos: Vector3) -> Node3D:
	var root := Node3D.new()
	add_child(root)
	root.global_position = pos
	var ring := MeshInstance3D.new()
	var tor := TorusMesh.new()
	tor.inner_radius = 16.0
	tor.outer_radius = 18.0
	tor.rings = 64
	ring.mesh = tor
	ring.material_override = Mats.glow(Color(0.5, 0.8, 1.0), 4.0)
	ring.rotation.x = PI / 2
	root.add_child(ring)
	var disc := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 16.0
	cm.bottom_radius = 16.0
	cm.height = 0.1
	disc.mesh = cm
	disc.material_override = Mats.unshaded(Color(0.2, 0.4, 0.9), 0.7)
	disc.rotation.x = PI / 2
	root.add_child(disc)
	root.scale = Vector3.ONE * 0.05
	create_tween().tween_property(root, "scale", Vector3.ONE, 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	return root


# ---------------------------------------------------------------- story

func intro() -> void:
	director.begin()
	Game.fx.set_black(true)
	player.place(spawn_point + Vector3(0, 28, 0), spawn_yaw)
	director.shot(Vector3(-40, 20, 30), Vector3(-160, 20, -230), 50.0)
	Game.fx.fade_in(2.0)
	director.move(Vector3(-10, 12, 18), Vector3(0, 30, -370), 6.0, 45.0)
	await director.wait(2.0)
	await director.say("narrator", "Beyond the Scribble Kingdom lies a desert so hot, even the ducks wear sunscreen.")
	await director.settle()
	director.shot(Vector3(6, 3, 14), Vector3(0, 4, 3), 50.0)
	Audio.play("whoosh", 1.1)
	var t := 0.0
	while player.global_position.y > 0.6 and t < 4.0 and not director.skipping:
		t += await director._frame()
	player.place(spawn_point, spawn_yaw)
	Audio.play("land")
	Fx.burst(self, spawn_point, Color(0.95, 0.8, 0.55, 0.9), 30, 6.0, 0.6, 0.8, -6.0)
	director.shake(0.3)
	var sp := player.global_position
	director.shot(sp + Vector3(-2.2, 1.5, -2.8), sp + Vector3(0, 1.3, 0), 36.0)
	await director.say("stax", "Hot. Hot hot hot. Why is the sand HOT? Why is EVERYTHING a duck?", "shocked")
	director.shot(Vector3(12, 6, 12), Vector3(0, 2, -30), 48.0)
	director.move(Vector3(5, 4, 10), Vector3(0, 3, -40), 4.0, 42.0)
	await director.title(info.chapter, info.title, info.subtitle)
	await director.settle()
	player.place(spawn_point, spawn_yaw)
	director.end()


func outro_lines() -> Array:
	return [
		["stax", "Six keys. Okay, Steve and I are gonna have a LONG talk about convenience fees.", "cheer"],
		["steve", "Fees? What fees? Never heard of 'em. ...The Last Vault awaits! Finally!"],
		["steve", "Small thing: it only opens at midnight. And midnight lives in a clocktower. Long story."],
		["stax", "Midnight LIVES somewhere?!", "shocked"],
	]


## Used by tests/level_smoke.gd: starts and wins the boss fight.
func test_hook(tree: SceneTree) -> bool:
	_start_boss()
	for n in 900:
		if director.active:
			director.skip()
		elif boss and boss.state != boss.B.WAIT:
			break
		await tree.physics_frame
	if boss == null:
		return false
	for i in boss.MAX_HP:
		boss.take_hit()
		for n in 15:
			await tree.physics_frame
	for n in 900:
		if director.active:
			director.skip()
		elif goal != null:
			break
		await tree.physics_frame
	return goal != null and not director.active
