extends "res://scripts/world/level_base.gd"
## Chapter 4: The Lost Sock Nebula. Every sock that ever vanished from a
## dryer drifts here in a pastel space void. The last Vault Key sits on top
## of the Washing Machine Planet.
## Route: colossal sock cuff -> sock pillars -> rainbow ribbon -> laundry
## basket -> clothespin -> bobbing socks -> lint cloud (ATM) -> low-gravity
## drift -> basket (ATM) -> ribbon -> spinning rings -> ring of socks (ATM) ->
## low-gravity spin-cycle discs up the planet -> the key on the dial.
## Side quest: Lefty lost his partner Righty, who hides up in the drift.

const PLANET := Vector3(0, 22, -236)
const PLANET_R := 18.0
const RING_Y := 23.0
const RING_R := 28.0
const DRIFT := Vector3(0, -8, -124)
const DRIFT_R := 25.0

const PINK := Color(1.0, 0.55, 0.78)
const MINT := Color(0.5, 0.95, 0.78)
const LAVENDER := Color(0.72, 0.6, 1.0)
const PEACH := Color(1.0, 0.72, 0.52)
const SKY := Color(0.52, 0.78, 1.0)
const LEMON := Color(1.0, 0.93, 0.5)
const CREAM := Color(0.98, 0.96, 0.92)
const TEAL := Color(0.3, 1.0, 0.9)
const RAINBOW: Array[Color] = [Color(1.0, 0.45, 0.55), Color(1.0, 0.7, 0.4), Color(1.0, 0.92, 0.45),
	Color(0.5, 0.95, 0.6), Color(0.45, 0.8, 1.0), Color(0.7, 0.55, 1.0)]

const SOCK_SHADER := """
shader_type spatial;
uniform vec4 col_a : source_color = vec4(1.0, 0.6, 0.8, 1.0);
uniform vec4 col_b : source_color = vec4(1.0);
uniform vec3 axis = vec3(0.0, 1.0, 0.0);
uniform float freq = 0.5;
uniform float heel_y = -1000.0;
uniform float cuff_y = 1000.0;
uniform float glow = 0.08;
varying vec3 lp;
varying vec4 tint;
void vertex() {
	lp = VERTEX;
	tint = COLOR;
}
void fragment() {
	float u = dot(lp, axis) * freq;
	float tri = abs(fract(u) - 0.5) * 2.0;
	float w = max(fwidth(u) * 2.0, 0.001);
	float s = smoothstep(0.5 - w, 0.5 + w, tri);
	if (lp.y < heel_y || lp.y > cuff_y) {
		s = 1.0;
	}
	vec3 a = col_a.rgb * tint.rgb;
	vec3 c = mix(a, col_b.rgb * mix(vec3(1.0), tint.rgb, 0.25), s);
	float rib = 0.5 + 0.5 * sin(atan(lp.x, lp.z) * 36.0);
	c *= 0.9 + 0.1 * rib;
	ALBEDO = c;
	ROUGHNESS = 0.92;
	RIM = 0.7;
	RIM_TINT = 0.6;
	EMISSION = c * glow;
}
"""

const FIELD_SHADER := """
shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never, shadows_disabled;
uniform vec4 color : source_color = vec4(0.3, 1.0, 0.9, 1.0);
uniform float height = 40.0;
uniform float strength = 1.0;
varying vec3 lp;
void vertex() {
	lp = VERTEX;
}
void fragment() {
	float fres = pow(1.0 - abs(dot(NORMAL, VIEW)), 3.0);
	float k = lp.y / height + 0.5;
	float fade = smoothstep(0.0, 0.12, k) * smoothstep(1.0, 0.55, k);
	float bands = 0.55 + 0.45 * sin(lp.y * 0.8 - TIME * 1.6 + atan(lp.x, lp.z) * 4.0);
	ALBEDO = color.rgb;
	ALPHA = clamp((fres * 0.8 + 0.035) * bands * fade * strength, 0.0, 1.0);
}
"""

const SWIRL_SHADER := """
shader_type spatial;
render_mode unshaded, cull_disabled;
void fragment() {
	vec2 p = UV - 0.5;
	float r = length(p) * 2.0;
	if (r > 1.0) {
		discard;
	}
	float a = atan(p.y, p.x);
	float sw = sin(a * 3.0 + r * 9.0 - TIME * 2.5);
	vec3 water = mix(vec3(0.05, 0.3, 0.75), vec3(0.3, 0.9, 1.0), 0.5 + 0.5 * sw);
	float socks = smoothstep(0.55, 0.9, sin(a * 4.0 - TIME * 3.0 + r * 6.0) * sin(r * 11.0 - TIME * 1.3));
	vec3 sc = 0.55 + 0.45 * cos(vec3(0.0, 2.1, 4.2) + a * 2.0 + TIME);
	vec3 col = mix(water, sc + 0.25, socks);
	col += vec3(0.8, 0.95, 1.0) * pow(1.0 - r, 3.0) * 0.5;
	vec2 cell = floor(p * 36.0 + vec2(0.0, TIME * 3.0));
	col += step(0.985, fract(sin(dot(cell, vec2(12.9898, 78.233))) * 43758.5453)) * 0.7;
	ALBEDO = col * 1.5;
}
"""

var _mats := {}
var _sock_mesh: ArrayMesh
var _steve: Node3D
var _lefty: Node3D
var _righty: Node3D
var _dino_sock: Node3D
var _reunited := false
var _spinners: Array = []
var _bobbers: Array = []
var _t := 0.0


func _init() -> void:
	music = "nebula"
	spawn_point = Vector3(0, 0.05, 3)
	spawn_yaw = 0.0
	kill_y = -22.0


func env_config() -> Dictionary:
	return {
		"top": Color(0.03, 0.02, 0.1), "horizon": Color(0.13, 0.06, 0.22), "bottom": Color(0.02, 0.03, 0.09),
		"sun_color": Color(0.75, 0.86, 1.0), "sun_energy": 0.75, "sun_angle": Vector2(-58, 35),
		"sun_size": 2.2, "sun_glow": 1.4, "stars": 1.2, "nebula": 1.0,
		"nebula_a": Color(0.75, 0.22, 0.95), "nebula_b": Color(0.1, 0.85, 0.85),
		"fog_color": Color(0.22, 0.1, 0.32), "fog_density": 0.004, "fog_sky": 0.0, "volumetric": 0.0,
		"ambient": 0.8, "exposure": 1.0, "glow": 1.25, "tint": Color(0.97, 0.95, 1.05),
		"saturation": 1.15, "vignette": 0.45, "sky_energy": 1.0,
	}


# ---------------------------------------------------------------- materials

## Striped knit material. `axis` picks the local direction the stripes run along.
func sock_mat(a: Color, b: Color, freq := 0.55, axis := Vector3.UP, heel := -1000.0, cuff := 1000.0, glow := 0.08) -> ShaderMaterial:
	var key := "%s%s%.2f%s%.2f%.2f%.2f" % [a, b, freq, axis, heel, cuff, glow]
	if _mats.has(key):
		return _mats[key]
	if not _mats.has("_sock_shader"):
		var sh := Shader.new()
		sh.code = SOCK_SHADER
		_mats["_sock_shader"] = sh
	var m := ShaderMaterial.new()
	m.shader = _mats["_sock_shader"]
	m.set_shader_parameter("col_a", a)
	m.set_shader_parameter("col_b", b)
	m.set_shader_parameter("freq", freq)
	m.set_shader_parameter("axis", axis)
	m.set_shader_parameter("heel_y", heel)
	m.set_shader_parameter("cuff_y", cuff)
	m.set_shader_parameter("glow", glow)
	_mats[key] = m
	return m


func field_mat(color: Color, height: float, strength := 1.0) -> ShaderMaterial:
	var sh := Shader.new()
	sh.code = FIELD_SHADER
	var m := ShaderMaterial.new()
	m.shader = sh
	m.set_shader_parameter("color", color)
	m.set_shader_parameter("height", height)
	m.set_shader_parameter("strength", strength)
	return m


func lint_mat() -> Material:
	return Mats.rough_surface(Color(0.93, 0.9, 0.97), Color(0.72, 0.68, 0.82), 0.5, 1.0, 17, 0.9)


## One sock mesh (cuff up at y 1.6, heel at the origin, toe toward -Z).
func sock_mesh() -> ArrayMesh:
	if _sock_mesh:
		return _sock_mesh
	var leg := CylinderMesh.new()
	leg.top_radius = 0.33
	leg.bottom_radius = 0.3
	leg.height = 1.6
	leg.radial_segments = 14
	leg.rings = 2
	var foot := CylinderMesh.new()
	foot.top_radius = 0.29
	foot.bottom_radius = 0.29
	foot.height = 0.8
	foot.radial_segments = 14
	foot.rings = 1
	var ball_mesh := SphereMesh.new()
	ball_mesh.radius = 0.305
	ball_mesh.height = 0.61
	ball_mesh.radial_segments = 14
	ball_mesh.rings = 7
	var parts := [
		[leg, Transform3D(Basis(), Vector3(0, 0.8, 0))],
		[foot, Transform3D(Basis(Vector3.RIGHT, PI / 2), Vector3(0, 0, -0.4))],
		[ball_mesh, Transform3D(Basis(), Vector3.ZERO)],
		[ball_mesh, Transform3D(Basis(), Vector3(0, 0, -0.8))],
	]
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var idx := PackedInt32Array()
	for part in parts:
		var arr: Array = (part[0] as PrimitiveMesh).get_mesh_arrays()
		var xf: Transform3D = part[1]
		var base := verts.size()
		for v in arr[Mesh.ARRAY_VERTEX]:
			verts.append(xf * v)
		for nn in arr[Mesh.ARRAY_NORMAL]:
			norms.append(xf.basis * nn)
		for i in arr[Mesh.ARRAY_INDEX]:
			idx.append(base + i)
	var out := []
	out.resize(Mesh.ARRAY_MAX)
	out[Mesh.ARRAY_VERTEX] = verts
	out[Mesh.ARRAY_NORMAL] = norms
	out[Mesh.ARRAY_INDEX] = idx
	_sock_mesh = ArrayMesh.new()
	_sock_mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, out)
	return _sock_mesh


## A decorative sock, `size` metres long, with heel and cuff in color b.
func deco_sock(pos: Vector3, size: float, a: Color, b: Color, rot := Vector3.ZERO, parent: Node = null) -> MeshInstance3D:
	var mi := deco(sock_mesh(), sock_mat(a, b, 3.0, Vector3.UP, 0.32, 1.3, 0.15), pos, rot, Vector3.ONE * size / 1.6, parent)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF if size > 20.0 else GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	return mi


# ---------------------------------------------------------------- platform kit

## A standing giant sock whose flat cuff at `top` is a platform.
func sock_pillar(top: Vector3, r: float, h: float, a: Color, b: Color, foot_yaw := 0.0) -> StaticBody3D:
	var body := cylinder(top - Vector3(0, h * 0.5, 0), r, h, sock_mat(a, b, 0.55), 36)
	deco_cyl(top + Vector3(0, -0.57, 0), r * 1.05, 1.2, sock_mat(b, b.darkened(0.12), 3.0))
	deco_cyl(top + Vector3(0, 0.06, 0), r * 0.86, 0.02, Mats.solid(b.darkened(0.18), 0.95))
	var bottom := top - Vector3(0, h, 0)
	var dir := Vector3(sin(foot_yaw), 0, cos(foot_yaw))
	var hm := Mats.solid(b, 0.95)
	deco_ball(bottom, r * 1.01, hm)
	deco_cyl(bottom + dir * r * 1.1, r * 0.99, r * 2.2, sock_mat(a, b, 0.55), Vector3(PI / 2, foot_yaw, 0))
	deco_ball(bottom + dir * r * 2.2, r * 0.99, hm)
	return body


## A flat-topped lint cloud. The walkable top is at `top`.
func lint_cloud(top: Vector3, r: float) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = top - Vector3(0, 0.5, 0)
	var cs := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = r * 0.86
	shape.height = 1.0
	cs.shape = shape
	body.add_child(cs)
	add_child(body)
	var m := lint_mat()
	deco_ball(top - Vector3(0, r * 0.45 - 0.08, 0), r, m, Vector3(1, 0.45, 1))
	for i in 6:
		var a := TAU * i / 6.0 + r
		var p := top + Vector3(cos(a) * r * 0.78, -r * 0.32, sin(a) * r * 0.78)
		deco_ball(p, r * 0.48, m, Vector3(1, 0.62, 1))
	deco_ball(top - Vector3(0, r * 0.55, 0), r * 0.8, m, Vector3(1, 0.7, 1))
	return body


## An open plastic laundry basket. `top` is the floor top at its centre.
func basket(top: Vector3, s: float, color: Color) -> void:
	var t := 0.35
	var h := 1.0
	var mat := Mats.pattern("grid", [color, color.darkened(0.35)], 0.9, 0.5)
	var rim := Mats.solid(color.lightened(0.35), 0.4)
	box(top - Vector3(0, 0.25, 0), Vector3(s, 0.5, s), Mats.solid(color.darkened(0.1), 0.5))
	for side in [-1.0, 1.0]:
		box(top + Vector3(0, h * 0.5, side * (s - t) * 0.5), Vector3(s, h, t), mat)
		box(top + Vector3(side * (s - t) * 0.5, h * 0.5, 0), Vector3(t, h, s - t * 2.0), mat)
		deco_box(top + Vector3(0, h - 0.06, side * (s - t) * 0.5), Vector3(s + 0.1, 0.13, t + 0.1), rim)
		deco_box(top + Vector3(side * (s - t) * 0.5, h - 0.06, 0), Vector3(t + 0.1, 0.13, s - 0.1), rim)
		deco_box(top + Vector3(side * (s * 0.5 + 0.01), h * 0.62, 0), Vector3(0.05, 0.26, 1.4), Mats.solid(color.darkened(0.6), 0.6))
	deco_box(top - Vector3(0, 0.6, 0), Vector3(s * 0.94, 0.25, s * 0.94), Mats.solid(color.darkened(0.3), 0.6))


## A giant wooden clothespin lying flat from a to b; walk on the top jaw.
func clothespin(a: Vector3, b: Vector3) -> void:
	var d := b - a
	var yaw := atan2(d.x, d.z)
	var len := d.length()
	var mid := (a + b) * 0.5
	var wood := Mats.rough_surface(Color(0.9, 0.72, 0.5), Color(0.74, 0.55, 0.36), 0.35, 0.85, 23, 0.4)
	box(mid - Vector3(0, 0.25, 0), Vector3(1.9, 0.5, len), wood, Vector3(0, yaw, 0))
	deco_box(mid - Vector3(0, 0.95, 0), Vector3(1.8, 0.5, len * 0.94), wood, Vector3(0, yaw, 0))
	var spring := TorusMesh.new()
	spring.inner_radius = 0.55
	spring.outer_radius = 0.72
	var steel := Mats.solid(Color(0.8, 0.82, 0.88), 0.25, 0.9)
	for i in 3:
		var p := a + d * (0.36 + i * 0.03) - Vector3(0, 0.6, 0)
		deco(spring, steel, p, Vector3(0, yaw, PI / 2))
	deco_box(a + d * 0.39 - Vector3(0, 0.6, 0), Vector3(2.2, 0.12, 0.12), steel, Vector3(0, yaw, 0))


## A rainbow ribbon bridge through `points` (the walking surface).
func ribbon(points: Array, width := 2.4, seg := 1.5) -> Array:
	var dense: Array = []
	var n := points.size()
	for i in n - 1:
		var p0: Vector3 = points[maxi(i - 1, 0)]
		var p1: Vector3 = points[i]
		var p2: Vector3 = points[i + 1]
		var p3: Vector3 = points[mini(i + 2, n - 1)]
		for k in 24:
			var t := k / 24.0
			dense.append(0.5 * ((2.0 * p1) + (-p0 + p2) * t + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t * t + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t * t * t))
	dense.append(points[n - 1])
	var pts: Array = [dense[0]]
	var acc := 0.0
	for i in range(1, dense.size()):
		acc += (dense[i] as Vector3).distance_to(dense[i - 1])
		if acc >= seg or i == dense.size() - 1:
			pts.append(dense[i])
			acc = 0.0
	for i in pts.size() - 1:
		var p: Vector3 = pts[i]
		var q: Vector3 = pts[i + 1]
		var d := q - p
		var flat := Vector2(d.x, d.z).length()
		var rot := Vector3(-atan2(d.y, flat), atan2(d.x, d.z), 0)
		var col: Color = RAINBOW[i % RAINBOW.size()]
		box((p + q) * 0.5 - Vector3(0, 0.12, 0), Vector3(width, 0.24, d.length() + 0.12), Mats.glow(col, 0.8), rot)
		deco_box((p + q) * 0.5 - Vector3(0, 0.3, 0), Vector3(width * 0.7, 0.1, d.length() + 0.1), Mats.glow(col.lightened(0.3), 2.2), rot)
	return pts


## A spinning washer-drum disc. `top` is its walkable surface.
func spin_disc(top: Vector3, d: float, spin: float, rim_color: Color) -> AnimatableBody3D:
	var drum := Mats.pattern("grid", [Color(0.78, 0.82, 0.9), Color(0.5, 0.55, 0.66)], 1.2, 0.3)
	drum.metallic = 0.6
	var m := mover(Vector3(d, 0.5, d), drum, top - Vector3(0, 0.25, 0), Vector3.ZERO, 4.0, 0.0, spin, "cylinder")
	var tor := TorusMesh.new()
	tor.inner_radius = d * 0.5 - 0.12
	tor.outer_radius = d * 0.5 + 0.18
	tor.rings = 32
	deco(tor, Mats.glow(rim_color, 2.4), Vector3.ZERO, Vector3.ZERO, Vector3.ONE, m)
	var fin := Mats.glow(rim_color.lightened(0.4), 1.4)
	for i in 3:
		deco(_box_mesh(Vector3(d * 0.86, 0.04, 0.22)), fin, Vector3(0, 0.26, 0), Vector3(0, TAU * i / 6.0, 0), Vector3.ONE, m)
	var hub := CylinderMesh.new()
	hub.top_radius = 0.5
	hub.bottom_radius = 0.5
	hub.height = 0.1
	deco(hub, Mats.glow(rim_color, 2.0), Vector3(0, 0.27, 0), Vector3.ZERO, Vector3.ONE, m)
	return m


## A floating sock that bobs up and down; its cuff top is the platform.
func bob_sock(pos: Vector3, r: float, amp: float, period: float, phase: float, a: Color, b: Color) -> AnimatableBody3D:
	var m := mover(Vector3(r * 2.0, 1.2, r * 2.0), sock_mat(b, b.darkened(0.12), 3.0), pos, Vector3(0, amp, 0), period, phase, 0.0, "cylinder")
	var leg := CylinderMesh.new()
	leg.top_radius = r * 0.96
	leg.bottom_radius = r * 0.92
	leg.height = 4.0
	leg.radial_segments = 24
	deco(leg, sock_mat(a, b, 0.6), Vector3(0, -2.6, 0), Vector3.ZERO, Vector3.ONE, m)
	var heel := SphereMesh.new()
	heel.radius = r * 0.92
	heel.height = r * 1.84
	deco(heel, Mats.solid(b, 0.95), Vector3(0, -4.6, 0), Vector3.ZERO, Vector3.ONE, m)
	var foot := CylinderMesh.new()
	foot.top_radius = r * 0.9
	foot.bottom_radius = r * 0.9
	foot.height = r * 2.0
	deco(foot, sock_mat(a, b, 0.6), Vector3(0, -4.6, -r), Vector3(PI / 2, 0, 0), Vector3.ONE, m)
	deco(heel, Mats.solid(b, 0.95), Vector3(0, -4.6, -r * 2.0), Vector3.ZERO, Vector3.ONE, m)
	return m


## A low-gravity cylinder with a glowing shell and rising sparkles.
func low_gravity(base: Vector3, r: float, h: float, color: Color) -> Area3D:
	var z := ZoneScript.new()
	z.mode = "gravity"
	z.gravity_scale = 0.4
	z.position = base + Vector3(0, h * 0.5, 0)
	var cs := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = r
	shape.height = h
	cs.shape = shape
	z.add_child(cs)
	add_child(z)
	var shell := CylinderMesh.new()
	shell.top_radius = r
	shell.bottom_radius = r
	shell.height = h
	shell.radial_segments = 64
	shell.cap_top = false
	shell.cap_bottom = false
	var mi := deco(shell, field_mat(color, h), base + Vector3(0, h * 0.5, 0))
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	Fx.ambient(self, base + Vector3(0, h * 0.45, 0), Vector3(r * 0.7, h * 0.4, r * 0.7), Color(color, 0.8), 260, 0.16, Vector3(0, 1.4, 0), 7.0)
	return z


func _box_mesh(size: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = size
	return b


## Point on a circle around the planet: angle from +Z toward +X.
func around(theta: float, r: float, y: float) -> Vector3:
	return Vector3(PLANET.x + sin(theta) * r, y, PLANET.z + cos(theta) * r)


# ---------------------------------------------------------------- build

func build() -> void:
	_build_start()
	_build_laundry_run()
	_build_drift()
	_build_approach()
	_build_planet()
	_build_backdrop()


func _build_start() -> void:
	# The cuff of a colossal sock is home base.
	sock_pillar(Vector3(0, 0, 0), 7.0, 40.0, LAVENDER, CREAM, 0.6)
	coin_ring(Vector3(0, 1, -1), 3.2, 6)
	omni(Vector3(0, 4.5, -1), Color(0.8, 0.6, 1.0), 16.0, 1.2)
	_steve = npc("steve", "steve", Vector3(-3.4, 0.05, -2.6), atan2(-3.4, -5.6), [
		["steve", "Quick tips! Teal glowing zones are low gravity. Jump in and float like a dryer sheet."],
		["steve", "Moths eat socks. Stomp them from above. Do NOT let them near that hoodie."],
		["stax", "This hoodie is limited edition. Nobody touches the hoodie.", "cool"],
		["steve", "Great talk! That'll be five coins. Convenience fee. ...Kidding! Signs don't need money."],
		["stax", "Everybody needs money, Steve. That's, like, my whole thing.", "shrug"],
	], [["steve", "Go get it! When I open the Vault— when YOU open the Vault! You. Space makes my words wobbly."]])
	_dino_sock = deco_sock(Vector3(4.2, 2.4, -3.0), 1.6, Color(0.45, 0.85, 0.35), Color(1.0, 0.6, 0.2), Vector3(0.4, 0.8, 0.3))
	_bobbers.append([_dino_sock, _dino_sock.position, 0.35, 1.3, 0.0, 0.4])
	sign_text("LOST & FOUND", Vector3(-11, 7.5, -16), PI - 0.5, 180, Color(1.0, 0.7, 0.95), 1.5)

	# Sock pillars hop forward.
	sock_pillar(Vector3(0, 0.6, -12.5), 2.6, 7.0, PINK, CREAM, 2.0)
	coin_arc(Vector3(0, 1.2, -6.5), Vector3(0, 1.8, -10.2), 1.4, 3)
	sock_pillar(Vector3(4.5, 1.6, -20.0), 2.4, 8.0, MINT, CREAM, -1.0)
	coin_arc(Vector3(1.4, 2.0, -14.8), Vector3(3.3, 2.8, -17.9), 1.5, 3)
	sock_pillar(Vector3(0.5, 2.6, -27.5), 2.6, 9.0, PEACH, LEMON, 0.5)
	coin_arc(Vector3(3.3, 3.0, -22.1), Vector3(1.6, 3.8, -25.3), 1.5, 3)
	tip(Vector3(0.5, 4.5, -28), Vector3(6, 4, 5), "steve", "Rainbow ribbons! Totally safe to walk on. I'm, like, eighty percent sure.")


func _build_laundry_run() -> void:
	# Ribbon up and over into a laundry basket.
	var r1 := ribbon([Vector3(0.5, 2.6, -30.0), Vector3(-0.5, 5.2, -36.5), Vector3(-2.0, 5.15, -43.7)])
	for i in range(1, r1.size() - 1, 2):
		coin(r1[i] + Vector3(0, 1.0, 0))
	basket(Vector3(-2, 4, -48), 9.0, SKY)
	coin_ring(Vector3(-2, 5, -48), 2.6, 8)
	coin(Vector3(-2, 9.4, -48), 5)
	enemy("moth", Vector3(-5.5, 4, -49.5), Vector3(1.5, 4, -46.5), 0.6)
	omni(Vector3(-2, 7.5, -48), PINK, 12.0, 1.3)
	for i in 5:
		deco_sock(Vector3(-5.5 + i * 1.5, 4.25, -51.2 + (i % 2) * 0.6), 1.1, RAINBOW[i], CREAM, Vector3(-PI / 2 + 0.2, i * 0.9, 0))
	tip(Vector3(-2, 6.5, -45), Vector3(9, 4, 3), "steve", "Moth alert! Those fuzzballs eat socks. Stomp 'em before they nibble your hoodie.")

	# Clothespin plank, then bobbing socks.
	clothespin(Vector3(-2, 4.8, -54.5), Vector3(-2, 4.8, -65.0))
	coin_line(Vector3(-2, 5.8, -56), Vector3(-2, 5.8, -63.5), 5)
	bob_sock(Vector3(-2, 3.2, -70), 2.2, 3.0, 4.0, 0.0, PINK, CREAM)
	bob_sock(Vector3(2.5, 4.2, -77), 2.2, 3.0, 4.0, 0.33, SKY, LEMON)
	bob_sock(Vector3(-1.5, 5.2, -85), 2.2, 3.0, 4.0, 0.66, MINT, CREAM)
	coin_arc(Vector3(-2, 8.2, -70), Vector3(2.5, 9.2, -77), 1.2, 3)
	coin_arc(Vector3(2.5, 9.2, -77), Vector3(-1.5, 10.2, -85), 1.2, 3)
	coin_arc(Vector3(-1.5, 9.0, -87.5), Vector3(0, 8.5, -91.5), 1.0, 3)

	# Lint cloud rest stop: ATM, Lefty.
	lint_cloud(Vector3(0, 7.5, -97), 6.0)
	checkpoint(Vector3(-2.5, 7.5, -94), 0.0)
	omni(Vector3(0, 10.5, -96), TEAL, 14.0, 1.2)
	coin_line(Vector3(-2, 8.5, -99.5), Vector3(2, 8.5, -99.5), 4)
	_lefty = npc("lefty", "lefty", Vector3(3.2, 7.5, -98.5), atan2(3.2, -5.5), [
		["lefty", "Oh! A visitor! Have you seen my Righty? Pink stripes, dreamy heel, absolutely perfect?"],
		["stax", "Buddy, this whole nebula is socks. That's like asking if I've seen a specific penny.", "shrug"],
		["lefty", "The Great Tumble Dry of 2019 tore us apart! I've floated alone ever since!"],
		["lefty", "Last I saw, he drifted up and to the left of the spinning ring. In the floaty part!"],
		["stax", "Fine. If I see a sock with separation anxiety, I'll send him your way.", "cool"],
	], [["lefty", "Up and left of the spinning ring! A sock is nothing without its pair."]])
	tip(Vector3(0, 9.5, -100), Vector3(11, 4, 2.5), "steve", "See that teal glow? Low gravity! Big floaty jumps. No refunds.")


func _build_drift() -> void:
	low_gravity(DRIFT, DRIFT_R, 50.0, TEAL)
	omni(Vector3(0, 17, -124), TEAL, 22.0, 1.0)
	sign_text("LOW GRAVITY", Vector3(-6.5, 12.5, -101), PI + 0.3, 110, TEAL, 1.2)
	# Far-apart islands that need the floaty jumps.
	sock_pillar(Vector3(4, 10.5, -113), 2.4, 6.0, LEMON, SKY, 2.4)
	coin_arc(Vector3(1.5, 9.0, -102.5), Vector3(3.6, 11.5, -110.5), 4.0, 5)
	spin_disc(Vector3(-4, 13.5, -125), 5.2, 0.7, PINK)
	coin_arc(Vector3(3, 11.5, -115.5), Vector3(-3, 14.5, -122.5), 4.0, 4)
	coin(Vector3(-4, 23.0, -125), 5)
	lint_cloud(Vector3(4, 15.5, -136), 3.4)
	coin_arc(Vector3(-2.5, 14.5, -127.5), Vector3(3, 16.5, -133.5), 4.0, 4)
	enemy("moth", Vector3(2.2, 15.5, -136.5), Vector3(5.8, 15.5, -135.5), 0.6)
	tip(Vector3(-4, 15.5, -125), Vector3(5, 3, 5), "steve", "Psst. Floaty moths are extra bouncy. Stomp one in low gravity and you'll touch the stars!")

	# Righty's hideout, up and left of the ring.
	lint_cloud(Vector3(-12, 17.5, -119), 1.9)
	coin_line(Vector3(-7, 17.5, -122), Vector3(-10.5, 19.0, -120), 2)
	lint_cloud(Vector3(-18, 21.5, -113), 3.0)
	coin_line(Vector3(-13.5, 20.5, -117.5), Vector3(-16, 22.5, -115), 2)
	coin(Vector3(-19.5, 23.0, -111.5), 5)
	_righty = npc("lefty", "lefty", Vector3(-17.5, 21.5, -113.5), atan2(-6.0, 6.0), [
		["lefty", "Hi! I'm Righty! Ignore the name tag. The laundry mixed us up. Classic laundry."],
		["lefty", "I lost my other half. Pink stripes, super dramatic, cries at fabric softener ads."],
		["stax", "That sounds exactly like a sock I'd avoid. But okay. I'll keep an eye out.", "think"],
	], [["lefty", "If you find my Lefty, tell him I'm floating right here. Being brave. Sort of."]])
	_righty.display_name = "Righty"
	Fx.ambient(self, Vector3(-18, 24, -113), Vector3(2.5, 2.0, 2.5), Color(1.0, 0.55, 0.8), 40, 0.2, Vector3(0, 0.6, 0), 3.0)
	omni(Vector3(-18, 24.5, -113), PINK, 10.0, 1.4)

	# Checkpoint basket, half inside the drift so you land floaty.
	basket(Vector3(0, 16, -150), 10.0, PINK)
	checkpoint(Vector3(-3, 16, -148.5), 0.0)
	coin_ring(Vector3(1.5, 17, -151), 2.2, 6)
	omni(Vector3(0, 19.5, -151), LAVENDER, 12.0, 1.2)
	tip(Vector3(0, 18, -151), Vector3(9, 4, 8), "steve", "Ooh, an ATM! That's a two-coin convenience fee. Kidding! I'll just put it on your tab.")


func _build_approach() -> void:
	var r2 := ribbon([Vector3(0.5, 17.15, -154.8), Vector3(5, 19.5, -163), Vector3(9.5, 21.2, -171), Vector3(11.5, 20.15, -177.6)])
	for i in range(1, r2.size() - 1, 2):
		coin(r2[i] + Vector3(0, 1.0, 0))
	lint_cloud(Vector3(12, 20, -181), 4.4)
	coin_ring(Vector3(12, 21, -181), 1.8, 3)
	enemy("moth", Vector3(10, 20, -180.5), Vector3(14, 20, -182.5), 0.6)
	spin_disc(Vector3(8, 21, -190), 5.0, 0.8, LAVENDER)
	spin_disc(Vector3(2, 22, -195.5), 5.0, -0.9, MINT)
	spin_disc(Vector3(-4, 23, -201), 5.0, 1.0, PEACH)
	coin(Vector3(8, 22.2, -190))
	coin(Vector3(2, 23.2, -195.5))
	coin(Vector3(-4, 24.2, -201))
	coin_arc(Vector3(10, 21.5, -185.5), Vector3(8.5, 22.2, -187.8), 1.2, 2)
	coin_arc(Vector3(5.5, 23.0, -192.5), Vector3(3.5, 23.4, -194), 1.2, 2)
	coin_arc(Vector3(-0.5, 24.0, -198), Vector3(-2.5, 24.4, -199.5), 1.2, 2)
	omni(Vector3(3, 26, -193), LAVENDER, 14.0, 1.0)


func _build_planet() -> void:
	var c := PLANET
	# The planet itself: a glossy white appliance-world.
	var body := StaticBody3D.new()
	body.position = c
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = PLANET_R
	sm.height = PLANET_R * 2.0
	sm.radial_segments = 72
	sm.rings = 36
	mi.mesh = sm
	mi.material_override = Mats.solid(Color(0.93, 0.94, 0.98), 0.2, 0.05)
	body.add_child(mi)
	var cs := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = PLANET_R
	cs.shape = shape
	body.add_child(cs)
	add_child(body)
	var chrome := Mats.solid(Color(0.8, 0.84, 0.9), 0.15, 1.0)
	var band := TorusMesh.new()
	band.inner_radius = PLANET_R - 0.3
	band.outer_radius = PLANET_R + 0.35
	band.rings = 96
	deco(band, chrome, c + Vector3(0, -3, 0))

	# The porthole door with its swirling spin cycle.
	var n := Vector3(0, 0.22, 1).normalized()
	var quad := QuadMesh.new()
	quad.size = Vector2(10.6, 10.6)
	var sw := Shader.new()
	sw.code = SWIRL_SHADER
	var swm := ShaderMaterial.new()
	swm.shader = sw
	var glass := deco(quad, swm, c + n * 18.35)
	glass.look_at(c, Vector3.UP)
	var rim := TorusMesh.new()
	rim.inner_radius = 5.2
	rim.outer_radius = 6.4
	rim.rings = 64
	var ring_node := deco(rim, chrome, c + n * 18.2)
	ring_node.look_at(c, Vector3.UP)
	ring_node.rotate_object_local(Vector3.RIGHT, PI / 2)
	var hinge := deco_box(c + n * 18.4 + Vector3(-6.6, 0, 0), Vector3(1.0, 2.6, 0.8), chrome)
	hinge.look_at(c, Vector3.UP)
	omni(c + n * 26.0, Color(0.4, 0.8, 1.0), 26.0, 3.0)
	var spin_sign := sign_text("SPIN CYCLE", c + Vector3(0, 12.2, 14.2), PI, 220, Color(0.5, 0.95, 1.0), 1.4)
	spin_sign.rotation.x = -0.6

	# Control panel and dials on the back.
	var panel_col := Mats.solid(Color(0.22, 0.24, 0.3), 0.4, 0.4)
	var back := deco_box(c + Vector3(0, 10, -14.6), Vector3(14, 3.2, 1.2), panel_col)
	back.look_at(c + Vector3(0, 10, 0), Vector3.UP)
	for i in 3:
		var kp := c + Vector3(-4.5 + i * 4.5, 10.3, -15.4)
		var knob := deco_cyl(kp, 0.9, 0.8, chrome, Vector3(PI / 2 - 0.5, 0, 0))
		knob.look_at(c + Vector3(0, 10, 0), Vector3.UP)
		knob.rotate_object_local(Vector3.RIGHT, PI / 2)
		deco_ball(kp + Vector3(0, 1.4, 0.3), 0.25, Mats.glow([MINT, LEMON, PINK][i], 3.0))

	# The key sits on the big dial at the north pole.
	cylinder(c + Vector3(0, PLANET_R + 0.3, 0), 3.5, 1.6, chrome, 40)
	deco_cyl(c + Vector3(0, PLANET_R + 1.13, 0), 3.3, 0.06, Mats.glow(TEAL, 1.2))
	deco_box(c + Vector3(0, PLANET_R + 1.18, -2.2), Vector3(0.4, 0.08, 1.8), Mats.glow(PINK, 2.5))
	place_goal(c + Vector3(0, PLANET_R + 1.1, 0))

	# A walkable ring of socks around the equator.
	var segs := 40
	for i in segs:
		var a := TAU * i / segs
		var p := around(a, RING_R, RING_Y - 0.5)
		var col: Color = RAINBOW[int(i / 4.0) % RAINBOW.size()]
		var m := sock_mat(col, CREAM, 0.42, Vector3(0, 0, 1), -1000.0, 1000.0, 0.12)
		box(p, Vector3(6.0, 1.0, TAU * RING_R / segs + 0.3), m, Vector3(0, a + PI / 2, 0))
		if i % 4 == 3:
			deco_ball(around(a + TAU / segs * 0.5, RING_R, RING_Y - 0.6), 1.9, Mats.solid(CREAM, 0.95), Vector3(1.0, 0.6, 1.0))
	var edge := TorusMesh.new()
	edge.inner_radius = RING_R + 2.9
	edge.outer_radius = RING_R + 3.2
	edge.rings = 128
	deco(edge, Mats.glow(LAVENDER, 2.0), Vector3(c.x, RING_Y - 0.1, c.z))
	var inner := TorusMesh.new()
	inner.inner_radius = RING_R - 3.2
	inner.outer_radius = RING_R - 2.9
	inner.rings = 128
	deco(inner, Mats.glow(TEAL, 2.0), Vector3(c.x, RING_Y - 0.1, c.z))

	checkpoint(around(0.14, RING_R, RING_Y), atan2(-cos(0.14), sin(0.14)))
	tip(around(-0.12, RING_R, RING_Y + 2.0), Vector3(10, 4, 6), "steve", "The Washing Machine Planet! Key's up top. Fun fact: signs can't be villains. Just a fact.")
	trigger(around(-0.12, RING_R, RING_Y + 2.0), Vector3(10, 4, 6), _nobody_asked)
	for i in 5:
		coin(around(-0.5 - i * 0.12, RING_R, RING_Y + 1.0))
	for i in 5:
		coin(around(0.3 + i * 0.1, RING_R, RING_Y + 1.0))
	coin(around(PI, RING_R, RING_Y + 1.2), 5)
	enemy("moth", around(0.42, RING_R, RING_Y), around(0.64, RING_R, RING_Y), 0.6)
	enemy("moth", around(-0.9, RING_R, RING_Y), around(-1.3, RING_R, RING_Y), 0.6)

	# Low-gravity spin cycle up the side of the planet.
	low_gravity(Vector3(c.x, RING_Y + 1.7, c.z), RING_R - 3.5, 42.0, Color(0.45, 0.85, 1.0))
	var discs := [[0.8, 21.0, 3.2], [1.2, 20.2, 6.2], [1.6, 18.8, 9.2], [2.0, 16.8, 12.2], [2.4, 13.8, 15.2]]
	var rims: Array[Color] = [TEAL, PINK, LEMON, MINT, LAVENDER]
	for i in discs.size():
		var dsc: Array = discs[i]
		var top := around(dsc[0], dsc[1], c.y + dsc[2] + 0.3)
		spin_disc(top, 4.6, 0.6 if i % 2 == 0 else -0.6, rims[i])
		coin(top + Vector3(0, 1.2, 0))
		if i > 0:
			var prev: Array = discs[i - 1]
			var from := around(prev[0], prev[1], c.y + prev[2] + 0.3)
			coin(from.lerp(top, 0.5) + Vector3(0, 3.0, 0))
	coin_ring(c + Vector3(0, PLANET_R + 0.9, 0), 6.5, 6)


func _nobody_asked(_p: Node3D) -> void:
	await get_tree().create_timer(5.0).timeout
	if not complete and not is_cinematic():
		bark("stax", "...Nobody asked, Steve.")


func _build_backdrop() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 44
	var pastels: Array[Color] = [PINK, MINT, LAVENDER, PEACH, SKY, LEMON]

	# Hundreds of lost socks drifting in the void.
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	mm.mesh = sock_mesh()
	var count := 520
	mm.instance_count = count
	var a := Vector3(0, 10, 30)
	var b := Vector3(0, 30, -270)
	var i := 0
	while i < count:
		var p := Vector3(rng.randf_range(-380, 380), rng.randf_range(-160, 220), rng.randf_range(-600, 300))
		var t := clampf((p - a).dot(b - a) / (b - a).length_squared(), 0.0, 1.0)
		if p.distance_to(a.lerp(b, t)) < 55.0:
			continue
		var basis := Basis.from_euler(Vector3(rng.randf() * TAU, rng.randf() * TAU, rng.randf() * TAU)).scaled(Vector3.ONE * rng.randf_range(2.0, 9.0))
		mm.set_instance_transform(i, Transform3D(basis, p))
		mm.set_instance_color(i, pastels[rng.randi() % pastels.size()])
		i += 1
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	mmi.material_override = sock_mat(Color.WHITE, Color.WHITE, 3.0, Vector3.UP, 0.32, 1.3, 0.35)
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mmi)
	_spinners.append([mmi, Vector3(0, 0.004, 0)])

	# An orbiting halo of small socks around the planet.
	var halo := Node3D.new()
	halo.position = PLANET + Vector3(0, 4, 0)
	halo.rotation = Vector3(0.18, 0, -0.12)
	add_child(halo)
	var hm := MultiMesh.new()
	hm.transform_format = MultiMesh.TRANSFORM_3D
	hm.use_colors = true
	hm.mesh = sock_mesh()
	hm.instance_count = 160
	for k in 160:
		var ang := TAU * k / 160.0 + rng.randf_range(-0.02, 0.02)
		var rr := rng.randf_range(38.0, 46.0)
		var bs := Basis.from_euler(Vector3(rng.randf() * TAU, rng.randf() * TAU, rng.randf() * TAU)).scaled(Vector3.ONE * rng.randf_range(0.9, 1.8))
		hm.set_instance_transform(k, Transform3D(bs, Vector3(sin(ang) * rr, rng.randf_range(-1.2, 1.2), cos(ang) * rr)))
		hm.set_instance_color(k, pastels[k % pastels.size()])
	var hmi := MultiMeshInstance3D.new()
	hmi.multimesh = hm
	hmi.material_override = mmi.material_override
	hmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	halo.add_child(hmi)
	_spinners.append([hmi, Vector3(0, 0.05, 0)])

	# Colossal background socks, slowly tumbling.
	var giants := [[Vector3(-150, 40, -90), 70.0], [Vector3(170, -20, -210), 90.0], [Vector3(-120, -60, -330), 110.0],
		[Vector3(110, 70, 60), 60.0], [Vector3(-40, 120, -250), 80.0], [Vector3(60, -90, -40), 70.0]]
	for k in giants.size():
		var g: Array = giants[k]
		var s := deco_sock(g[0], g[1], pastels[k % pastels.size()], CREAM, Vector3(rng.randf() * TAU, rng.randf() * TAU, 0))
		_spinners.append([s, Vector3(0.01, 0.015, 0.0) * (1.0 if k % 2 == 0 else -1.0)])

	# A clothesline of hanging socks across the opening view.
	var l0 := Vector3(-26, 12, -38)
	var l1 := Vector3(24, 15, -56)
	var wood := Mats.solid(Color(0.85, 0.66, 0.44), 0.8)
	for e in [l0, l1]:
		deco_box(e + Vector3(0, -1.2, 0), Vector3(0.7, 3.0, 0.5), wood)
		deco_box(e + Vector3(0, -0.2, 0), Vector3(0.9, 0.6, 0.6), Mats.solid(Color(0.8, 0.82, 0.88), 0.25, 0.9))
	var prev := l0
	for k in range(1, 25):
		var t := k / 24.0
		var p := l0.lerp(l1, t) - Vector3(0, sin(t * PI) * 3.0, 0)
		var d := p - prev
		deco_box((p + prev) * 0.5, Vector3(0.08, 0.08, d.length() + 0.05), Mats.glow(Color(1.0, 0.9, 0.95), 2.5),
			Vector3(-atan2(d.y, Vector2(d.x, d.z).length()), atan2(d.x, d.z), 0))
		if k % 4 == 2:
			deco_sock(p - Vector3(0, 2.3, 0), 2.2, pastels[k % pastels.size()], CREAM, Vector3(0, rng.randf() * TAU, 0))
			deco_box(p - Vector3(0, 0.1, 0), Vector3(0.18, 0.6, 0.35), wood)
		prev = p

	# Floating detergent bubbles and stray lint.
	var bubble := Mats.glass(Color(0.75, 0.9, 1.0), 0.22)
	for k in 14:
		var p := PLANET + Vector3(rng.randf_range(-40, 40), rng.randf_range(-10, 30), rng.randf_range(-35, 45))
		if p.distance_to(PLANET) < PLANET_R + 14.0:
			continue
		var bb := deco_ball(p, rng.randf_range(0.6, 1.6), bubble)
		_bobbers.append([bb, p, rng.randf_range(0.3, 0.9), rng.randf_range(0.5, 1.0), rng.randf() * TAU, 0.0])
	for k in 8:
		var p := Vector3(rng.randf_range(-40, 40), rng.randf_range(-12, 30), rng.randf_range(-40, -220))
		if absf(p.x) < 16.0:
			p.x += 30.0 * signf(p.x + 0.01)
		deco_ball(p, rng.randf_range(1.5, 3.5), lint_mat(), Vector3(1, 0.5, 1))

	Fx.ambient(self, Vector3(0, 10, -60), Vector3(40, 18, 70), Color(1.0, 0.85, 1.0, 0.7), 220, 0.12, Vector3(0.2, 0.25, 0), 8.0)
	Fx.ambient(self, Vector3(0, 25, -190), Vector3(45, 22, 60), Color(0.8, 0.95, 1.0, 0.7), 220, 0.12, Vector3(0.2, 0.25, 0), 8.0)


func _process(delta: float) -> void:
	_t += delta
	for s in _spinners:
		if is_instance_valid(s[0]):
			(s[0] as Node3D).rotation += (s[1] as Vector3) * delta
	for b in _bobbers:
		var n: Node3D = b[0]
		if is_instance_valid(n):
			n.position = (b[1] as Vector3) + Vector3(0, sin(_t * b[3] + b[4]) * b[2], 0)
			n.rotation.y += b[5] * delta


# ---------------------------------------------------------------- story

func intro() -> void:
	director.begin()
	Game.fx.set_black(true)
	director.actors["steve"] = _steve.puppet
	player.process_mode = Node.PROCESS_MODE_DISABLED
	player.global_position = spawn_point + Vector3(0, -200, 0)
	var sp := spawn_point

	# A slow drift through the nebula, past the sock pillars to the cuff.
	director.shot(Vector3(46, 30, -118), Vector3(10, 14, -70), 40.0)
	Game.fx.fade_in(2.5)
	await director.move(Vector3(24, 13, -44), Vector3(2, 5, -24), 5.0, 44.0, "in")
	await director.move(Vector3(12, 6, 20), sp + Vector3(0, 3, 0), 4.5, 50.0, "out")

	# Stax floats down from above.
	player.place(sp + Vector3(0, 11, 0), spawn_yaw)
	player.process_mode = Node.PROCESS_MODE_INHERIT
	player.gravity_scale = 0.3
	player.model.emote = "cool"
	director.shot(sp + Vector3(3.5, 0.9, 7.5), sp + Vector3(0, 8, 0), 52.0)
	director.track(player, Vector3(3.5, 0.9, 7.5), Vector3(0, 1.2, 0), 2.6)
	var t := 0.0
	while t < 3.5 and not director.skipping and not player.is_on_floor():
		await get_tree().process_frame
		t += get_process_delta_time()
	player.gravity_scale = 1.0
	player.model.emote = ""
	director.shake(0.3)
	await director.settle()

	var c := sp + Vector3(0, 1.2, 0)
	director.orbit(c, 6.5, 1.3, PI / 2 + 0.7, PI / 2 - 0.3, 5.0, 46.0)
	await director.title(info.chapter, info.title, info.subtitle)
	await director.settle()

	director.shot(c + Vector3(2.2, 0.4, 3.8), c + Vector3(0, 0.1, 0), 38.0)
	await director.say("stax", "Okay. Floating socks. Purple space. Somebody explain.", "shrug")
	director.face(_dino_sock.global_position)
	director.shot(c + Vector3(-1.3, 0.5, 3.2), _dino_sock.global_position, 40.0)
	director.move(c + Vector3(-0.6, 0.6, 2.2), _dino_sock.global_position, 4.0)
	await director.say("stax", "Wait. That's MY sock! The dino one I lost in second grade!", "point")
	await director.say("stax", "Every dryer in history has been running a sock heist. Respect, honestly.", "think")
	await director.settle()

	director.face(_steve.global_position)
	_steve.face_toward(player.global_position)
	director.two_shot(player, _steve, 1.0, 44.0)
	await director.lines([
		["steve", "Welcome to the Lost Sock Nebula! Where every missing sock ends up. Forever."],
		["stax", "STEVE?! We're in SPACE. How are you already here?!", "shocked"],
		["steve", "Signs are everywhere, kid. It's kind of our whole thing.", "shrug"],
		["steve", "Last key's on top of the Washing Machine Planet. Then it's Vault time for me— for YOU!"],
		["stax", "Great. A planet-sized appliance between me and my money. Let's spin.", "cool"],
	])
	player.gravity_scale = 1.0
	player.process_mode = Node.PROCESS_MODE_INHERIT
	player.place(spawn_point, spawn_yaw)
	director.end()


func outro_lines() -> Array:
	return [
		["stax", "Key number four! Baron, your little vault's about to get a very rich visitor.", "cheer"],
		["steve", "That's all four! The Last Vault awaits. Don't worry, I'll be there. I'm always there."],
		["stax", "...Why does that sound less comforting every time?", "think"],
		["steve", "Small detour first. I know a shortcut through a kid's drawing. What could go wrong?"],
	]


## Righty and Lefty meet up whichever of them Stax finds second.
func _talk(n: Node3D) -> void:
	if not _reunited and ((n == _righty and _lefty.talked) or (n == _lefty and _righty.talked)):
		await _reunion(n)
	else:
		await super(n)


func on_talked(n: Node3D) -> void:
	if n == _lefty and not _reunited:
		hud.banner("SIDE QUEST: FIND RIGHTY", 2.0, PINK)


func _reunion(n: Node3D) -> void:
	_reunited = true
	_lefty.talked = true
	_righty.talked = true
	director.begin()
	director.actors["lefty"] = n.puppet
	director.face(n.global_position)
	n.face_toward(player.global_position)
	director.two_shot(player, n, 1.0)
	if n == _righty:
		await director.lines([
			["stax", "Hey. There's a pink, super dramatic sock down there. Says he's your other half.", "point"],
			["lefty", "LEFTY?! My Lefty?! Hold on, sweetie, I'm coming!", "cheer"],
		])
	else:
		await director.lines([
			["lefty", "You found Righty?! Where? WHERE?!", "shocked"],
			["stax", "Up in the floaty part, being sad. HEY, RIGHTY! Your sock's down here!", "point"],
		])

	var from := _righty.global_position
	var home := _lefty.global_position + Vector3(1.4, 0, 0.3)
	var look := _lefty.global_position + Vector3(0.7, 1.2, 0)
	director.shot(look + Vector3(-4.0, 2.2, 6.5), look + Vector3(0, 0.6, 0), 50.0)
	director.move(look + Vector3(-1.6, 0.6, 4.2), look, 2.6, 40.0)
	_righty.puppet.emote = "cheer"
	var t := 0.0
	while t < 2.4 and not director.skipping:
		await get_tree().process_frame
		t += get_process_delta_time()
		var k := clampf(t / 2.4, 0.0, 1.0)
		k = k * k * (3.0 - 2.0 * k)
		_righty.global_position = from.lerp(home, k) + Vector3(0, sin(k * PI) * 3.0, 0)
	_righty.global_position = home
	_righty.face_toward(_lefty.global_position)
	_lefty.face_toward(home)
	Fx.burst(self, home + Vector3(-0.7, 1.6, 0), PINK, 40, 5.0, 0.35, 1.0, -3.0)
	Audio.play("checkpoint", 1.3)
	await director.settle()
	director.actors["lefty"] = _lefty.puppet
	_lefty.puppet.emote = "cheer"
	director.two_shot(_lefty, _righty, 1.0, 40.0)
	await director.lines([
		["lefty", "RIGHTY! My sole mate! We're a matching pair again!", "cheer"],
		["lefty", "Stax, take this! We found it in a coat pocket in 1987. Keep the change!"],
		["stax", "Aww. A sock reunion. Honestly? The coins make it extra beautiful.", "cheer"],
	])
	var after := [["lefty", "Thanks, Stax! We'll never be apart again. Unless somebody does laundry."]]
	for s in [_lefty, _righty]:
		s.lines = after
		s.repeat_lines = after
		s.puppet.emote = ""
	director.end()
	var p := player.global_position
	coin(p + Vector3(1.6, 1.0, 0), 5)
	coin(p + Vector3(-1.6, 1.0, 0), 5)
	hud.banner("SOCKS REUNITED!", 2.0, PINK)
