extends "res://scripts/world/level_base.gd"
## Chapter 1: Goldhaven Rooftops. Sunset parkour across the city to the top
## of the Bank Tower. Opens with the Baron's broadcast on a giant billboard.
## Route: home roof -> gap jumps -> window-washer ride -> wall-kick alley ->
## crane jib over a spinning girder -> billboards -> balcony spiral -> helipad.

const TOWER := Vector3(34, 0, -150)
const SCREEN_POS := Vector3(-23.9, 40, -18)
## Traffic avenues: [coordinate, runs along z?].
const LANES := [[-14.0, true], [16.0, true], [-100.0, false], [-170.0, false], [-48.0, false]]

var _wall_mats: Array = []
var _roof: Material
var _trim: Material
var _baron: Node3D
var _steve: Node3D
var _steve_top: Node3D
var _piggy: Node3D
var _blimp: Node3D
var _cars: Array = []
var _beacons: Array[OmniLight3D] = []
var _t := 0.0


func _init() -> void:
	music = "rooftops"
	spawn_point = Vector3(0, 24.3, 5)
	spawn_yaw = 0.0
	kill_y = 8.0


func env_config() -> Dictionary:
	return {
		"top": Color(0.16, 0.18, 0.42), "horizon": Color(1.0, 0.56, 0.34), "bottom": Color(0.22, 0.14, 0.2),
		"sun_color": Color(1.0, 0.72, 0.48), "sun_energy": 1.5, "sun_angle": Vector2(-14, -150),
		"sun_size": 2.5, "sun_glow": 1.0, "clouds": 0.55, "cloud_color": Color(1.0, 0.66, 0.55),
		"fog_color": Color(0.95, 0.62, 0.48), "fog_density": 0.0032, "volumetric": 0.01,
		"vol_color": Color(1.0, 0.82, 0.66), "ambient": 0.8, "exposure": 1.0, "glow": 0.9,
		"tint": Color(1.03, 1.0, 0.96), "saturation": 1.1,
	}


# ---------------------------------------------------------------- build

func build() -> void:
	_wall_mats = [
		Mats.pattern("windows", [Color(0.14, 0.16, 0.22), Color(0.2, 0.26, 0.36), Color(1.0, 0.82, 0.5)], 0.08, 0.35, true, 11, 0.9),
		Mats.pattern("windows", [Color(0.42, 0.24, 0.18), Color(0.2, 0.16, 0.18), Color(1.0, 0.7, 0.4)], 0.08, 0.8, true, 12, 0.9),
		Mats.pattern("windows", [Color(0.5, 0.48, 0.45), Color(0.24, 0.26, 0.3), Color(0.9, 0.95, 1.0)], 0.08, 0.6, true, 13, 0.9),
	]
	_roof = Mats.rough_surface(Color(0.36, 0.34, 0.33), Color(0.46, 0.44, 0.42), 0.2, 0.9, 5)
	_trim = Mats.solid(Color(0.2, 0.18, 0.18), 0.6, 0.3)
	_build_street()
	_build_route()
	_build_filler()
	_build_broadcast()
	_build_blimp()
	Fx.ambient(self, Vector3(10, 34, -70), Vector3(60, 14, 90), Color(1.0, 0.85, 0.6, 0.5), 160, 0.1)


## A building with a flat concrete roof whose top is at `top`.
func building(x: float, z: float, w: float, d: float, top: float, style := 0) -> void:
	box(Vector3(x, (top - 0.4) * 0.5, z), Vector3(w, top - 0.4, d), _wall_mats[style % 3])
	box(Vector3(x, top - 0.2, z), Vector3(w + 0.3, 0.4, d + 0.3), _roof)
	deco_box(Vector3(x, top - 0.45, z), Vector3(w + 0.5, 0.15, d + 0.5), _trim)


func ac_unit(pos: Vector3) -> void:
	box(pos + Vector3(0, 0.6, 0), Vector3(1.8, 1.2, 1.4), Mats.solid(Color(0.7, 0.72, 0.74), 0.5, 0.6))
	var fan := deco_cyl(pos + Vector3(0, 1.22, 0), 0.5, 0.05, Mats.solid(Color(0.15, 0.15, 0.17), 0.5))
	fan.name = "Fan"


func water_tower(pos: Vector3) -> void:
	var wood := Mats.solid(Color(0.5, 0.33, 0.2), 0.9)
	for x in [-1.0, 1.0]:
		for z in [-1.0, 1.0]:
			deco_box(pos + Vector3(x * 1.2, 1.2, z * 1.2), Vector3(0.2, 2.4, 0.2), _trim)
	cylinder(pos + Vector3(0, 3.6, 0), 1.9, 2.6, wood)
	deco_cyl(pos + Vector3(0, 5.3, 0), 2.1, 0.8, Mats.solid(Color(0.3, 0.3, 0.32), 0.7), Vector3.ZERO, 0.2)
	box(pos + Vector3(0, 2.3, 0), Vector3(3.2, 0.2, 3.2), _trim)


func _build_street() -> void:
	box(Vector3(10, -0.5, -80), Vector3(700, 1, 700), Mats.rough_surface(Color(0.1, 0.1, 0.12), Color(0.16, 0.15, 0.16), 0.1, 0.8, 9))
	var head := Mats.glow(Color(1.0, 0.95, 0.8), 3.0)
	var tail := Mats.glow(Color(1.0, 0.15, 0.1), 3.0)
	var rng := RandomNumberGenerator.new()
	rng.seed = 21
	# Traffic streaks along the avenues far below.
	for lane in LANES:
		for i in 7:
			var car := Node3D.new()
			add_child(car)
			var body := deco_box(Vector3.ZERO, Vector3(1.8, 1.2, 4.0), Mats.solid(Color(rng.randf(), rng.randf() * 0.6, 0.3), 0.3, 0.6))
			body.reparent(car, false)
			var dir := 1.0 if i % 2 == 0 else -1.0
			var lamp := deco_box(Vector3(0, 0.1, -2.05 * dir), Vector3(1.6, 0.25, 0.1), head if dir > 0 else tail)
			lamp.reparent(car, false)
			var lamp2 := deco_box(Vector3(0, 0.1, 2.05 * dir), Vector3(1.6, 0.25, 0.1), tail if dir > 0 else head)
			lamp2.reparent(car, false)
			var along := rng.randf_range(-250, 250)
			var off := (1.8 if dir > 0 else -1.8)
			if lane[1]:
				car.position = Vector3(lane[0] + off, 0.6, along)
			else:
				car.position = Vector3(along, 0.6, lane[0] + off)
				car.rotation.y = PI / 2
			_cars.append({"node": car, "along_z": lane[1], "speed": dir * rng.randf_range(10.0, 18.0)})
	# Street lamps.
	for i in 10:
		omni(Vector3(-14 + (i % 2) * 30, 5, 20 - i * 22), Color(1.0, 0.7, 0.4), 14.0, 1.2)


func _build_route() -> void:
	# 1. Home roof, with Stax's empty piggy bank and a water tower.
	building(0, 0, 20, 20, 24, 1)
	water_tower(Vector3(6, 24, 6))
	coin(Vector3(6, 29.2, 6), 5)
	ac_unit(Vector3(-6, 24, -4))
	ac_unit(Vector3(-6, 24, 5))
	_piggy = _make_piggy(Vector3(1.6, 24, 7.2))
	coin_ring(Vector3(0, 25, -2), 3.0, 8)
	_steve = npc("steve", "steve", Vector3(-2.6, 24, 3.2), PI - 0.6, [
		["steve", "Movement tips! Run, crouch, then jump: that's a long jump. Great for big gaps!"],
		["steve", "Crouch while standing still, then jump: backflip! Perfect for tall things. Like water towers."],
		["stax", "Is there money on the water tower?", "think"],
		["steve", "I couldn't possibly say. Advice is free! Tipping is... strongly encouraged."],
	], [["steve", "The Bank Tower's that way. Follow the golden light! I'll meet you there. Somehow."]])

	# 2-3. Easy gap jumps.
	building(0, -18, 12, 10, 23, 0)
	coin_arc(Vector3(0, 24.4, -10.5), Vector3(0, 23.4, -13.5), 1.4, 4)
	building(-2, -34, 14, 14, 22, 2)
	coin_arc(Vector3(0, 23.4, -23.5), Vector3(0, 22.4, -26.5), 1.6, 4)
	ac_unit(Vector3(-6, 22, -38))
	tip(Vector3(0, 24, -18), Vector3(12, 4, 8), "steve", "Tip: Hold jump for a big jump. Land and jump again for a double... then a triple!")
	npc("pigeon", "pigeon", Vector3(3.5, 22, -31), -PI / 2, [
		["pigeon", "Coo. You're the kid with the money glasses. Coo."],
		["stax", "You've heard of me?", "cool"],
		["pigeon", "Everybody has. You tried to pay for bread with a coupon for bread."],
		["stax", "It was a VALID coupon.", "shrug"],
		["pigeon", "Word on the wire: the Baron's blimp circled the Bank Tower. Big glowing key up top."],
		["pigeon", "Also, that talking sign's been watching you all day. Never blinks. Coo."],
		["stax", "He's a sign. He doesn't have eyelids.", "facepalm"],
		["pigeon", "Exactly. Suspicious. Coo."],
	], [["pigeon", "Key's on top of the Bank Tower. Past the crane. Watch out for Repo Drones. Coo."]])

	# 4. The window-washer ride over a wide gap.
	tip(Vector3(-2, 24, -39), Vector3(14, 4, 4), "steve", "Tip: Ride the window-washer platform. Keep your arms inside the platform at all times!")
	var washer := mover(Vector3(4, 0.4, 3), Mats.solid(Color(0.85, 0.7, 0.2), 0.4, 0.6), Vector3(0, 21.8, -43), Vector3(0, 0, -12), 7.0)
	var rail := deco_box(Vector3(0, 0.6, 1.4), Vector3(4, 0.1, 0.1), _trim)
	rail.reparent(washer, false)
	coin_line(Vector3(0, 23.2, -45), Vector3(0, 23.2, -53), 4)
	building(0, -66, 18, 18, 22, 1)
	checkpoint(Vector3(6, 22, -60), 0.0)
	enemy("drone", Vector3(-5, 22, -69), Vector3(5, 22, -69), 0.6)
	tip(Vector3(0, 24, -62), Vector3(18, 4, 6), "steve", "Tip: Repo Drones repossess coins. Stomp them! Unlike me. I would never take your coins.")
	coin_ring(Vector3(-4, 23, -64), 2.0, 6)

	# 5. Wall-kick alley between two tall buildings.
	building(-6, -85, 8, 14, 36, 0)
	building(6, -85, 8, 14, 36, 2)
	box(Vector3(0, 21.8, -84), Vector3(4, 0.4, 18), _roof)
	coin_line(Vector3(0, 24, -82), Vector3(0, 34, -82), 5)
	coin(Vector3(0, 30, -88), 5)
	tip(Vector3(0, 24, -79), Vector3(4, 4, 6), "steve", "Tip: Jump into a wall, then jump again as you touch it. Wall kicks! Bounce your way up!")
	sign_text("GOLD\nGYM", Vector3(-1.95, 31, -85), -PI / 2, 120, Color(1.0, 0.4, 0.7), 1.5)
	omni(Vector3(-0.5, 31, -85), Color(1.0, 0.4, 0.7), 6.0, 1.5)

	# 6. The crane: walk the jib, jump the spinning girder.
	var steel := Mats.solid(Color(0.95, 0.72, 0.1), 0.5, 0.5)
	box(Vector3(-6, 35.8, -111), Vector3(1.6, 0.4, 38), steel)
	for i in 12:
		deco_box(Vector3(-6, 35.2, -93 - i * 3.2), Vector3(1.6, 0.8, 0.12), steel, Vector3(0.6, 0, 0))
	deco_box(Vector3(-9.5, 23, -104), Vector3(1.6, 46, 1.6), steel)
	box(Vector3(-9.5, 38.5, -104), Vector3(3, 3, 3), Mats.solid(Color(0.9, 0.9, 0.85), 0.5))
	coin(Vector3(-9.5, 41.2, -104), 5)
	box(Vector3(-7.8, 36, -104), Vector3(2.2, 0.4, 2.2), steel)
	hazard_box(Vector3(-6, 36.7, -113), Vector3(9, 0.6, 0.6), Mats.glow(Color(1.0, 0.25, 0.1), 1.5), 1.3)
	deco_cyl(Vector3(-6, 41, -113), 0.05, 8.0, _trim)
	coin_line(Vector3(-6, 37, -96), Vector3(-6, 37, -108), 5)
	coin_line(Vector3(-6, 37, -118), Vector3(-6, 37, -128), 4)
	tip(Vector3(-6, 37, -97), Vector3(3, 4, 4), "steve", "Tip: Jump over the spinning girder! Or don't. I'm a sign, not a cop.")
	building(-4, -138, 14, 16, 34, 1)
	checkpoint(Vector3(-8, 34, -134), 0.0)
	enemy("drone", Vector3(-8, 34, -143), Vector3(0, 34, -143), 0.6)
	sign_text("BUY\nGOLD", Vector3(-4, 38, -145.9), PI, 160, Color(1.0, 0.8, 0.2), 1.6)
	deco_box(Vector3(-4, 38, -146.2), Vector3(8, 4.6, 0.3), _trim)
	omni(Vector3(-4, 38, -143.5), Color(1.0, 0.8, 0.3), 8.0, 1.5)

	# 7. Billboard tops stepping up toward the Bank Tower.
	var board := Mats.solid(Color(0.25, 0.2, 0.3), 0.5, 0.3)
	var steps := [Vector3(9, 36, -140), Vector3(14.5, 38, -142.5), Vector3(19.5, 40, -144)]
	for s in steps:
		box(s - Vector3(0, 0.2, 0), Vector3(3.5, 0.4, 3), board)
		deco_box(s - Vector3(0, 5, 0), Vector3(0.4, 10, 0.4), _trim)
		coin(s + Vector3(0, 1.2, 0))
	sign_text("$$$", Vector3(14.5, 37, -141), PI, 140, Color(0.4, 1.0, 0.5), 1.5)

	# 8. The Bank Tower: podium, balcony spiral, helipad.
	box(Vector3(TOWER.x, 19.8, TOWER.z), Vector3(24, 39.6, 24), _wall_mats[2])
	box(Vector3(TOWER.x, 39.8, TOWER.z), Vector3(24.4, 0.4, 24.4), _roof)
	checkpoint(Vector3(23.2, 40, -140), -PI / 2)
	coin(Vector3(44, 41.2, -160), 5)
	enemy("drone", Vector3(24, 40, -158), Vector3(24, 40, -146), 0.6)
	box(Vector3(TOWER.x, 51.8, TOWER.z), Vector3(14, 23.6, 14), Mats.pattern("windows",
		[Color(0.1, 0.1, 0.12), Color(0.18, 0.2, 0.28), Color(1.0, 0.85, 0.45)], 0.1, 0.25, true, 17, 1.1))
	box(Vector3(TOWER.x, 63.8, TOWER.z), Vector3(14.6, 0.4, 14.6), _roof)
	tip(Vector3(24, 42, -144), Vector3(4, 4, 10), "steve", "Tip: Climb the balconies to the top! Can't believe I'm giving this away for free.")
	var balcony := Mats.solid(Color(0.8, 0.78, 0.74), 0.4, 0.3)
	var r := 8.6
	var s0 := 7.0 * r + 6.0
	for i in 11:
		var p := _ring(s0 + i * 4.4, r)
		var top := 42.0 + i * 2.0
		box(Vector3(TOWER.x + p.x, top - 0.2, TOWER.z + p.y), Vector3(3, 0.4, 3), balcony)
		if i % 2 == 1:
			coin(Vector3(TOWER.x + p.x, top + 1.1, TOWER.z + p.y))
	# Helipad with the key.
	deco_cyl(Vector3(TOWER.x, 64.02, TOWER.z), 5.5, 0.04, Mats.solid(Color(0.15, 0.15, 0.17), 0.8))
	deco_box(Vector3(TOWER.x - 1.4, 64.06, TOWER.z), Vector3(0.6, 0.04, 4), Mats.solid(Color(0.95, 0.9, 0.3), 0.6))
	deco_box(Vector3(TOWER.x + 1.4, 64.06, TOWER.z), Vector3(0.6, 0.04, 4), Mats.solid(Color(0.95, 0.9, 0.3), 0.6))
	deco_box(Vector3(TOWER.x, 64.06, TOWER.z), Vector3(2.8, 0.04, 0.6), Mats.solid(Color(0.95, 0.9, 0.3), 0.6))
	place_goal(Vector3(TOWER.x, 64, TOWER.z))
	_steve_top = npc("steve", "steve", Vector3(TOWER.x + 5, 64, TOWER.z + 5), PI + 0.8, [
		["stax", "Steve?! How did you get up here before me?", "shocked"],
		["steve", "Signs are everywhere, kid. It's kind of our whole thing."],
		["steve", "Key's right there. Go on. Don't mind me. Just a regular sign."],
	], [["steve", "Just a regular sign. Standing here. Regularly."]])
	sign_text("GOLDHAVEN BANK", Vector3(TOWER.x, 67.5, TOWER.z - 6.5), PI, 180, Color(1.0, 0.8, 0.3), 1.8)
	deco_box(Vector3(TOWER.x, 67.5, TOWER.z - 6.8), Vector3(13, 2.2, 0.3), _trim)
	for cx in [-1.0, 1.0]:
		for cz in [-1.0, 1.0]:
			var b := omni(Vector3(TOWER.x + cx * 7, 65, TOWER.z + cz * 7), Color(1, 0.1, 0.05), 5.0, 2.0)
			_beacons.append(b)
			deco_ball(b.position, 0.2, Mats.glow(Color(1, 0.15, 0.1), 4.0))


## Point on a square ring of half-size r around the tower, by distance s.
func _ring(s: float, r: float) -> Vector2:
	s = fposmod(s, 8.0 * r)
	if s < 2.0 * r:
		return Vector2(-r + s, r)
	s -= 2.0 * r
	if s < 2.0 * r:
		return Vector2(r, r - s)
	s -= 2.0 * r
	if s < 2.0 * r:
		return Vector2(r - s, -r)
	s -= 2.0 * r
	return Vector2(-r, -r + s)


## Background buildings: low near the route, towering far away.
func _build_filler() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 99
	var route := [Vector2(0, 0), Vector2(0, -34), Vector2(0, -66), Vector2(0, -85), Vector2(-5, -115),
		Vector2(-4, -138), Vector2(15, -142), Vector2(34, -150)]
	for gx in range(-8, 12):
		for gz in range(-13, 4):
			var x := gx * 22.0 + rng.randf_range(-3, 3)
			var z := gz * 22.0 + rng.randf_range(-3, 3)
			var near := 1e9
			for p in route:
				near = minf(near, Vector2(x, z).distance_to(p))
			if near < 20.0:
				continue
			var h := rng.randf_range(8.0, 18.0) if near < 45.0 else rng.randf_range(26.0, 80.0)
			if absf(x - (SCREEN_POS.x - 8.0)) < 16 and absf(z - SCREEN_POS.z) < 18:
				continue
			var w := rng.randf_range(10.0, 17.0)
			var d := rng.randf_range(10.0, 17.0)
			var on_street := false
			for lane in LANES:
				var c: float = x if lane[1] else z
				var half := (w if lane[1] else d) * 0.5
				if absf(c - lane[0]) < half + 3.0:
					on_street = true
			if on_street:
				continue
			deco_box(Vector3(x, h * 0.5, z), Vector3(w, h, d), _wall_mats[rng.randi() % 3])
	# Far skyline ring.
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	var bm := BoxMesh.new()
	bm.material = Mats.pattern("windows", [Color(0.08, 0.08, 0.12), Color(0.12, 0.12, 0.18), Color(1.0, 0.75, 0.45)], 0.05, 0.6, true, 31, 0.7)
	mm.mesh = bm
	mm.instance_count = 160
	for i in mm.instance_count:
		var a := rng.randf() * TAU
		var dist := rng.randf_range(260.0, 420.0)
		var h := rng.randf_range(40.0, 170.0)
		var w := rng.randf_range(18.0, 40.0)
		var t := Transform3D(Basis().scaled(Vector3(w, h, w)).rotated(Vector3.UP, rng.randf() * TAU),
			Vector3(10 + cos(a) * dist, h * 0.5, -80 + sin(a) * dist))
		mm.set_instance_transform(i, t)
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mmi)


## A giant screen showing the Baron live, rendered from a tiny studio set.
func _build_broadcast() -> void:
	box(Vector3(SCREEN_POS.x - 8.2, 25, SCREEN_POS.z), Vector3(16, 50, 22), _wall_mats[0])
	var vp := SubViewport.new()
	vp.size = Vector2i(640, 360)
	vp.own_world_3d = true
	vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(vp)
	var studio_env := Environment.new()
	studio_env.background_mode = Environment.BG_COLOR
	studio_env.background_color = Color(0.25, 0.08, 0.35)
	studio_env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	studio_env.ambient_light_color = Color(0.6, 0.5, 0.7)
	studio_env.tonemap_mode = Environment.TONE_MAPPER_ACES
	var we := WorldEnvironment.new()
	we.environment = studio_env
	vp.add_child(we)
	var key := DirectionalLight3D.new()
	key.rotation = Vector3(-0.5, 0.6, 0)
	key.light_energy = 1.6
	vp.add_child(key)
	_baron = Puppet.new()
	_baron.kind = "baron"
	_baron.speaker = "baron"
	vp.add_child(_baron)
	var back := MeshInstance3D.new()
	var bq := QuadMesh.new()
	bq.size = Vector2(12, 7)
	back.mesh = bq
	back.material_override = Mats.pattern("stripes", [Color(0.4, 0.12, 0.5), Color(0.3, 0.08, 0.4)], 0.5, 0.9)
	back.position = Vector3(0, 2, 2.5)
	back.rotation.y = PI
	vp.add_child(back)
	for i in 5:
		var c := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = 0.4
		cm.bottom_radius = 0.4
		cm.height = 0.1
		c.mesh = cm
		c.material_override = Mats.gold()
		c.position = Vector3(-2.5 + i * 1.25, 0.05 + (i % 2) * 0.1, -0.8)
		vp.add_child(c)
	var cam := Camera3D.new()
	cam.fov = 38.0
	vp.add_child(cam)
	cam.look_at_from_position(Vector3(0.8, 2.0, -4.6), Vector3(0, 1.6, 0))
	var ticker := Label.new()
	ticker.text = "  BREAKING NEWS  ·  ALL COINS IN GOLDHAVEN STOLEN  ·  "
	ticker.add_theme_font_override("font", Mats.bold_font())
	ticker.add_theme_font_size_override("font_size", 26)
	ticker.add_theme_color_override("font_color", Color.WHITE)
	var bar := ColorRect.new()
	bar.color = Color(0.8, 0.05, 0.05)
	bar.position = Vector2(0, 300)
	bar.size = Vector2(640, 44)
	vp.add_child(bar)
	ticker.position = Vector2(8, 304)
	vp.add_child(ticker)

	var screen := MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(16, 9)
	screen.mesh = q
	var sm := StandardMaterial3D.new()
	sm.albedo_texture = vp.get_texture()
	sm.emission_enabled = true
	sm.emission_texture = vp.get_texture()
	sm.emission_energy_multiplier = 1.4
	sm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	screen.material_override = sm
	screen.position = SCREEN_POS
	screen.rotation.y = PI / 2
	add_child(screen)
	deco_box(SCREEN_POS - Vector3(0.2, 0, 0), Vector3(0.3, 9.8, 16.8), _trim)
	omni(SCREEN_POS + Vector3(4, 0, 0), Color(0.7, 0.3, 0.9), 16.0, 1.5)


func _build_blimp() -> void:
	_blimp = Node3D.new()
	add_child(_blimp)
	var purple := Mats.toon(Color(0.45, 0.2, 0.55))
	deco_ball(Vector3.ZERO, 6.0, purple, Vector3(1, 1, 2.6)).reparent(_blimp, false)
	for side in [-1.0, 1.0]:
		deco_box(Vector3(side * 3, 0, 13), Vector3(5, 0.4, 4), purple).reparent(_blimp, false)
	deco_box(Vector3(0, 3, 13), Vector3(0.4, 5, 4), purple).reparent(_blimp, false)
	deco_box(Vector3(0, -6.5, 0), Vector3(3, 2, 7), Mats.toon(Color(0.2, 0.2, 0.22))).reparent(_blimp, false)
	for side in [-1.0, 1.0]:
		var l := sign_text("VON BANKRUPT", Vector3(side * 6.05, 0, 0), -side * PI / 2, 200, Color(1.0, 0.85, 0.3), 1.2)
		l.reparent(_blimp, false)


func _make_piggy(pos: Vector3) -> Node3D:
	var root := Node3D.new()
	root.position = pos
	root.rotation.y = 2.4
	add_child(root)
	var pink := Mats.toon(Color(1.0, 0.6, 0.72))
	deco_ball(Vector3(0, 0.45, 0), 0.4, pink, Vector3(1, 0.9, 1.2)).reparent(root, false)
	deco_cyl(Vector3(0, 0.45, -0.5), 0.15, 0.12, pink, Vector3(PI / 2, 0, 0)).reparent(root, false)
	for x in [-0.2, 0.2]:
		deco_box(Vector3(x, 0.8, -0.2), Vector3(0.12, 0.16, 0.06), pink).reparent(root, false)
		for z in [-0.25, 0.25]:
			deco_cyl(Vector3(x, 0.1, z), 0.07, 0.2, pink).reparent(root, false)
	deco_box(Vector3(0, 0.84, 0.05), Vector3(0.22, 0.02, 0.05), Mats.solid(Color(0.1, 0.05, 0.05))).reparent(root, false)
	return root


# ---------------------------------------------------------------- animation

func _process(delta: float) -> void:
	_t += delta
	for c in _cars:
		var n: Node3D = c.node
		if c.along_z:
			n.position.z = wrapf(n.position.z + c.speed * delta, -330.0, 170.0)
		else:
			n.position.x = wrapf(n.position.x + c.speed * delta, -240.0, 260.0)
	if _blimp:
		var a := _t * 0.03
		_blimp.position = Vector3(10 + cos(a) * 120, 95, -80 + sin(a) * 120)
		_blimp.rotation.y = -a
	for i in _beacons.size():
		_beacons[i].light_energy = 3.0 if fmod(_t + i * 0.25, 1.5) < 0.3 else 0.2


# ---------------------------------------------------------------- story

func intro() -> void:
	director.begin()
	Game.fx.set_black(true)
	player.place(Vector3(0, 24.3, 6), PI / 2)
	_steve.visible = false

	# The city at sunset.
	director.shot(Vector3(90, 80, 70), Vector3(10, 30, -60), 60.0)
	Game.fx.fade_in(2.5)
	director.move(Vector3(24, 42, 26), Vector3(-8, 30, -30), 9.0, 48.0)
	await director.wait(1.2)
	await director.say("news", "Good evening, Goldhaven. This is Channel 9 with a shocking story.")
	await director.say("news", "Overnight, every single coin in the city vanished. Every. Single. One.")
	await director.say("news", "We go live to the man responsible, who has bought ALL of our airtime.")
	await director.settle()

	# The broadcast.
	director.shot(SCREEN_POS + Vector3(16, -3, 7), SCREEN_POS, 40.0)
	director.move(SCREEN_POS + Vector3(10, -1.5, 2), SCREEN_POS, 7.0, 34.0)
	_baron.emote = "laugh"
	await director.say("baron", "Mwahahaha! Greetings, peasants! It is I, Baron Von Bankrupt!")
	_baron.emote = "point"
	await director.say("baron", "Your coins, your savings, your piggy banks. All mine! Locked in The Last Vault!")
	_baron.emote = "laugh"
	await director.say("baron", "Beyond reality itself, sealed by four Golden Vault Keys. You'll never find them!")
	_baron.emote = ""

	# Stax, on his roof.
	var sp := player.global_position
	director.shot(sp + Vector3(-3.2, 1.4, 2.2), sp + Vector3(0, 1.3, 0), 36.0)
	director.move(sp + Vector3(-2.2, 1.5, 1.4), sp + Vector3(0, 1.4, 0), 5.0)
	await director.say("stax", "Every coin? ...Even MY coins?!", "shocked")
	var t := create_tween()
	t.tween_property(_piggy, "rotation:z", 0.4, 0.1)
	t.tween_property(_piggy, "rotation:z", -0.4, 0.1)
	t.tween_property(_piggy, "rotation:z", 0.0, 0.1)
	Audio.play("pop", 0.6)
	director.shot(_piggy.global_position + Vector3(-1.2, 0.8, 1.2), _piggy.global_position + Vector3(0, 0.5, 0), 30.0)
	await director.say("stax", "Forty-seven dollars and a button. Gone.", "sad")
	director.shot(sp + Vector3(-1.4, 1.2, -1.6), sp + Vector3(0, 1.5, 0), 34.0, -0.05)
	await director.say("stax", "Okay, Baron. You just robbed the wrong kid.", "cool")

	# Steve pops up.
	_steve.visible = true
	var steve_body: Node3D = _steve.puppet
	steve_body.position.y = -3.0
	Audio.play("boing")
	director.two_shot(player, _steve, 1.0, 44.0)
	var rise := create_tween()
	rise.tween_property(steve_body, "position:y", 0.0, 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	director.face(_steve.global_position)
	director.actors["steve"] = steve_body
	await director.lines([
		["steve", "Howdy, partner! Signpost Steve, friendly tutorial sign. I go wherever I'm needed!"],
		["stax", "...Did a sign just talk to me?", "shocked"],
		["steve", "Rude. Listen: to open The Last Vault you'll need four Golden Vault Keys."],
		["steve", "The first one's on top of the Goldhaven Bank Tower. That glowing light over there!"],
		["stax", "And you're helping me because...?", "think"],
		["steve", "Because I'm a helpful sign! Totally free. Small convenience fee. Kidding! ...Mostly."],
	])
	steve_body.position.y = 0.0

	# Push in toward the tower as the title lands.
	director.shot(sp + Vector3(1.5, 2.0, 5.0), TOWER + Vector3(0, 60, 0), 50.0)
	director.move(sp + Vector3(0.5, 1.8, 2.5), TOWER + Vector3(0, 60, 0), 5.0, 42.0)
	await director.title(info.chapter, info.title, info.subtitle)
	await director.settle()
	player.place(spawn_point, spawn_yaw)
	director.end()
	bark("steve", "Talk to me with F if you want more tips! Or not. I'm a sign. I'll wait.")


func outro() -> void:
	director.begin()
	player.velocity = Vector3.ZERO
	player.speed = 0.0
	Audio.stop_music(0.3)
	Audio.play("fanfare")
	player.model.emote = "hold"
	var key_model: Node3D = goal.model
	key_model.reparent(player)
	key_model.position = Vector3(0.4, 2.6, 0)
	create_tween().tween_property(key_model, "scale", Vector3.ONE * 0.7, 0.4)
	var c := player.global_position + Vector3(0, 1.2, 0)
	director.shot(c + Vector3(0, 0.6, -4.5).rotated(Vector3.UP, player.facing), c, 40.0)
	Game.fx.flash(Color(1, 0.9, 0.6), 0.6)
	director.orbit(c, 5.0, 1.2, player.facing + PI / 2 + 0.3, player.facing + PI / 2 + 1.5, 5.0)
	await director.title("", "VAULT KEY SECURED", "Coins collected: %d" % player.coins, 1.4)
	director.actors["steve"] = _steve_top.puppet
	_steve_top.face_toward(player.global_position)
	await director.lines([
		["stax", "One key down, three to go! Baron, I'm coming for my forty-seven dollars!", "cheer"],
		["steve", "Great work! The next key is in... oh no."],
		["stax", "Oh no what?", "shocked"],
		["steve", "The Breakfast Dimension. Hope you're hungry!"],
	])
	# A portal tears open behind Stax and swallows him.
	var portal := _make_portal(player.global_position + Vector3(0, 1.8, 0) + Vector3(0, 0, 3.0).rotated(Vector3.UP, player.facing))
	Audio.play("whoosh", 0.6)
	Audio.play("rumble")
	director.shake(0.5)
	director.shot(c + Vector3(-5, 1.5, 0).rotated(Vector3.UP, player.facing), portal.global_position, 45.0)
	await director.say("stax", "The WHAT dimension?!", "shocked")
	var pull := create_tween().set_parallel()
	pull.tween_property(player, "global_position", portal.global_position - Vector3(0, 0.8, 0), 0.9).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_IN)
	pull.tween_property(player, "scale", Vector3.ONE * 0.1, 0.9).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_IN)
	await director.wait(0.8)
	Game.fx.flash(Color(1.0, 0.95, 0.8), 0.8)
	Audio.play("boom")
	await Game.fx.fade_out(0.8, Color.WHITE)
	director.end()


func _make_portal(pos: Vector3) -> Node3D:
	var root := Node3D.new()
	add_child(root)
	root.global_position = pos
	root.rotation.y = player.facing
	var ring := MeshInstance3D.new()
	var tor := TorusMesh.new()
	tor.inner_radius = 1.6
	tor.outer_radius = 1.9
	tor.rings = 32
	ring.mesh = tor
	ring.material_override = Mats.glow(Color(1.0, 0.75, 0.4), 4.0)
	ring.rotation.x = PI / 2
	root.add_child(ring)
	var disc := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 1.65
	cm.bottom_radius = 1.65
	cm.height = 0.02
	disc.mesh = cm
	var dm := StandardMaterial3D.new()
	dm.albedo_color = Color(1.0, 0.85, 0.95, 0.85)
	dm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	dm.emission_enabled = true
	dm.emission = Color(1.0, 0.6, 0.8)
	dm.emission_energy_multiplier = 3.0
	disc.material_override = dm
	disc.rotation.x = PI / 2
	root.add_child(disc)
	var light := OmniLight3D.new()
	light.light_color = Color(1.0, 0.7, 0.8)
	light.light_energy = 4.0
	light.omni_range = 10.0
	root.add_child(light)
	Fx.burst(self, pos, Color(1.0, 0.8, 0.9), 60, 8.0, 0.3, 1.2, 0.0)
	root.scale = Vector3.ONE * 0.05
	var t := create_tween()
	t.tween_property(root, "scale", Vector3.ONE, 0.6).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	t.parallel().tween_property(ring, "rotation:y", TAU * 3.0, 6.0)
	return root
