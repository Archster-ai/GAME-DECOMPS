extends "res://scripts/world/level_base.gd"
## Chapter 5: The Scribble Kingdom. A world drawn in crayon by a seven-year-old,
## floating over a giant sheet of notebook paper. Everything wobbles like a
## hand-drawn cartoon. The world draws itself into existence in the intro.
## Route: crayon house -> lollipop trees -> rainbow bridge -> cloud (ATM) ->
## paper airplanes -> pencil bridge -> vanishing eraser blocks -> castle keep.

const CRAYON_SHADER := """
shader_type spatial;
render_mode diffuse_toon, specular_toon;
uniform vec4 color : source_color = vec4(1.0);
uniform float boil = 0.03;
varying vec3 wp;
float h(vec3 p) { return fract(sin(dot(p, vec3(12.9898, 78.233, 37.719))) * 43758.5453); }
void vertex() {
	vec3 w = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	float f = floor(TIME * 8.0);
	VERTEX += (vec3(h(w + f), h(w.yzx + f), h(w.zxy + f)) - 0.5) * boil;
	wp = w;
}
void fragment() {
	vec3 n = abs((INV_VIEW_MATRIX * vec4(NORMAL, 0.0)).xyz);
	vec2 uv = n.y > 0.6 ? wp.xz : (n.x > n.z ? wp.zy : wp.xy);
	float jitter = h(vec3(floor(uv * 1.5), 1.0));
	float lines = sin((uv.x * 0.8 + uv.y) * 9.0 + jitter * 6.0);
	float stroke = smoothstep(-0.3, 0.9, lines);
	float grain = h(vec3(floor(uv * 60.0), 3.0));
	vec3 c = mix(color.rgb * 0.78, color.rgb * 1.08, stroke);
	c = mix(c, vec3(1.0, 0.98, 0.92), step(0.94, grain) * 0.25);
	ALBEDO = c;
	ROUGHNESS = 1.0;
}
"""

const OUTLINE := """
shader_type spatial;
render_mode unshaded, cull_front, shadows_disabled;
uniform float width = 0.06;
void vertex() { VERTEX += normalize(VERTEX + vec3(0.0001)) * width; }
void fragment() { ALBEDO = vec3(0.08, 0.07, 0.1); }
"""

const PAPER_SHADER := """
shader_type spatial;
render_mode unshaded;
void fragment() {
	vec2 p = UV * 400.0;
	vec3 c = vec3(0.98, 0.97, 0.93);
	float line = smoothstep(0.08, 0.0, abs(fract(p.y / 6.0) - 0.5) - 0.44);
	c = mix(c, vec3(0.55, 0.7, 0.95), line * 0.8);
	float margin = smoothstep(0.4, 0.0, abs(p.x - 150.0) - 0.3);
	c = mix(c, vec3(0.95, 0.35, 0.4), margin);
	ALBEDO = c;
}
"""

const RED := Color(0.9, 0.2, 0.2)
const ORANGE := Color(1.0, 0.55, 0.15)
const YELLOW := Color(1.0, 0.88, 0.2)
const GREEN := Color(0.35, 0.8, 0.3)
const BLUE := Color(0.25, 0.5, 0.95)
const PURPLE := Color(0.6, 0.35, 0.9)
const PINK := Color(1.0, 0.55, 0.75)
const BROWN := Color(0.55, 0.33, 0.18)
const WHITE := Color(0.98, 0.97, 0.95)
const RAINBOW := [RED, ORANGE, YELLOW, GREEN, BLUE, PURPLE]
const CASTLE := Vector3(0, 8, -160)

var _mats := {}
var _outline: ShaderMaterial
var _drawn: Array[Node3D] = []
var _erasers: Array = []     # {body, mesh, timer, gone}
var _sun: Node3D
var _t := 0.0


func _init() -> void:
	music = "crayon"
	spawn_point = Vector3(0, 0.1, 4)
	spawn_yaw = 0.0
	kill_y = -20.0


func env_config() -> Dictionary:
	return {
		"top": Color(0.45, 0.68, 1.0), "horizon": Color(1.0, 0.98, 0.9), "bottom": Color(0.95, 0.94, 0.9),
		"sun_color": Color(1.0, 0.95, 0.8), "sun_energy": 1.3, "sun_angle": Vector2(-50, -30),
		"sun_size": 0.0, "sun_glow": 0.2, "clouds": 0.4, "cloud_color": Color(1, 1, 1),
		"fog_color": Color(0.98, 0.97, 0.93), "fog_density": 0.004, "volumetric": 0.0,
		"ambient": 1.3, "exposure": 1.0, "glow": 0.4, "saturation": 1.15, "vignette": 0.3,
	}


## Crayon material for a color, with a thick marker outline.
func crayon(color: Color) -> ShaderMaterial:
	var key := str(color)
	if _mats.has(key):
		return _mats[key]
	if _outline == null:
		var osh := Shader.new()
		osh.code = OUTLINE
		_outline = ShaderMaterial.new()
		_outline.shader = osh
	var sh: Shader = _mats.get("_shader")
	if sh == null:
		sh = Shader.new()
		sh.code = CRAYON_SHADER
		_mats["_shader"] = sh
	var m := ShaderMaterial.new()
	m.shader = sh
	m.set_shader_parameter("color", color)
	m.next_pass = _outline
	_mats[key] = m
	return m


# ---------------------------------------------------------------- props

func tree(pos: Vector3, top: float, r: float, color: Color) -> void:
	deco_box(Vector3(pos.x, (pos.y + top - r) * 0.5, pos.z), Vector3(0.5, top - r - pos.y + 0.5, 0.5), crayon(BROWN))
	ball(Vector3(pos.x, top - r, pos.z), r, crayon(color))


func flower(pos: Vector3, color: Color) -> void:
	deco_box(pos + Vector3(0, 0.4, 0), Vector3(0.08, 0.8, 0.08), crayon(GREEN))
	deco_ball(pos + Vector3(0, 0.85, 0), 0.22, crayon(color))
	deco_ball(pos + Vector3(0, 0.85, -0.12), 0.1, crayon(YELLOW))


func house(pos: Vector3, color: Color) -> void:
	box(pos + Vector3(0, 2, 0), Vector3(5, 4, 5), crayon(color))
	# A triangle roof: a box turned 45 degrees and squashed.
	var roof := PrismMesh.new()
	roof.size = Vector3(6.0, 2.8, 5.6)
	deco(roof, crayon(BROWN), pos + Vector3(0, 5.4, 0))
	deco_box(pos + Vector3(0, 1.1, -2.52), Vector3(1.2, 2.2, 0.06), crayon(BROWN))
	for x in [-1.5, 1.5]:
		deco_box(pos + Vector3(x, 2.7, -2.52), Vector3(1.0, 1.0, 0.06), crayon(Color(0.6, 0.85, 1.0)))
	deco_box(pos + Vector3(1.4, 5.8, 1.0), Vector3(0.7, 1.6, 0.7), crayon(RED))


func cloud(top: Vector3, r: float) -> void:
	cylinder(top - Vector3(0, 0.5, 0), r, 1.0, crayon(WHITE), 32)
	for i in 6:
		var a := TAU * i / 6.0
		deco_ball(top + Vector3(cos(a) * r * 0.75, -0.6, sin(a) * r * 0.75), r * 0.42, crayon(WHITE), Vector3(1, 0.7, 1))
	deco_ball(top - Vector3(0, 1.0, 0), r * 0.8, crayon(WHITE), Vector3(1, 0.5, 1))


## A giant standing crayon for the skyline.
func big_crayon(pos: Vector3, h: float, color: Color) -> void:
	deco_cyl(pos + Vector3(0, h * 0.5, 0), 2.0, h, crayon(color))
	deco_cyl(pos + Vector3(0, h * 0.62, 0), 2.05, h * 0.3, crayon(color.darkened(0.25)))
	deco_cyl(pos + Vector3(0, h + 1.5, 0), 2.0, 3.0, crayon(color), Vector3.ZERO, 0.3)
	sign_text("WAXY", pos + Vector3(0, h * 0.62, -2.1), 0.0, 180, Color(0.1, 0.1, 0.1))


## A pink eraser block that rubs itself out shortly after you stand on it.
func eraser(pos: Vector3) -> void:
	var body := box(pos, Vector3(2.8, 1.2, 2.8), crayon(PINK))
	_erasers.append({"body": body, "timer": -1.0, "gone": 0.0, "pos": pos})


func paper_plane(pos: Vector3, travel: Vector3, period: float, phase: float) -> void:
	var m := mover(Vector3(3, 0.4, 4.4), crayon(WHITE), pos, travel, period, phase)
	for s in [-1.0, 1.0]:
		var wing := deco_box(Vector3(s * 1.6, 0.3, 0.4), Vector3(1.6, 0.06, 3.4), crayon(WHITE), Vector3(0, 0, -s * 0.35))
		wing.reparent(m, false)
	var nose := deco_box(Vector3(0, 0.1, -2.4), Vector3(1.2, 0.2, 1.2), crayon(WHITE), Vector3(0, PI / 4, 0))
	nose.reparent(m, false)


func sky_sun(pos: Vector3) -> void:
	_sun = Node3D.new()
	_sun.position = pos
	add_child(_sun)
	var face := deco_ball(Vector3.ZERO, 10.0, crayon(YELLOW))
	face.reparent(_sun, false)
	for i in 12:
		var a := TAU * i / 12.0
		var ray := deco_box(Vector3(cos(a) * 15.0, sin(a) * 15.0, 0), Vector3(7.0, 1.4, 1.4), crayon(ORANGE), Vector3(0, 0, a))
		ray.reparent(_sun, false)
	for x in [-3.5, 3.5]:
		deco_ball(Vector3(x, 2.5, 9.2), 1.2, crayon(Color(0.1, 0.1, 0.12))).reparent(_sun, false)
	for i in 7:
		var a := PI * (0.15 + 0.7 * i / 6.0)
		deco_box(Vector3(cos(a) * 5.0, -sin(a) * 4.5 - 1.0, 9.4), Vector3(1.6, 0.6, 0.6), crayon(RED), Vector3(0, 0, -a + PI / 2)).reparent(_sun, false)


# ---------------------------------------------------------------- build

func build() -> void:
	# The notebook page far below.
	var page := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(1200, 1200)
	page.mesh = pm
	var psh := Shader.new()
	psh.code = PAPER_SHADER
	var pmat := ShaderMaterial.new()
	pmat.shader = psh
	page.material_override = pmat
	page.position = Vector3(0, -40, -100)
	add_child(page)
	sky_sun(Vector3(70, 80, -220))
	for p in [[-60.0, -90.0, 50.0, RED], [70.0, -60.0, 40.0, BLUE], [-50.0, -200.0, 60.0, GREEN],
			[60.0, -170.0, 45.0, PURPLE], [-80.0, 10.0, 35.0, ORANGE], [30.0, -280.0, 55.0, PINK]]:
		big_crayon(Vector3(p[0], -40, p[1]), p[2], p[3])
	for i in 14:
		var a := TAU * i / 14.0
		var c := Vector3(cos(a) * 110.0, 20.0 + (i % 4) * 9.0, -100 + sin(a) * 110.0)
		for k in 3:
			deco_ball(c + Vector3(k * 4.0 - 4.0, sin(k) * 1.0, 0), 4.0 - absf(k - 1.0), crayon(WHITE), Vector3(1, 0.6, 1))

	_build_start()
	_build_trees_and_rainbow()
	_build_cloud_and_planes()
	_build_pencil_and_erasers()
	_build_castle()

	# Everything drawn gets revealed stroke by stroke in the intro.
	for c in get_children():
		if c is MeshInstance3D or c is StaticBody3D or c is AnimatableBody3D or (c is Node3D and c == _sun):
			_drawn.append(c)


func _build_start() -> void:
	cylinder(Vector3(0, -1.5, 0), 10.0, 3.0, crayon(GREEN), 32)
	deco_cyl(Vector3(0, -3.5, 0), 9.0, 1.4, crayon(BROWN), Vector3.ZERO, 6.0)
	house(Vector3(-5, 0, 2), RED)
	for i in 9:
		var a := TAU * i / 9.0 + 0.3
		flower(Vector3(cos(a) * 8.0, 0, sin(a) * 8.0), RAINBOW[i % RAINBOW.size()])
	coin_ring(Vector3(2, 1, -2), 3.0, 8)
	coin(Vector3(-5, 7.2, 2), 5)
	npc("steve", "steve", Vector3(4, 0, 1), 2.4, [
		["steve", "Welcome to the Scribble Kingdom! Everything here was drawn by a seven-year-old."],
		["stax", "It shows. That cloud has teeth.", "think"],
		["steve", "Tip: pink eraser blocks rub themselves out after you step on them. Keep moving!"],
		["steve", "And this shortcut is definitely the fastest way to the Vault. I'm VERY invested in you getting there."],
		["stax", "...Why are you so invested?", "think"],
		["steve", "Because I care! About you. And other things. Mostly you. Onward!"],
	], [["steve", "Keep moving on the erasers! Nothing lasts forever here. Except fees."]])
	npc("doodle", "doodle", Vector3(-1.5, 0, -5), 0.4, [
		["doodle", "Hi!! I'm Doodle! A kid named Timmy drew me in second grade!", "wave"],
		["stax", "Cool. Where's Timmy now?", "shrug"],
		["doodle", "He grew up. Got a job. Does taxes now. I've waited on the fridge for nineteen years!"],
		["stax", "No offense, but Timmy drew your hands like forks.", "facepalm"],
		["doodle", "They ARE forks! I can eat spaghetti with them! It's the best!", "cheer"],
		["doodle", "The key's up in Timmy's castle. He never finished the drawbridge, so... use the stairs!"],
		["doodle", "And watch out for Scribbles. That's what happened when Timmy got mad at his homework."],
	], [["doodle", "Castle's at the end! Erasers erase. That's kind of their whole thing!"]])


func _build_trees_and_rainbow() -> void:
	tip(Vector3(0, 1.5, -9), Vector3(12, 4, 3), "steve", "Hop across the lollipop trees! Round tops, so land in the middle.")
	tree(Vector3(-3, -8, -14.5), 1.6, 2.4, PINK)
	tree(Vector3(2, -8, -20.5), 3.3, 2.4, ORANGE)
	tree(Vector3(-1.5, -8, -26.5), 5.0, 2.4, PURPLE)
	coin_arc(Vector3(-1.5, 1.5, -10.5), Vector3(-3, 2.8, -14.5), 1.2, 3)
	coin_arc(Vector3(-3, 2.8, -14.5), Vector3(2, 4.5, -20.5), 1.2, 3)
	coin_arc(Vector3(2, 4.5, -20.5), Vector3(-1.5, 6.2, -26.5), 1.2, 3)

	# The rainbow bridge: one arc, drawn without lifting the crayon.
	var a := Vector3(-1.5, 5.0, -30)
	var b := Vector3(0, 5.0, -52)
	var n := 12
	var pts := []
	for i in n + 1:
		var t := float(i) / n
		pts.append(a.lerp(b, t) + Vector3(0, sin(t * PI) * 4.5, 0))
	for i in n:
		var p0: Vector3 = pts[i]
		var p1: Vector3 = pts[i + 1]
		var d := p1 - p0
		var basis := Basis.looking_at(d, Vector3.UP)
		for band in 3:
			var col: Color = RAINBOW[(i + band * 2) % RAINBOW.size()]
			var off := basis.x * (band - 1) * 1.0
			box((p0 + p1) * 0.5 - basis.y * 0.2 + off, Vector3(1.0, 0.4, d.length() + 0.3), crayon(col), basis.get_euler())
		if i % 2 == 1:
			coin(p1 + Vector3(0, 1.1, 0))
	tip(Vector3(-1.5, 7, -30), Vector3(5, 4, 3), "steve", "Rainbow bridge! Drawn in one go. Honestly impressive for a seven-year-old.")


func _build_cloud_and_planes() -> void:
	cloud(Vector3(0, 5, -59), 7.0)
	checkpoint(Vector3(-3, 5, -56), 0.0)
	enemy("scribble", Vector3(-4, 5, -61), Vector3(4, 5, -61))
	coin_ring(Vector3(2, 6, -58), 2.0, 6)
	tip(Vector3(0, 6.5, -63), Vector3(12, 4, 3), "steve", "Paper airplanes! Ride one across. They fly about as well as you'd expect.")
	paper_plane(Vector3(-2, 4.6, -68.5), Vector3(0, 0, -18), 7.0, 0.0)
	paper_plane(Vector3(3, 5.6, -68.5), Vector3(0, 0, -18), 7.0, 0.5)
	coin_line(Vector3(0.5, 7.0, -70), Vector3(0.5, 7.0, -84), 5)
	cloud(Vector3(0, 5, -92), 4.5)
	coin(Vector3(0, 6.3, -92))


func _build_pencil_and_erasers() -> void:
	# A giant pencil lying across the gap.
	var start := Vector3(0, 5, -96.5)
	var length := 26.0
	var center := start + Vector3(0, -1.0, -length * 0.5)
	box(center, Vector3(2.0, 2.0, length), crayon(YELLOW))
	var hexa := deco_cyl(center, 1.15, length, crayon(YELLOW), Vector3(PI / 2, 0, 0))
	(hexa.mesh as CylinderMesh).radial_segments = 6
	deco_cyl(start + Vector3(0, -1.0, 1.2), 1.2, 2.4, crayon(PINK), Vector3(PI / 2, 0, 0))
	deco_cyl(start + Vector3(0, -1.0, -0.1), 1.25, 0.5, crayon(Color(0.75, 0.75, 0.78)), Vector3(PI / 2, 0, 0))
	coin_line(start + Vector3(0, 1.2, -3), start + Vector3(0, 1.2, -22), 6)
	enemy("scribble", start + Vector3(0, 0, -8), start + Vector3(0, 0, -18))
	var tip_end := start + Vector3(0, -1.0, -length)
	var cone := CylinderMesh.new()
	cone.top_radius = 1.15
	cone.bottom_radius = 0.05
	cone.height = 3.0
	cone.radial_segments = 6
	deco(cone, crayon(Color(0.9, 0.75, 0.55)), tip_end + Vector3(0, 0, -1.5), Vector3(-PI / 2, 0, 0))

	# The pencil ends at a scribbled ledge, then eraser blocks over the void.
	box(Vector3(0, 3.6, -126), Vector3(5, 0.8, 4), crayon(BLUE))
	tip(Vector3(0, 5, -126), Vector3(5, 3, 4), "steve", "Eraser blocks! They rub out right after you land. Don't stop to admire them.")
	var steps := [Vector3(0, 3.4, -131), Vector3(3, 4.0, -135.5), Vector3(0, 4.6, -140), Vector3(-3, 5.2, -144.5), Vector3(0, 5.8, -149)]
	for s in steps:
		eraser(s)
		coin(s + Vector3(0, 1.6, 0))


func _build_castle() -> void:
	var c := CASTLE
	box(c + Vector3(0, -1.0, 0), Vector3(20, 2.0, 20), crayon(Color(0.7, 0.7, 0.75)))
	checkpoint(c + Vector3(-5, 0, 7), 0.0)
	enemy("scribble", c + Vector3(-7, 0, 3), c + Vector3(7, 0, 3))
	enemy("scribble", c + Vector3(6, 0, -3), c + Vector3(6, 0, -8))
	# Corner towers with pointy hats.
	for x in [-8.5, 8.5]:
		for z in [-8.5, 8.5]:
			cylinder(c + Vector3(x, 4, z), 1.8, 8.0, crayon(Color(0.75, 0.75, 0.8)), 16)
			deco_cyl(c + Vector3(x, 9.5, z), 2.2, 3.0, crayon(BLUE), Vector3.ZERO, 0.05)
	# The keep, with drawn-on stairs wrapping around it.
	var keep := c + Vector3(0, 0, -3)
	box(keep + Vector3(0, 5, 0), Vector3(8, 10, 8), crayon(Color(0.8, 0.78, 0.82)))
	for i in 4:
		deco_box(keep + Vector3(-3 + i * 2, 10.4, -3.8), Vector3(1.0, 0.8, 0.4), crayon(Color(0.8, 0.78, 0.82)))
	deco_box(keep + Vector3(0, 4, -4.03), Vector3(1.6, 2.4, 0.06), crayon(Color(0.1, 0.1, 0.12)))
	var stair := [Vector3(5.5, 1.3, 2), Vector3(5.5, 2.6, -1), Vector3(5.5, 3.9, -4), Vector3(3, 5.2, -6),
		Vector3(0, 6.5, -6), Vector3(-3, 7.8, -6), Vector3(-5.5, 9.1, -4), Vector3(-5.5, 10.0, -1)]
	for i in stair.size():
		var s: Vector3 = stair[i]
		box(keep + s - Vector3(0, 0.3, 0), Vector3(2.6, 0.6, 2.6), crayon(RAINBOW[i % RAINBOW.size()]))
		coin(keep + s + Vector3(0, 1.1, 0))
	place_goal(keep + Vector3(0, 10, 0))
	# A flag on top.
	deco_box(keep + Vector3(3, 12.5, 3), Vector3(0.15, 5, 0.15), crayon(BROWN))
	deco_box(keep + Vector3(3.9, 14.2, 3), Vector3(1.8, 1.2, 0.08), crayon(RED))
	sign_text("TIMMY'S\nCASTLE\nKEEP OUT", keep + Vector3(0, 7, -4.05), 0.0, 90, Color(0.15, 0.1, 0.4))
	tip(c + Vector3(0, 1.5, 7), Vector3(20, 4, 4), "steve", "Timmy's castle! Take the stairs to the top. The key is waiting. So am I. In spirit.")
	coin(c + Vector3(8.5, 9.2, 8.5), 5)


# ---------------------------------------------------------------- mechanics

func _physics_process(delta: float) -> void:
	super(delta)
	for e in _erasers:
		var body: StaticBody3D = e.body
		if e.gone > 0.0:
			e.gone -= delta
			if e.gone <= 0.0:
				body.collision_layer = 1
				body.visible = true
				create_tween().tween_property(body, "scale", Vector3.ONE, 0.3).from(Vector3.ONE * 0.1)
			continue
		if e.timer < 0.0:
			var p := player.global_position
			var local: Vector3 = p - body.global_position
			if player.is_on_floor() and absf(local.x) < 1.6 and absf(local.z) < 1.6 and local.y > 0.4 and local.y < 1.2:
				e.timer = 0.55
				Audio.play("dive", 1.6, 0.1, -6.0)
		else:
			e.timer -= delta
			body.scale = Vector3.ONE * (1.0 - 0.1 * sin(e.timer * 40.0) * 0.5)
			if e.timer <= 0.0:
				e.timer = -1.0
				e.gone = 2.5
				body.collision_layer = 0
				body.visible = false
				body.scale = Vector3.ONE
				Fx.burst(self, body.global_position, PINK, 20, 4.0, 0.3, 0.6, -8.0, "cube")


func _process(delta: float) -> void:
	_t += delta
	if _sun:
		_sun.look_at(player.global_position if player else Vector3.ZERO, Vector3.UP)
		_sun.rotate_object_local(Vector3.UP, PI)


# ---------------------------------------------------------------- story

func intro() -> void:
	director.begin()
	Game.fx.set_black(true)
	player.place(Vector3(0, 30, 4), 0.0)
	player.visible = false
	player.set_physics_process(false)
	for d in _drawn:
		d.scale = Vector3.ONE * 0.01
	# A blank page. Then the world gets drawn in, stroke by stroke.
	director.shot(Vector3(24, 14, 24), Vector3(0, 2, -60), 55.0)
	Game.fx.fade_in(1.0)
	await director.say("narrator", "Once upon a time, a seven-year-old named Timmy had a box of crayons...")
	director.move(Vector3(-18, 10, -30), Vector3(0, 4, -110), 5.0, 50.0)
	var order := _drawn.duplicate()
	order.sort_custom(func(a, b): return a.global_position.z > b.global_position.z)
	var step := 3.2 / maxf(order.size(), 1)
	for i in order.size():
		if director.skipping:
			break
		var n: Node3D = order[i]
		create_tween().tween_property(n, "scale", Vector3.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		if i % 6 == 0:
			Audio.play("pop", 1.2, 0.2, -10.0)
		await director.wait(step)
	for d in _drawn:
		d.scale = Vector3.ONE
	await director.settle()
	await director.say("narrator", "...and absolutely no idea how gravity works.")

	# Stax falls out of a scribbled hole in the sky.
	player.visible = true
	player.set_physics_process(true)
	director.shot(Vector3(6, 3, 12), Vector3(0, 6, 3), 50.0)
	Audio.play("whoosh", 1.3)
	var land := 0.0
	while player.global_position.y > 0.5 and land < 4.0 and not director.skipping:
		land += await director._frame()
	player.place(spawn_point, spawn_yaw)
	director.shake(0.3)
	var sp := player.global_position
	director.shot(sp + Vector3(-2.4, 1.5, -2.8), sp + Vector3(0, 1.3, 0), 36.0)
	await director.say("stax", "Why is everything... wobbly? Am I wobbly? Is my HOODIE wobbly?", "shocked")
	director.shot(Vector3(10, 6, 14), Vector3(0, 2, -8), 45.0)
	director.move(Vector3(4, 5, 10), Vector3(0, 3, -20), 4.0, 42.0)
	await director.title(info.chapter, info.title, info.subtitle)
	await director.settle()
	player.place(spawn_point, spawn_yaw)
	director.end()


func outro_lines() -> Array:
	return [
		["stax", "Wait. That's FIVE keys. You said the Vault needed four!", "shocked"],
		["steve", "Did I? Turns out it has six locks. I'm a sign, not a calculator."],
		["stax", "Where's number six?", "facepalm"],
		["steve", "The Rubber Duck Desert. Bring sunscreen. And maybe a sword. No reason."],
	]
