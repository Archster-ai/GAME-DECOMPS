extends Node3D
## Base class for every chapter. Sets up lighting, sky and post-processing
## from `env_config()`, calls `build()` to make the geometry, spawns Stax,
## the camera, the HUD and the cutscene director, then plays `intro()`.
## Touching the Vault Key plays `outro()` and moves on to the next chapter.

const PlayerScript := preload("res://scripts/actors/player.gd")
const CameraRigScript := preload("res://scripts/actors/camera_rig.gd")
const DirectorScript := preload("res://scripts/cinema/director.gd")
const HudScript := preload("res://scripts/ui/hud.gd")
const PickupScript := preload("res://scripts/world/pickup.gd")
const HazardScript := preload("res://scripts/world/hazard.gd")
const MoverScript := preload("res://scripts/world/mover.gd")
const BouncerScript := preload("res://scripts/world/bouncer.gd")
const ZoneScript := preload("res://scripts/world/zone.gd")
const TriggerScript := preload("res://scripts/world/trigger.gd")
const CheckpointScript := preload("res://scripts/world/checkpoint.gd")
const KeyScript := preload("res://scripts/world/key_goal.gd")
const NpcScript := preload("res://scripts/world/npc.gd")
const EnemyScript := preload("res://scripts/world/enemy.gd")
const Puppet := preload("res://scripts/actors/puppet.gd")
const Mats := preload("res://scripts/world/mats.gd")
const Fx := preload("res://scripts/world/fx.gd")

const SKY_SHADER := """
shader_type sky;
uniform vec3 top_color : source_color = vec3(0.2, 0.4, 0.9);
uniform vec3 horizon_color : source_color = vec3(0.8, 0.85, 1.0);
uniform vec3 bottom_color : source_color = vec3(0.3, 0.35, 0.4);
uniform vec3 sun_color : source_color = vec3(1.0, 0.9, 0.7);
uniform float sun_size = 1.0;
uniform float sun_glow = 0.5;
uniform float stars = 0.0;
uniform float nebula = 0.0;
uniform vec3 nebula_a : source_color = vec3(0.6, 0.2, 0.8);
uniform vec3 nebula_b : source_color = vec3(0.1, 0.5, 0.9);
uniform float clouds = 0.0;
uniform vec3 cloud_color : source_color = vec3(1.0);
uniform float energy = 1.0;

float hash(vec3 p) {
	p = fract(p * 0.3183099 + 0.1);
	p *= 17.0;
	return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}
float noise(vec3 x) {
	vec3 i = floor(x);
	vec3 f = fract(x);
	f = f * f * (3.0 - 2.0 * f);
	return mix(mix(mix(hash(i), hash(i + vec3(1, 0, 0)), f.x),
			mix(hash(i + vec3(0, 1, 0)), hash(i + vec3(1, 1, 0)), f.x), f.y),
		mix(mix(hash(i + vec3(0, 0, 1)), hash(i + vec3(1, 0, 1)), f.x),
			mix(hash(i + vec3(0, 1, 1)), hash(i + vec3(1, 1, 1)), f.x), f.y), f.z);
}
float fbm(vec3 p) {
	float v = 0.0;
	float a = 0.5;
	for (int i = 0; i < 5; i++) {
		v += a * noise(p);
		p *= 2.03;
		a *= 0.5;
	}
	return v;
}
void sky() {
	vec3 d = EYEDIR;
	float h = d.y;
	vec3 col = h >= 0.0
		? mix(horizon_color, top_color, pow(clamp(h, 0.0, 1.0), 0.45))
		: mix(horizon_color, bottom_color, pow(clamp(-h, 0.0, 1.0), 0.35));
	if (LIGHT0_ENABLED) {
		float s = max(dot(d, LIGHT0_DIRECTION), 0.0);
		float disc = smoothstep(0.9992 - 0.0008 * sun_size, 0.9997, s);
		col += sun_color * (disc * 16.0 + pow(s, 64.0) * 0.6 + pow(s, 6.0) * sun_glow * 0.35);
	}
	if (nebula > 0.0) {
		float n = fbm(d * 2.5);
		float n2 = fbm(d * 5.0 + 4.0);
		col += mix(nebula_a, nebula_b, n2) * pow(n, 2.2) * nebula * 2.2;
	}
	if (stars > 0.0) {
		vec3 p = d * 200.0;
		float st = hash(floor(p));
		col += vec3(step(0.997, st) * (0.4 + 0.6 * hash(floor(p) + 3.0))) * stars * smoothstep(-0.2, 0.15, h);
	}
	if (clouds > 0.0 && h > 0.0) {
		vec2 uv = d.xz / (h + 0.12);
		float c = fbm(vec3(uv * 1.2, 1.7));
		c = smoothstep(0.48, 0.78, c) * clouds * smoothstep(0.0, 0.2, h);
		col = mix(col, cloud_color * (0.75 + 0.5 * c), c);
	}
	COLOR = col * energy;
}
"""

var level_index := 0
var info := {}
var spawn_point := Vector3(0, 1, 0)
var spawn_yaw := 0.0
var kill_y := -30.0
var music := "rooftops"
var player: CharacterBody3D
var rig: Node3D
var hud: CanvasLayer
var director: Node3D
var goal: Area3D
var complete := false
var env: Environment
var sun: DirectionalLight3D
var sky_mat: ShaderMaterial


func _ready() -> void:
	level_index = maxi(Game.current_level, 0)
	info = Game.level_info(level_index)
	_setup_environment(env_config())
	build()
	_spawn()
	_run.call_deferred()


# ---------------------------------------------------------------- overridables

## Keys: top, horizon, bottom (sky colors), sun_color, sun_energy,
## sun_angle (Vector2 pitch/yaw degrees), ambient, fog_color, fog_density,
## volumetric (density), vol_color, player_light (fill light on Stax), stars, nebula, nebula_a, nebula_b,
## clouds, cloud_color, exposure, glow, tint, saturation, vignette, ssr.
func env_config() -> Dictionary:
	return {}


func build() -> void:
	pass


## The opening cutscene. The default flies in over the spawn point.
func intro() -> void:
	director.begin()
	Game.fx.set_black(true)
	var s := spawn_point
	director.shot(s + Vector3(14, 10, 14), s + Vector3(0, 1, 0), 55.0)
	Game.fx.fade_in(1.2)
	director.move(s + Vector3(-3, 2.5, 5), s + Vector3(0, 1.2, 0), 4.0, 45.0)
	await director.title(info.chapter, info.title, info.subtitle)
	await director.settle()
	director.end()


## Extra lines after the key is collected, before the chapter ends.
func outro_lines() -> Array:
	return [["stax", "Key secured. Money: incoming.", "cheer"]]


# ---------------------------------------------------------------- flow

func _run() -> void:
	Audio.play_music(music)
	hud.set_chapter("%s  ·  %s" % [info.chapter, info.title])
	await intro()
	_start_play()


func _start_play() -> void:
	player.frozen = false


func is_cinematic() -> bool:
	return director != null and director.active


func _spawn() -> void:
	player = PlayerScript.new()
	player.add_to_group("player")
	add_child(player)
	player.place(spawn_point, spawn_yaw)
	player.spawn_point = spawn_point
	player.spawn_facing = spawn_yaw
	player.kill_y = kill_y
	player.frozen = true
	player.double_jump = Game.has_double_jump
	# Dim chapters give Stax a soft fill light so he never turns into a silhouette.
	var fill: float = env_config().get("player_light", 0.0)
	if fill > 0.0:
		var l := OmniLight3D.new()
		l.position = Vector3(0, 2.6, 2.2)
		l.light_color = Color(1.0, 0.95, 0.85)
		l.light_energy = fill
		l.omni_range = 5.0
		l.light_specular = 0.2
		player.add_child(l)

	rig = CameraRigScript.new()
	rig.target = player
	add_child(rig)
	rig.snap_behind()
	player.camera_rig = rig

	hud = HudScript.new()
	add_child(hud)
	hud.set_coins(0)
	hud.set_health(player.hp)
	player.coins_changed.connect(hud.set_coins)
	player.health_changed.connect(hud.set_health)

	director = DirectorScript.new()
	director.level = self
	director.player = player
	director.hud = hud
	add_child(director)
	rig.make_current()


func _physics_process(_delta: float) -> void:
	if director == null or director.active or complete or player.frozen:
		return
	var best: Node3D = null
	var best_d := 1e9
	for n in get_tree().get_nodes_in_group("npcs"):
		var d: float = n.global_position.distance_to(player.global_position)
		if d < n.talk_radius and d < best_d:
			best = n
			best_d = d
	if best:
		hud.prompt("[F]  Talk to %s" % best.display_name)
		if Input.is_action_just_pressed("talk"):
			hud.prompt("")
			_talk(best)
	else:
		hud.prompt("")


func _talk(npc: Node3D) -> void:
	await director.conversation(npc, npc.next_lines())
	on_talked(npc)


## Called after a conversation ends.
func on_talked(_npc: Node3D) -> void:
	pass


func _on_goal() -> void:
	if complete:
		return
	complete = true
	await outro()
	Game.complete_level(player.coins)


## Default ending: Stax raises the key, fanfare, orbit, fade.
func outro() -> void:
	director.begin()
	player.velocity = Vector3.ZERO
	player.speed = 0.0
	Audio.stop_music(0.3)
	Audio.play("fanfare")
	player.model.emote = "hold"
	var key_model: Node3D = goal.model
	key_model.reparent(player)
	key_model.position = Vector3(0.4, 2.6, 0)
	var t := create_tween()
	t.tween_property(key_model, "scale", Vector3.ONE * 0.7, 0.4)
	var c := player.global_position + Vector3(0, 1.2, 0)
	director.shot(c + Vector3(0, 0.8, -4.5).rotated(Vector3.UP, player.facing), c, 40.0)
	Game.fx.flash(Color(1, 0.9, 0.6), 0.6)
	director.orbit(c, 5.0, 1.0, player.facing + PI / 2 + 0.4, player.facing + PI / 2 + 1.4, 5.0)
	await director.title("", "VAULT KEY SECURED", "Coins collected: %d" % player.coins, 1.6)
	await director.lines(outro_lines())
	await Game.fx.fade_out(1.0)
	director.end()
	Game.fx.close_dialogue()


## Call the moment a boss is defeated (see player.safe).
func boss_beaten() -> void:
	if player:
		player.safe = true


func bark(speaker: String, text: String) -> void:
	hud.bark(speaker, text)


# ---------------------------------------------------------------- environment

func _setup_environment(c: Dictionary) -> void:
	var q: int = Game.settings.quality
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sh := Shader.new()
	sh.code = SKY_SHADER
	sky_mat = ShaderMaterial.new()
	sky_mat.shader = sh
	sky_mat.set_shader_parameter("top_color", c.get("top", Color(0.2, 0.4, 0.9)))
	sky_mat.set_shader_parameter("horizon_color", c.get("horizon", Color(0.8, 0.85, 1.0)))
	sky_mat.set_shader_parameter("bottom_color", c.get("bottom", Color(0.3, 0.35, 0.4)))
	sky_mat.set_shader_parameter("sun_color", c.get("sun_color", Color(1, 0.9, 0.7)))
	sky_mat.set_shader_parameter("sun_size", c.get("sun_size", 1.0))
	sky_mat.set_shader_parameter("sun_glow", c.get("sun_glow", 0.6))
	sky_mat.set_shader_parameter("stars", c.get("stars", 0.0))
	sky_mat.set_shader_parameter("nebula", c.get("nebula", 0.0))
	sky_mat.set_shader_parameter("nebula_a", c.get("nebula_a", Color(0.6, 0.2, 0.8)))
	sky_mat.set_shader_parameter("nebula_b", c.get("nebula_b", Color(0.1, 0.5, 0.9)))
	sky_mat.set_shader_parameter("clouds", c.get("clouds", 0.0))
	sky_mat.set_shader_parameter("cloud_color", c.get("cloud_color", Color.WHITE))
	sky_mat.set_shader_parameter("energy", c.get("sky_energy", 1.0))
	sky.sky_material = sky_mat
	sky.radiance_size = Sky.RADIANCE_SIZE_128
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = c.get("ambient", 1.0)
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.tonemap_exposure = c.get("exposure", 1.0)
	env.tonemap_white = 6.0
	env.glow_enabled = true
	env.glow_intensity = c.get("glow", 0.8)
	env.glow_strength = 1.0
	env.glow_bloom = 0.06
	env.glow_hdr_threshold = 0.9
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SOFTLIGHT
	env.set_glow_level(0, 0.0)
	env.set_glow_level(2, 1.0)
	env.set_glow_level(4, 0.8)
	env.set_glow_level(6, 0.4)
	env.fog_enabled = c.get("fog_density", 0.004) > 0.0
	env.fog_light_color = c.get("fog_color", Color(0.7, 0.8, 1.0))
	env.fog_density = c.get("fog_density", 0.004)
	env.fog_aerial_perspective = 0.4
	env.fog_sky_affect = c.get("fog_sky", 0.25)
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.06
	env.adjustment_saturation = c.get("env_saturation", 1.1)
	if q >= 1:
		env.ssao_enabled = true
		env.ssao_radius = 1.4
		env.ssao_intensity = 1.8
		env.ssao_detail = 0.6
		var vol: float = c.get("volumetric", 0.01)
		if vol > 0.0:
			env.volumetric_fog_enabled = true
			env.volumetric_fog_density = vol
			env.volumetric_fog_albedo = c.get("vol_color", Color(1, 1, 1))
			env.volumetric_fog_emission = c.get("vol_emission", Color(0, 0, 0))
			env.volumetric_fog_anisotropy = 0.55
			env.volumetric_fog_length = 90.0
			env.volumetric_fog_sky_affect = 0.0
	if q >= 2:
		env.ssil_enabled = true
		env.sdfgi_enabled = c.get("sdfgi", true)
		env.sdfgi_use_occlusion = true
		env.ssr_enabled = c.get("ssr", false)
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	sun = DirectionalLight3D.new()
	var ang: Vector2 = c.get("sun_angle", Vector2(-45, 30))
	sun.rotation = Vector3(deg_to_rad(ang.x), deg_to_rad(ang.y), 0)
	sun.light_color = c.get("sun_color", Color(1, 0.95, 0.85))
	sun.light_energy = c.get("sun_energy", 1.3)
	sun.shadow_enabled = true
	sun.shadow_blur = 1.5
	sun.directional_shadow_max_distance = 110.0 if q >= 1 else 60.0
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS if q >= 1 else DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.light_volumetric_fog_energy = c.get("sun_fog", 1.0)
	add_child(sun)
	Game.fx.set_grade(c.get("tint", Color.WHITE), c.get("saturation", 1.08), c.get("vignette", 0.38))


# ---------------------------------------------------------------- builders

func box(pos: Vector3, size: Vector3, mat: Material, rot := Vector3.ZERO) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = pos
	body.rotation = rot
	var mi := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.material_override = mat
	body.add_child(mi)
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	cs.shape = shape
	body.add_child(cs)
	add_child(body)
	return body


func cylinder(pos: Vector3, radius: float, height: float, mat: Material, segments := 24, top := -1.0) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = pos
	var mi := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius if top < 0.0 else top
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = segments
	mi.mesh = mesh
	mi.material_override = mat
	body.add_child(mi)
	var cs := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = maxf(radius, top)
	shape.height = height
	cs.shape = shape
	body.add_child(cs)
	add_child(body)
	return body


## Mesh with no collision.
func deco(mesh: Mesh, mat: Material, pos: Vector3, rot := Vector3.ZERO, scl := Vector3.ONE, parent: Node = null) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	mi.scale = scl
	(parent if parent else self).add_child(mi)
	return mi


func deco_box(pos: Vector3, size: Vector3, mat: Material, rot := Vector3.ZERO) -> MeshInstance3D:
	var b := BoxMesh.new()
	b.size = size
	return deco(b, mat, pos, rot)


func deco_ball(pos: Vector3, radius: float, mat: Material, squish := Vector3.ONE) -> MeshInstance3D:
	var s := SphereMesh.new()
	s.radius = radius
	s.height = radius * 2.0
	s.radial_segments = 24
	s.rings = 12
	return deco(s, mat, pos, Vector3.ZERO, squish)


func deco_cyl(pos: Vector3, radius: float, height: float, mat: Material, rot := Vector3.ZERO, top := -1.0) -> MeshInstance3D:
	var c := CylinderMesh.new()
	c.bottom_radius = radius
	c.top_radius = radius if top < 0.0 else top
	c.height = height
	c.radial_segments = 20
	return deco(c, mat, pos, rot)


## Solid sphere with collision.
func ball(pos: Vector3, radius: float, mat: Material, squish := Vector3.ONE) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = pos
	body.scale = squish
	var mi := MeshInstance3D.new()
	var s := SphereMesh.new()
	s.radius = radius
	s.height = radius * 2.0
	s.radial_segments = 28
	s.rings = 14
	mi.mesh = s
	mi.material_override = mat
	body.add_child(mi)
	var cs := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = radius
	cs.shape = shape
	body.add_child(cs)
	add_child(body)
	return body


func coin(pos: Vector3, value := 1) -> void:
	var p := PickupScript.new()
	p.value = value
	p.position = pos
	add_child(p)


func coin_line(from: Vector3, to: Vector3, count: int) -> void:
	for i in count:
		coin(from.lerp(to, float(i) / maxf(count - 1, 1)))


func coin_ring(center: Vector3, radius: float, count := 8) -> void:
	for i in count:
		var a := TAU * i / count
		coin(center + Vector3(cos(a) * radius, 0, sin(a) * radius))


func coin_arc(from: Vector3, to: Vector3, height: float, count: int) -> void:
	for i in count:
		var t := float(i) / maxf(count - 1, 1)
		coin(from.lerp(to, t) + Vector3(0, sin(t * PI) * height, 0))


func checkpoint(pos: Vector3, yaw := 0.0) -> Area3D:
	var c := CheckpointScript.new()
	c.position = pos
	c.rotation.y = yaw
	add_child(c)
	return c


func place_goal(pos: Vector3) -> Area3D:
	goal = KeyScript.new()
	goal.position = pos
	add_child(goal)
	goal.collected.connect(_on_goal)
	return goal


func npc(kind: String, speaker: String, pos: Vector3, yaw: float, lines: Array, repeat: Array = []) -> Node3D:
	var n := NpcScript.new()
	n.kind = kind
	n.speaker = speaker
	n.lines = lines
	n.repeat_lines = repeat
	n.position = pos
	n.rotation.y = yaw
	add_child(n)
	return n


func enemy(kind: String, a: Vector3, b: Vector3, hover := 0.0) -> Node3D:
	var e := EnemyScript.new()
	e.kind = kind
	e.a = a
	e.b = b
	e.hover = hover
	add_child(e)
	return e


func mover(size: Vector3, mat: Material, pos: Vector3, travel: Vector3, period := 4.0, phase := 0.0, spin := 0.0, kind := "box") -> AnimatableBody3D:
	var m := MoverScript.new()
	m.size = size
	m.material = mat
	m.position = pos
	m.travel = travel
	m.period = period
	m.phase = phase
	m.spin = spin
	m.shape_kind = kind
	add_child(m)
	return m


func hazard_box(pos: Vector3, size: Vector3, mat: Material, spin := 0.0, bob := Vector3.ZERO, bob_speed := 1.0, bob_phase := 0.0) -> Area3D:
	var h := HazardScript.new()
	h.position = pos
	h.spin_speed = spin
	h.bob_axis = bob
	h.bob_speed = bob_speed
	h.bob_phase = bob_phase
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	cs.shape = shape
	h.add_child(cs)
	var mi := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.material_override = mat
	h.add_child(mi)
	add_child(h)
	return h


func bouncer(pos: Vector3, radius: float, strength: float, visual: Node3D) -> Area3D:
	var b := BouncerScript.new()
	b.position = pos
	b.strength = strength
	var cs := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = radius
	shape.height = 0.8
	cs.shape = shape
	cs.position.y = 0.3
	b.add_child(cs)
	b.add_child(visual)
	b.visual = visual
	add_child(b)
	return b


func zone(pos: Vector3, size: Vector3, mode: String) -> Area3D:
	var z := ZoneScript.new()
	z.position = pos
	z.mode = mode
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	cs.shape = shape
	z.add_child(cs)
	add_child(z)
	return z


func trigger(pos: Vector3, size: Vector3, fn: Callable, once := true) -> Area3D:
	var t := TriggerScript.new()
	t.position = pos
	t.on_enter = fn
	t.once = once
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	cs.shape = shape
	t.add_child(cs)
	add_child(t)
	return t


## A one-shot radio line when Stax walks into the box.
func tip(pos: Vector3, size: Vector3, speaker: String, text: String) -> void:
	trigger(pos, size, func(_p): bark(speaker, text))


func omni(pos: Vector3, color: Color, reach := 8.0, energy := 1.5, shadows := false) -> OmniLight3D:
	var l := OmniLight3D.new()
	l.position = pos
	l.light_color = color
	l.omni_range = reach
	l.light_energy = energy
	l.shadow_enabled = shadows and Game.settings.quality >= 2
	add_child(l)
	return l


func spot(pos: Vector3, look: Vector3, color: Color, reach := 20.0, angle := 30.0, energy := 3.0) -> SpotLight3D:
	var l := SpotLight3D.new()
	add_child(l)
	l.look_at_from_position(pos, look, Vector3.UP if absf((look - pos).normalized().y) < 0.99 else Vector3.FORWARD)
	l.light_color = color
	l.spot_range = reach
	l.spot_angle = angle
	l.light_energy = energy
	l.shadow_enabled = Game.settings.quality >= 1
	return l


## Billboard-free 3D text, e.g. neon signs. Faces -Z at yaw 0.
func sign_text(text: String, pos: Vector3, yaw: float, size := 96, color := Color.WHITE, glow := 0.0) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.font = Mats.bold_font()
	l.font_size = size
	l.pixel_size = 0.01
	l.modulate = color * (1.0 + glow) if glow > 0.0 else color
	l.outline_size = 0
	l.position = pos
	l.rotation.y = yaw + PI
	l.shaded = glow <= 0.0
	add_child(l)
	return l


## A big solid dollar sign, `height` units tall, facing -Z at yaw 0.
func dollar(pos: Vector3, yaw: float, height: float, mat: Material, depth := 1.0) -> MeshInstance3D:
	return deco(Mats.dollar_mesh(), mat, pos, Vector3(0, yaw + PI, 0), Vector3(height, height, height * depth))
