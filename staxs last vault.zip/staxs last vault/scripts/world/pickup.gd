extends Node3D
## Coins. A normal coin is worth 1, a big coin 5. Coins drift toward Stax
## when he gets close, then burst into sparkles.

const Mats := preload("res://scripts/world/mats.gd")
const Fx := preload("res://scripts/world/fx.gd")

static var _coin_mesh: CylinderMesh

var value := 1
var _player: Node3D
var _base_y := 0.0
var _t := 0.0
var _pull := false
var _spin: Node3D


func _ready() -> void:
	add_to_group("coins")
	_t = position.x * 0.3 + position.z * 0.2
	_base_y = position.y
	if _coin_mesh == null:
		_coin_mesh = CylinderMesh.new()
		_coin_mesh.top_radius = 0.42
		_coin_mesh.bottom_radius = 0.42
		_coin_mesh.height = 0.1
		_coin_mesh.radial_segments = 16
		_coin_mesh.rings = 1
	_spin = Node3D.new()
	add_child(_spin)
	var disc := MeshInstance3D.new()
	disc.mesh = _coin_mesh
	disc.material_override = Mats.gold()
	disc.rotation.x = PI / 2
	_spin.add_child(disc)
	var g := MeshInstance3D.new()
	g.mesh = Mats.dollar_mesh()
	g.material_override = Mats.solid(Color(0.85, 0.5, 0.08), 0.3, 1.0)
	g.scale = Vector3(0.55, 0.55, 1.1)
	g.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_spin.add_child(g)
	if value > 1:
		_spin.scale = Vector3.ONE * 2.0
		var light := OmniLight3D.new()
		light.light_color = Color(1.0, 0.8, 0.3)
		light.omni_range = 5.0
		light.light_energy = 1.5
		add_child(light)


func _physics_process(delta: float) -> void:
	_t += delta
	_spin.rotation.y += delta * (3.0 if not _pull else 12.0)
	if _player == null:
		_player = get_tree().get_first_node_in_group("player")
		if _player == null:
			return
	var target := _player.global_position + Vector3(0, 0.8, 0)
	var d := global_position.distance_to(target)
	if d < 2.6 and not _player.dead:
		_pull = true
	if _pull:
		global_position = global_position.move_toward(target, delta * maxf(14.0, 30.0 - d * 6.0))
		if global_position.distance_to(target) < 0.6:
			_collect()
	else:
		position.y = _base_y + sin(_t * 2.5) * 0.12


func _collect() -> void:
	_player.add_coin(value)
	Fx.burst(get_parent(), global_position, Color(1.0, 0.85, 0.3), 10 if value == 1 else 30, 4.0, 0.22, 0.5, -4.0)
	if value > 1:
		Audio.play("checkpoint", 1.5, 0.0, -4.0)
	queue_free()
