extends Area3D
## An invisible volume that affects Stax while he is inside.
## mode: push (conveyors, wind), gravity (low-gravity), hurt, kill.

var mode := "push"
var push := Vector3.ZERO
var gravity_scale := 0.4
var floor_only := true
var _inside: Array[Node3D] = []


func _ready() -> void:
	body_entered.connect(func(b):
		if b.is_in_group("player"):
			_inside.append(b)
			if mode == "gravity":
				b.gravity_scale = gravity_scale
			elif mode == "kill":
				b.die())
	body_exited.connect(func(b):
		_inside.erase(b)
		if mode == "gravity" and b.is_in_group("player"):
			b.gravity_scale = 1.0)


func _physics_process(_delta: float) -> void:
	for b in _inside:
		if not is_instance_valid(b):
			continue
		match mode:
			"push":
				if not floor_only or b.is_on_floor():
					b.push += push
			"hurt":
				b.take_damage(1, global_position)
