extends Area3D
## A bounce pad. Landing on it launches Stax upward.

var strength := 24.0
var visual: Node3D
var _squash := 1.0


func _ready() -> void:
	body_entered.connect(_on_body)


func _on_body(body: Node3D) -> void:
	if body.has_method("bounce") and body.velocity.y <= 0.5:
		body.bounce(strength)
		_squash = 0.5
		Audio.play("boing", 1.0, 0.08)


func _process(delta: float) -> void:
	_squash = lerpf(_squash, 1.0, 10.0 * delta)
	if visual:
		visual.scale = Vector3(1.0 / sqrt(_squash), _squash, 1.0 / sqrt(_squash))
