extends Area3D
## The Golden Vault Key at the end of each chapter, with a light beacon.

const Mats := preload("res://scripts/world/mats.gd")
const Fx := preload("res://scripts/world/fx.gd")

signal collected

var model: Node3D
var _t := 0.0
var _taken := false


func _ready() -> void:
	var shape := CollisionShape3D.new()
	var s := SphereShape3D.new()
	s.radius = 1.6
	shape.shape = s
	shape.position.y = 1.5
	add_child(shape)

	model = Node3D.new()
	model.position.y = 1.6
	add_child(model)
	var ring := MeshInstance3D.new()
	var tor := TorusMesh.new()
	tor.inner_radius = 0.35
	tor.outer_radius = 0.6
	tor.rings = 24
	tor.ring_segments = 10
	ring.mesh = tor
	ring.material_override = Mats.gold()
	ring.rotation.x = PI / 2
	ring.position.y = 0.8
	model.add_child(ring)
	_bar(Vector3(0.22, 1.9, 0.18), Vector3(0, -0.4, 0))
	_bar(Vector3(0.5, 0.2, 0.18), Vector3(0.3, -1.1, 0))
	_bar(Vector3(0.36, 0.2, 0.18), Vector3(0.24, -0.75, 0))
	var glyph := MeshInstance3D.new()
	glyph.mesh = Mats.dollar_mesh()
	glyph.scale = Vector3.ONE * 0.6
	glyph.material_override = Mats.glow(Color(1.0, 0.95, 0.7), 3.0)
	glyph.position.y = 0.8
	model.add_child(glyph)

	var light := OmniLight3D.new()
	light.light_color = Color(1.0, 0.8, 0.35)
	light.light_energy = 3.0
	light.omni_range = 10.0
	light.position.y = 1.6
	add_child(light)

	# A tall soft beam so the goal can be spotted from anywhere.
	var beam := MeshInstance3D.new()
	var c := CylinderMesh.new()
	c.top_radius = 1.2
	c.bottom_radius = 0.6
	c.height = 80.0
	c.cap_top = false
	c.cap_bottom = false
	beam.mesh = c
	var bm := StandardMaterial3D.new()
	bm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	bm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	bm.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	bm.cull_mode = BaseMaterial3D.CULL_DISABLED
	bm.albedo_color = Color(1.0, 0.75, 0.3, 0.12)
	beam.material_override = bm
	beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	beam.position.y = 40.0
	add_child(beam)
	Fx.ambient(self, Vector3(0, 2, 0), Vector3(1.2, 1.5, 1.2), Color(1.0, 0.85, 0.4), 40, 0.15, Vector3(0, 1.2, 0), 2.0)
	body_entered.connect(_on_body)


func _bar(size: Vector3, pos: Vector3) -> void:
	var mi := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = size
	mi.mesh = b
	mi.material_override = Mats.gold()
	mi.position = pos
	model.add_child(mi)


func _process(delta: float) -> void:
	_t += delta
	if not _taken:
		model.rotation.y += delta * 1.5
		model.position.y = 1.6 + sin(_t * 2.0) * 0.2


func _on_body(b: Node3D) -> void:
	if _taken or not b.is_in_group("player") or b.dead:
		return
	_taken = true
	collected.emit()
