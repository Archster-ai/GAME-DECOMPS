extends Node3D
## A character Stax can talk to. The level shows a prompt when he is close.

const Puppet := preload("res://scripts/actors/puppet.gd")

var kind := "steve"
var tint := Color(1.0, 0.3, 0.8)   # only used by "raver"
var speaker := "steve"
var display_name := ""
## Lines for the first talk and for every talk after.
var lines: Array = []
var repeat_lines: Array = []
var talk_radius := 3.5
var talked := false
var puppet: Node3D
var _face_yaw := 0.0


func _ready() -> void:
	add_to_group("npcs")
	puppet = Puppet.new()
	puppet.kind = kind
	puppet.speaker = speaker
	puppet.tint = tint
	add_child(puppet)
	_face_yaw = rotation.y
	if display_name == "":
		display_name = Voice.info(speaker).name


func next_lines() -> Array:
	var l := lines if not talked or repeat_lines.is_empty() else repeat_lines
	talked = true
	return l


func face_toward(p: Vector3) -> void:
	var d := p - global_position
	_face_yaw = atan2(-d.x, -d.z)


func _process(delta: float) -> void:
	rotation.y = lerp_angle(rotation.y, _face_yaw, 4.0 * delta)
