extends RefCounted
## Shared material, texture and font factory. Everything is procedural.

static var _cache := {}
static var _outline: ShaderMaterial
static var _font: Font
static var _dollar: ArrayMesh

const OUTLINE_SHADER := """
shader_type spatial;
render_mode unshaded, cull_front, depth_draw_opaque, shadows_disabled;
uniform vec4 color : source_color = vec4(0.06, 0.035, 0.02, 1.0);
uniform float width = 0.02;
void vertex() {
	VERTEX += normalize(VERTEX + vec3(0.0001)) * width;
}
void fragment() {
	ALBEDO = color.rgb;
}
"""


static func solid(color: Color, rough := 0.7, metal := 0.0) -> StandardMaterial3D:
	var key := "s%s%.2f%.2f" % [color, rough, metal]
	if _cache.has(key):
		return _cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	m.metallic = metal
	_cache[key] = m
	return m


## Cartoon material with a dark inverted-hull outline, used on characters.
static func toon(color: Color, rough := 0.75, rim := 0.25) -> StandardMaterial3D:
	var key := "t%s%.2f%.2f" % [color, rough, rim]
	if _cache.has(key):
		return _cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	if rim > 0.0:
		m.rim_enabled = true
		m.rim = rim
		m.rim_tint = 0.4
	m.next_pass = outline()
	_cache[key] = m
	return m


static func outline() -> ShaderMaterial:
	if _outline == null:
		var sh := Shader.new()
		sh.code = OUTLINE_SHADER
		_outline = ShaderMaterial.new()
		_outline.shader = sh
	return _outline


static func glow(color: Color, energy := 2.0) -> StandardMaterial3D:
	var key := "g%s%.2f" % [color, energy]
	if _cache.has(key):
		return _cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.emission_enabled = true
	m.emission = color
	m.emission_energy_multiplier = energy
	_cache[key] = m
	return m


static func unshaded(color: Color, alpha := 1.0) -> StandardMaterial3D:
	var key := "u%s%.2f" % [color, alpha]
	if _cache.has(key):
		return _cache[key]
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = Color(color, alpha)
	if alpha < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_cache[key] = m
	return m


static func gold() -> StandardMaterial3D:
	if _cache.has("gold"):
		return _cache.gold
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(1.0, 0.76, 0.22)
	m.metallic = 1.0
	m.roughness = 0.22
	m.emission_enabled = true
	m.emission = Color(0.55, 0.35, 0.05)
	m.emission_energy_multiplier = 0.6
	_cache.gold = m
	return m


static func glass(color: Color, alpha := 0.35) -> StandardMaterial3D:
	var key := "gl%s%.2f" % [color, alpha]
	if _cache.has(key):
		return _cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(color, alpha)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.roughness = 0.05
	m.metallic = 0.3
	_cache[key] = m
	return m


## Triplanar noise-textured surface with a matching normal map.
static func rough_surface(a: Color, b: Color, scale := 0.25, rough := 0.85, seed := 1, bump := 0.6) -> StandardMaterial3D:
	var key := "r%s%s%.2f%.2f%d%.2f" % [a, b, scale, rough, seed, bump]
	if _cache.has(key):
		return _cache[key]
	var noise := FastNoiseLite.new()
	noise.seed = seed
	noise.frequency = 0.02
	noise.fractal_octaves = 4
	var grad := Gradient.new()
	grad.set_color(0, a)
	grad.set_color(1, b)
	var tex := NoiseTexture2D.new()
	tex.width = 256
	tex.height = 256
	tex.seamless = true
	tex.noise = noise
	tex.color_ramp = grad
	var nrm := NoiseTexture2D.new()
	nrm.width = 256
	nrm.height = 256
	nrm.seamless = true
	nrm.as_normal_map = true
	nrm.bump_strength = 4.0
	nrm.noise = noise
	var m := StandardMaterial3D.new()
	m.albedo_texture = tex
	m.normal_enabled = bump > 0.0
	m.normal_texture = nrm
	m.normal_scale = bump
	m.roughness = rough
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	m.uv1_scale = Vector3.ONE * scale
	_cache[key] = m
	return m


## Image-based patterns. kind: checker, stripes, bricks, tiles, windows, carpet, grid.
static func pattern(kind: String, colors: Array, scale := 0.5, rough := 0.8, emissive := false, seed := 7, energy := 1.6) -> StandardMaterial3D:
	var key := "p%s%s%.2f%.2f%s%d%.2f" % [kind, str(colors), scale, rough, emissive, seed, energy]
	if _cache.has(key):
		return _cache[key]
	var img := pattern_image(kind, colors, seed)
	var tex := ImageTexture.create_from_image(img)
	var m := StandardMaterial3D.new()
	m.albedo_texture = tex
	m.roughness = rough
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	m.uv1_scale = Vector3.ONE * scale
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	if emissive:
		m.emission_enabled = true
		m.emission_texture = tex
		m.emission_energy_multiplier = energy
	_cache[key] = m
	return m


static func pattern_image(kind: String, colors: Array, seed := 7) -> Image:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed
	var size := 64
	var img := Image.create(size, size, true, Image.FORMAT_RGBA8)
	var c0: Color = colors[0]
	var c1: Color = colors[1 % colors.size()]
	var c2: Color = colors[2 % colors.size()]
	for y in size:
		for x in size:
			var c := c0
			match kind:
				"checker":
					c = c0 if (int(x / 32.0) + int(y / 32.0)) % 2 == 0 else c1
				"stripes":
					c = c0 if int(x / 8.0) % 2 == 0 else c1
				"bricks":
					var row := int(y / 8.0)
					var off := 8 if row % 2 == 0 else 0
					var mortar := y % 8 == 0 or (x + off) % 16 == 0
					c = c1 if mortar else c0.lerp(c2, float((row * 7 + int((x + off) / 16.0) * 3) % 5) / 8.0)
				"tiles":
					c = c1 if x % 16 == 0 or y % 16 == 0 else c0
				"grid":
					c = c1 if x % 32 < 2 or y % 32 < 2 else c0
				"carpet":
					var n := float((x * 13 + y * 7 + (x * y) % 11) % 17) / 17.0
					c = c0.lerp(c1, n * 0.5)
				"windows":
					var cell_x := x % 16
					var cell_y := y % 16
					if cell_x < 3 or cell_x > 12 or cell_y < 3 or cell_y > 13:
						c = c0
					else:
						c = c1
			img.set_pixel(x, y, c)
	if kind == "windows":
		# Randomly light some windows.
		for cy in 4:
			for cx in 4:
				var lit := rng.randf() < 0.45
				var col: Color = c2 if lit else c1
				for y in range(cy * 16 + 3, cy * 16 + 14):
					for x in range(cx * 16 + 3, cx * 16 + 13):
						img.set_pixel(x, y, col)
	img.generate_mipmaps()
	return img


## Chunky display font for logos and signs, with safe fallbacks.
static func bold_font() -> Font:
	if _font == null:
		var f := SystemFont.new()
		f.font_names = PackedStringArray(["Arial Black", "Impact", "Montserrat Black", "DejaVu Sans", "Liberation Sans", "sans-serif"])
		f.font_weight = 900
		_font = f
	return _font


static func text_mesh(text: String, size := 64, depth := 0.05, pixel := 0.01) -> TextMesh:
	var t := TextMesh.new()
	t.text = text
	t.font = bold_font()
	t.font_size = size
	t.depth = depth
	t.pixel_size = pixel
	return t


## A solid "$" built from an extruded stroke, 1 unit tall, facing +Z.
## (Font glyphs are not used because many fonts' "$" outlines self-intersect.)
static func dollar_mesh() -> ArrayMesh:
	if _dollar:
		return _dollar
	var s_path := PackedVector2Array()
	var r := 0.2
	for i in 15:
		var a := deg_to_rad(lerpf(25.0, 270.0, i / 14.0))
		s_path.append(Vector2(0, r) + Vector2(cos(a), sin(a)) * r)
	for i in range(1, 15):
		var a := deg_to_rad(lerpf(90.0, -155.0, i / 14.0))
		s_path.append(Vector2(0, -r) + Vector2(cos(a), sin(a)) * r)
	var bar := PackedVector2Array([Vector2(0, -0.52), Vector2(0, 0.52)])
	_dollar = stroke_mesh([s_path, bar], 0.12, 0.12)
	return _dollar


## Extrudes 2D polylines into solid strokes (rectangular cross-section).
static func stroke_mesh(paths: Array, width: float, depth: float) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var zf := depth * 0.5
	var zb := -depth * 0.5
	for path in paths:
		var n: int = path.size()
		var left := []
		var right := []
		var norms := []
		for i in n:
			var t: Vector2 = (path[mini(i + 1, n - 1)] - path[maxi(i - 1, 0)]).normalized()
			var nn := Vector2(-t.y, t.x)
			left.append(path[i] + nn * width * 0.5)
			right.append(path[i] - nn * width * 0.5)
			norms.append(nn)
		for i in n - 1:
			var nl := Vector3(norms[i].x, norms[i].y, 0)
			_quad(st, _v(left[i], zf), _v(left[i + 1], zf), _v(right[i + 1], zf), _v(right[i], zf), Vector3.BACK)
			_quad(st, _v(right[i], zb), _v(right[i + 1], zb), _v(left[i + 1], zb), _v(left[i], zb), Vector3.FORWARD)
			_quad(st, _v(left[i], zb), _v(left[i + 1], zb), _v(left[i + 1], zf), _v(left[i], zf), nl)
			_quad(st, _v(right[i], zf), _v(right[i + 1], zf), _v(right[i + 1], zb), _v(right[i], zb), -nl)
		var t_end: Vector2 = (path[n - 1] - path[n - 2]).normalized()
		var t0: Vector2 = (path[1] - path[0]).normalized()
		_quad(st, _v(left[n - 1], zf), _v(left[n - 1], zb), _v(right[n - 1], zb), _v(right[n - 1], zf), Vector3(t_end.x, t_end.y, 0))
		_quad(st, _v(right[0], zf), _v(right[0], zb), _v(left[0], zb), _v(left[0], zf), Vector3(-t0.x, -t0.y, 0))
	return st.commit()


static func _v(p: Vector2, z: float) -> Vector3:
	return Vector3(p.x, p.y, z)


static func _quad(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, d: Vector3, normal: Vector3) -> void:
	for v in [a, b, c, a, c, d]:
		st.set_normal(normal)
		st.add_vertex(v)
