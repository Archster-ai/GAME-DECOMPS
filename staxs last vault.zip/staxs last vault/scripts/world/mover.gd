extends AnimatableBody3D
## A moving and/or spinning platform. Stax rides it automatically.
## Set `size`, `material`, `travel` (offset from start), `period`, `spin`.

var size := Vector3(4, 0.6, 4)
var material: Material
var travel := Vector3.ZERO
var period := 4.0
var phase := 0.0
var spin := 0.0
var shape_kind := "box"   # box | cylinder
var _origin := Vector3.ZERO
var _t := 0.0


func _ready() -> void:
	sync_to_physics = true
	_origin = position
	_t = phase * period
	var mi := MeshInstance3D.new()
	var cs := CollisionShape3D.new()
	if shape_kind == "cylinder":
		var m := CylinderMesh.new()
		m.top_radius = size.x * 0.5
		m.bottom_radius = size.x * 0.5
		m.height = size.y
		m.radial_segments = 24
		mi.mesh = m
		var s := CylinderShape3D.new()
		s.radius = size.x * 0.5
		s.height = size.y
		cs.shape = s
	else:
		var m := BoxMesh.new()
		m.size = size
		mi.mesh = m
		var s := BoxShape3D.new()
		s.size = size
		cs.shape = s
	mi.material_override = material
	add_child(mi)
	add_child(cs)


func _physics_process(delta: float) -> void:
	_t += delta
	if travel != Vector3.ZERO:
		var k := 0.5 - 0.5 * cos(_t / period * TAU)
		position = _origin + travel * k
	if spin != 0.0:
		rotation.y += spin * delta
