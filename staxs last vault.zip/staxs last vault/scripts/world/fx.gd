extends RefCounted
## One-shot and ambient particle effects.

const Mats := preload("res://scripts/world/mats.gd")


static func _draw_mesh(color: Color, size: float, shape := "quad") -> Mesh:
	var mesh: PrimitiveMesh
	if shape == "cube":
		var b := BoxMesh.new()
		b.size = Vector3.ONE * size
		mesh = b
	elif shape == "coin":
		var c := CylinderMesh.new()
		c.top_radius = size
		c.bottom_radius = size
		c.height = size * 0.25
		c.radial_segments = 12
		c.rings = 1
		mesh = c
	else:
		var q := QuadMesh.new()
		q.size = Vector2.ONE * size
		mesh = q
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	if shape == "quad":
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.vertex_color_use_as_albedo = true
		m.albedo_texture = _soft_dot()
	elif shape == "coin":
		m = Mats.gold()
	else:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = 1.5
	mesh.material = m
	return mesh


static var _dot: ImageTexture

static func _soft_dot() -> ImageTexture:
	if _dot:
		return _dot
	var img := Image.create(32, 32, false, Image.FORMAT_RGBA8)
	for y in 32:
		for x in 32:
			var d := Vector2(x - 15.5, y - 15.5).length() / 16.0
			var a := clampf(1.0 - d, 0.0, 1.0)
			img.set_pixel(x, y, Color(1, 1, 1, a * a))
	_dot = ImageTexture.create_from_image(img)
	return _dot


## Spawns a one-shot burst at `pos` in `parent`'s space; it frees itself.
static func burst(parent: Node, pos: Vector3, color: Color, amount := 16, speed := 5.0,
		size := 0.25, life := 0.7, gravity := -9.0, shape := "quad") -> GPUParticles3D:
	if parent == null or not parent.is_inside_tree():
		return null
	var p := GPUParticles3D.new()
	p.one_shot = true
	p.amount = amount
	p.lifetime = life
	p.explosiveness = 0.95
	var pm := ParticleProcessMaterial.new()
	pm.direction = Vector3.UP
	pm.spread = 180.0
	pm.initial_velocity_min = speed * 0.5
	pm.initial_velocity_max = speed
	pm.gravity = Vector3(0, gravity, 0)
	pm.damping_min = 1.0
	pm.damping_max = 3.0
	pm.scale_min = 0.6
	pm.scale_max = 1.2
	var curve := Curve.new()
	curve.add_point(Vector2(0, 1))
	curve.add_point(Vector2(1, 0))
	var ct := CurveTexture.new()
	ct.curve = curve
	pm.scale_curve = ct
	pm.color = color
	if shape != "quad":
		pm.angular_velocity_min = -360.0
		pm.angular_velocity_max = 360.0
		pm.particle_flag_rotate_y = true
	p.process_material = pm
	p.draw_pass_1 = _draw_mesh(color, size, shape)
	parent.add_child(p)
	p.global_position = pos
	p.emitting = true
	p.finished.connect(p.queue_free)
	return p


## Endless ambient particles filling a box (dust motes, sparkles, crumbs).
static func ambient(parent: Node, center: Vector3, extents: Vector3, color: Color, amount := 120,
		size := 0.12, velocity := Vector3(0, 0.3, 0), life := 6.0) -> GPUParticles3D:
	var p := GPUParticles3D.new()
	p.amount = amount
	p.lifetime = life
	p.preprocess = life
	p.visibility_aabb = AABB(-extents * 1.2, extents * 2.4)
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = extents
	pm.direction = velocity.normalized() if velocity.length() > 0.0 else Vector3.UP
	pm.spread = 30.0
	pm.initial_velocity_min = velocity.length() * 0.5
	pm.initial_velocity_max = velocity.length()
	pm.gravity = Vector3.ZERO
	pm.turbulence_enabled = true
	pm.turbulence_noise_strength = 0.4
	pm.turbulence_noise_scale = 4.0
	var curve := Curve.new()
	curve.add_point(Vector2(0, 0))
	curve.add_point(Vector2(0.2, 1))
	curve.add_point(Vector2(0.8, 1))
	curve.add_point(Vector2(1, 0))
	var ct := CurveTexture.new()
	ct.curve = curve
	pm.scale_curve = ct
	pm.color = color
	p.process_material = pm
	p.draw_pass_1 = _draw_mesh(color, size)
	p.position = center
	parent.add_child(p)
	return p
