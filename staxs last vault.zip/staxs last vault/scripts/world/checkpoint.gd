extends Area3D
## A golden ATM. Touch it to save your spot and refill health.

const Mats := preload("res://scripts/world/mats.gd")
const Fx := preload("res://scripts/world/fx.gd")

signal activated

var yaw := 0.0
var active := false
var _screen: MeshInstance3D
var _label: Label3D
var _light: OmniLight3D


func _ready() -> void:
	add_to_group("checkpoints")
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(2.6, 3, 2.6)
	shape.shape = box
	shape.position.y = 1.5
	add_child(shape)

	var body := StaticBody3D.new()
	add_child(body)
	var col := CollisionShape3D.new()
	var cbox := BoxShape3D.new()
	cbox.size = Vector3(1.1, 2.0, 0.8)
	col.shape = cbox
	col.position = Vector3(0, 1.0, 0.3)
	body.add_child(col)

	_part(Vector3(1.1, 2.0, 0.8), Mats.solid(Color(0.2, 0.25, 0.32), 0.35, 0.7), Vector3(0, 1.0, 0.3))
	_part(Vector3(1.16, 0.18, 0.86), Mats.gold(), Vector3(0, 2.05, 0.3))
	_part(Vector3(0.9, 0.08, 0.3), Mats.solid(Color(0.1, 0.1, 0.12), 0.5), Vector3(0, 0.95, -0.12))
	_screen = _part(Vector3(0.8, 0.5, 0.04), Mats.glow(Color(0.2, 0.5, 1.0), 1.5), Vector3(0, 1.5, -0.1))
	_label = Label3D.new()
	_label.text = "INSERT\nSTAX"
	_label.font = Mats.bold_font()
	_label.font_size = 40
	_label.pixel_size = 0.004
	_label.position = Vector3(0, 1.5, -0.13)
	_label.rotation.y = PI
	_label.modulate = Color(0.85, 0.95, 1.0)
	add_child(_label)
	var top := Label3D.new()
	top.text = "ATM"
	top.font = Mats.bold_font()
	top.font_size = 56
	top.pixel_size = 0.005
	top.position = Vector3(0, 2.05, -0.14)
	top.rotation.y = PI
	top.modulate = Color(0.3, 0.2, 0.05)
	add_child(top)
	_light = OmniLight3D.new()
	_light.position = Vector3(0, 1.6, -0.8)
	_light.light_color = Color(0.3, 0.55, 1.0)
	_light.omni_range = 4.0
	add_child(_light)
	body_entered.connect(_on_body)


func _part(size: Vector3, mat: Material, pos: Vector3) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var m := BoxMesh.new()
	m.size = size
	mi.mesh = m
	mi.material_override = mat
	mi.position = pos
	add_child(mi)
	return mi


func _on_body(b: Node3D) -> void:
	if not b.is_in_group("player"):
		return
	b.heal_full()
	b.spawn_point = global_position + Vector3(0, 0.5, 0) + global_transform.basis.z * -2.0
	b.spawn_facing = rotation.y
	if active:
		return
	for c in get_tree().get_nodes_in_group("checkpoints"):
		if c != self:
			c.active = false
	active = true
	_screen.material_override = Mats.glow(Color(0.2, 1.0, 0.4), 2.0)
	_label.text = "$ $ $\nSAVED"
	_light.light_color = Color(0.3, 1.0, 0.45)
	Audio.play("checkpoint")
	Fx.burst(get_parent(), global_position + Vector3(0, 2.2, 0), Color(0.4, 1.0, 0.5), 30, 6.0, 0.25, 0.8, -6.0)
	activated.emit()
