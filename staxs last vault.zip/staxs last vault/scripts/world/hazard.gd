extends Area3D
## Damages the player on touch. Can spin around Y (a rotating bar) and/or
## bob back and forth along an axis (a stamp, a piston).

var damage := 1
var spin_speed := 0.0
var bob_axis := Vector3.ZERO
var bob_speed := 1.0
var bob_phase := 0.0
var _origin := Vector3.ZERO
var _t := 0.0


func _ready() -> void:
	_origin = position
	_t = bob_phase
	body_entered.connect(_on_body_entered)


func _physics_process(delta: float) -> void:
	_t += delta
	if spin_speed != 0.0:
		rotation.y += spin_speed * delta
	if bob_axis != Vector3.ZERO:
		# Slam quickly, rise slowly: a sharp stamp motion.
		var s := fmod(_t * bob_speed, 1.0)
		var k := 1.0 - pow(1.0 - s / 0.25, 3.0) if s < 0.25 else 1.0 - (s - 0.25) / 0.75
		position = _origin + bob_axis * k
	for body in get_overlapping_bodies():
		_on_body_entered(body)


func _on_body_entered(body: Node3D) -> void:
	if body.has_method("take_damage"):
		body.take_damage(damage, global_position)
