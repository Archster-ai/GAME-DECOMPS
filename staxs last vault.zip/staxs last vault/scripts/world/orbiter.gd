extends AnimatableBody3D
## A platform that circles `center` at `radius`, turning to keep facing out
## like a car on a carousel. Stax rides it automatically. Add the collision
## shape and meshes as children.

var center := Vector3.ZERO
var radius := 5.0
var speed := 0.5          # radians per second
var angle := 0.0


func _ready() -> void:
	sync_to_physics = true
	_place()
	# The ring it sweeps, for tests/reachability.gd.
	var r := radius + 2.0
	set_meta("sweep", AABB(center + Vector3(-r, 0.3, -r), Vector3(r * 2.0, 0.0, r * 2.0)))


func _physics_process(delta: float) -> void:
	angle += speed * delta
	_place()


## One transform write: with sync_to_physics, setting position and then
## rotation separately would send the old position along with the rotation.
func _place() -> void:
	transform = Transform3D(Basis(Vector3.UP, angle), center + Vector3(sin(angle), 0, cos(angle)) * radius)
