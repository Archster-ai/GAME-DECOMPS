extends Area3D
## Calls `on_enter` (with the player) when Stax walks in. One-shot by default.

var on_enter: Callable
var once := true
var _fired := false


func _ready() -> void:
	body_entered.connect(func(b):
		if not b.is_in_group("player") or (once and _fired):
			return
		_fired = true
		if on_enter.is_valid():
			on_enter.call(b))
