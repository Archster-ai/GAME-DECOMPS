extends Node3D
## A simple enemy that patrols between `a` and `b` (world positions) and
## chases Stax along that line when he is near. Stomp it, dive into it or
## ground-pound it; touching it from the side hurts.

const Puppet := preload("res://scripts/actors/puppet.gd")
const Fx := preload("res://scripts/world/fx.gd")

signal defeated

var kind := "toast"
var a := Vector3.ZERO
var b := Vector3.ZERO
var speed := 2.5
var chase_speed := 4.5
var radius := 0.6
var height := 1.4
var hover := 0.0
var puppet: Node3D
var dead := false
var _t := 0.0
var _dir := 1.0
var _player: Node3D


func _ready() -> void:
	add_to_group("enemies")
	puppet = Puppet.new()
	puppet.kind = kind
	add_child(puppet)
	global_position = a
	_t = randf()


func _physics_process(delta: float) -> void:
	if dead:
		return
	if _player == null:
		_player = get_tree().get_first_node_in_group("player")
		if _player == null:
			return
	var seg := b - a
	var seg_len := maxf(seg.length(), 0.01)
	var along := (global_position - a).dot(seg) / seg_len
	var target_along := along
	var pp := _player.global_position
	var near: bool = pp.distance_to(global_position) < 8.0 and absf(pp.y - global_position.y) < 3.0 and not _player.frozen
	if near:
		target_along = clampf((pp - a).dot(seg) / seg_len, 0.0, seg_len)
		along = move_toward(along, target_along, chase_speed * delta)
	else:
		along += _dir * speed * delta
		if along >= seg_len:
			along = seg_len
			_dir = -1.0
		elif along <= 0.0:
			along = 0.0
			_dir = 1.0
	var prev := global_position
	global_position = a + seg / seg_len * along + Vector3(0, hover, 0)
	var moved := global_position - prev
	moved.y = 0
	if moved.length() > 0.001:
		rotation.y = lerp_angle(rotation.y, atan2(-moved.x, -moved.z), 10.0 * delta)
	elif near:
		var d := pp - global_position
		rotation.y = lerp_angle(rotation.y, atan2(-d.x, -d.z), 6.0 * delta)
	_check_player()


func _check_player() -> void:
	if _player.dead or _player.frozen:
		return
	var pp: Vector3 = _player.global_position
	var flat := Vector2(pp.x - global_position.x, pp.z - global_position.z).length()
	var top := global_position.y + height
	if flat > radius + 0.5:
		return
	if pp.y > top - 0.5 and pp.y < top + 0.8 and _player.velocity.y <= 0.0:
		_player.bounce(13.0)
		defeat()
	elif pp.y < top and pp.y + 1.5 > global_position.y:
		if _player.is_attacking():
			defeat()
		else:
			_player.take_damage(1, global_position)


func defeat() -> void:
	if dead:
		return
	dead = true
	Audio.play("stomp")
	Audio.play("pop", 0.8)
	Fx.burst(get_parent(), global_position + Vector3(0, 0.6, 0), Color(1, 1, 1, 0.8), 20, 5.0, 0.4, 0.6, -2.0)
	Fx.burst(get_parent(), global_position + Vector3(0, 0.8, 0), Color(1, 0.85, 0.3), 8, 6.0, 0.18, 0.8, -12.0, "coin")
	_player.add_coin(3)
	defeated.emit()
	var t := create_tween()
	t.tween_property(puppet, "scale", Vector3(1.6, 0.1, 1.6), 0.12)
	t.tween_property(puppet, "scale", Vector3.ZERO, 0.2)
	t.tween_callback(queue_free)
