extends Node3D
## A closed rollercoaster loop with a train riding it. The track is a circle
## around `center` with a few gentle hills, `base_y` above the ground. The
## train's cars are moving platforms (Stax rides them), each with low solid
## side walls so a bad landing doesn't send him over the edge.
##
## Positions along the track are measured in metres of arc length `s`.

const Mats := preload("res://scripts/world/mats.gd")

var center := Vector3.ZERO
var radius := 55.0
var base_y := 38.0
var hill_amp := 4.5
var hills := 3
var car_len := 12.0
var car_gap := 0.6
var car_count := 3
var car_width := 8.0
var speed := 9.0
var head_s := 0.0
var cars: Array[AnimatableBody3D] = []


func _ready() -> void:
	_build_track()
	var colors := [Color(0.95, 0.25, 0.35), Color(1.0, 0.8, 0.2), Color(0.3, 0.55, 1.0)]
	for i in car_count:
		var car := AnimatableBody3D.new()
		car.sync_to_physics = true
		_car_shape(car, Vector3(car_width, 0.7, car_len), Vector3(0, -0.35, 0))
		for side in [-1.0, 1.0]:
			_car_shape(car, Vector3(0.3, 1.0, car_len), Vector3(side * (car_width * 0.5 - 0.15), 0.5, 0))
		var body_mat := Mats.toon(colors[i % colors.size()], 0.5, 0.3)
		_car_mesh(car, Vector3(car_width, 0.5, car_len), Vector3(0, -0.45, 0), body_mat)
		_car_mesh(car, Vector3(car_width - 1.0, 0.8, car_len - 1.0), Vector3(0, -1.1, 0), Mats.solid(Color(0.2, 0.2, 0.25), 0.5, 0.6))
		for side in [-1.0, 1.0]:
			_car_mesh(car, Vector3(0.3, 1.0, car_len), Vector3(side * (car_width * 0.5 - 0.15), 0.5, 0), body_mat)
			_car_mesh(car, Vector3(0.4, 0.15, car_len + 0.2), Vector3(side * (car_width * 0.5 - 0.15), 1.05, 0), Mats.gold())
		# Seat benches, low enough to hop over.
		for z in [-3.6, 0.0, 3.6]:
			_car_mesh(car, Vector3(car_width - 2.6, 0.35, 1.2), Vector3(0, 0.18, z), Mats.toon(Color(0.98, 0.95, 0.9), 0.7, 0.2))
		# Fairy lights along the walls.
		for k in 5:
			for side in [-1.0, 1.0]:
				var bulb := MeshInstance3D.new()
				var sm := SphereMesh.new()
				sm.radius = 0.15
				sm.height = 0.3
				bulb.mesh = sm
				bulb.material_override = Mats.glow(Color.from_hsv((i * 5 + k) * 0.11, 0.6, 1.0), 3.0)
				bulb.position = Vector3(side * (car_width * 0.5 - 0.15), 1.25, -car_len * 0.5 + 1.2 + k * 2.4)
				car.add_child(bulb)
		if i == 0:
			# A big cartoon nose on the front car.
			var nose := MeshInstance3D.new()
			var cm := CylinderMesh.new()
			cm.top_radius = 0.0
			cm.bottom_radius = car_width * 0.45
			cm.height = 3.5
			nose.mesh = cm
			nose.material_override = body_mat
			nose.rotation.x = -PI / 2
			nose.position = Vector3(0, -0.5, -car_len * 0.5 - 1.7)
			car.add_child(nose)
		add_child(car)
		cars.append(car)
	_place_cars()


func _car_shape(car: AnimatableBody3D, size: Vector3, pos: Vector3) -> void:
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	cs.shape = shape
	cs.position = pos
	car.add_child(cs)


func _car_mesh(car: Node3D, size: Vector3, pos: Vector3, mat: Material) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	car.add_child(mi)


# ---------------------------------------------------------------- the path

func track_length() -> float:
	return TAU * radius


func pos_at(s: float) -> Vector3:
	var a := s / radius
	return Vector3(center.x + sin(a) * radius, base_y + hill_amp * sin(hills * a), center.z - cos(a) * radius)


## Unit vector along the track (with the slope of the hills).
func tangent_at(s: float) -> Vector3:
	var a := s / radius
	return Vector3(radius * cos(a), hill_amp * hills * cos(hills * a), radius * sin(a)).normalized()


## Horizontal unit vector pointing away from the middle of the loop.
func out_at(s: float) -> Vector3:
	var a := s / radius
	return Vector3(sin(a), 0, -cos(a))


func xf_at(s: float) -> Transform3D:
	return Transform3D(Basis.looking_at(tangent_at(s), Vector3.UP), pos_at(s))


## Where car `i` is (or will be, `ahead` seconds from now).
func car_xf(i: int, ahead := 0.0) -> Transform3D:
	return xf_at(head_s + speed * ahead - i * (car_len + car_gap))


## The car whose middle is nearest to a world position.
func nearest_car(p: Vector3) -> int:
	var best := 0
	var bd := 1e9
	for i in cars.size():
		var d := cars[i].global_position.distance_to(p)
		if d < bd:
			bd = d
			best = i
	return best


func _physics_process(delta: float) -> void:
	head_s += speed * delta
	_place_cars()


func _place_cars() -> void:
	for i in cars.size():
		cars[i].transform = car_xf(i)


# ---------------------------------------------------------------- the track

func _build_track() -> void:
	var rail := Mats.solid(Color(0.85, 0.87, 0.92), 0.25, 0.9)
	var wood := Mats.toon(Color(0.55, 0.32, 0.2), 0.8, 0.1)
	var post := Mats.toon(Color(0.95, 0.3, 0.4), 0.7, 0.2)
	var step := 3.0
	var n := int(track_length() / step)
	for i in n:
		var s := i * step
		var xf := xf_at(s)
		var sleeper := MeshInstance3D.new()
		var sb := BoxMesh.new()
		sb.size = Vector3(car_width + 1.0, 0.3, 0.7)
		sleeper.mesh = sb
		sleeper.material_override = wood
		sleeper.transform = Transform3D(xf.basis, xf.origin - xf.basis.y * 1.2)
		add_child(sleeper)
		for side in [-1.0, 1.0]:
			var r := MeshInstance3D.new()
			var rb := BoxMesh.new()
			rb.size = Vector3(0.35, 0.35, step + 0.2)
			r.mesh = rb
			r.material_override = rail
			r.transform = Transform3D(xf.basis, xf.origin - xf.basis.y * 0.95 + xf.basis.x * side * (car_width * 0.5 - 0.6))
			add_child(r)
		if i % 4 == 0:
			var p := MeshInstance3D.new()
			var cm := CylinderMesh.new()
			var h := xf.origin.y - 1.4
			cm.top_radius = 0.45
			cm.bottom_radius = 0.7
			cm.height = h
			p.mesh = cm
			p.material_override = post
			p.position = Vector3(xf.origin.x, h * 0.5, xf.origin.z)
			add_child(p)
