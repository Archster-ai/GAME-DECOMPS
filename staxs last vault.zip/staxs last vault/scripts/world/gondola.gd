extends AnimatableBody3D
## A Ferris wheel car: rides a vertical circle around `center` (the wheel's axle
## runs along X) and stays level, like a real gondola. Stax rides it
## automatically. Add the collision shape and meshes as children.

var center := Vector3.ZERO
var radius := 11.0
var speed := 0.35         # radians per second
var angle := 0.0          # 0 = top of the wheel
## For tests/reachability.gd: it treats this as a lift from the bottom to the top.
var travel := Vector3.ZERO


func _ready() -> void:
	sync_to_physics = true
	travel = Vector3(0, radius * 2.0, 0)
	_place()
	set_meta("sweep", AABB(center + Vector3(-2.0, -radius, -radius - 2.0), Vector3(4.0, radius * 2.0, radius * 2.0 + 4.0)))


func _physics_process(delta: float) -> void:
	angle += speed * delta
	_place()


func _place() -> void:
	transform = Transform3D(Basis(), center + Vector3(0, cos(angle) * radius, sin(angle) * radius))
