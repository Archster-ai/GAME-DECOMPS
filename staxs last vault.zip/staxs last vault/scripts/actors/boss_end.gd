extends Node3D
## THE END: the title card that has closed every chapter, come to life as six
## giant letters. Every letter is one hit, and its name shrinks as you erase
## it: THE END -> THE EN -> THE E -> THE -> TH -> T.
## Phase 1 (the page): the golden underline sweeps the floor (jump it), the
## letters rain tiny words (dodge the rings), and the last letter of its name
## leaps and slams into the floor. Stuck letters can be stomped or pounded.
## Phase 2 (after "THE" rips the floor into a slide): the letters chase Stax
## down the slide throwing words, then finish the fight at the bottom.

signal hit(hp: int)
signal defeated
signal name_changed(text: String)
signal phase_two
signal final_phase

const Mats := preload("res://scripts/world/mats.gd")
const Fx := preload("res://scripts/world/fx.gd")

const WORD := "THE END"
const MAX_HP := 6
const LETTER_H := 3.4        # roughly how tall a glyph is

enum B { WAIT, UNDERLINE, RAIN, STAMP, STUCK, RECOVER, RIPPING, SLIDE, DEAD,
	FINAL_WAIT, F_TYPE, F_BACKSPACE, F_SWEEP, F_SLAM, F_STUCK, F_RECOVER }
const CURSOR_HP := 3

var player: CharacterBody3D
var level: Node3D
var arena_center := Vector3.ZERO
var arena_radius := 18.0
var state: B = B.WAIT
var letters: Array = []      # {ch, node, body, alive, home, pos}
var _t := 0.0
var _st := 0.0
var _cycle := 0
var _stamper := -1
var _from := Vector3.ZERO
var _target := Vector3.ZERO
var _marker: MeshInstance3D
var _line: MeshInstance3D
var _line_z := 0.0
var _drops: Array = []
var _waves: Array = []
var _rain_t := 0.0
var _phase2 := false
var _bottom := false
# The final phase: THE CURSOR.
var cursor_hp := CURSOR_HP
var _final := false
var _cursor: Node3D
var _cursor_mat: StandardMaterial3D
var _cursor_body: StaticBody3D
var _tiles: Array = []        # {body, mesh, gone, warn}
var _sweeps := 0
var _cur_from := Vector3.ZERO
var _cur_to := Vector3.ZERO


func _ready() -> void:
	var ink := Mats.toon(Color(0.97, 0.97, 0.95), 0.4, 0.4)
	for i in WORD.length():
		var ch := WORD[i]
		if ch == " ":
			continue
		var node := Node3D.new()
		node.top_level = true
		add_child(node)
		var mi := MeshInstance3D.new()
		mi.mesh = Mats.text_mesh(ch, 128, 1.2, 0.035)
		mi.material_override = ink
		node.add_child(mi)
		# Something to land on while the letter is stuck in the floor.
		var body := StaticBody3D.new()
		var cs := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = Vector3(3.0, 2.2, 1.8)
		cs.shape = shape
		body.add_child(cs)
		body.top_level = true
		add_child(body)
		letters.append({"ch": ch, "node": node, "body": body, "alive": true, "home": Vector3.ZERO, "pos": Vector3.ZERO, "slot": i})
		_solid(body, false)
	_marker = _disc(3.0, Color(1.0, 0.15, 0.2))
	_line = MeshInstance3D.new()
	var lm := BoxMesh.new()
	lm.size = Vector3(1, 0.9, 0.8)
	_line.mesh = lm
	# Its own copy: it pulses, and the shared material is used elsewhere.
	_line.material_override = Mats.glow(Color(1.0, 0.8, 0.3), 4.0).duplicate()
	_line.top_level = true
	_line.visible = false
	add_child(_line)


func _solid(b: StaticBody3D, on: bool) -> void:
	b.collision_layer = 1 if on else 0
	b.collision_mask = 0
	(b.get_child(0) as CollisionShape3D).disabled = not on


func _disc(r: float, color: Color) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var c := CylinderMesh.new()
	c.top_radius = r
	c.bottom_radius = r
	c.height = 0.04
	c.radial_segments = 32
	m.mesh = c
	m.material_override = Mats.unshaded(color, 0.5)
	m.top_level = true
	m.visible = false
	add_child(m)
	return m


## Lines the letters up across the back of an arena.
func set_arena(center: Vector3, radius: float) -> void:
	arena_center = center
	arena_radius = radius
	for l in letters:
		var slot: int = l.slot
		l.home = center + Vector3((slot - 3) * 3.6, 7.0, -radius + 4.0)
		if l.pos == Vector3.ZERO:
			l.pos = l.home


func hp() -> int:
	var n := 0
	for l in letters:
		if l.alive:
			n += 1
	return n


## What it's called right now: THE END, THE EN, ..., T.
func current_name() -> String:
	var s := ""
	for i in WORD.length():
		if WORD[i] == " ":
			s += " "
			continue
		for l in letters:
			if l.slot == i and l.alive:
				s += l.ch
	return s.strip_edges()


func start() -> void:
	_cycle = 0
	_next()


func _next() -> void:
	if hp() <= 0:
		return
	var order := [B.UNDERLINE, B.RAIN, B.STAMP] if not _bottom else [B.RAIN, B.STAMP]
	_go(order[_cycle % order.size()])
	_cycle += 1


func _go(s: B) -> void:
	state = s
	_st = 0.0
	match s:
		B.UNDERLINE:
			_line_z = arena_center.z - arena_radius
			_line.visible = true
			_line.scale = Vector3(arena_radius * 2.0, 1, 1)
			_line.global_position = Vector3(arena_center.x, arena_center.y + 0.45, _line_z)
			_line.material_override.emission_energy_multiplier = 1.0
			if level:
				level.bark("theend", ["UNDERLINED. FOR EMPHASIS.", "Every title card needs a line under it.", "Read the FINE PRINT."][_cycle % 3])
		B.RAIN:
			_rain_t = 0.0
			if level:
				level.bark("theend", ["the end the end the end the end", "Fin. Fine. FINITO.", "...and they all lived NEVER after."][_cycle % 3])
		B.STAMP:
			_stamper = _last_alive()
			_from = letters[_stamper].pos
			_target = _clamp(player.global_position)
			_marker.visible = true
			Audio.play("whoosh", 0.8)


func _last_alive() -> int:
	var best := -1
	for i in letters.size():
		if letters[i].alive:
			best = i
	return best


func _physics_process(delta: float) -> void:
	_t += delta
	_st += delta
	_update_drops(delta)
	_update_waves(delta)
	_animate(delta)
	if player == null:
		return
	match state:
		B.UNDERLINE: _st_underline(delta)
		B.RAIN: _st_rain(delta)
		B.STAMP: _st_stamp(delta)
		B.STUCK: _st_stuck()
		B.RECOVER:
			if _st > 0.8:
				_next()
		B.SLIDE: _st_slide(delta)
		B.F_TYPE: _f_type(delta)
		B.F_BACKSPACE: _f_backspace()
		B.F_SWEEP: _f_sweep(delta)
		B.F_SLAM: _f_slam(delta)
		B.F_STUCK: _f_stuck()
		B.F_RECOVER:
			_cursor_idle(delta)
			if _st > 0.6:
				_f_next()
	if _final and _cursor:
		_update_tiles()


## Letters hover at home, wobble like a title card that won't hold still.
func _animate(delta: float) -> void:
	for i in letters.size():
		var l: Dictionary = letters[i]
		var node: Node3D = l.node
		node.visible = l.alive
		if not l.alive:
			continue
		var stuck := state == B.STUCK and i == _stamper
		var flying := state == B.STAMP and i == _stamper
		if not stuck and not flying:
			var goal: Vector3 = l.home + Vector3(0, sin(_t * 1.6 + i) * 0.6, 0)
			if state == B.SLIDE and player:
				# Chasing Stax down the slide, a little ahead of him.
				goal = player.global_position + Vector3((i - 2.5) * 3.2, 7.5 + sin(_t * 3.0 + i) * 1.0, -16.0)
			l.pos = l.pos.lerp(goal, clampf(delta * (4.0 if state == B.SLIDE else 2.5), 0.0, 1.0))
			node.rotation = Vector3(0, sin(_t * 0.9 + i) * 0.15, sin(_t * 1.3 + i) * 0.06)
		node.global_position = l.pos


func _clamp(p: Vector3) -> Vector3:
	var d := p - arena_center
	d.y = 0.0
	if d.length() > arena_radius - 2.0:
		d = d.normalized() * (arena_radius - 2.0)
	return Vector3(arena_center.x + d.x, arena_center.y, arena_center.z + d.z)


# ---------------------------------------------------------------- attacks

func _st_underline(delta: float) -> void:
	var warn := 0.9
	if _st < warn:
		_line.material_override.emission_energy_multiplier = 1.0 + sin(_st * 30.0) * 0.8
		return
	_line.material_override.emission_energy_multiplier = 4.0
	_line_z += delta * (12.5 if hp() > 4 else 15.5)
	_line.global_position.z = _line_z
	var p := player.global_position
	if not player.dead and absf(p.z - _line_z) < 0.7 and p.y < arena_center.y + 1.0 and absf(p.x - arena_center.x) < arena_radius:
		player.take_damage(1, Vector3(p.x, p.y, _line_z - 1.0))
	if _line_z > arena_center.z + arena_radius:
		_line.visible = false
		# Below half health it comes straight back the other way.
		if hp() <= 4 and _st < 10.0:
			_st = 10.0
			_line.visible = true
			_line_z = arena_center.z - arena_radius
			return
		_next()


func _st_rain(delta: float) -> void:
	_rain_t -= delta
	var count := 10 if not _bottom else 12
	if _rain_t <= 0.0 and _st < 2.0:
		_rain_t = 0.2
		var target := player.global_position + Vector3(randf_range(-5, 5), 0, randf_range(-5, 5))
		drop(_clamp(target) if randf() > 0.3 else _clamp(player.global_position))
	if _st > 2.0 + count * 0.05 + 1.8:
		_next()


func _st_stamp(delta: float) -> void:
	var dur := 0.85
	var k := clampf(_st / dur, 0.0, 1.0)
	if k < 0.7:
		_target = _target.lerp(_clamp(player.global_position), clampf(4.0 * delta, 0.0, 1.0))
	_marker.global_position = _target + Vector3(0, 0.05, 0)
	var l: Dictionary = letters[_stamper]
	var flat := _from.lerp(_target, k)
	l.pos = Vector3(flat.x, lerpf(_from.y, arena_center.y + 0.9, k) + sin(k * PI) * 10.0, flat.z)
	(l.node as Node3D).rotation = Vector3(k * TAU, 0, 0)
	if k >= 1.0:
		l.pos = _target + Vector3(0, 0.9, 0)
		(l.node as Node3D).rotation = Vector3(0, 0, 0.18)
		_marker.visible = false
		Audio.play("boom")
		Audio.play("stomp", 0.6)
		if level and level.rig:
			level.rig.shake(0.6)
		Fx.burst(get_parent(), _target + Vector3(0, 0.3, 0), Color(0.1, 0.1, 0.12, 0.9), 40, 10.0, 0.5, 0.8, -8.0, "cube")
		_spawn_wave(_target)
		var d := Vector2(player.global_position.x - _target.x, player.global_position.z - _target.z)
		if d.length() < 2.6:
			player.take_damage(1, _target)
		var body: StaticBody3D = l.body
		body.global_position = _target + Vector3(0, 1.1, 0)
		_solid(body, true)
		_go(B.STUCK)
		if level and level.has_method("on_letter_stuck"):
			level.on_letter_stuck()


func _st_stuck() -> void:
	var l: Dictionary = letters[_stamper]
	(l.node as Node3D).rotation.z = 0.18 + sin(_t * 20.0) * 0.03
	var p := player.global_position
	var at: Vector3 = l.pos
	var flat := Vector2(p.x - at.x, p.z - at.z).length()
	var top := arena_center.y + 2.2
	var pounded: bool = flat < 3.5 and player.state == player.S.POUND_LAND
	var stomped: bool = flat < 2.4 and p.y > top - 0.4 and (player.is_on_floor() or player.velocity.y < 0.0)
	if pounded or stomped:
		take_hit()
		return
	if _st > (3.2 if not _bottom else 2.6):
		_solid(l.body, false)
		Audio.play("whoosh", 1.3)
		_go(B.RECOVER)


## Erases a letter (also used by the tests).
func take_hit() -> void:
	if state == B.DEAD:
		return
	if _final:
		_hit_cursor()
		return
	var i := _stamper if state == B.STUCK else _last_alive()
	if i < 0:
		return
	var l: Dictionary = letters[i]
	l.alive = false
	_solid(l.body, false)
	var at: Vector3 = l.pos + Vector3(0, 1.5, 0)
	Audio.play("scratch", 0.8)
	Audio.play("pop", 0.7)
	Game.fx.flash(Color(1, 1, 1), 0.3)
	if level and level.rig:
		level.rig.shake(0.5)
	Fx.burst(get_parent(), at, Color(0.05, 0.05, 0.08, 0.95), 60, 12.0, 0.4, 1.0, -6.0, "cube")
	Fx.burst(get_parent(), at, Color(1.0, 0.85, 0.3), 20, 8.0, 0.18, 0.8, -12.0, "coin")
	if player:
		player.bounce(15.0, false)
	var n := hp()
	hit.emit(n)
	name_changed.emit(current_name())
	if n <= 0:
		# Not dead. Not even close.
		_final = true
		_clear_attacks()
		state = B.FINAL_WAIT
		final_phase.emit()
		return
	if n == 3 and not _phase2:
		_phase2 = true
		_clear_attacks()
		_go(B.RIPPING)
		phase_two.emit()
		return
	_go(B.RECOVER)


func _die() -> void:
	state = B.DEAD
	_clear_attacks()
	defeated.emit()


## The slide: letters swoop along ahead of Stax, throwing words onto the slide.
func begin_slide() -> void:
	if state == B.DEAD:
		return
	_bottom = false
	_go(B.SLIDE)


func _st_slide(delta: float) -> void:
	_rain_t -= delta
	if _rain_t <= 0.0:
		_rain_t = 0.65
		# Aim at the slide surface ahead of Stax.
		var ahead := player.global_position + Vector3(randf_range(-4.5, 4.5), 6.0, randf_range(-14.0, -9.0))
		var hit_ := get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(ahead, ahead + Vector3(0, -30, 0), 1, [player.get_rid()]))
		if hit_:
			drop(hit_.position, 0.0, 0.8)


## The bottom of the slide: the last letters make their stand.
func begin_bottom(center: Vector3, radius: float) -> void:
	if state == B.DEAD:
		return
	_bottom = true
	set_arena(center, radius)
	_cycle = 0
	_next()


# ---------------------------------------------------------------- THE CURSOR

## All the erased ink pours back together into one giant blinking cursor, and
## the floor under the fight becomes tiles it can delete.
func begin_final(center: Vector3) -> void:
	set_arena(center, 13.0)
	_clear_attacks()
	_build_tiles(center)
	if _cursor == null:
		_cursor = Node3D.new()
		_cursor.top_level = true
		add_child(_cursor)
		var bar := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(1.2, 10.0, 1.2)
		bar.mesh = bm
		_cursor_mat = Mats.glow(Color(1.0, 0.85, 0.3), 5.0).duplicate()
		bar.material_override = _cursor_mat
		_cursor.add_child(bar)
		var light := OmniLight3D.new()
		light.light_color = Color(1.0, 0.85, 0.4)
		light.omni_range = 18.0
		light.light_energy = 3.0
		_cursor.add_child(light)
		Fx.ambient(_cursor, Vector3.ZERO, Vector3(0.8, 5.0, 0.8), Color(1.0, 0.9, 0.5, 0.9), 60, 0.2, Vector3(0, 2, 0), 1.0)
		_cursor_body = StaticBody3D.new()
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		sh.size = Vector3(10.0, 1.4, 1.6)
		cs.shape = sh
		_cursor_body.add_child(cs)
		_cursor_body.top_level = true
		add_child(_cursor_body)
	_solid(_cursor_body, false)
	_cursor.global_position = center + Vector3(0, 9, -9)
	_cursor.rotation = Vector3.ZERO
	cursor_hp = CURSOR_HP
	_cycle = 0
	_f_next()


func _build_tiles(center: Vector3) -> void:
	for t in _tiles:
		t.body.queue_free()
	_tiles.clear()
	var paper := Mats.solid(Color(0.97, 0.97, 0.97), 0.8)
	for ix in 5:
		for iz in 5:
			var body := StaticBody3D.new()
			var cs := CollisionShape3D.new()
			var sh := BoxShape3D.new()
			sh.size = Vector3(5.8, 1.0, 5.8)
			cs.shape = sh
			body.add_child(cs)
			var mi := MeshInstance3D.new()
			var bm := BoxMesh.new()
			bm.size = Vector3(5.8, 1.0, 5.8)
			mi.mesh = bm
			mi.material_override = paper
			body.add_child(mi)
			get_parent().add_child(body)
			body.global_position = center + Vector3((ix - 2) * 6.0, -0.5, (iz - 2) * 6.0)
			_tiles.append({"body": body, "mesh": mi, "gone": false, "warn": -1.0, "ix": ix, "iz": iz})


func _update_tiles() -> void:
	for t in _tiles:
		if t.warn >= 0.0:
			t.warn -= get_physics_process_delta_time()
			(t.mesh as MeshInstance3D).visible = fmod(t.warn, 0.14) > 0.05
			if t.warn < 0.0:
				t.gone = true
				t.warn = -1.0
				(t.mesh as MeshInstance3D).visible = false
				(t.body as StaticBody3D).collision_layer = 0
				Audio.play("scratch", 1.5, 0.1, -4.0)
				Fx.burst(get_parent(), (t.body as Node3D).global_position, Color(0.95, 0.95, 0.95), 20, 6.0, 0.4, 0.8, -8.0, "cube")


func _restore_tiles() -> void:
	for t in _tiles:
		t.gone = false
		t.warn = -1.0
		(t.mesh as MeshInstance3D).visible = true
		(t.body as StaticBody3D).collision_layer = 1


func _f_next() -> void:
	var order := [B.F_TYPE, B.F_BACKSPACE, B.F_SWEEP, B.F_SLAM]
	state = order[_cycle % order.size()]
	_cycle += 1
	_st = 0.0
	_sweeps = 0
	_rain_t = 0.0
	match state:
		B.F_TYPE:
			if level:
				level.bark("theend", ["TYPING... TYPING... TYPING...", "Every word I write FALLS ON YOU.", "Lorem ipsum DOLOR."][_cycle % 3])
		B.F_BACKSPACE:
			if level:
				level.bark("theend", ["BACKSPACE.", "Deleting... your... FLOOR.", "Ctrl. Z. EVERYTHING."][_cycle % 3])
		B.F_SWEEP:
			Audio.play("whoosh", 0.6)
		B.F_SLAM:
			_cur_from = _cursor.global_position
			_cur_to = _near_tile(player.global_position)
			_marker.visible = true
			Audio.play("whoosh", 0.9)


func _speed() -> float:
	return 1.0 + (CURSOR_HP - cursor_hp) * 0.25


func _cursor_idle(delta: float) -> void:
	var goal := arena_center + Vector3(sin(_t * 0.7) * 6.0, 9.0, -9.0)
	_cursor.global_position = _cursor.global_position.lerp(goal, clampf(delta * 3.0, 0.0, 1.0))
	_cursor.rotation = _cursor.rotation.lerp(Vector3.ZERO, clampf(delta * 6.0, 0.0, 1.0))
	# Blink, like any cursor waiting for input.
	_cursor.visible = fmod(_t, 0.9) < 0.6


func _f_type(delta: float) -> void:
	_cursor_idle(delta)
	_rain_t -= delta
	if _rain_t <= 0.0 and _st < 3.0:
		_rain_t = 0.16 / _speed()
		var target := player.global_position + Vector3(randf_range(-6, 6), 0, randf_range(-6, 6))
		drop(_on_tile(target) if randf() > 0.25 else _on_tile(player.global_position), 0.0, 0.8)
	if _st > 4.4:
		_f_next()


func _f_backspace() -> void:
	_cursor_idle(get_physics_process_delta_time())
	if _st < 0.05:
		# Delete the tiles furthest from the centre first, never the last few.
		var left: Array = []
		for t in _tiles:
			if not t.gone and t.warn < 0.0:
				left.append(t)
		left.sort_custom(func(a, b): return absi(a.ix - 2) + absi(a.iz - 2) > absi(b.ix - 2) + absi(b.iz - 2))
		var n := mini(3 + CURSOR_HP - cursor_hp, left.size() - 6)
		for i in maxi(n, 0):
			left[i].warn = 1.0
		Audio.play("zap", 0.7)
	if _st > 1.6:
		_f_next()


func _f_sweep(delta: float) -> void:
	# The cursor tips over into an underscore and sweeps the floor, twice.
	var dur := 1.3 / _speed()
	var k := clampf(_st / dur, 0.0, 1.0)
	var dir := 1.0 if _sweeps % 2 == 0 else -1.0
	var z := arena_center.z + dir * lerpf(-arena_radius - 3.0, arena_radius + 3.0, k)
	_cursor.visible = true
	_cursor.rotation = Vector3(0, 0, PI / 2)
	_cursor.scale = Vector3(1, 3.2, 1)
	_cursor.global_position = Vector3(arena_center.x, arena_center.y + 0.6, z)
	var p := player.global_position
	if not player.dead and absf(p.z - z) < 1.0 and p.y < arena_center.y + 1.2:
		player.take_damage(1, Vector3(p.x, p.y, z - dir))
	if k >= 1.0:
		_sweeps += 1
		_st = 0.0
		if _sweeps >= 2:
			_cursor.scale = Vector3.ONE
			_cursor.global_position = arena_center + Vector3(0, 9, -9)
			_f_next()


func _f_slam(delta: float) -> void:
	var dur := 0.9 / _speed()
	var k := clampf(_st / dur, 0.0, 1.0)
	if k < 0.6:
		_cur_to = _cur_to.lerp(_near_tile(player.global_position), clampf(4.0 * delta, 0.0, 1.0))
	_marker.global_position = _cur_to + Vector3(0, 0.05, 0)
	_cursor.visible = true
	var flat := _cur_from.lerp(_cur_to, k)
	_cursor.global_position = Vector3(flat.x, lerpf(_cur_from.y, _cur_to.y + 0.7, k) + sin(k * PI) * 8.0, flat.z)
	_cursor.rotation = Vector3(0, 0, k * PI * 2.5)
	if k >= 1.0:
		_marker.visible = false
		_cursor.global_position = _cur_to + Vector3(0, 0.7, 0)
		_cursor.rotation = Vector3(0, 0, PI / 2)
		Audio.play("boom")
		Audio.play("hit_low")
		if level and level.rig:
			level.rig.shake(0.8)
		_spawn_wave(_cur_to)
		_spawn_wave(_cur_to)
		_waves[-1].r = -3.0
		if Vector2(player.global_position.x - _cur_to.x, player.global_position.z - _cur_to.z).length() < 3.0:
			player.take_damage(1, _cur_to)
		_cursor_body.global_position = _cur_to + Vector3(0, 0.7, 0)
		_solid(_cursor_body, true)
		state = B.F_STUCK
		_st = 0.0
		if level and level.has_method("on_letter_stuck"):
			level.on_letter_stuck()


func _f_stuck() -> void:
	_cursor_mat.emission_energy_multiplier = 5.0 + sin(_t * 25.0) * 3.0
	var c := _cursor.global_position
	var p := player.global_position
	var along := absf(p.x - c.x)
	var across := absf(p.z - c.z)
	var top := c.y + 0.7
	var pounded: bool = along < 5.5 and across < 3.0 and player.state == player.S.POUND_LAND
	var stomped: bool = along < 5.2 and across < 1.4 and p.y > top - 0.4 and (player.is_on_floor() or player.velocity.y < 0.0)
	if pounded or stomped:
		_hit_cursor()
		return
	if _st > 2.6 - (CURSOR_HP - cursor_hp) * 0.3:
		_solid(_cursor_body, false)
		_cursor_mat.emission_energy_multiplier = 5.0
		state = B.F_RECOVER
		_st = 0.0


func _hit_cursor() -> void:
	cursor_hp -= 1
	hit.emit(cursor_hp)
	_solid(_cursor_body, false)
	_marker.visible = false
	_cursor_mat.emission_energy_multiplier = 5.0
	var at := _cursor.global_position
	Audio.play("clang", 0.5)
	Audio.play("boom", 1.3)
	Game.fx.flash(Color(1.0, 0.9, 0.5), 0.5)
	Game.fx.aberrate(1.0, 0.6)
	if level and level.rig:
		level.rig.shake(0.9)
	Fx.burst(get_parent(), at, Color(1.0, 0.85, 0.3), 60, 14.0, 0.3, 1.0, -6.0)
	Fx.burst(get_parent(), at, Color(1.0, 0.85, 0.3), 24, 9.0, 0.18, 0.8, -12.0, "coin")
	if player:
		player.bounce(16.0, false)
	for d in _drops:
		d.node.queue_free()
		d.ring.queue_free()
	_drops.clear()
	_restore_tiles()
	if cursor_hp <= 0:
		_cursor.visible = false
		for t in _tiles:
			t.body.queue_free()
		_tiles.clear()
		_die()
		return
	if level:
		level.bark("theend", ["ERROR. ERROR. SYNTAX ERROR.", "You cannot delete THE CURSOR. I AM THE DELETE."][CURSOR_HP - cursor_hp - 1])
	_cursor.global_position = arena_center + Vector3(0, 9, -9)
	_cursor.rotation = Vector3.ZERO
	state = B.F_RECOVER
	_st = 0.0


## Stax died in the final phase: start it over (every tile back).
func reset_final() -> void:
	_clear_attacks()
	begin_final(arena_center)


func _on_tile(p: Vector3) -> Vector3:
	return _near_tile(p)


## The nearest spot on a tile that still exists.
func _near_tile(p: Vector3) -> Vector3:
	var best := arena_center
	var bd := 1e9
	for t in _tiles:
		if t.gone or t.warn >= 0.0:
			continue
		var c: Vector3 = (t.body as Node3D).global_position
		var d := Vector2(c.x - p.x, c.z - p.z).length()
		if d < bd:
			bd = d
			best = c
	var off := Vector3(clampf(p.x - best.x, -2.4, 2.4), 0, clampf(p.z - best.z, -2.4, 2.4))
	return Vector3(best.x + off.x, arena_center.y, best.z + off.z)


## Stax fell off: back to the top of the slide, with every letter he hasn't
## erased yet. (Phase 1 resets completely.)
func reset() -> void:
	_clear_attacks()
	if not _phase2:
		for l in letters:
			l.alive = true
		name_changed.emit(current_name())
		_cycle = 0
		_next()


func _clear_attacks() -> void:
	for d in _drops:
		d.node.queue_free()
		d.ring.queue_free()
	_drops.clear()
	for w in _waves:
		w.node.queue_free()
	_waves.clear()
	_marker.visible = false
	_line.visible = false
	for l in letters:
		_solid(l.body, false)


# ---------------------------------------------------------------- projectiles

const TINY := ["the", "end", "fin", "THE", "END", "FIN", "..."]


## A small word dropping onto `target` with a warning ring.
func drop(target: Vector3, delay := 0.0, fall := 1.0) -> void:
	var ring := _disc(2.0, Color(1.0, 0.2, 0.3))
	ring.visible = true
	ring.global_position = target + Vector3(0, 0.05, 0)
	var node := MeshInstance3D.new()
	node.mesh = Mats.text_mesh(TINY[randi() % TINY.size()], 96, 0.5, 0.02)
	node.material_override = Mats.toon(Color(0.1, 0.1, 0.12), 0.5, 0.3)
	get_parent().add_child(node)
	var from := target + Vector3(randf_range(-3, 3), 22, randf_range(-3, 3))
	node.global_position = from
	node.visible = false
	_drops.append({"node": node, "ring": ring, "from": from, "to": target, "t": -delay - 0.55, "dur": fall})


func _update_drops(delta: float) -> void:
	for d in _drops.duplicate():
		d.t += delta
		var node: MeshInstance3D = d.node
		var ring: MeshInstance3D = d.ring
		ring.scale = Vector3.ONE * (0.8 + 0.2 * sin(_t * 18.0))
		if d.t < 0.0:
			continue
		node.visible = true
		var k: float = clampf(d.t / d.dur, 0.0, 1.0)
		node.global_position = d.from.lerp(d.to, k * k)
		node.rotation += Vector3(4, 3, 5) * delta
		if k >= 1.0:
			Audio.play("clang", 1.6, 0.1, -4.0)
			Fx.burst(get_parent(), d.to + Vector3(0, 0.5, 0), Color(0.1, 0.1, 0.12), 16, 6.0, 0.25, 0.6, -10.0, "cube")
			if player and not player.dead:
				var dist := Vector2(player.global_position.x - d.to.x, player.global_position.z - d.to.z).length()
				if dist < 2.1 and absf(player.global_position.y - d.to.y) < 2.2:
					player.take_damage(1, d.to)
			node.queue_free()
			ring.queue_free()
			_drops.erase(d)


func _spawn_wave(at: Vector3) -> void:
	var ring := MeshInstance3D.new()
	var tor := TorusMesh.new()
	tor.inner_radius = 0.85
	tor.outer_radius = 1.0
	tor.rings = 48
	tor.ring_segments = 8
	ring.mesh = tor
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.1, 0.1, 0.12, 0.9)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	ring.material_override = m
	get_parent().add_child(ring)
	ring.global_position = at + Vector3(0, 0.35, 0)
	_waves.append({"node": ring, "r": 1.0, "mat": m, "center": at})


func _update_waves(delta: float) -> void:
	for w in _waves.duplicate():
		w.r += delta * 12.0
		var node: MeshInstance3D = w.node
		node.scale = Vector3(maxf(w.r, 0.01), 1.3, maxf(w.r, 0.01))
		w.mat.albedo_color.a = clampf(1.0 - w.r / (arena_radius * 1.6), 0.0, 1.0)
		if player and not player.dead:
			var flat := Vector2(player.global_position.x - w.center.x, player.global_position.z - w.center.z).length()
			if absf(flat - w.r) < 0.8 and player.global_position.y < w.center.y + 0.9 and player.global_position.y > w.center.y - 1.0:
				player.take_damage(1, w.center)
		if w.r > arena_radius * 1.6:
			node.queue_free()
			_waves.erase(w)
