extends Node3D
## Captain Moneybeard, who arrives on a pirate ship out of nowhere.
## Loop: charge at Stax with his cutlass -> order a cannon volley from the
## ship (dodge the red target rings) -> leap and slam his anchor (jump the
## shockwave) -> the anchor sticks in the sand and he's stuck: stomp his hat
## or ground-pound next to him. Three hits and his coat falls off.

signal hit(hp: int)
signal defeated

const Puppet := preload("res://scripts/actors/puppet.gd")
const Mats := preload("res://scripts/world/mats.gd")
const Fx := preload("res://scripts/world/fx.gd")

const S := 1.6            # model scale
const MAX_HP := 3
const HEAD := 2.6 * S     # top of his hat

enum B { WAIT, CHASE, VOLLEY, LEAP, STUCK, RECOVER, DEAD }

const HIT_LINES := [
	"ARR! Me hat! Nobody touches the hat!",
	"Blast ye! That's coming out of yer wages!",
	"Parrot! Do something!",
]

var player: CharacterBody3D
var level: Node3D
var arena_center := Vector3.ZERO
var arena_radius := 18.0
## Where the ship's cannons fire from.
var cannons: Array[Vector3] = []
var puppet: Node3D
var hp := MAX_HP
var state: B = B.WAIT
var _t := 0.0
var _yaw := 0.0
var _from := Vector3.ZERO
var _target := Vector3.ZERO
var _marker: MeshInstance3D
var _stars: Node3D
var _balls: Array = []
var _waves: Array = []
var _hurt_cd := 0.0
var _next_attack := 0


func _ready() -> void:
	puppet = Puppet.new()
	puppet.kind = "moneybeard"
	puppet.speaker = "moneybeard"
	puppet.scale = Vector3.ONE * S
	add_child(puppet)
	_marker = _disc(3.0, Color(1.0, 0.15, 0.05))
	_stars = Node3D.new()
	_stars.top_level = true
	_stars.visible = false
	add_child(_stars)
	for i in 5:
		var st := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.18
		sm.height = 0.36
		st.mesh = sm
		st.material_override = Mats.glow(Color(1.0, 0.95, 0.4), 4.0)
		st.position = Vector3(cos(TAU * i / 5.0) * 1.0, 0, sin(TAU * i / 5.0) * 1.0)
		_stars.add_child(st)


func _disc(r: float, color: Color) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var c := CylinderMesh.new()
	c.top_radius = r
	c.bottom_radius = r
	c.height = 0.04
	c.radial_segments = 32
	m.mesh = c
	m.material_override = Mats.unshaded(color, 0.5)
	m.top_level = true
	m.visible = false
	add_child(m)
	return m


func phase() -> int:
	return MAX_HP - hp + 1


func start() -> void:
	_go(B.CHASE)


func _go(s: B) -> void:
	state = s
	_t = 0.0


func _face(delta: float, rate := 6.0) -> void:
	var d := player.global_position - global_position
	_yaw = lerp_angle(_yaw, atan2(-d.x, -d.z), clampf(rate * delta, 0.0, 1.0))
	rotation.y = _yaw


func _clamp(p: Vector3) -> Vector3:
	var d := p - arena_center
	d.y = 0.0
	if d.length() > arena_radius - 2.0:
		d = d.normalized() * (arena_radius - 2.0)
	return Vector3(arena_center.x + d.x, arena_center.y, arena_center.z + d.z)


func _physics_process(delta: float) -> void:
	_t += delta
	_hurt_cd -= delta
	_update_balls(delta)
	_update_waves(delta)
	if player == null or state == B.WAIT or state == B.DEAD:
		return
	match state:
		B.CHASE: _st_chase(delta)
		B.VOLLEY: _st_volley(delta)
		B.LEAP: _st_leap(delta)
		B.STUCK: _st_stuck(delta)
		B.RECOVER:
			if _t > 0.7:
				_go(B.CHASE)
	# His cutlass hurts while he's up and about.
	if state in [B.CHASE, B.VOLLEY] and _hurt_cd <= 0.0 and not player.dead:
		var flat := Vector2(player.global_position.x - global_position.x, player.global_position.z - global_position.z)
		if flat.length() < 1.8 and player.global_position.y < global_position.y + HEAD - 0.3:
			player.take_damage(1, global_position)
			_hurt_cd = 1.0
			puppet.emote = "attack"
			Audio.play("zap", 0.6)


func _st_chase(delta: float) -> void:
	_face(delta)
	puppet.emote = "attack" if fmod(_t, 0.6) < 0.25 else ""
	var to := player.global_position - global_position
	to.y = 0.0
	if to.length() > 1.4:
		global_position = _clamp(global_position + to.normalized() * (3.5 + phase() * 0.8) * delta)
	if _t > [3.0, 2.4, 2.0][phase() - 1]:
		puppet.emote = ""
		_next_attack += 1
		if _next_attack % 2 == 1:
			_go(B.VOLLEY)
			puppet.emote = "point"
			if level:
				level.bark("moneybeard", ["FIRE THE CANNONS!", "BROADSIDE, ye scallywags!", "Aim for the one with the fancy glasses!"][(_next_attack / 2) % 3])
			_fire_volley()
		else:
			_begin_leap()


func _st_volley(delta: float) -> void:
	_face(delta, 3.0)
	if _t > 2.4:
		puppet.emote = ""
		_begin_leap()


func _begin_leap() -> void:
	_from = global_position
	_target = _clamp(player.global_position)
	_marker.visible = true
	Audio.play("whoosh", 0.9)
	puppet.emote = "laugh"
	_go(B.LEAP)


func _st_leap(delta: float) -> void:
	var dur: float = [1.1, 0.95, 0.8][phase() - 1]
	if _t < dur * 0.6:
		_target = _target.lerp(_clamp(player.global_position), clampf(4.0 * delta, 0.0, 1.0))
	var k := clampf(_t / dur, 0.0, 1.0)
	var flat := _from.lerp(_target, k)
	global_position = Vector3(flat.x, arena_center.y + sin(k * PI) * 9.0, flat.z)
	_face(delta, 8.0)
	_marker.global_position = _target + Vector3(0, 0.03, 0)
	if k >= 1.0:
		global_position = _target
		_marker.visible = false
		Audio.play("boom")
		if level and level.rig:
			level.rig.shake(0.6)
		Fx.burst(get_parent(), global_position + Vector3(0, 0.3, 0), Color(1.0, 0.85, 0.55, 0.9), 40, 10.0, 0.7, 0.8, -6.0)
		_spawn_wave(global_position)
		var d := Vector2(player.global_position.x - global_position.x, player.global_position.z - global_position.z)
		if d.length() < 2.8:
			player.take_damage(1, global_position)
		# The anchor sticks in the sand.
		puppet.emote = "shocked"
		_stars.visible = true
		_go(B.STUCK)
		if level and level.has_method("on_boss_stuck"):
			level.on_boss_stuck()


func _st_stuck(delta: float) -> void:
	_stars.global_position = global_position + Vector3(0, HEAD + 0.6, 0)
	_stars.rotation.y += delta * 5.0
	puppet.rotation.z = sin(_t * 12.0) * 0.08
	var p := player.global_position
	var flat := Vector2(p.x - global_position.x, p.z - global_position.z).length()
	var stomped := flat < 1.5 and p.y > global_position.y + HEAD - 0.7 and player.velocity.y < 0.0
	var pounded: bool = flat < 3.0 and player.state == player.S.POUND_LAND
	if stomped or pounded:
		take_hit()
		return
	if _t > [3.4, 2.8, 2.3][phase() - 1]:
		_unstick()


func _unstick() -> void:
	puppet.rotation.z = 0.0
	puppet.emote = ""
	_stars.visible = false
	_go(B.RECOVER)


## Registers a hit (also used by the automated tests).
func take_hit() -> void:
	if state == B.DEAD:
		return
	hp -= 1
	hit.emit(hp)
	Audio.play("clang", 0.8)
	Audio.play("stomp")
	Game.fx.flash(Color(1, 1, 1), 0.25)
	if level and level.rig:
		level.rig.shake(0.5)
	Fx.burst(get_parent(), global_position + Vector3(0, HEAD, 0), Color(1.0, 0.85, 0.3), 16, 7.0, 0.18, 0.8, -12.0, "coin")
	if player:
		player.bounce(15.0, false)
	puppet.squash = 0.5
	_unstick()
	if hp <= 0:
		_die()
		return
	if level:
		level.bark("moneybeard", HIT_LINES[(MAX_HP - hp - 1) % HIT_LINES.size()])


## Back to full health at the start, for a fresh attempt after Stax dies.
func reset(at: Vector3) -> void:
	_marker.visible = false
	for b in _balls:
		b.node.queue_free()
		b.ring.queue_free()
	_balls.clear()
	for w in _waves:
		w.node.queue_free()
	_waves.clear()
	hp = MAX_HP
	_next_attack = 0
	_unstick()
	global_position = at
	_go(B.CHASE)


func _die() -> void:
	state = B.DEAD
	_marker.visible = false
	for b in _balls:
		b.node.queue_free()
		b.ring.queue_free()
	_balls.clear()
	for w in _waves:
		w.node.queue_free()
	_waves.clear()
	defeated.emit()


# ---------------------------------------------------------------- attacks

func _fire_volley() -> void:
	var count: int = [4, 6, 8][phase() - 1]
	for i in count:
		var target := player.global_position if i == 0 else player.global_position + Vector3(randf_range(-6, 6), 0, randf_range(-6, 6))
		target = _clamp(target)
		var from: Vector3 = cannons[i % cannons.size()] if not cannons.is_empty() else global_position + Vector3(0, 8, 0)
		var ring := _disc(2.4, Color(1.0, 0.2, 0.05))
		ring.visible = true
		ring.global_position = target + Vector3(0, 0.04, 0)
		var ball := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.55
		sm.height = 1.1
		ball.mesh = sm
		ball.material_override = Mats.solid(Color(0.08, 0.08, 0.09), 0.3, 0.8)
		get_parent().add_child(ball)
		ball.global_position = from
		_balls.append({"node": ball, "ring": ring, "from": from, "to": target, "t": -i * 0.22, "dur": 1.5})
		Fx.burst(get_parent(), from, Color(1.0, 0.9, 0.7, 0.8), 10, 5.0, 0.8, 0.6, 0.0)
	Audio.play("boom", 1.4, 0.1, -4.0)


func _update_balls(delta: float) -> void:
	for b in _balls.duplicate():
		b.t += delta
		var node: MeshInstance3D = b.node
		var ring: MeshInstance3D = b.ring
		ring.scale = Vector3.ONE * (0.8 + 0.2 * sin(b.t * 18.0))
		if b.t < 0.0:
			node.visible = false
			continue
		node.visible = true
		var k: float = clampf(b.t / b.dur, 0.0, 1.0)
		node.global_position = b.from.lerp(b.to, k) + Vector3(0, sin(k * PI) * 14.0, 0)
		if k >= 1.0:
			Audio.play("boom", 1.2, 0.1, -3.0)
			Fx.burst(get_parent(), b.to + Vector3(0, 0.4, 0), Color(1.0, 0.6, 0.2), 24, 8.0, 0.5, 0.6, -6.0)
			if player and not player.dead:
				var d := Vector2(player.global_position.x - b.to.x, player.global_position.z - b.to.z).length()
				if d < 2.6 and player.global_position.y < b.to.y + 2.0:
					player.take_damage(1, b.to)
			node.queue_free()
			ring.queue_free()
			_balls.erase(b)


func _spawn_wave(at: Vector3) -> void:
	var ring := MeshInstance3D.new()
	var tor := TorusMesh.new()
	tor.inner_radius = 0.85
	tor.outer_radius = 1.0
	tor.rings = 48
	tor.ring_segments = 8
	ring.mesh = tor
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(1.0, 0.8, 0.4, 0.9)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.emission_enabled = true
	m.emission = Color(1.0, 0.6, 0.2)
	m.emission_energy_multiplier = 2.5
	ring.material_override = m
	get_parent().add_child(ring)
	ring.global_position = at + Vector3(0, 0.35, 0)
	_waves.append({"node": ring, "r": 1.0, "mat": m, "center": at})


func _update_waves(delta: float) -> void:
	for w in _waves.duplicate():
		w.r += delta * (11.0 + phase() * 2.0)
		var node: MeshInstance3D = w.node
		node.scale = Vector3(w.r, 1.3, w.r)
		w.mat.albedo_color.a = clampf(1.0 - w.r / arena_radius, 0.0, 1.0)
		if player and not player.dead:
			var flat := Vector2(player.global_position.x - w.center.x, player.global_position.z - w.center.z).length()
			if absf(flat - w.r) < 0.8 and player.global_position.y < w.center.y + 0.9:
				player.take_damage(1, w.center)
		if w.r > arena_radius + 2.0:
			node.queue_free()
			_waves.erase(w)
