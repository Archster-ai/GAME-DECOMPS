extends Node3D
## Kilowatt, the Light Dragon: the city's power grid, wearing a light show as
## a body. Built from glowing spheres that trail the head like a live wire.
## He fights over a square rooftop stage, and each cycle ends the same way:
## he crashes his head into the floor and is stunned, and Stax stomps it.
##   STRIKE  marked spots on the floor, then lightning falls on them
##   SWEEP   a laser line spins from the middle of the stage (jump it; the
##           very centre is safe)
##   GRID    the floor tiles flash yellow, then go live: leave the tile
##   DIVE    a red line shows his charge, then he crashes down along it
## Four stomps and the show is over. The last phase, OVERLOAD, mixes every
## attack together, adds a STORM (lasers AND lightning at once) and a fake-out
## dive, and leaves only a short window to stomp. Getting knocked out restarts the
## current phase, not the whole fight.

signal hit(hp: int)
signal defeated

const Mats := preload("res://scripts/world/mats.gd")
const Fx := preload("res://scripts/world/fx.gd")

const MAX_HP := 4
const GOD_HP := 3                  # the second health bar, after the horror
const HALF := 13.0                 # half the width of the square stage
const SEGMENTS := 18
const GAP := 5                     # frames of trail between body segments
const TILE := 8.4

enum B { WAIT, STRIKE, STORM, NOVA, SWEEP, GRID, DIVE_AIM, DIVE_RUN, STUNNED, RECOVER, DEAD }

const HIT_LINES := [
	"BZZT! My HEAD! That is where the WIFI lives!",
	"OW OW OW! Fine. FINE. Full power.",
	"NO NO NO! ALL OF IT! EVERY VOLT! OVERLOAD!",
]
const GOD_LINES := [
	"EVERY LIGHT! EVERY LIGHT IS WATCHING!",
	"YOU CANNOT SWITCH ME OFF. I AM THE SWITCH.",
]
const TAUNTS := ["ZAP!", "FEEL THE VOLTAGE!", "I AM THE GRID!", "CHARGING!", "BRIGHTER! LOUDER!"]

var player: CharacterBody3D
var level: Node3D
var arena_center := Vector3.ZERO   # the middle of the stage's floor
var hp := MAX_HP
var state: B = B.WAIT
var head: Node3D
var _t := 0.0
var _st := 0.0
var _cycle := 0
var _goal := Vector3.ZERO
var _look := Vector3.ZERO
var _rate := 3.0
var _history: Array[Vector3] = []
var _segs: Array[MeshInstance3D] = []
var _wings: Node3D
var _wing_l: Node3D
var _wing_r: Node3D
var _jaw: Node3D
var _core: MeshInstance3D
var _core_mat: StandardMaterial3D
var _light: OmniLight3D
# STRIKE
var _bolts: Array = []           # {pos, t, ring, col, fired}
var _next_bolt := 0.0
# SWEEP
var _beams: Node3D
var _beam_lines: Array[MeshInstance3D] = []
var _beam_angle := 0.0
var _beam_live := false
# GRID
var _tiles: Array = []           # {mesh, mat, center, live}
var _round := 0
var _round_t := 0.0
# DIVE
var _aim: MeshInstance3D
var _dive_from := Vector3.ZERO
var _dive_to := Vector3.ZERO
var _locked := false
var _told := false
var _fakes := 0
var _dead_at := Vector3.ZERO
# The god form: after the first defeat he comes apart into a cloud of lights,
# then gathers back up as something much worse.
var god := false
var _hs := 1.0                     # head scale (bigger as the god dragon)
var _motes: Array = []             # {node, vel, ph}
var _mote_mode := 0                # 0 none, 1 drift, 2 gather
var _gather_to := Vector3.ZERO
var _gather_t := 0.0
var _waves: Array = []             # NOVA rings: {node, r}
var _halos: Array[Node3D] = []
var _aberrate_t := 3.0


func _ready() -> void:
	_build()


# ---------------------------------------------------------------- the model

func _glow(c: Color, e := 2.0) -> StandardMaterial3D:
	return Mats.glow(c, e)


func _mesh_child(parent: Node3D, mesh: Mesh, mat: Material, pos := Vector3.ZERO, rot := Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	parent.add_child(mi)
	return mi


func _sphere(r: float) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	s.radial_segments = 16
	s.rings = 8
	return s


func _box(size: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = size
	return b


func _build() -> void:
	head = Node3D.new()
	head.top_level = true
	add_child(head)
	var white := _glow(Color(0.8, 0.97, 1.0), 1.6)
	var blue := _glow(Color(0.15, 0.6, 1.0), 2.4)
	var sk := _mesh_child(head, _sphere(1.4), white)
	sk.scale = Vector3(1.0, 0.85, 1.3)
	_mesh_child(head, _box(Vector3(1.1, 0.75, 1.7)), white, Vector3(0, -0.2, -1.8))
	_jaw = Node3D.new()
	_jaw.position = Vector3(0, -0.55, -0.9)
	head.add_child(_jaw)
	_mesh_child(_jaw, _box(Vector3(1.0, 0.3, 1.7)), blue, Vector3(0, 0, -0.85))
	for side in [-1.0, 1.0]:
		_mesh_child(head, _sphere(0.28), _glow(Color(1.0, 0.95, 0.3), 5.0), Vector3(side * 0.62, 0.35, -1.25))
		var horn := CylinderMesh.new()
		horn.top_radius = 0.0
		horn.bottom_radius = 0.32
		horn.height = 2.2
		_mesh_child(head, horn, blue, Vector3(side * 0.75, 1.0, 0.5), Vector3(-1.1, 0, -side * 0.35))
	_core_mat = _glow(Color(0.5, 1.0, 1.0), 4.0).duplicate()
	_core = _mesh_child(head, _sphere(0.42), _core_mat, Vector3(0, 0.95, -0.55))
	_light = OmniLight3D.new()
	_light.light_color = Color(0.5, 0.85, 1.0)
	_light.omni_range = 30.0
	_light.light_energy = 3.0
	head.add_child(_light)
	Fx.ambient(head, Vector3.ZERO, Vector3(1.6, 1.2, 1.8), Color(0.6, 0.95, 1.0, 0.9), 50, 0.16, Vector3.ZERO, 0.9)

	for i in SEGMENTS:
		var r := lerpf(1.15, 0.22, float(i) / SEGMENTS)
		var seg := MeshInstance3D.new()
		seg.mesh = _sphere(r)
		seg.material_override = _glow(Color(0.15, 0.7, 1.0) if i % 2 == 0 else Color(0.75, 0.95, 1.0), 2.4)
		seg.top_level = true
		add_child(seg)
		_segs.append(seg)
	_wings = Node3D.new()
	_wings.top_level = true
	add_child(_wings)
	for side in [-1.0, 1.0]:
		var pivot := Node3D.new()
		pivot.position = Vector3(side * 0.6, 0.6, 0)
		_wings.add_child(pivot)
		var panel := _mesh_child(pivot, _box(Vector3(7.0, 0.08, 3.2)), _glow(Color(0.4, 0.85, 1.0), 2.0), Vector3(side * 3.5, 0, 0.6))
		panel.rotation.y = side * 0.25
		_mesh_child(pivot, _box(Vector3(7.2, 0.14, 0.18)), _glow(Color(1, 1, 1), 4.0), Vector3(side * 3.5, 0.02, -0.9)).rotation.y = side * 0.25
		if side < 0.0:
			_wing_l = pivot
		else:
			_wing_r = pivot
	# The floor tiles that GRID electrifies.
	for gx in 3:
		for gz in 3:
			var mat := StandardMaterial3D.new()
			mat.emission_enabled = true
			mat.albedo_color = Color(0.05, 0.1, 0.2)
			mat.emission = Color(0.1, 0.4, 0.9)
			mat.emission_energy_multiplier = 0.5
			var mi := _mesh_child(self, _box(Vector3(TILE - 0.5, 0.05, TILE - 0.5)), mat)
			mi.top_level = true
			_tiles.append({"mesh": mi, "mat": mat, "center": Vector3((gx - 1) * TILE, 0, (gz - 1) * TILE), "live": false, "warn": false})
	_beams = Node3D.new()
	_beams.top_level = true
	add_child(_beams)
	for i in 3:
		var line := _mesh_child(_beams, _box(Vector3(1.0, 0.2, HALF * 3.2)), _glow(Color(1.0, 0.3, 0.5), 5.0))
		line.visible = false
		_beam_lines.append(line)
	_aim = _mesh_child(self, _box(Vector3(3.6, 0.06, 1.0)), Mats.unshaded(Color(1.0, 0.2, 0.3), 0.55))
	_aim.top_level = true
	_aim.visible = false
	set_arena(arena_center)
	_history.clear()


func set_arena(center: Vector3) -> void:
	arena_center = center
	for t in _tiles:
		(t.mesh as Node3D).global_position = center + t.center + Vector3(0, 0.04, 0)
	_beams.global_position = center + Vector3(0, 0.5, 0)


## Puts the whole dragon somewhere (for the intro), body trailing behind.
func place(pos: Vector3, look_at_pos: Vector3) -> void:
	head.global_position = pos
	_goal = pos
	_look = look_at_pos
	_face(look_at_pos - pos, 1.0)
	_history.clear()
	for i in SEGMENTS * GAP + 2:
		_history.append(pos + Vector3(0, 0, 1.0) * (SEGMENTS * GAP - i) * 0.05)
	_update_body(0.0)


# ---------------------------------------------------------------- flow

func phase() -> int:
	if god:
		return 5
	return MAX_HP - hp + 1


func start() -> void:
	_cycle = 0
	_go(B.RECOVER)
	_st = -0.6


func _next() -> void:
	var order: Array
	match phase():
		1: order = [B.STRIKE, B.DIVE_AIM]
		2: order = [B.SWEEP, B.GRID, B.DIVE_AIM]
		3: order = [B.STRIKE, B.GRID, B.SWEEP, B.DIVE_AIM]
		4: order = [B.STORM, B.GRID, B.STRIKE, B.DIVE_AIM, B.SWEEP, B.GRID, B.STORM, B.DIVE_AIM]
		_: order = [B.NOVA, B.STORM, B.GRID, B.DIVE_AIM, B.SWEEP, B.NOVA, B.GRID, B.STRIKE, B.DIVE_AIM, B.STORM]
	_go(order[_cycle % order.size()])
	_cycle += 1


func _go(s: B) -> void:
	state = s
	_st = 0.0
	_rate = 3.0
	_locked = false
	_beam_live = false
	_aim.visible = false
	match s:
		B.STRIKE, B.STORM:
			_next_bolt = 0.6
			_taunt()
			if s == B.STORM:
				_beam_angle = randf() * TAU
		B.SWEEP:
			_beam_angle = randf() * TAU
			_taunt()
		B.NOVA:
			_taunt()
		B.GRID:
			_round = 0
			_round_t = 0.0
			_taunt()
		B.DIVE_AIM:
			_pick_dive()
			_taunt()
		B.STUNNED:
			pass


func _taunt() -> void:
	if level and randf() < 0.6:
		level.bark("kilowatt", TAUNTS[randi() % TAUNTS.size()])


func _hover_point(y := 12.0) -> Vector3:
	return arena_center + Vector3(sin(_t * 0.5) * 3.0, y + sin(_t * 1.3) * 0.8, cos(_t * 0.4) * 2.0)


func _physics_process(delta: float) -> void:
	_t += delta
	_st += delta
	if head == null:
		return
	_light.light_energy = 3.0 + sin(_t * 47.0) * 1.2 + (randf() * 1.5 if fmod(_t, 0.4) < 0.05 else 0.0)
	_update_bolts(delta)
	_update_motes(delta)
	_update_waves(delta)
	if god:
		_god_flavour(delta)
	_update_tiles(delta)
	match state:
		B.WAIT:
			_goal = _hover_point(14.0)
			_look = arena_center
		B.RECOVER:
			_goal = _hover_point(14.0)
			_look = player.global_position if player else arena_center
			if _st > 1.6:
				_next()
		B.STRIKE:
			_st_strike(delta)
		B.STORM:
			_st_sweep(delta)
			_drop_bolts(delta, 1.3 if god else 1.6, 3 if god else 2)
		B.NOVA:
			_st_nova(delta)
		B.SWEEP:
			_st_sweep(delta)
		B.GRID:
			_st_grid(delta)
		B.DIVE_AIM:
			_st_aim()
		B.DIVE_RUN:
			_st_run()
		B.STUNNED:
			_st_stunned()
		B.DEAD:
			# He hangs there, sputtering, so the cutscene can watch him go.
			_goal = _dead_at + Vector3(0, 3.0 + sin(_t * 3.0) * 0.3, 0)
			_rate = 1.5
			_look = arena_center + Vector3(0, 3, 12)
	if state != B.DIVE_RUN:
		head.global_position = head.global_position.lerp(_goal, 1.0 - exp(-_rate * delta))
	_face(_look - head.global_position, 1.0 - exp(-6.0 * delta))
	_jaw.rotation.x = lerpf(_jaw.rotation.x, 0.5 if state in [B.STRIKE, B.DIVE_AIM, B.DIVE_RUN] else 0.05 + sin(_t * 3.0) * 0.03, 6.0 * delta)
	_core.scale = Vector3.ONE * (1.0 + (sin(_t * 12.0) * 0.4 if state == B.STUNNED else 0.0))
	_core_mat.emission = Color(1.0, 0.25, 0.3) if state == B.STUNNED else Color(0.5, 1.0, 1.0)
	_history.append(head.global_position)
	if _history.size() > SEGMENTS * GAP + 10:
		_history.pop_front()
	_update_body(delta)


func _face(dir: Vector3, k: float) -> void:
	if dir.length() < 0.01:
		return
	var target := Basis.looking_at(dir.normalized(), Vector3.UP)
	head.basis = head.basis.orthonormalized().slerp(target, clampf(k, 0.0, 1.0))
	head.scale = Vector3.ONE * _hs


func _update_body(_delta: float) -> void:
	var n := _history.size()
	for i in SEGMENTS:
		var idx := n - 1 - (i + 1) * GAP
		var p: Vector3 = _history[maxi(idx, 0)] if n > 0 else head.global_position
		# A little wave so the body writhes.
		p += Vector3(0, sin(_t * 5.0 - i * 0.6) * 0.35, 0)
		_segs[i].global_position = p
	if _wings:
		var base: Vector3 = _segs[1].global_position if not _segs.is_empty() else head.global_position
		_wings.global_position = base + Vector3(0, 0.6, 0)
		_wings.basis = head.basis.orthonormalized() * Basis.from_scale(Vector3.ONE * _hs * 1.2)
		var flap := sin(_t * 9.0) * 0.55
		_wing_l.rotation.z = flap + 0.15
		_wing_r.rotation.z = -flap - 0.15


# ---------------------------------------------------------------- STRIKE

func _st_strike(delta: float) -> void:
	_goal = _hover_point(12.0)
	_look = player.global_position if player else arena_center
	var rate: float = [1.3, 1.1, 0.95, 0.75, 0.6][phase() - 1]
	var extra: int = [1, 2, 3, 4, 5][phase() - 1]
	_drop_bolts(delta, rate, extra)
	if _st > 8.2:
		_go(B.RECOVER)
		_st = 0.6


func _drop_bolts(delta: float, rate: float, extra: int) -> void:
	_next_bolt -= delta
	if _next_bolt <= 0.0 and _st < 6.4 + (2.0 if state == B.STORM else 0.0):
		_next_bolt = rate
		_add_bolt(player.global_position)
		for i in extra:
			_add_bolt(arena_center + Vector3(randf_range(-HALF, HALF), 0, randf_range(-HALF, HALF)))


func _add_bolt(at: Vector3) -> void:
	var p := Vector3(clampf(at.x, arena_center.x - HALF + 1.0, arena_center.x + HALF - 1.0), arena_center.y + 0.06, clampf(at.z, arena_center.z - HALF + 1.0, arena_center.z + HALF - 1.0))
	var ring := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 2.4
	cm.bottom_radius = 2.4
	cm.height = 0.05
	ring.mesh = cm
	ring.material_override = Mats.unshaded(Color(1.0, 0.85, 0.2), 0.6)
	ring.top_level = true
	add_child(ring)
	ring.global_position = p
	_bolts.append({"pos": p, "t": 0.0, "ring": ring, "col": null, "fired": false})
	Audio.play("whoosh", 1.6, 0.1, -8.0)


func _update_bolts(delta: float) -> void:
	for b in _bolts.duplicate():
		b.t += delta
		if not b.fired and b.t >= 1.05:
			b.fired = true
			(b.ring.material_override as StandardMaterial3D).albedo_color = Color(1.0, 0.25, 0.3, 0.8)
			var col := MeshInstance3D.new()
			var cm := CylinderMesh.new()
			cm.top_radius = 0.7
			cm.bottom_radius = 1.6
			cm.height = 40.0
			col.mesh = cm
			col.material_override = _glow(Color(0.7, 0.95, 1.0), 8.0)
			col.top_level = true
			add_child(col)
			col.global_position = b.pos + Vector3(0, 20.0, 0)
			b.col = col
			Audio.play("thunder", 1.4, 0.1, -4.0)
			Audio.play("boom", 1.5, 0.1, -6.0)
			Fx.burst(self, b.pos + Vector3(0, 0.3, 0), Color(0.7, 0.95, 1.0), 40, 12.0, 0.25, 0.6, -8.0)
			Game.fx.flash(Color(0.7, 0.9, 1.0), 0.15)
			if level and level.rig:
				level.rig.shake(0.35)
			if player and not player.dead:
				var d := Vector2(player.global_position.x - b.pos.x, player.global_position.z - b.pos.z).length()
				if d < 2.4 and player.global_position.y < b.pos.y + 6.0:
					player.take_damage(1, b.pos)
		if b.fired and b.t > 1.4:
			b.ring.queue_free()
			if b.col:
				b.col.queue_free()
			_bolts.erase(b)


# ---------------------------------------------------------------- SWEEP

func _st_sweep(delta: float) -> void:
	_goal = arena_center + Vector3(0, 14.0, 0)
	_look = arena_center
	_rate = 4.0
	var lines := 3 if phase() >= 5 else (2 if (phase() >= 3 or state == B.STORM) else 1)
	if _st < 1.4:
		# Telegraph: thin, harmless lines.
		for i in _beam_lines.size():
			_beam_lines[i].visible = i < lines
			_beam_lines[i].scale = Vector3(0.2, 1.0, 1.0)
	else:
		if not _beam_live:
			_beam_live = true
			Audio.play("rumble", 1.8, 0.0, -4.0)
			for i in _beam_lines.size():
				_beam_lines[i].scale = Vector3(1.0, 1.0, 1.0)
		var w: float = [1.0, 1.25, 1.5, 1.9, 2.1][phase() - 1]
		if state == B.STORM:
			w = 1.4
		var dir := 1.0 if int(_cycle / 2.0) % 2 == 0 else -1.0
		# OVERLOAD reverses the sweep mid-spin.
		if phase() >= 4 and int(_st * 0.45) % 2 == 1:
			dir = -dir
		_beam_angle += w * delta * dir
	_beams.rotation.y = _beam_angle
	for i in _beam_lines.size():
		_beam_lines[i].rotation.y = i * PI / float(lines)
	if _beam_live and player and not player.dead:
		var rel := Vector2(player.global_position.x - arena_center.x, player.global_position.z - arena_center.z)
		if player.global_position.y < arena_center.y + 1.05:
			for i in lines:
				var a := _beam_angle + i * PI / float(lines)
				# The beam box is long in local Z, and rotation.y = a turns
				# local -Z toward (-sin a, -cos a).
				var d := Vector2(-sin(a), -cos(a))
				var along := rel.dot(d)
				var perp := absf(rel.x * d.y - rel.y * d.x)
				if absf(along) > 1.3 and perp < 0.85:
					player.take_damage(1, arena_center)
	if _st > (8.6 if state == B.STORM else 7.8):
		_end_beams()
		_go(B.RECOVER)
		_st = 0.6


func _end_beams() -> void:
	_beam_live = false
	for l in _beam_lines:
		l.visible = false


# ---------------------------------------------------------------- GRID

func _st_grid(delta: float) -> void:
	_goal = _hover_point(13.0)
	_look = arena_center
	_round_t += delta
	var rounds := 2 if phase() < 3 else (3 if phase() < 5 else 4)
	var warn_t := 1.3 if phase() < 4 else (1.0 if phase() < 5 else 0.85)
	if _round_t < 0.05 and _round < rounds:
		_pick_tiles()
	if _round_t > warn_t and _round_t <= warn_t + delta * 1.5:
		for t in _tiles:
			if t.warn:
				t.live = true
				t.mat.emission = Color(1.0, 0.2, 0.3)
				t.mat.emission_energy_multiplier = 4.5
		Audio.play("thunder", 1.3, 0.1, -6.0)
		Fx.burst(self, arena_center + Vector3(0, 0.5, 0), Color(1.0, 0.4, 0.4), 30, 9.0, 0.2, 0.5, -6.0)
		if level and level.rig:
			level.rig.shake(0.25)
	if _round_t > warn_t + 1.0:
		_clear_tiles()
		_round += 1
		_round_t = -0.4
		if _round >= rounds:
			_go(B.RECOVER)
			_st = 0.6


func _pick_tiles() -> void:
	_clear_tiles()
	var count: int = [4, 4, 5, 6, 7][phase() - 1]
	var order := range(9)
	order.shuffle()
	# One tile is always the one Stax is standing on, so he has to move.
	var mine := _tile_at(player.global_position) if player else -1
	if mine >= 0 and randf() < 0.75:
		order.erase(mine)
		order.push_front(mine)
	for i in count:
		var t = _tiles[order[i]]
		t.warn = true
		t.mat.emission = Color(1.0, 0.85, 0.2)
		t.mat.emission_energy_multiplier = 3.0
	Audio.play("clang", 1.6, 0.05, -8.0)


func _clear_tiles() -> void:
	for t in _tiles:
		t.warn = false
		t.live = false
		t.mat.emission = Color(0.1, 0.4, 0.9)
		t.mat.emission_energy_multiplier = 0.5


func _tile_at(p: Vector3) -> int:
	var gx := int(floorf((p.x - arena_center.x) / TILE + 1.5))
	var gz := int(floorf((p.z - arena_center.z) / TILE + 1.5))
	if gx < 0 or gx > 2 or gz < 0 or gz > 2:
		return -1
	return gx * 3 + gz


func _update_tiles(_delta: float) -> void:
	if state != B.GRID or player == null or player.dead:
		return
	if player.global_position.y > arena_center.y + 1.0:
		return
	var i := _tile_at(player.global_position)
	if i >= 0 and _tiles[i].live:
		player.take_damage(1, player.global_position)


# ---------------------------------------------------------------- DIVE

func _pick_dive() -> void:
	# He comes in from a random side of the stage.
	var a := randf() * TAU
	_dive_from = arena_center + Vector3(sin(a) * (HALF + 9.0), 7.0, cos(a) * (HALF + 9.0))
	_dive_to = arena_center


func _st_aim() -> void:
	var dur := 1.35 if phase() >= 4 else 1.9
	_goal = _dive_from
	_rate = 5.0
	if not _locked:
		# Follow Stax until the last moment...
		var target := player.global_position if player else arena_center
		var dir := Vector3(target.x - _dive_from.x, 0, target.z - _dive_from.z).normalized()
		_dive_to = Vector3(target.x, arena_center.y + 1.4 * _hs, target.z) + dir * 3.5
		_dive_to.x = clampf(_dive_to.x, arena_center.x - HALF + 2.0, arena_center.x + HALF - 2.0)
		_dive_to.z = clampf(_dive_to.z, arena_center.z - HALF + 2.0, arena_center.z + HALF - 2.0)
		if _st > dur * 0.5:
			_locked = true
			Audio.play("clang", 0.7, 0.0, -4.0)
	_look = _dive_to
	# The warning stripe, from the edge of the stage to where he'll land.
	var a := Vector3(_dive_from.x, arena_center.y + 0.09, _dive_from.z)
	var b := Vector3(_dive_to.x, arena_center.y + 0.09, _dive_to.z)
	var len := a.distance_to(b)
	_aim.visible = true
	_aim.global_position = (a + b) * 0.5
	_aim.look_at(b, Vector3.UP)
	_aim.scale = Vector3(1.0, 1.0, len)
	(_aim.material_override as StandardMaterial3D).albedo_color = Color(1.0, 0.2, 0.3, 0.35 + 0.35 * (0.5 + 0.5 * sin(_st * 22.0)) if _locked else 0.3)
	if _st > dur:
		_go(B.DIVE_RUN)
		Audio.play("whoosh", 0.6)
		Audio.play("rumble", 1.6, 0.0, -2.0)


func _st_run() -> void:
	var dur := 0.55 if phase() >= 4 else 0.7
	var k := clampf(_st / dur, 0.0, 1.0)
	var e := k * k
	var from := _dive_from
	head.global_position = from.lerp(_dive_to, e) + Vector3(0, sin(k * PI) * 1.5, 0)
	_look = _dive_to
	if player and not player.dead:
		var h := head.global_position
		var d := Vector2(player.global_position.x - h.x, player.global_position.z - h.z).length()
		if d < 2.3 * _hs and player.global_position.y < h.y + 1.7 * _hs and player.global_position.y > h.y - 3.0:
			player.take_damage(1, h)
	if k >= 1.0:
		_aim.visible = false
		_crash()


func _crash() -> void:
	# OVERLOAD: the first crash is a fake-out. He rips his head out of the
	# floor and charges again before there's time to stomp.
	if phase() >= 4 and _fakes < (2 if god else 1):
		_fakes += 1
		Audio.play("boom", 0.8)
		Fx.burst(self, head.global_position, Color(0.7, 0.95, 1.0), 50, 14.0, 0.25, 0.7, -6.0)
		if level and level.rig:
			level.rig.shake(0.6)
		_go(B.DIVE_AIM)
		return
	_fakes = 0
	state = B.STUNNED
	_st = 0.0
	Audio.play("boom", 0.6)
	Audio.play("hit_low", 0.5)
	Audio.play("thunder", 0.9)
	Game.fx.flash(Color(0.8, 0.95, 1.0), 0.4)
	Game.fx.aberrate(0.8, 0.5)
	if level and level.rig:
		level.rig.shake(0.9)
	Fx.burst(self, head.global_position, Color(0.7, 0.95, 1.0), 80, 16.0, 0.3, 0.9, -6.0)
	Fx.burst(self, head.global_position, Color(1.0, 0.85, 0.3), 30, 10.0, 0.2, 0.7, -8.0, "coin")
	if level and not _told:
		_told = true
		level.bark("steve", "His head's cracked open and the core is showing! STOMP it, or ground pound it!")
	# Where he crashed, the electric floor goes dark for a moment.
	_clear_tiles()


func _st_stunned() -> void:
	var stun: float = [4.6, 4.0, 3.5, 2.8, 2.4][phase() - 1]
	_goal = Vector3(head.global_position.x, arena_center.y + 1.4 * _hs, head.global_position.z)
	_rate = 12.0
	var fwd := -head.global_transform.basis.z.normalized()
	_look = head.global_position + Vector3(fwd.x, 0, fwd.z) * 5.0
	_head_hit_check()
	if state == B.STUNNED and _st > stun:
		Audio.play("whoosh", 0.8)
		_go(B.RECOVER)
		_st = 0.0


func _head_hit_check() -> void:
	if player == null or player.dead:
		return
	var p := player.global_position
	var h := head.global_position
	var flat := Vector2(p.x - h.x, p.z - h.z).length()
	var pounded: bool = player.state == player.S.POUND_LAND and flat < 4.2 * _hs
	var stomped: bool = flat < 2.7 * _hs and p.y > h.y + 0.7 * _hs and p.y < h.y + 3.2 * _hs and player.velocity.y <= 0.0 and not player.is_on_floor()
	if pounded or stomped:
		take_hit()


# ---------------------------------------------------------------- hits

func take_hit() -> void:
	if state == B.DEAD:
		return
	hp -= 1
	hit.emit(hp)
	_clear_attacks()
	Audio.play("clang", 0.5)
	Audio.play("boom", 1.2)
	Audio.play("checkpoint", 0.7 + (MAX_HP - hp) * 0.15)
	Game.fx.flash(Color(1.0, 1.0, 1.0), 0.5)
	Game.fx.aberrate(1.0, 0.6)
	if level and level.rig:
		level.rig.shake(1.0)
	Fx.burst(self, head.global_position, Color(0.7, 0.95, 1.0), 90, 18.0, 0.3, 1.0, -4.0)
	Fx.burst(self, head.global_position, Color(1.0, 0.85, 0.3), 30, 12.0, 0.2, 0.8, -10.0, "coin")
	if player:
		player.bounce(16.0, false)
	if hp <= 0:
		state = B.DEAD
		_st = 0.0
		_dead_at = head.global_position
		defeated.emit()
		return
	if hp == 1 and not god:
		_light.light_color = Color(1.0, 0.45, 0.4)
		Audio.play("thunder", 0.6)
	if level:
		if god:
			level.bark("goddragon", GOD_LINES[(GOD_HP - hp - 1) % GOD_LINES.size()])
		else:
			level.bark("kilowatt", HIT_LINES[(MAX_HP - hp - 1) % HIT_LINES.size()])
	_go(B.RECOVER)
	_st = -0.6


## Knocked out: the current phase starts over. Health stays where it was.
func reset() -> void:
	_clear_attacks()
	_cycle = 0
	_go(B.RECOVER)
	_st = -0.4


func _clear_attacks() -> void:
	for b in _bolts:
		b.ring.queue_free()
		if b.col:
			b.col.queue_free()
	_bolts.clear()
	for w in _waves:
		w.node.queue_free()
	_waves.clear()
	_clear_tiles()
	_end_beams()
	_aim.visible = false
	_locked = false
	_fakes = 0
	_rate = 3.0


# ---------------------------------------------------------------- NOVA

func _st_nova(delta: float) -> void:
	_goal = arena_center + Vector3(0, 13.0, 0)
	_look = arena_center
	_rate = 4.0
	var gap := 1.0 if god else 1.3
	if _st < 6.0 and fmod(_st, gap) < delta:
		_spawn_wave()
	if _st > 7.6:
		_go(B.RECOVER)
		_st = 0.6


func _spawn_wave() -> void:
	var ring := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.93
	tm.outer_radius = 1.07
	tm.rings = 32
	ring.mesh = tm
	ring.material_override = _glow(Color(1.0, 0.3, 0.9), 5.0)
	ring.top_level = true
	add_child(ring)
	ring.global_position = arena_center + Vector3(0, 0.15, 0)
	_waves.append({"node": ring, "r": 1.0})
	Audio.play("boom", 1.1, 0.05, -4.0)
	if level and level.rig:
		level.rig.shake(0.3)


func _update_waves(delta: float) -> void:
	for w in _waves.duplicate():
		w.r += (10.0 if god else 8.0) * delta
		(w.node as Node3D).scale = Vector3(w.r, 1.0, w.r)
		if player and not player.dead and player.global_position.y < arena_center.y + 1.0:
			var flat := Vector2(player.global_position.x - arena_center.x, player.global_position.z - arena_center.z).length()
			if absf(flat - w.r) < 0.9:
				player.take_damage(1, arena_center)
		if w.r > 28.0:
			w.node.queue_free()
			_waves.erase(w)


# ---------------------------------------------------------------- the horror

## He comes apart into a cloud of lights.
func disperse() -> void:
	for n in [head] + _segs + [_wings]:
		(n as Node3D).visible = false
	_mote_mode = 1
	var spots: Array[Vector3] = [head.global_position]
	for s in _segs:
		spots.append(s.global_position)
	var small := _sphere(0.2)
	var big := _sphere(0.35)
	for i in 70:
		var m := MeshInstance3D.new()
		m.mesh = small if i % 3 else big
		var cols := [Color(0.7, 0.95, 1.0), Color(1.0, 1.0, 1.0), Color(1.0, 0.4, 0.8), Color(0.6, 0.5, 1.0)]
		m.material_override = _glow(cols[i % cols.size()], 4.0)
		m.top_level = true
		add_child(m)
		m.global_position = spots[i % spots.size()] + Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1))
		_motes.append({"node": m, "vel": Vector3(randf_range(-4, 4), randf_range(-1, 6), randf_range(-4, 4)), "ph": randf() * TAU})
	_light.light_energy = 0.0
	_light.visible = false


## The lights swirl in toward a point.
func gather(to: Vector3) -> void:
	_gather_to = to
	_gather_t = 0.0
	_mote_mode = 2


func _update_motes(delta: float) -> void:
	if _mote_mode == 0:
		return
	if _mote_mode == 2:
		_gather_t += delta
	for m in _motes:
		var n: Node3D = m.node
		if _mote_mode == 1:
			m.vel += Vector3(randf_range(-1, 1), randf_range(-0.6, 1), randf_range(-1, 1)) * delta * 8.0
			m.vel = m.vel.limit_length(5.0)
			n.global_position += m.vel * delta
		else:
			var to: Vector3 = _gather_to - n.global_position
			var tang := Vector3(-to.z, 0.0, to.x).normalized()
			n.global_position += (to * 1.6 + tang * clampf(to.length() * 0.7, 0.0, 12.0)) * delta * (0.35 + _gather_t * 0.6)
		n.scale = Vector3.ONE * (0.7 + 0.5 * sin(_t * 9.0 + m.ph))


## The lights become the god dragon: bigger, hotter, and not at all polite.
func become_god(at: Vector3, look_at_pos: Vector3) -> void:
	_mote_mode = 0
	for m in _motes:
		m.node.queue_free()
	_motes.clear()
	god = true
	hp = GOD_HP
	_hs = 1.55
	_light.visible = true
	_light.light_color = Color(1.0, 0.35, 0.9)
	_light.omni_range = 45.0
	for n in [head] + _segs + [_wings]:
		(n as Node3D).visible = true
	for i in _segs.size():
		var seg := _segs[i]
		seg.material_override = _glow(Color(1.0, 0.2, 0.6) if i % 2 == 0 else Color(1, 1, 1), 3.5)
		seg.scale = Vector3.ONE * 1.5
	# A halo of three turning rings behind his head.
	for i in 3:
		var ring := MeshInstance3D.new()
		var tm := TorusMesh.new()
		tm.inner_radius = 2.6 + i * 0.7
		tm.outer_radius = 2.75 + i * 0.7
		ring.mesh = tm
		ring.material_override = _glow(Color(1.0, 0.4, 0.9) if i % 2 == 0 else Color(0.6, 0.9, 1.0), 4.0)
		ring.position = Vector3(0, 0.6, 1.6)
		ring.rotation.x = PI / 2
		head.add_child(ring)
		_halos.append(ring)
	_core_mat.emission_energy_multiplier = 8.0
	place(at, look_at_pos)
	_cycle = 0
	_go(B.RECOVER)
	_st = -1.0


func _god_flavour(delta: float) -> void:
	for i in _halos.size():
		_halos[i].rotation.z += delta * (1.5 + i * 0.8) * (1.0 if i % 2 == 0 else -1.0)
		_halos[i].rotation.y = sin(_t * 0.7 + i) * 0.4
	_light.light_energy = 3.0 + sin(_t * 61.0) * 2.5
	_aberrate_t -= delta
	if _aberrate_t <= 0.0:
		_aberrate_t = randf_range(2.0, 4.5)
		Game.fx.aberrate(0.7, 0.35)
