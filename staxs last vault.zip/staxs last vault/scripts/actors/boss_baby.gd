extends Node3D
## Baby Bigbucks, the richest (and largest) baby in the multiverse. Stax
## never hits him: the bar is his fussiness, and the goal is naptime.
## Loop: hurl alphabet blocks (dodge the red rings) -> butt-bounce (jump the
## shockwaves) -> yawn. While he yawns a Lullaby Star pops up somewhere on
## the play mat: stomp or ground-pound it before he shakes it off. Three
## lullabies and he's out cold.

signal hit(hp: int)
signal defeated

const Puppet := preload("res://scripts/actors/puppet.gd")
const Mats := preload("res://scripts/world/mats.gd")
const Fx := preload("res://scripts/world/fx.gd")

const S := 4.2            # model scale
const MAX_HP := 3
const BODY_R := 3.6       # the collision cylinder Stax bumps into

enum B { WAIT, THROW, BOUNCE, TIRED, CRY, DEAD }

const CRY_LINES := [
	"WAAAAAH! NO NAP! NO NAAAP!",
	"Mmmh... NO! Not sleepy! NOT SLEEPYYY!",
]
const TANTRUM_LINES := [
	"NUH-UH! MINE!",
	"NO LULLABY! MORE BLOCKS!",
	"Baby says NO.",
]
const LETTERS := "ABCDEFGHIJKLMNOPQRSTUVWXYZ$"
const BLOCK_COLORS := [Color(0.95, 0.3, 0.3), Color(0.3, 0.6, 1.0), Color(1.0, 0.8, 0.2), Color(0.35, 0.8, 0.4)]

var player: CharacterBody3D
var level: Node3D
var arena_center := Vector3.ZERO
var arena_radius := 18.0
var puppet: Node3D
var hp := MAX_HP
var state: B = B.WAIT
var _t := 0.0
var _home := Vector3.ZERO
var _bounces_left := 0
var _thrown := false
var _loops := 0
var _blocks: Array = []
var _waves: Array = []
var _star: Node3D
var _star_mat: StandardMaterial3D
var _body: StaticBody3D


func _ready() -> void:
	puppet = Puppet.new()
	puppet.kind = "baby"
	puppet.speaker = "baby"
	puppet.scale = Vector3.ONE * S
	add_child(puppet)
	_body = StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = BODY_R
	shape.height = 9.0
	cs.shape = shape
	cs.position.y = 4.5
	_body.add_child(cs)
	add_child(_body)
	_build_star()


func phase() -> int:
	return MAX_HP - hp + 1


func start() -> void:
	_home = global_position
	_go(B.THROW)


func _go(s: B) -> void:
	state = s
	_t = 0.0
	_thrown = false


func _physics_process(delta: float) -> void:
	_t += delta
	_update_blocks(delta)
	_update_waves(delta)
	_update_star(delta)
	if player == null or state == B.WAIT or state == B.DEAD:
		return
	match state:
		B.THROW: _st_throw()
		B.BOUNCE: _st_bounce()
		B.TIRED: _st_tired()
		B.CRY:
			if _t > 1.8:
				puppet.emote = ""
				_go(B.THROW)


# ---------------------------------------------------------------- states

func _st_throw() -> void:
	if not _thrown and _t > 0.2:
		puppet.emote = "throw"
	if not _thrown and _t > 0.7:
		_thrown = true
		puppet.emote = ""
		_throw_blocks()
	if _t > 2.8:
		_bounces_left = [1, 2, 3][phase() - 1]
		_go(B.BOUNCE)
		Audio.play("whoosh", 0.7)


func _st_bounce() -> void:
	var dur := 1.0 - phase() * 0.08
	var k := clampf(_t / dur, 0.0, 1.0)
	global_position = _home + Vector3(0, sin(k * PI) * 4.0, 0)
	puppet.squash = 1.0 + sin(k * PI) * 0.15
	if k >= 1.0:
		global_position = _home
		puppet.squash = 0.6
		Audio.play("boom", 0.8)
		Audio.play("boing", 0.5)
		if level and level.rig:
			level.rig.shake(0.5)
		Fx.burst(get_parent(), _home + Vector3(0, 0.3, 4.0), Color(1.0, 0.95, 0.9, 0.9), 40, 10.0, 0.7, 0.8, -6.0)
		_spawn_wave(Vector3(_home.x, arena_center.y, _home.z))
		_bounces_left -= 1
		if _bounces_left > 0:
			_t = -0.25
		else:
			_begin_tired()


func _begin_tired() -> void:
	_go(B.TIRED)
	_loops += 1
	puppet.emote = "sleepy"
	Audio.play("whoosh", 0.4, 0.0, -6.0)
	if level:
		level.bark("baby", "Hwaaaahhh... *yawn*")
	_show_star()
	if level and level.has_method("on_boss_tired"):
		level.on_boss_tired()


func _st_tired() -> void:
	if _star_pressed():
		take_hit()
		return
	if _t > [7.0, 6.0, 5.2][phase() - 1]:
		# He shakes the yawn off. Tantrum.
		_hide_star(false)
		puppet.emote = "tantrum"
		Audio.play("rumble", 1.3)
		if level:
			level.bark("baby", TANTRUM_LINES[_loops % TANTRUM_LINES.size()])
			if level.rig:
				level.rig.shake(0.4)
		_go(B.CRY)


# ---------------------------------------------------------------- the Lullaby Star

func _build_star() -> void:
	_star = Node3D.new()
	_star.top_level = true
	_star.visible = false
	add_child(_star)
	var base := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 1.3
	cm.bottom_radius = 1.5
	cm.height = 0.6
	base.mesh = cm
	base.material_override = Mats.toon(Color(0.55, 0.4, 0.9))
	base.position.y = 0.3
	_star.add_child(base)
	var top := MeshInstance3D.new()
	var tm := CylinderMesh.new()
	tm.top_radius = 1.0
	tm.bottom_radius = 1.1
	tm.height = 0.4
	top.mesh = tm
	# Its own copy: it pulses, and the shared material is used elsewhere.
	_star_mat = Mats.glow(Color(1.0, 0.85, 0.3), 3.0).duplicate()
	top.material_override = _star_mat
	top.position.y = 0.75
	top.name = "Top"
	_star.add_child(top)
	for i in 5:
		var a := TAU * i / 5.0
		var pt := MeshInstance3D.new()
		var pm := PrismMesh.new()
		pm.size = Vector3(0.7, 0.9, 0.35)
		pt.mesh = pm
		pt.material_override = _star_mat
		pt.position = Vector3(sin(a) * 1.35, 0.75, cos(a) * 1.35)
		pt.rotation = Vector3(PI / 2, a, 0)
		pt.rotation_order = EULER_ORDER_YXZ
		_star.add_child(pt)
	# A beam of light so it's easy to spot from anywhere on the mat.
	var beam := MeshInstance3D.new()
	var bm := CylinderMesh.new()
	bm.top_radius = 0.9
	bm.bottom_radius = 0.9
	bm.height = 14.0
	bm.cap_top = false
	bm.cap_bottom = false
	beam.mesh = bm
	beam.material_override = Mats.unshaded(Color(1.0, 0.9, 0.5), 0.18)
	beam.position.y = 7.0
	beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_star.add_child(beam)
	var l := OmniLight3D.new()
	l.light_color = Color(1.0, 0.85, 0.5)
	l.omni_range = 7.0
	l.light_energy = 2.0
	l.position.y = 2.0
	_star.add_child(l)
	var note := Label3D.new()
	note.text = "♪"
	note.font_size = 160
	note.pixel_size = 0.01
	note.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	note.modulate = Color(1.0, 0.9, 0.5)
	note.position.y = 3.0
	note.name = "Note"
	_star.add_child(note)


func _show_star() -> void:
	# Somewhere on the mat, away from both Stax and the baby.
	var best := arena_center
	var best_score := -1e9
	for i in 12:
		var a := randf() * TAU
		var d := randf_range(5.0, arena_radius - 4.0)
		var p := arena_center + Vector3(sin(a) * d, 0, cos(a) * d)
		var from_baby := Vector2(p.x - _home.x, p.z - _home.z).length()
		if from_baby < BODY_R + 4.0:
			continue
		var from_stax := Vector2(p.x - player.global_position.x, p.z - player.global_position.z).length()
		var score := -absf(from_stax - 9.0)
		if score > best_score:
			best_score = score
			best = p
	_star.global_position = best
	_star.scale = Vector3.ONE * 0.05
	_star.visible = true
	create_tween().tween_property(_star, "scale", Vector3.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	Audio.play("pop", 1.3)
	Fx.burst(get_parent(), best + Vector3(0, 1, 0), Color(1.0, 0.9, 0.5), 20, 5.0, 0.25, 0.7, -3.0)


func _hide_star(played: bool) -> void:
	if not _star.visible:
		return
	var p := _star.global_position
	_star.visible = false
	if played:
		Fx.burst(get_parent(), p + Vector3(0, 1.5, 0), Color(1.0, 0.85, 0.4), 40, 8.0, 0.3, 1.2, -2.0)
		Fx.burst(get_parent(), p + Vector3(0, 1.0, 0), Color(0.7, 0.6, 1.0), 20, 5.0, 0.4, 1.4, 1.5)
	else:
		Fx.burst(get_parent(), p + Vector3(0, 1.0, 0), Color(0.6, 0.5, 0.9, 0.7), 16, 4.0, 0.3, 0.6, -4.0)


func _update_star(delta: float) -> void:
	if not _star.visible:
		return
	_star.rotation.y += delta * 1.5
	_star.get_node("Note").position.y = 3.0 + sin(_t * 3.0) * 0.3
	_star_mat.emission_energy_multiplier = 2.5 + sin(_t * 8.0) * 1.2


func _star_pressed() -> bool:
	if not _star.visible or player == null or player.dead:
		return false
	var p := player.global_position
	var sp := _star.global_position
	var flat := Vector2(p.x - sp.x, p.z - sp.z).length()
	var top := sp.y + 0.95
	if flat > 1.8:
		return false
	var pounded: bool = player.state == player.S.POUND_LAND
	var stomped: bool = p.y > top - 0.5 and p.y < top + 1.0 and player.velocity.y <= 0.0 and not player.is_on_floor()
	return pounded or stomped


## Registers a lullaby (also used by the automated tests).
func take_hit() -> void:
	if state == B.DEAD:
		return
	hp -= 1
	hit.emit(hp)
	_hide_star(true)
	# A little music-box chime, climbing with each lullaby.
	Audio.play("checkpoint", 0.9 + (MAX_HP - hp) * 0.12, 0.0)
	Audio.play("bong", 1.6, 0.0, -6.0)
	Game.fx.flash(Color(0.85, 0.8, 1.0), 0.3)
	if player:
		player.bounce(15.0, false)
	puppet.squash = 0.7
	if hp <= 0:
		_die()
		return
	puppet.emote = "cry"
	if level:
		level.bark("baby", CRY_LINES[(MAX_HP - hp - 1) % CRY_LINES.size()])
	_go(B.CRY)


## Back to square one, for a fresh attempt after Stax is knocked out.
func reset(at: Vector3) -> void:
	_clear_attacks()
	hp = MAX_HP
	_loops = 0
	puppet.emote = ""
	global_position = at
	_home = at
	_go(B.THROW)


func _die() -> void:
	state = B.DEAD
	_clear_attacks()
	puppet.emote = "asleep"
	defeated.emit()


func _clear_attacks() -> void:
	for b in _blocks:
		b.node.queue_free()
		b.ring.queue_free()
	_blocks.clear()
	for w in _waves:
		w.node.queue_free()
	_waves.clear()
	_star.visible = false


# ---------------------------------------------------------------- attacks

func _disc(r: float, color: Color) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var c := CylinderMesh.new()
	c.top_radius = r
	c.bottom_radius = r
	c.height = 0.04
	c.radial_segments = 32
	m.mesh = c
	m.material_override = Mats.unshaded(color, 0.5)
	get_parent().add_child(m)
	return m


func _throw_blocks() -> void:
	var count: int = [4, 6, 8][phase() - 1]
	var hand: Vector3 = puppet.parts.rattle.global_position
	Audio.play("whoosh", 1.2)
	if level and _loops == 0:
		level.bark("baby", "BLOCKS! Baby share! Baby share HARD!")
	for i in count:
		var target := player.global_position if i == 0 else player.global_position + Vector3(randf_range(-7, 7), 0, randf_range(-7, 7))
		target = _clamp(target)
		var ring := _disc(2.2, Color(1.0, 0.2, 0.1))
		ring.global_position = target + Vector3(0, 0.04, 0)
		var blk := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3.ONE * 1.3
		blk.mesh = bm
		blk.material_override = Mats.toon(BLOCK_COLORS[i % BLOCK_COLORS.size()])
		var letter := Label3D.new()
		letter.text = LETTERS[randi() % LETTERS.length()]
		letter.font = Mats.bold_font()
		letter.font_size = 96
		letter.pixel_size = 0.01
		letter.position.z = 0.66
		letter.modulate = Color.WHITE
		blk.add_child(letter)
		get_parent().add_child(blk)
		blk.global_position = hand
		_blocks.append({"node": blk, "ring": ring, "from": hand, "to": target, "t": -i * 0.18, "dur": 1.3,
			"spin": Vector3(randf_range(-6, 6), randf_range(-6, 6), randf_range(-6, 6))})


func _clamp(p: Vector3) -> Vector3:
	var d := p - arena_center
	d.y = 0.0
	if d.length() > arena_radius - 2.0:
		d = d.normalized() * (arena_radius - 2.0)
	var out := Vector3(arena_center.x + d.x, arena_center.y, arena_center.z + d.z)
	# Not inside the baby.
	var from_baby := Vector2(out.x - _home.x, out.z - _home.z)
	if from_baby.length() < BODY_R + 1.5:
		var push := from_baby.normalized() if from_baby.length() > 0.01 else Vector2(0, 1)
		push *= BODY_R + 1.5
		out.x = _home.x + push.x
		out.z = _home.z + push.y
	return out


func _update_blocks(delta: float) -> void:
	for b in _blocks.duplicate():
		b.t += delta
		var node: MeshInstance3D = b.node
		var ring: MeshInstance3D = b.ring
		ring.scale = Vector3.ONE * (0.8 + 0.2 * sin(b.t * 18.0))
		if b.t < 0.0:
			node.visible = false
			continue
		node.visible = true
		var k: float = clampf(b.t / b.dur, 0.0, 1.0)
		node.global_position = b.from.lerp(b.to, k) + Vector3(0, sin(k * PI) * 10.0 + 0.65 * k, 0)
		node.rotation += b.spin * delta
		if k >= 1.0:
			Audio.play("clang", 1.4, 0.1, -3.0)
			Audio.play("stomp", 0.8, 0.1, -4.0)
			Fx.burst(get_parent(), b.to + Vector3(0, 0.5, 0), node.material_override.albedo_color, 18, 7.0, 0.35, 0.6, -10.0, "cube")
			if player and not player.dead:
				var d := Vector2(player.global_position.x - b.to.x, player.global_position.z - b.to.z).length()
				if d < 2.3 and player.global_position.y < b.to.y + 2.0:
					player.take_damage(1, b.to)
			node.queue_free()
			ring.queue_free()
			_blocks.erase(b)


func _spawn_wave(at: Vector3) -> void:
	var ring := MeshInstance3D.new()
	var tor := TorusMesh.new()
	tor.inner_radius = 0.85
	tor.outer_radius = 1.0
	tor.rings = 48
	tor.ring_segments = 8
	ring.mesh = tor
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.75, 0.85, 1.0, 0.9)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.emission_enabled = true
	m.emission = Color(0.6, 0.7, 1.0)
	m.emission_energy_multiplier = 2.5
	ring.material_override = m
	get_parent().add_child(ring)
	ring.global_position = at + Vector3(0, 0.35, 0)
	_waves.append({"node": ring, "r": BODY_R, "mat": m, "center": at})


func _update_waves(delta: float) -> void:
	for w in _waves.duplicate():
		w.r += delta * (10.0 + phase() * 1.5)
		var node: MeshInstance3D = w.node
		node.scale = Vector3(w.r, 1.3, w.r)
		w.mat.albedo_color.a = clampf(1.2 - w.r / (arena_radius * 2.0), 0.0, 1.0)
		if player and not player.dead:
			var flat := Vector2(player.global_position.x - w.center.x, player.global_position.z - w.center.z).length()
			if absf(flat - w.r) < 0.8 and player.global_position.y < w.center.y + 0.9:
				player.take_damage(1, w.center)
		if w.r > arena_radius * 2.0 + 2.0:
			node.queue_free()
			_waves.erase(w)
