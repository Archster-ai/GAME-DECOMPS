extends Node3D
## Stax: a blocky kid in a red hood, brown jacket, teal tee, gold chain and
## dollar-sign shades. Built from primitives with a cartoon outline.
## Feet at y = 0, facing -Z. Limbs are posed procedurally.

const Mats := preload("res://scripts/world/mats.gd")

const SKIN := Color(0.98, 0.8, 0.63)
const HAIR := Color(0.42, 0.22, 0.1)
const HAIR_LIGHT := Color(0.55, 0.31, 0.15)
const HOOD := Color(0.74, 0.12, 0.08)
const JACKET := Color(0.27, 0.18, 0.13)
const SHIRT := Color(0.08, 0.42, 0.42)
const PANTS := Color(0.17, 0.21, 0.16)
const SHOE := Color(0.1, 0.1, 0.11)

## Current emote, overriding movement poses: "", wave, cheer, shocked, point,
## shrug, hold, think, facepalm, sad, dance, cool.
var emote := ""
## Where the head should look, in local yaw radians.
var head_yaw := 0.0

var arm_l: Node3D
var arm_r: Node3D
var leg_l: Node3D
var leg_r: Node3D
var head: Node3D
var torso: Node3D
var lens_mat: StandardMaterial3D
var _phase := 0.0
var _t := 0.0


func _ready() -> void:
	scale = Vector3.ONE * 0.86
	_build()


func _box(size: Vector3, color: Color, pos: Vector3, parent: Node3D, outline := true, rot := Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = size
	mi.mesh = b
	mi.material_override = Mats.toon(color) if outline else Mats.solid(color, 0.7)
	mi.position = pos
	mi.rotation = rot
	parent.add_child(mi)
	return mi


func _build() -> void:
	torso = Node3D.new()
	torso.position.y = 0.62
	add_child(torso)

	# Legs pivot at the hips.
	leg_l = _limb(Vector3(-0.155, 0.62, 0))
	leg_r = _limb(Vector3(0.155, 0.62, 0))
	for leg in [leg_l, leg_r]:
		_box(Vector3(0.29, 0.52, 0.3), PANTS, Vector3(0, -0.26, 0), leg)
		_box(Vector3(0.31, 0.14, 0.38), SHOE, Vector3(0, -0.55, -0.03), leg)
		_box(Vector3(0.32, 0.04, 0.39), Color(0.92, 0.92, 0.9), Vector3(0, -0.6, -0.03), leg, false)

	# Jacket body with an open front showing the tee.
	_box(Vector3(0.64, 0.64, 0.36), JACKET, Vector3(0, 0.31, 0), torso)
	_box(Vector3(0.26, 0.6, 0.02), SHIRT, Vector3(0, 0.3, -0.185), torso, false)
	_box(Vector3(0.05, 0.62, 0.03), Color(0.2, 0.13, 0.09), Vector3(-0.155, 0.31, -0.18), torso, false)
	_box(Vector3(0.05, 0.62, 0.03), Color(0.2, 0.13, 0.09), Vector3(0.155, 0.31, -0.18), torso, false)
	# Hood bunched around the neck at the back.
	_box(Vector3(0.6, 0.16, 0.24), HOOD, Vector3(0, 0.64, 0.1), torso)

	# Gold chain: links in a U across the chest and a dollar pendant.
	var links := 13
	for i in links:
		var t := float(i) / (links - 1)
		var x := lerpf(-0.2, 0.2, t)
		var y := 0.62 - (1.0 - pow(2.0 * t - 1.0, 2.0)) * 0.26
		var link := MeshInstance3D.new()
		var torus := TorusMesh.new()
		torus.inner_radius = 0.016
		torus.outer_radius = 0.034
		torus.rings = 8
		torus.ring_segments = 6
		link.mesh = torus
		link.material_override = Mats.gold()
		link.position = Vector3(x, y, -0.2)
		link.rotation = Vector3(PI / 2, 0, float(i % 2) * PI / 2 + (t - 0.5))
		torso.add_child(link)
	var pendant := MeshInstance3D.new()
	pendant.mesh = Mats.dollar_mesh()
	pendant.material_override = Mats.gold()
	pendant.position = Vector3(0, 0.26, -0.22)
	pendant.scale = Vector3(0.2, 0.2, 0.3)
	torso.add_child(pendant)

	# Arms pivot at the shoulders.
	arm_l = _limb(Vector3(-0.44, 1.2, 0))
	arm_r = _limb(Vector3(0.44, 1.2, 0))
	for arm in [arm_l, arm_r]:
		_box(Vector3(0.25, 0.5, 0.3), JACKET, Vector3(0, -0.22, 0), arm)
		_box(Vector3(0.27, 0.06, 0.32), Color(0.2, 0.13, 0.09), Vector3(0, -0.47, 0), arm, false)
		_box(Vector3(0.22, 0.16, 0.24), SKIN, Vector3(0, -0.58, 0), arm)

	_build_head()


func _limb(pos: Vector3) -> Node3D:
	var n := Node3D.new()
	n.position = pos
	add_child(n)
	return n


func _build_head() -> void:
	head = Node3D.new()
	head.position.y = 1.24
	add_child(head)
	_box(Vector3(0.56, 0.52, 0.52), SKIN, Vector3(0, 0.28, 0), head)

	# Smile decal.
	var face := MeshInstance3D.new()
	var quad := QuadMesh.new()
	quad.size = Vector2(0.5, 0.46)
	face.mesh = quad
	var fm := StandardMaterial3D.new()
	fm.albedo_texture = ImageTexture.create_from_image(_face_image())
	fm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	fm.roughness = 0.8
	face.material_override = fm
	face.position = Vector3(0, 0.26, -0.262)
	face.rotation.y = PI
	head.add_child(face)

	# Hair: a cap, a big fringe swoop and tufts flicking out to the left.
	_box(Vector3(0.6, 0.14, 0.56), HAIR, Vector3(0, 0.56, 0), head)
	_box(Vector3(0.58, 0.12, 0.1), HAIR, Vector3(0.02, 0.47, -0.25), head, true, Vector3(0, 0, -0.1))
	_box(Vector3(0.3, 0.1, 0.1), HAIR_LIGHT, Vector3(-0.1, 0.42, -0.28), head, true, Vector3(0, 0, 0.35))
	_box(Vector3(0.22, 0.09, 0.1), HAIR, Vector3(0.14, 0.41, -0.275), head, true, Vector3(0, 0, -0.45))
	_box(Vector3(0.26, 0.08, 0.14), HAIR, Vector3(-0.36, 0.5, -0.12), head, true, Vector3(0, 0.3, 0.5))
	_box(Vector3(0.22, 0.07, 0.12), HAIR_LIGHT, Vector3(-0.4, 0.4, -0.02), head, true, Vector3(0, 0.1, 0.8))
	_box(Vector3(0.08, 0.22, 0.2), HAIR, Vector3(-0.29, 0.3, -0.14), head)
	_box(Vector3(0.08, 0.22, 0.2), HAIR, Vector3(0.29, 0.3, -0.14), head)

	# Hood: back, sides and top, open at the face.
	_box(Vector3(0.72, 0.7, 0.12), HOOD, Vector3(0, 0.3, 0.32), head)
	_box(Vector3(0.1, 0.66, 0.56), HOOD, Vector3(-0.35, 0.3, 0.05), head)
	_box(Vector3(0.1, 0.66, 0.56), HOOD, Vector3(0.35, 0.3, 0.05), head)
	_box(Vector3(0.72, 0.12, 0.5), HOOD, Vector3(0, 0.67, 0.08), head)
	_box(Vector3(0.62, 0.08, 0.08), Color(0.58, 0.08, 0.06), Vector3(0, 0.62, -0.18), head, false)

	# Dollar-sign shades.
	lens_mat = StandardMaterial3D.new()
	lens_mat.albedo_color = Color(1.0, 0.78, 0.2)
	lens_mat.metallic = 0.8
	lens_mat.roughness = 0.25
	lens_mat.emission_enabled = true
	lens_mat.emission = Color(1.0, 0.65, 0.1)
	lens_mat.emission_energy_multiplier = 1.2
	for side in [-1.0, 1.0]:
		var rim := MeshInstance3D.new()
		var torus := TorusMesh.new()
		torus.inner_radius = 0.11
		torus.outer_radius = 0.135
		torus.rings = 16
		torus.ring_segments = 6
		rim.mesh = torus
		rim.material_override = Mats.solid(Color(0.08, 0.06, 0.05), 0.4, 0.5)
		rim.rotation.x = PI / 2
		rim.position = Vector3(side * 0.135, 0.3, -0.29)
		head.add_child(rim)
		var lens := MeshInstance3D.new()
		var disc := CylinderMesh.new()
		disc.top_radius = 0.115
		disc.bottom_radius = 0.115
		disc.height = 0.012
		disc.radial_segments = 16
		lens.mesh = disc
		lens.material_override = Mats.solid(Color(0.12, 0.07, 0.03), 0.1, 0.4)
		lens.rotation.x = PI / 2
		lens.position = Vector3(side * 0.135, 0.3, -0.285)
		head.add_child(lens)
		var glyph := MeshInstance3D.new()
		glyph.mesh = Mats.dollar_mesh()
		glyph.material_override = lens_mat
		glyph.position = Vector3(side * 0.135, 0.3, -0.3)
		glyph.scale = Vector3(0.19, 0.19, 0.2)
		head.add_child(glyph)
	_box(Vector3(0.05, 0.025, 0.03), Color(0.08, 0.06, 0.05), Vector3(0, 0.33, -0.29), head, false)
	_box(Vector3(0.02, 0.025, 0.3), Color(0.08, 0.06, 0.05), Vector3(-0.28, 0.32, -0.15), head, false)
	_box(Vector3(0.02, 0.025, 0.3), Color(0.08, 0.06, 0.05), Vector3(0.28, 0.32, -0.15), head, false)


func _face_image() -> Image:
	var w := 128
	var img := Image.create(w, w, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	# A lopsided confident smile, like the key art.
	for i in 200:
		var t := float(i) / 199.0
		var x := lerpf(42.0, 88.0, t)
		var y := 86.0 + sin(t * PI) * 12.0 - t * 4.0
		for dy in range(-3, 4):
			for dx in range(-3, 4):
				if dx * dx + dy * dy <= 9:
					img.set_pixel(clampi(int(x) + dx, 0, w - 1), clampi(int(y) + dy, 0, w - 1), Color(0.1, 0.05, 0.03))
	return img


## state: idle, run, air, fall, dive, crouch, skid, pound, hurt, slide, flip.
func animate(delta: float, state: String, speed: float) -> void:
	_t += delta
	var al := Vector3(0, 0, 0.08)   # arm rotations (x swings forward/back, z out)
	var ar := Vector3(0, 0, -0.08)
	var ll := Vector3.ZERO
	var lr := Vector3.ZERO
	var head_tilt := 0.0
	var bob := 0.0

	match state:
		"run":
			_phase += delta * (5.0 + speed * 0.9)
			var s := sin(_phase) * clampf(speed / 7.0, 0.35, 1.0)
			ll.x = s * 1.0
			lr.x = -s * 1.0
			al.x = -s * 1.1
			ar.x = s * 1.1
			bob = absf(cos(_phase)) * 0.05
		"air":
			al = Vector3(-2.7, 0, 0.25)
			ar = Vector3(-2.7, 0, -0.25)
			ll.x = -0.5
			lr.x = 0.2
		"fall":
			al = Vector3(-0.3, 0, 1.3)
			ar = Vector3(-0.3, 0, -1.3)
			ll.x = 0.3
			lr.x = -0.3
		"dive", "slide":
			al = Vector3(-3.0, 0, 0.15)
			ar = Vector3(-3.0, 0, -0.15)
		"crouch":
			al = Vector3(-0.6, 0, 0.3)
			ar = Vector3(-0.6, 0, -0.3)
		"skid":
			al = Vector3(0.8, 0, 0.6)
			ar = Vector3(0.8, 0, -0.6)
			ll.x = -0.6
		"pound":
			al = Vector3(-2.5, 0, 0.6)
			ar = Vector3(-2.5, 0, -0.6)
			ll.x = -1.3
			lr.x = -1.3
		"hurt":
			al = Vector3(-1.0, 0, 1.6)
			ar = Vector3(-1.0, 0, -1.6)
			head_tilt = 0.3
		"flip":
			al = Vector3(-1.2, 0, 0.3)
			ar = Vector3(-1.2, 0, -0.3)
			ll.x = -1.0
			lr.x = -1.0
		_:
			# Idle: breathing and a little weight shift.
			bob = sin(_t * 2.0) * 0.012
			al.z = 0.1 + sin(_t * 2.0) * 0.03
			ar.z = -0.1 - sin(_t * 2.0) * 0.03

	match emote:
		"wave":
			ar = Vector3(-2.9, 0, -0.3 + sin(_t * 10.0) * 0.35)
		"cheer":
			al = Vector3(-3.0, 0, 0.35)
			ar = Vector3(-3.0, 0, -0.35)
			bob = absf(sin(_t * 7.0)) * 0.12
		"shocked":
			al = Vector3(-0.4, 0, 1.3)
			ar = Vector3(-0.4, 0, -1.3)
			head_tilt = -0.15
		"point":
			ar = Vector3(-1.6, 0, 0)
		"shrug":
			al = Vector3(-0.5, 0, 0.9)
			ar = Vector3(-0.5, 0, -0.9)
			head_tilt = 0.12
		"hold":
			ar = Vector3(-3.1, 0, -0.1)
			al = Vector3(0, 0, 0.3)
		"think":
			ar = Vector3(-2.2, 0, 0.7)
			head_tilt = 0.1
		"facepalm":
			ar = Vector3(-2.6, 0, 0.55)
			head_tilt = 0.35
		"sad":
			al = Vector3(0.1, 0, 0.02)
			ar = Vector3(0.1, 0, -0.02)
			head_tilt = 0.4
		"dance":
			var d := sin(_t * 8.0)
			al = Vector3(-1.5 - d * 1.2, 0, 0.5)
			ar = Vector3(-1.5 + d * 1.2, 0, -0.5)
			ll.x = maxf(d, 0.0) * 0.5
			lr.x = maxf(-d, 0.0) * 0.5
			bob = absf(d) * 0.08
		"cool":
			al = Vector3(0.1, 0, 0.25)
			ar = Vector3(-2.3, 0, 0.9)

	var k := clampf(14.0 * delta, 0.0, 1.0)
	arm_l.rotation = arm_l.rotation.lerp(al, k)
	arm_r.rotation = arm_r.rotation.lerp(ar, k)
	leg_l.rotation = leg_l.rotation.lerp(ll, k)
	leg_r.rotation = leg_r.rotation.lerp(lr, k)
	head.rotation.x = lerpf(head.rotation.x, head_tilt, k)
	head.rotation.y = lerp_angle(head.rotation.y, head_yaw, k * 0.5)
	position.y = lerpf(position.y, bob, k)
	lens_mat.emission_energy_multiplier = 1.0 + 0.5 * sin(_t * 3.0) + (1.5 if emote == "cheer" else 0.0)
