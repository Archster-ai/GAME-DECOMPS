extends Node3D
## The final boss: a giant Signpost Steve.
## Loop: shuffle toward Stax -> leap and slam (shockwave ring to jump over)
## -> after the last slam of a combo he topples face-down, stunned. Ground
## pound the glowing spot on his back to hurt him. Later phases chain more
## slams and fire volleys of arrow signs.

signal hit(hp: int)
signal defeated

const Puppet := preload("res://scripts/actors/puppet.gd")
const Mats := preload("res://scripts/world/mats.gd")
const Fx := preload("res://scripts/world/fx.gd")

const S := 4.5           # model scale
const MAX_HP := 5
const ARENA_CENTER := Vector3(0, 0, -14)
const ARENA_RADIUS := 20.0

enum B { WAIT, IDLE, RISE, SLAM, FALLEN, RECOVER, VOLLEY, DEAD }

const HIT_LINES := [
	"OW! That's a violation of my terms of service!",
	"Splinters! You gave me SPLINTERS!",
	"Stop that! I'm load-bearing!",
	"You'll be hearing from my lawyer! He's also a sign!",
]
const TAUNTS := [
	"Here's a tip: DODGE!",
	"This way! That way! ALL THE WAYS!",
	"Convenience fee: YOUR HEALTH!",
	"Jump! No, not like that. Like THAT!",
]

var player: CharacterBody3D
var level: Node3D
var puppet: Node3D
var hp := MAX_HP
var state: B = B.WAIT
var _t := 0.0
var _combo := 0
var _target := Vector3.ZERO
var _from := Vector3.ZERO
var _yaw := 0.0
var _board_body: StaticBody3D
var _weak: MeshInstance3D
var _marker: MeshInstance3D
var _stars: Node3D
var _waves: Array = []
var _arrows: Array = []
var _volley_left := 0
var _volley_timer := 0.0
var _taunt_i := 0
var _hurt_cooldown := 0.0


func _ready() -> void:
	puppet = Puppet.new()
	puppet.kind = "steve"
	puppet.speaker = "steve"
	puppet.scale = Vector3.ONE * S
	add_child(puppet)

	_board_body = StaticBody3D.new()
	_board_body.collision_layer = 0
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(1.9 * S, 0.6, 0.95 * S)
	cs.shape = shape
	_board_body.add_child(cs)
	add_child(_board_body)
	_board_body.top_level = true

	_weak = MeshInstance3D.new()
	var disc := CylinderMesh.new()
	disc.top_radius = 1.4
	disc.bottom_radius = 1.4
	disc.height = 0.05
	_weak.mesh = disc
	_weak.material_override = Mats.glow(Color(1.0, 0.85, 0.2), 3.0)
	_weak.top_level = true
	_weak.visible = false
	add_child(_weak)

	_marker = MeshInstance3D.new()
	var md := CylinderMesh.new()
	md.top_radius = 3.2
	md.bottom_radius = 3.2
	md.height = 0.04
	_marker.mesh = md
	_marker.material_override = Mats.unshaded(Color(1.0, 0.1, 0.05), 0.5)
	_marker.top_level = true
	_marker.visible = false
	add_child(_marker)

	_stars = Node3D.new()
	_stars.top_level = true
	_stars.visible = false
	add_child(_stars)
	for i in 5:
		var st := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.25
		sm.height = 0.5
		st.mesh = sm
		st.material_override = Mats.glow(Color(1.0, 0.95, 0.4), 4.0)
		st.position = Vector3(cos(TAU * i / 5.0) * 1.6, 0, sin(TAU * i / 5.0) * 1.6)
		_stars.add_child(st)


func phase() -> int:
	return 1 if hp >= 4 else (2 if hp >= 2 else 3)


func start() -> void:
	state = B.IDLE
	_t = 0.0


func _go(s: B) -> void:
	state = s
	_t = 0.0


func _fwd() -> Vector3:
	return Vector3(-sin(_yaw), 0, -cos(_yaw))


func _face_player(delta: float, rate := 3.0) -> void:
	var d := player.global_position - global_position
	_yaw = lerp_angle(_yaw, atan2(-d.x, -d.z), clampf(rate * delta, 0.0, 1.0))
	rotation.y = _yaw


func _physics_process(delta: float) -> void:
	_t += delta
	_hurt_cooldown -= delta
	_update_waves(delta)
	_update_arrows(delta)
	if player == null or state == B.WAIT or state == B.DEAD:
		return
	match state:
		B.IDLE: _st_idle(delta)
		B.RISE: _st_rise(delta)
		B.SLAM: _st_slam(delta)
		B.FALLEN: _st_fallen(delta)
		B.RECOVER: pass
		B.VOLLEY: _st_volley(delta)
	# Touching his post while he stands hurts.
	if state in [B.IDLE, B.VOLLEY] and _hurt_cooldown <= 0.0:
		var flat := Vector2(player.global_position.x - global_position.x, player.global_position.z - global_position.z)
		if flat.length() < 1.6 and player.global_position.y < 8.0:
			player.take_damage(1, global_position)
			_hurt_cooldown = 1.0


func _st_idle(delta: float) -> void:
	_face_player(delta)
	var to := player.global_position - global_position
	to.y = 0.0
	if to.length() > 7.0:
		global_position += to.normalized() * (2.5 + phase()) * delta
	var wait: float = [2.2, 1.6, 1.1][phase() - 1]
	if _t > wait:
		if phase() >= 2 and _combo == 0 and randf() < 0.6:
			_volley_left = 3 if phase() == 2 else 5
			_volley_timer = 0.4
			_say_taunt()
			_go(B.VOLLEY)
		else:
			_begin_rise()


func _begin_rise() -> void:
	_from = global_position
	_target = _clamp_arena(player.global_position)
	_marker.visible = true
	Audio.play("whoosh", 0.7, 0.0, -2.0)
	_go(B.RISE)


func _st_rise(delta: float) -> void:
	var dur: float = [1.2, 1.0, 0.8][phase() - 1]
	if _t < dur * 0.7:
		_target = _target.lerp(_clamp_arena(player.global_position), clampf(4.0 * delta, 0.0, 1.0))
	var k := clampf(_t / dur, 0.0, 1.0)
	var flat := _from.lerp(_target, 1.0 - pow(1.0 - k, 2.0))
	global_position = Vector3(flat.x, sin(k * PI * 0.5) * 14.0, flat.z)
	_face_player(delta, 6.0)
	_marker.global_position = Vector3(_target.x, 0.03, _target.z)
	_marker.scale = Vector3.ONE * (0.6 + 0.4 * sin(_t * 20.0) * 0.5 + 0.4)
	if k >= 1.0:
		_go(B.SLAM)


func _st_slam(delta: float) -> void:
	global_position.y = maxf(global_position.y - 45.0 * delta, 0.0)
	if global_position.y <= 0.0:
		_marker.visible = false
		Audio.play("boom")
		Audio.play("hit_low", 0.9)
		if level and level.rig:
			level.rig.shake(0.7)
		Fx.burst(get_parent(), global_position + Vector3(0, 0.3, 0), Color(1.0, 0.9, 0.7, 0.8), 40, 12.0, 0.8, 0.8, -4.0)
		_spawn_wave(global_position)
		var flat := Vector2(player.global_position.x - global_position.x, player.global_position.z - global_position.z)
		if flat.length() < 3.2:
			player.take_damage(2, global_position)
		if level:
			for i in 2:
				var a := randf() * TAU
				level.coin(_clamp_arena(global_position + Vector3(cos(a) * 6.0, 0, sin(a) * 6.0)) + Vector3(0, 1.0, 0))
		_combo += 1
		if _combo >= phase():
			_combo = 0
			_topple()
		else:
			_begin_rise()


func _topple() -> void:
	_go(B.FALLEN)
	var t := create_tween()
	t.tween_property(puppet, "rotation:x", -PI / 2, 0.5).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	t.parallel().tween_property(self, "position:y", 0.3, 0.5)
	t.tween_callback(func():
		Audio.play("clang", 0.5)
		if level and level.rig:
			level.rig.shake(0.3)
		var center := global_position + _fwd() * 1.85 * S
		_board_body.global_transform = Transform3D(Basis(Vector3.UP, _yaw), Vector3(center.x, 0.3, center.z))
		_board_body.collision_layer = 1
		_weak.global_position = Vector3(center.x, 0.64, center.z)
		_weak.visible = true
		_stars.visible = true
		_stars.global_position = global_position + Vector3(0, 2.0, 0)
		if level and level.has_method("on_boss_fallen"):
			level.on_boss_fallen())


func _st_fallen(delta: float) -> void:
	_stars.rotation.y += delta * 4.0
	_weak.scale = Vector3.ONE * (1.0 + 0.15 * sin(_t * 10.0))
	if not _weak.visible:
		return
	var center := _weak.global_position
	var local := (player.global_position - center).rotated(Vector3.UP, -_yaw)
	var on_board := absf(local.x) < 0.95 * S and absf(local.z) < 0.5 * S and player.global_position.y > 0.4
	if on_board and player.state == player.S.POUND_LAND:
		take_hit()
		return
	if _t > [4.5, 3.8, 3.2][phase() - 1]:
		_recover()


## Registers a hit (also used by the automated tests).
func take_hit() -> void:
	if state == B.DEAD:
		return
	hp -= 1
	hit.emit(hp)
	Audio.play("clang")
	Audio.play("hit_low")
	Game.fx.flash(Color(1, 1, 1), 0.3)
	Game.fx.aberrate(1.0)
	if level and level.rig:
		level.rig.shake(0.6)
	Fx.burst(get_parent(), _weak.global_position + Vector3(0, 0.5, 0), Color(0.85, 0.6, 0.35), 30, 9.0, 0.35, 0.9, -12.0, "cube")
	player.bounce(16.0, false)
	_hitstop()
	if hp <= 0:
		_die()
		return
	if level:
		level.bark("steve_evil", HIT_LINES[(MAX_HP - hp - 1) % HIT_LINES.size()])
	_recover()


func _hitstop() -> void:
	Engine.time_scale = 0.05
	await get_tree().create_timer(0.09, true, false, true).timeout
	Engine.time_scale = 1.0


func _recover() -> void:
	_go(B.RECOVER)
	_hide_fallen()
	var t := create_tween()
	t.tween_property(puppet, "rotation:x", 0.0, 0.6).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	t.parallel().tween_property(self, "position:y", 0.0, 0.6)
	t.tween_callback(func():
		# A shove to get Stax off him.
		var d := player.global_position - global_position
		d.y = 0.0
		if d.length() < 11.0 and player.is_on_floor():
			player.facing = atan2(d.x, d.z)
			player.bounce(10.0, false)
			player.speed = -9.0
		_go(B.IDLE))


func _hide_fallen() -> void:
	_board_body.collision_layer = 0
	_weak.visible = false
	_stars.visible = false


func _st_volley(delta: float) -> void:
	_face_player(delta, 5.0)
	_volley_timer -= delta
	if _volley_timer <= 0.0 and _volley_left > 0:
		_volley_left -= 1
		_volley_timer = 0.45 if phase() == 2 else 0.32
		_fire_arrow()
	if _volley_left <= 0 and _volley_timer <= -0.8:
		_begin_rise()


func _say_taunt() -> void:
	if level:
		level.bark("steve_evil", TAUNTS[_taunt_i % TAUNTS.size()])
	_taunt_i += 1


func _clamp_arena(p: Vector3) -> Vector3:
	var d := p - ARENA_CENTER
	d.y = 0.0
	if d.length() > ARENA_RADIUS - 3.0:
		d = d.normalized() * (ARENA_RADIUS - 3.0)
	return ARENA_CENTER + d


# ---------------------------------------------------------------- attacks

func _spawn_wave(at: Vector3) -> void:
	var ring := MeshInstance3D.new()
	var tor := TorusMesh.new()
	tor.inner_radius = 0.85
	tor.outer_radius = 1.0
	tor.rings = 48
	tor.ring_segments = 8
	ring.mesh = tor
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(1.0, 0.55, 0.15, 0.9)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.emission_enabled = true
	m.emission = Color(1.0, 0.45, 0.1)
	m.emission_energy_multiplier = 3.0
	ring.material_override = m
	get_parent().add_child(ring)
	ring.global_position = Vector3(at.x, 0.35, at.z)
	_waves.append({"node": ring, "r": 1.0, "mat": m, "center": Vector3(at.x, 0, at.z)})


func _update_waves(delta: float) -> void:
	for w in _waves.duplicate():
		w.r += delta * (13.0 + phase() * 2.0)
		var node: MeshInstance3D = w.node
		node.scale = Vector3(w.r, 1.4, w.r)
		w.mat.albedo_color.a = clampf(1.0 - w.r / 30.0, 0.0, 1.0)
		if player and not player.dead:
			var flat := Vector2(player.global_position.x - w.center.x, player.global_position.z - w.center.z).length()
			if absf(flat - w.r) < 0.9 and player.global_position.y < 0.9:
				player.take_damage(1, w.center)
		if w.r > 30.0:
			node.queue_free()
			_waves.erase(w)


func _fire_arrow() -> void:
	var arrow := Node3D.new()
	var plank := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = Vector3(0.9, 0.5, 2.0)
	plank.mesh = b
	plank.material_override = Mats.toon(Color(0.85, 0.6, 0.35))
	arrow.add_child(plank)
	var tip := MeshInstance3D.new()
	var tb := BoxMesh.new()
	tb.size = Vector3(1.1, 0.5, 1.1)
	tip.mesh = tb
	tip.material_override = Mats.glow(Color(1.0, 0.3, 0.1), 2.0)
	tip.rotation.y = PI / 4
	tip.position.z = -1.1
	arrow.add_child(tip)
	get_parent().add_child(arrow)
	var from := global_position + Vector3(0, 1.85 * S, 0)
	var aim := player.global_position + Vector3(0, 0.8, 0) + player.velocity * 0.25
	arrow.global_position = from
	var dir := (aim - from).normalized()
	arrow.look_at(from + dir, Vector3.UP)
	_arrows.append({"node": arrow, "dir": dir, "t": 0.0})
	Audio.play("zap", 0.8)


func _update_arrows(delta: float) -> void:
	for a in _arrows.duplicate():
		a.t += delta
		var node: Node3D = a.node
		node.global_position += a.dir * 20.0 * delta
		var hit_player := player != null and node.global_position.distance_to(player.global_position + Vector3(0, 0.8, 0)) < 1.2
		if hit_player:
			player.take_damage(1, node.global_position)
		if hit_player or a.t > 3.0 or node.global_position.y < -0.5:
			Fx.burst(get_parent(), node.global_position, Color(0.85, 0.6, 0.35), 8, 4.0, 0.2, 0.4, -9.0, "cube")
			node.queue_free()
			_arrows.erase(a)


func clear_attacks() -> void:
	for w in _waves:
		w.node.queue_free()
	_waves.clear()
	for a in _arrows:
		a.node.queue_free()
	_arrows.clear()
	_marker.visible = false


## Back to full health at the start, for a fresh attempt after Stax dies.
func reset(at: Vector3) -> void:
	clear_attacks()
	_hide_fallen()
	hp = MAX_HP
	_combo = 0
	puppet.rotation.x = 0.0
	global_position = at
	_go(B.IDLE)


func _die() -> void:
	state = B.DEAD
	clear_attacks()
	_hide_fallen()
	defeated.emit()


## Deflates back to normal size for the ending.
func shrink(time := 2.0) -> void:
	var t := create_tween().set_parallel()
	t.tween_property(puppet, "scale", Vector3.ONE, time).set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT)
	t.tween_property(puppet, "rotation:x", 0.0, 0.6)
	t.tween_property(self, "position:y", 0.0, 0.6)
