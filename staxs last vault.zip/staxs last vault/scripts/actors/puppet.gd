extends Node3D
## Visual models for every non-player character, built from primitives.
## Set `kind` before adding to the tree. Puppets bob while idle, bounce in
## time while their speaker id is talking, and react to a few emotes.
##
## Kinds: steve, baron, waffle, gary, lefty, pigeon, doodle, camel, moneybeard,
##        cuckoo, grandclock, toast, stapler, moth, drone, scribble, duck, gearbot,
##        baby, teddy, soldier, snowman, ember, dragon_ice, dragon_fire, placeholder, clown,
##        raver (a light-show fan: set `tint` for their colour), dj.

const Mats := preload("res://scripts/world/mats.gd")

var kind := "steve"
var speaker := ""
var emote := ""
var squash := 1.0
var tint := Color(1.0, 0.3, 0.8)
var mouth: Node3D
var body: Node3D
var parts := {}
var _t := 0.0
var _talk := 0.0


func _ready() -> void:
	_t = randf() * 10.0
	body = Node3D.new()
	add_child(body)
	match kind:
		"steve": _build_steve()
		"baron": _build_baron()
		"waffle": _build_waffle()
		"gary": _build_gary()
		"lefty": _build_lefty()
		"pigeon": _build_pigeon()
		"toast": _build_toast()
		"stapler": _build_stapler()
		"moth": _build_moth()
		"drone": _build_drone()
		"doodle": _build_doodle()
		"scribble": _build_scribble()
		"duck": _build_duck()
		"camel": _build_camel()
		"moneybeard": _build_moneybeard()
		"cuckoo": _build_cuckoo()
		"gearbot": _build_gearbot()
		"grandclock": _build_grandclock()
		"baby": _build_baby()
		"teddy": _build_teddy()
		"soldier": _build_soldier()
		"snowman": _build_snowman()
		"ember": _build_ember()
		"dragon_ice": _build_dragon_head(false)
		"dragon_fire": _build_dragon_head(true)
		"placeholder": _build_placeholder()
		"clown": _build_clown()
		"raver": _build_raver(false)
		"dj": _build_raver(true)


# ---------------------------------------------------------------- building blocks

func box(size: Vector3, color: Color, pos: Vector3, parent: Node3D = null, outline := true, rot := Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = size
	mi.mesh = b
	mi.material_override = Mats.toon(color) if outline else Mats.solid(color, 0.6)
	mi.position = pos
	mi.rotation = rot
	(parent if parent else body).add_child(mi)
	return mi


func ball(radius: float, color: Color, pos: Vector3, parent: Node3D = null, outline := true, squish := Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var s := SphereMesh.new()
	s.radius = radius
	s.height = radius * 2.0
	s.radial_segments = 20
	s.rings = 10
	mi.mesh = s
	mi.material_override = Mats.toon(color) if outline else Mats.solid(color, 0.5)
	mi.position = pos
	mi.scale = squish
	(parent if parent else body).add_child(mi)
	return mi


func cyl(radius: float, height: float, color: Color, pos: Vector3, parent: Node3D = null, outline := true, rot := Vector3.ZERO, top := -1.0) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var c := CylinderMesh.new()
	c.bottom_radius = radius
	c.top_radius = radius if top < 0.0 else top
	c.height = height
	c.radial_segments = 18
	mi.mesh = c
	mi.material_override = Mats.toon(color) if outline else Mats.solid(color, 0.5)
	mi.position = pos
	mi.rotation = rot
	(parent if parent else body).add_child(mi)
	return mi


## Cartoon eyes: white balls with black pupils, facing -Z.
func eyes(center: Vector3, spacing: float, size: float, parent: Node3D = null, angry := false) -> void:
	var p: Node3D = parent if parent else body
	for side in [-1.0, 1.0]:
		ball(size, Color.WHITE, center + Vector3(side * spacing, 0, 0), p, true, Vector3(1, 1.15, 0.6))
		ball(size * 0.5, Color(0.05, 0.05, 0.05), center + Vector3(side * spacing * 0.9, -size * 0.1, -size * 0.45), p, false)
		if angry:
			box(Vector3(size * 2.2, size * 0.4, size * 0.4), Color(0.1, 0.05, 0.02),
				center + Vector3(side * spacing, size * 1.2, -size * 0.3), p, false, Vector3(0, 0, side * 0.45))


func label(text: String, size: int, color: Color, pos: Vector3, parent: Node3D = null) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.font = Mats.bold_font()
	l.font_size = size
	l.pixel_size = 0.004
	l.modulate = color
	l.outline_size = 0
	l.position = pos
	l.rotation.y = PI
	(parent if parent else body).add_child(l)
	return l


# ---------------------------------------------------------------- characters

func _build_steve() -> void:
	var wood := Color(0.82, 0.62, 0.38)
	var dark := Color(0.48, 0.3, 0.16)
	box(Vector3(0.18, 2.1, 0.18), dark, Vector3(0, 1.05, 0.05))
	var board := Node3D.new()
	board.position.y = 1.85
	body.add_child(board)
	parts.board = board
	box(Vector3(1.7, 0.95, 0.12), wood, Vector3(0, 0, 0), board)
	# Arrow tip on the right side: he is a tutorial sign, after all.
	box(Vector3(0.5, 0.5, 0.12), wood, Vector3(0.9, 0, 0), board, true, Vector3(0, 0, PI / 4))
	# Wood grain lines.
	for i in 3:
		box(Vector3(1.5, 0.02, 0.01), dark, Vector3(0, -0.3 + i * 0.3, -0.065), board, false)
	eyes(Vector3(-0.28, 0.1, -0.09), 0.2, 0.12, board)
	mouth = box(Vector3(0.36, 0.08, 0.03), Color(0.25, 0.08, 0.05), Vector3(-0.28, -0.22, -0.07), board, false)
	# Little brows that make him look very trustworthy.
	for side in [-1.0, 1.0]:
		box(Vector3(0.2, 0.04, 0.02), Color(0.3, 0.18, 0.08), Vector3(-0.28 + side * 0.2, 0.3, -0.07), board, false, Vector3(0, 0, -side * 0.15))
	var tip := label("TIPS!", 64, Color(0.3, 0.16, 0.06), Vector3(0.45, 0.05, -0.07), board)
	tip.pixel_size = 0.0035
	parts.tip = tip


func _build_baron() -> void:
	var suit := Color(0.35, 0.16, 0.45)
	box(Vector3(0.22, 0.5, 0.24), Color(0.1, 0.1, 0.12), Vector3(-0.25, 0.25, 0))
	box(Vector3(0.22, 0.5, 0.24), Color(0.1, 0.1, 0.12), Vector3(0.25, 0.25, 0))
	ball(0.75, suit, Vector3(0, 1.1, 0), null, true, Vector3(1, 0.95, 0.9))
	box(Vector3(0.3, 0.55, 0.05), Color(0.95, 0.95, 0.92), Vector3(0, 1.25, -0.66), null, false)
	box(Vector3(0.14, 0.35, 0.06), Color(0.8, 0.1, 0.12), Vector3(0, 1.3, -0.7), null, false)
	for i in 3:
		ball(0.04, Mats.gold().albedo_color, Vector3(0, 0.95 - i * 0.14, -0.69), null, false)
	var head := Node3D.new()
	head.position.y = 1.95
	body.add_child(head)
	parts.head = head
	ball(0.42, Color(0.96, 0.78, 0.66), Vector3.ZERO, head)
	ball(0.1, Color(0.95, 0.55, 0.5), Vector3(0, -0.02, -0.4), head, false)
	eyes(Vector3(0, 0.1, -0.33), 0.15, 0.08, head)
	# Monocle.
	var mono := MeshInstance3D.new()
	var tor := TorusMesh.new()
	tor.inner_radius = 0.1
	tor.outer_radius = 0.125
	mono.mesh = tor
	mono.material_override = Mats.gold()
	mono.rotation.x = PI / 2
	mono.position = Vector3(0.15, 0.1, -0.4)
	head.add_child(mono)
	# The mustache of a man who has never paid a parking ticket.
	for side in [-1.0, 1.0]:
		box(Vector3(0.36, 0.1, 0.1), Color(0.95, 0.95, 0.95), Vector3(side * 0.2, -0.13, -0.38), head, true, Vector3(0, 0, side * -0.3))
	mouth = box(Vector3(0.18, 0.05, 0.04), Color(0.3, 0.05, 0.05), Vector3(0, -0.24, -0.37), head, false)
	# Top hat.
	cyl(0.46, 0.05, Color(0.08, 0.08, 0.1), Vector3(0, 0.34, 0), head)
	cyl(0.3, 0.6, Color(0.08, 0.08, 0.1), Vector3(0, 0.66, 0), head)
	cyl(0.305, 0.1, suit, Vector3(0, 0.42, 0), head, false)
	# Arms and a gold-topped cane.
	var arm_r := Node3D.new()
	arm_r.position = Vector3(0.75, 1.35, 0)
	body.add_child(arm_r)
	parts.arm_r = arm_r
	box(Vector3(0.22, 0.6, 0.22), suit, Vector3(0, -0.3, 0), arm_r)
	ball(0.13, Color.WHITE, Vector3(0, -0.65, 0), arm_r)
	cyl(0.035, 1.3, Color(0.1, 0.06, 0.04), Vector3(0, -1.1, -0.1), arm_r, false)
	ball(0.09, Mats.gold().albedo_color, Vector3(0, -0.45, -0.1), arm_r, false)
	var arm_l := Node3D.new()
	arm_l.position = Vector3(-0.75, 1.35, 0)
	body.add_child(arm_l)
	parts.arm_l = arm_l
	box(Vector3(0.22, 0.6, 0.22), suit, Vector3(0, -0.3, 0), arm_l)
	ball(0.13, Color.WHITE, Vector3(0, -0.65, 0), arm_l)


func _build_waffle() -> void:
	var gold_brown := Color(0.85, 0.58, 0.25)
	box(Vector3(0.08, 0.5, 0.08), Color(0.7, 0.45, 0.2), Vector3(-0.25, 0.25, 0))
	box(Vector3(0.08, 0.5, 0.08), Color(0.7, 0.45, 0.2), Vector3(0.25, 0.25, 0))
	var w := box(Vector3(1.1, 1.1, 0.22), gold_brown, Vector3(0, 1.05, 0))
	w.material_override = Mats.pattern("grid", [gold_brown, Color(0.6, 0.35, 0.12)], 2.0, 0.7)
	w.material_override.next_pass = Mats.outline()
	# Butter pat hat and a pat of dignity.
	box(Vector3(0.4, 0.14, 0.3), Color(1.0, 0.92, 0.5), Vector3(0.05, 1.68, 0), null, true, Vector3(0, 0, -0.12))
	eyes(Vector3(0, 1.2, -0.14), 0.18, 0.1)
	mouth = box(Vector3(0.24, 0.06, 0.03), Color(0.35, 0.12, 0.05), Vector3(0, 0.88, -0.13), null, false)
	# A fork, held like a knight's sword.
	var arm := Node3D.new()
	arm.position = Vector3(0.6, 1.0, 0)
	body.add_child(arm)
	parts.arm_r = arm
	box(Vector3(0.06, 0.45, 0.06), Color(0.7, 0.45, 0.2), Vector3(0, -0.2, 0), arm)
	box(Vector3(0.04, 0.9, 0.04), Color(0.85, 0.85, 0.9), Vector3(0, 0.1, -0.2), arm, false, Vector3(-0.6, 0, 0))
	for i in 3:
		box(Vector3(0.02, 0.18, 0.02), Color(0.85, 0.85, 0.9), Vector3(-0.04 + i * 0.04, 0.5, -0.45), arm, false, Vector3(-0.6, 0, 0))
	# A tiny cape, because he is a Sir.
	box(Vector3(0.9, 1.0, 0.04), Color(0.7, 0.1, 0.15), Vector3(0, 1.0, 0.15), null, true, Vector3(0.12, 0, 0))


## A light-show fan with a glow stick, or the DJ (headphones and a glowing visor).
func _build_raver(dj: bool) -> void:
	var skins := [Color(0.95, 0.78, 0.62), Color(0.78, 0.55, 0.38), Color(0.52, 0.35, 0.24), Color(0.98, 0.86, 0.72)]
	var skin: Color = skins[absi(hash(tint)) % skins.size()]
	var dark := Color(0.12, 0.1, 0.18)
	box(Vector3(0.24, 0.6, 0.26), dark, Vector3(-0.14, 0.3, 0))
	box(Vector3(0.24, 0.6, 0.26), dark, Vector3(0.14, 0.3, 0))
	box(Vector3(0.56, 0.6, 0.32), tint if not dj else Color(0.15, 0.1, 0.25), Vector3(0, 0.88, 0))
	if dj:
		box(Vector3(0.4, 0.08, 0.02), Color(1, 1, 1), Vector3(0, 0.95, -0.17), null, false).material_override = Mats.glow(Color(1.0, 0.3, 0.9), 3.0)
	for side in [-1.0, 1.0]:
		var arm := Node3D.new()
		arm.position = Vector3(side * 0.36, 1.12, 0)
		body.add_child(arm)
		parts["arm_l" if side < 0.0 else "arm_r"] = arm
		box(Vector3(0.18, 0.56, 0.2), tint if not dj else Color(0.15, 0.1, 0.25), Vector3(0, -0.26, 0), arm)
		box(Vector3(0.16, 0.16, 0.16), skin, Vector3(0, -0.58, 0), arm, false)
		var stick := box(Vector3(0.06, 0.6, 0.06), Color.WHITE, Vector3(0, -0.85, 0), arm, false)
		stick.material_override = Mats.glow(tint if side > 0.0 else tint.lightened(0.4), 3.5)
	var head := Node3D.new()
	head.position.y = 1.18
	body.add_child(head)
	parts.head = head
	box(Vector3(0.44, 0.44, 0.42), skin, Vector3(0, 0.24, 0), head)
	box(Vector3(0.48, 0.14, 0.46), tint.lightened(0.2), Vector3(0, 0.5, 0.02), head, false).material_override = Mats.glow(tint.lightened(0.2), 1.6)
	if dj:
		box(Vector3(0.5, 0.1, 0.07), Color(1, 1, 1), Vector3(0, 0.3, -0.22), head, false).material_override = Mats.glow(Color(0.3, 0.95, 1.0), 4.0)
		for side in [-1.0, 1.0]:
			box(Vector3(0.1, 0.24, 0.3), Color(0.1, 0.1, 0.12), Vector3(side * 0.28, 0.26, 0), head)
	else:
		eyes(Vector3(0, 0.3, -0.22), 0.1, 0.05, head)
	mouth = box(Vector3(0.14, 0.04, 0.02), Color(0.35, 0.15, 0.15), Vector3(0, 0.1, -0.215), head, false)


func _build_gary() -> void:
	var suit := Color(0.4, 0.42, 0.45)
	var skin := Color(0.85, 0.82, 0.75)
	box(Vector3(0.28, 0.62, 0.3), Color(0.2, 0.2, 0.22), Vector3(-0.155, 0.31, 0))
	box(Vector3(0.28, 0.62, 0.3), Color(0.2, 0.2, 0.22), Vector3(0.155, 0.31, 0))
	box(Vector3(0.64, 0.64, 0.36), suit, Vector3(0, 0.94, 0))
	box(Vector3(0.24, 0.6, 0.02), Color(0.95, 0.95, 0.9), Vector3(0, 0.95, -0.185), null, false)
	box(Vector3(0.1, 0.5, 0.02), Color(0.3, 0.35, 0.6), Vector3(0, 0.95, -0.2), null, false)
	box(Vector3(0.24, 0.62, 0.28), suit, Vector3(-0.44, 0.94, 0), null, true, Vector3(0, 0, 0.08))
	var arm := Node3D.new()
	arm.position = Vector3(0.44, 1.22, 0)
	body.add_child(arm)
	parts.arm_r = arm
	box(Vector3(0.24, 0.62, 0.28), suit, Vector3(0, -0.28, 0), arm)
	# Coffee mug that has not been refilled since the 1600s.
	cyl(0.1, 0.18, Color(0.9, 0.9, 0.88), Vector3(0, -0.62, -0.12), arm)
	var head := Node3D.new()
	head.position.y = 1.26
	body.add_child(head)
	parts.head = head
	box(Vector3(0.54, 0.5, 0.5), skin, Vector3(0, 0.26, 0), head)
	box(Vector3(0.58, 0.08, 0.54), Color(0.55, 0.55, 0.55), Vector3(0, 0.54, 0), head)
	eyes(Vector3(0, 0.32, -0.26), 0.12, 0.06, head)
	for side in [-1.0, 1.0]:
		box(Vector3(0.14, 0.05, 0.02), Color(0.45, 0.4, 0.5), Vector3(side * 0.12, 0.24, -0.255), head, false)
	mouth = box(Vector3(0.16, 0.03, 0.02), Color(0.3, 0.2, 0.2), Vector3(0, 0.12, -0.255), head, false)
	# Cobwebs.
	var web := box(Vector3(0.3, 0.3, 0.005), Color(1, 1, 1), Vector3(0.28, 0.5, 0.1), head, false, Vector3(0, PI / 2, PI / 4))
	web.material_override = Mats.unshaded(Color(1, 1, 1), 0.35)


func _build_lefty() -> void:
	var pink := Color(1.0, 0.45, 0.7)
	var white := Color(0.98, 0.95, 0.95)
	for i in 5:
		var c := pink if i % 2 == 0 else white
		cyl(0.3, 0.26, c, Vector3(0, 0.55 + i * 0.26, 0))
	cyl(0.3, 0.1, white, Vector3(0, 1.85, 0), null, true, Vector3.ZERO, 0.33)
	var foot := cyl(0.3, 0.7, pink, Vector3(0, 0.3, -0.25), null, true, Vector3(PI / 2, 0, 0))
	foot.scale = Vector3(1, 1, 0.9)
	ball(0.3, white, Vector3(0, 0.3, -0.6), null, true, Vector3(1, 1, 0.8))
	eyes(Vector3(0, 1.45, -0.28), 0.12, 0.1)
	mouth = box(Vector3(0.14, 0.05, 0.03), Color(0.4, 0.1, 0.2), Vector3(0, 1.2, -0.3), null, false)


func _build_pigeon() -> void:
	var grey := Color(0.55, 0.58, 0.65)
	ball(0.35, grey, Vector3(0, 0.45, 0), null, true, Vector3(0.9, 0.9, 1.2))
	var head := Node3D.new()
	head.position = Vector3(0, 0.85, -0.25)
	body.add_child(head)
	parts.head = head
	ball(0.2, Color(0.35, 0.4, 0.5), Vector3.ZERO, head)
	ball(0.16, Color(0.4, 0.65, 0.55), Vector3(0, -0.15, 0.05), head, false)
	cyl(0.05, 0.16, Color(1.0, 0.7, 0.2), Vector3(0, -0.02, -0.25), head, true, Vector3(PI / 2, 0, 0), 0.0)
	for side in [-1.0, 1.0]:
		ball(0.05, Color(1, 0.5, 0.1), Vector3(side * 0.12, 0.06, -0.15), head, false)
		box(Vector3(0.04, 0.2, 0.04), Color(0.95, 0.5, 0.4), Vector3(side * 0.12, 0.1, 0), null, false)
		box(Vector3(0.1, 0.3, 0.5), grey, Vector3(side * 0.3, 0.5, 0.05), null, true, Vector3(0.3, 0, side * 0.2))
	mouth = head


func _build_toast() -> void:
	var bread := Color(0.96, 0.82, 0.55)
	var crust := Color(0.62, 0.36, 0.14)
	box(Vector3(0.9, 0.95, 0.2), crust, Vector3(0, 0.85, 0))
	box(Vector3(0.78, 0.82, 0.22), bread, Vector3(0, 0.83, 0), null, false)
	ball(0.3, crust, Vector3(-0.22, 1.3, 0), null, true, Vector3(1, 0.8, 0.35))
	ball(0.3, crust, Vector3(0.22, 1.3, 0), null, true, Vector3(1, 0.8, 0.35))
	eyes(Vector3(0, 0.95, -0.13), 0.16, 0.09, null, true)
	mouth = box(Vector3(0.3, 0.06, 0.03), Color(0.3, 0.1, 0.05), Vector3(0, 0.62, -0.12), null, false)
	for side in [-1.0, 1.0]:
		var leg := box(Vector3(0.07, 0.4, 0.07), Color(0.2, 0.15, 0.1), Vector3(side * 0.2, 0.2, 0))
		parts["leg_l" if side < 0.0 else "leg_r"] = leg


func _build_stapler() -> void:
	box(Vector3(0.6, 0.2, 1.3), Color(0.12, 0.12, 0.14), Vector3(0, 0.1, 0))
	var jaw := Node3D.new()
	jaw.position = Vector3(0, 0.25, 0.55)
	body.add_child(jaw)
	parts.jaw = jaw
	box(Vector3(0.56, 0.26, 1.3), Color(0.8, 0.12, 0.1), Vector3(0, 0.1, -0.6), jaw)
	box(Vector3(0.5, 0.05, 0.3), Color(0.8, 0.8, 0.85), Vector3(0, -0.04, -1.1), jaw, false)
	eyes(Vector3(0, 0.3, -1.0), 0.14, 0.08, jaw, true)


func _build_moth() -> void:
	var fuzz := Color(0.75, 0.7, 0.62)
	ball(0.35, fuzz, Vector3(0, 0.9, 0), null, true, Vector3(0.8, 0.8, 1.3))
	ball(0.25, Color(0.6, 0.55, 0.5), Vector3(0, 1.05, -0.4))
	eyes(Vector3(0, 1.1, -0.6), 0.12, 0.09, null, true)
	for side in [-1.0, 1.0]:
		var wing := Node3D.new()
		wing.position = Vector3(side * 0.2, 1.0, 0)
		body.add_child(wing)
		parts["wing_l" if side < 0.0 else "wing_r"] = wing
		var w := box(Vector3(0.9, 0.04, 0.7), Color(0.85, 0.8, 0.7), Vector3(side * 0.5, 0, 0), wing)
		w.material_override = Mats.pattern("stripes", [Color(0.85, 0.8, 0.7), Color(0.65, 0.58, 0.5)], 3.0)
		w.material_override.next_pass = Mats.outline()
		box(Vector3(0.03, 0.3, 0.03), Color(0.3, 0.25, 0.2), Vector3(side * 0.08, 1.35, -0.55), null, false, Vector3(0.4, 0, side * 0.4))
	mouth = body


func _build_drone() -> void:
	ball(0.45, Color(0.2, 0.22, 0.26), Vector3(0, 1.0, 0))
	var eye := ball(0.16, Color(1, 0.1, 0.1), Vector3(0, 1.0, -0.38), null, false)
	eye.material_override = Mats.glow(Color(1, 0.1, 0.05), 3.0)
	box(Vector3(1.6, 0.06, 0.12), Color(0.15, 0.15, 0.18), Vector3(0, 1.3, 0))
	for side in [-1.0, 1.0]:
		var rotor := Node3D.new()
		rotor.position = Vector3(side * 0.8, 1.38, 0)
		body.add_child(rotor)
		parts["rotor_l" if side < 0.0 else "rotor_r"] = rotor
		box(Vector3(0.7, 0.02, 0.08), Color(0.6, 0.6, 0.65), Vector3.ZERO, rotor, false)
	var tag := label("REPO", 48, Color(1, 0.85, 0.2), Vector3(0, 0.75, -0.42))
	tag.pixel_size = 0.004
	mouth = body



func _build_doodle() -> void:
	# A stick figure somebody drew in second grade and then forgot about.
	var ink := Color(0.1, 0.1, 0.15)
	ball(0.34, Color(1.0, 0.95, 0.85), Vector3(0, 1.75, 0), null, true, Vector3(1, 1, 0.5))
	eyes(Vector3(0, 1.8, -0.16), 0.11, 0.06)
	mouth = box(Vector3(0.2, 0.04, 0.02), Color(0.8, 0.1, 0.1), Vector3(0, 1.62, -0.17), null, false)
	for i in 5:
		box(Vector3(0.05, 0.28, 0.05), Color(1.0, 0.5, 0.1), Vector3(-0.24 + i * 0.12, 2.08, 0), null, false, Vector3(0, 0, -0.5 + i * 0.25))
	box(Vector3(0.07, 0.8, 0.07), ink, Vector3(0, 1.0, 0), null, false)
	# Triangle skirt of crayon purple.
	cyl(0.38, 0.55, Color(0.55, 0.3, 0.9), Vector3(0, 0.92, 0), null, true, Vector3.ZERO, 0.04)
	for side in [-1.0, 1.0]:
		var arm := Node3D.new()
		arm.position = Vector3(side * 0.05, 1.3, 0)
		body.add_child(arm)
		parts["arm_l" if side < 0.0 else "arm_r"] = arm
		box(Vector3(0.6, 0.06, 0.06), ink, Vector3(side * 0.3, 0, 0), arm, false)
		box(Vector3(0.07, 0.62, 0.07), ink, Vector3(side * 0.13, 0.3, 0), null, false, Vector3(0, 0, side * 0.3))


func _build_scribble() -> void:
	# An angry tangle of crayon lines.
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	var col := [Color(0.35, 0.15, 0.6), Color(0.1, 0.1, 0.12), Color(0.8, 0.15, 0.2)]
	var tangle := Node3D.new()
	tangle.position.y = 0.8
	body.add_child(tangle)
	parts.tangle = tangle
	for i in 7:
		var t := MeshInstance3D.new()
		var tor := TorusMesh.new()
		tor.inner_radius = rng.randf_range(0.45, 0.62)
		tor.outer_radius = tor.inner_radius + 0.07
		tor.rings = 20
		tor.ring_segments = 5
		t.mesh = tor
		t.material_override = Mats.solid(col[i % 3], 0.9)
		t.rotation = Vector3(rng.randf() * TAU, rng.randf() * TAU, rng.randf() * TAU)
		tangle.add_child(t)
	eyes(Vector3(0, 0.95, -0.55), 0.16, 0.12, null, true)
	mouth = body


func _build_duck() -> void:
	var yellow := Color(1.0, 0.85, 0.1)
	ball(0.55, yellow, Vector3(0, 0.5, 0.1), null, true, Vector3(1, 0.75, 1.25))
	ball(0.3, yellow, Vector3(0, 0.95, 0.5), null, true, Vector3(1, 0.5, 0.8))
	var head := Node3D.new()
	head.position = Vector3(0, 1.15, -0.35)
	body.add_child(head)
	parts.head = head
	ball(0.34, yellow, Vector3.ZERO, head)
	box(Vector3(0.32, 0.1, 0.3), Color(1.0, 0.45, 0.05), Vector3(0, -0.05, -0.35), head)
	eyes(Vector3(0, 0.1, -0.27), 0.13, 0.08, head, true)
	mouth = head


func _build_camel() -> void:
	# A camel folded out of hotel towels.
	var towel := Color(0.55, 0.85, 0.85)
	var cream := Color(0.97, 0.96, 0.92)
	for x in [-0.35, 0.35]:
		for z in [-0.5, 0.5]:
			cyl(0.13, 1.0, cream, Vector3(x, 0.5, z))
	box(Vector3(1.0, 0.5, 1.5), towel, Vector3(0, 1.15, 0))
	ball(0.35, towel, Vector3(0, 1.5, 0.15), null, true, Vector3(1.2, 0.8, 1.4))
	box(Vector3(0.9, 0.08, 1.4), cream, Vector3(0, 1.42, 0), null, false)
	var neck := Node3D.new()
	neck.position = Vector3(0, 1.3, -0.7)
	body.add_child(neck)
	parts.head = neck
	cyl(0.14, 1.0, towel, Vector3(0, 0.45, -0.1), neck, true, Vector3(-0.35, 0, 0))
	box(Vector3(0.34, 0.3, 0.55), towel, Vector3(0, 0.95, -0.35), neck)
	eyes(Vector3(0, 1.05, -0.63), 0.1, 0.07, neck)
	mouth = box(Vector3(0.18, 0.04, 0.02), Color(0.3, 0.3, 0.3), Vector3(0, 0.85, -0.63), neck, false)


func _build_moneybeard() -> void:
	var coat := Color(0.62, 0.08, 0.08)
	var skin := Color(0.9, 0.7, 0.55)
	var black := Color(0.08, 0.07, 0.07)
	box(Vector3(0.3, 0.7, 0.32), black, Vector3(-0.25, 0.35, 0))
	cyl(0.07, 0.7, Color(0.5, 0.33, 0.18), Vector3(0.25, 0.35, 0))
	box(Vector3(1.1, 1.2, 0.72), coat, Vector3(0, 1.3, 0))
	box(Vector3(1.14, 0.14, 0.76), black, Vector3(0, 1.05, 0), null, false)
	box(Vector3(0.22, 0.18, 0.05), Mats.gold().albedo_color, Vector3(0, 1.05, -0.4), null, false)
	for i in 3:
		ball(0.05, Mats.gold().albedo_color, Vector3(0.18, 1.6 - i * 0.2, -0.37), null, false)
		ball(0.05, Mats.gold().albedo_color, Vector3(-0.18, 1.6 - i * 0.2, -0.37), null, false)
	var head := Node3D.new()
	head.position.y = 2.05
	body.add_child(head)
	parts.head = head
	box(Vector3(0.62, 0.58, 0.58), skin, Vector3.ZERO, head)
	ball(0.1, Color(0.95, 0.5, 0.4), Vector3(0, -0.02, -0.32), head, false)
	# One eye, one patch.
	ball(0.08, Color.WHITE, Vector3(-0.14, 0.08, -0.29), head, false)
	ball(0.04, black, Vector3(-0.14, 0.08, -0.34), head, false)
	box(Vector3(0.2, 0.18, 0.04), black, Vector3(0.14, 0.08, -0.3), head, false)
	box(Vector3(0.7, 0.04, 0.04), black, Vector3(0, 0.14, -0.3), head, false, Vector3(0, 0, 0.3))
	# A beard made entirely of gold coins.
	for i in 11:
		var a := -0.9 + i * 0.18
		var c := cyl(0.1, 0.03, Mats.gold().albedo_color, Vector3(sin(a) * 0.3, -0.3 - cos(a) * 0.12 - (i % 3) * 0.05, -0.28 + absf(a) * 0.1), head, false, Vector3(PI / 2, 0, a))
		c.material_override = Mats.gold()
	mouth = box(Vector3(0.22, 0.06, 0.04), Color(0.3, 0.05, 0.05), Vector3(0, -0.14, -0.3), head, false)
	# Tricorn hat with a dollar-sign jolly roger.
	cyl(0.55, 0.08, black, Vector3(0, 0.34, 0), head)
	cyl(0.34, 0.35, black, Vector3(0, 0.52, 0), head)
	for i in 3:
		var a := TAU * i / 3.0
		box(Vector3(0.7, 0.25, 0.08), black, Vector3(sin(a) * 0.42, 0.45, cos(a) * 0.42), head, true, Vector3(0.4, a, 0))
	var sk := MeshInstance3D.new()
	sk.mesh = Mats.dollar_mesh()
	sk.material_override = Mats.solid(Color.WHITE, 0.5)
	sk.scale = Vector3(0.25, 0.25, 0.3)
	sk.position = Vector3(0, 0.55, -0.36)
	head.add_child(sk)
	# Cutlass arm and hook arm.
	var arm_r := Node3D.new()
	arm_r.position = Vector3(0.66, 1.75, 0)
	body.add_child(arm_r)
	parts.arm_r = arm_r
	box(Vector3(0.26, 0.7, 0.28), coat, Vector3(0, -0.32, 0), arm_r)
	box(Vector3(0.22, 0.18, 0.24), skin, Vector3(0, -0.72, 0), arm_r)
	box(Vector3(0.08, 1.2, 0.03), Color(0.85, 0.87, 0.92), Vector3(0, -0.72, -0.62), arm_r, false, Vector3(PI / 2, 0, 0))
	box(Vector3(0.3, 0.06, 0.1), Mats.gold().albedo_color, Vector3(0, -0.72, -0.1), arm_r, false)
	var arm_l := Node3D.new()
	arm_l.position = Vector3(-0.66, 1.75, 0)
	body.add_child(arm_l)
	parts.arm_l = arm_l
	box(Vector3(0.26, 0.7, 0.28), coat, Vector3(0, -0.32, 0), arm_l)
	var hook := MeshInstance3D.new()
	var tor := TorusMesh.new()
	tor.inner_radius = 0.1
	tor.outer_radius = 0.15
	hook.mesh = tor
	hook.material_override = Mats.gold()
	hook.rotation.z = PI / 2
	hook.position.y = -0.8
	arm_l.add_child(hook)
	# The parrot, who does most of the thinking.
	var parrot := Node3D.new()
	parrot.position = Vector3(0.45, 2.02, 0.05)
	body.add_child(parrot)
	parts.parrot = parrot
	ball(0.16, Color(0.1, 0.75, 0.25), Vector3(0, 0, 0), parrot, true, Vector3(0.9, 1.2, 1))
	ball(0.11, Color(0.1, 0.75, 0.25), Vector3(0, 0.2, -0.05), parrot)
	box(Vector3(0.06, 0.08, 0.1), Color(1.0, 0.3, 0.1), Vector3(0, 0.18, -0.17), parrot, false)
	box(Vector3(0.1, 0.24, 0.05), Color(0.9, 0.15, 0.15), Vector3(0, -0.15, 0.12), parrot, false, Vector3(0.5, 0, 0))



func _build_cuckoo() -> void:
	# A wooden cuckoo on a spring, out of its clock for the first time in years.
	var wood := Color(0.55, 0.35, 0.18)
	box(Vector3(0.9, 1.2, 0.8), Color(0.4, 0.24, 0.12), Vector3(0, 0.6, 0.3))
	for i in 5:
		var coil := MeshInstance3D.new()
		var t := TorusMesh.new()
		t.inner_radius = 0.1
		t.outer_radius = 0.14
		coil.mesh = t
		coil.material_override = Mats.solid(Color(0.75, 0.75, 0.8), 0.3, 0.9)
		coil.rotation.x = PI / 2
		coil.position = Vector3(0, 1.0, -0.15 - i * 0.08)
		body.add_child(coil)
	var bird := Node3D.new()
	bird.position = Vector3(0, 1.0, -0.6)
	body.add_child(bird)
	parts.bird = bird
	ball(0.3, wood, Vector3.ZERO, bird, true, Vector3(0.9, 0.9, 1.2))
	ball(0.2, wood, Vector3(0, 0.25, -0.2), bird)
	box(Vector3(0.1, 0.08, 0.25), Color(1.0, 0.6, 0.1), Vector3(0, 0.22, -0.45), bird, false)
	eyes(Vector3(0, 0.32, -0.36), 0.08, 0.05, bird)
	box(Vector3(0.5, 0.06, 0.3), Color(0.35, 0.2, 0.1), Vector3(0, 0.05, 0.25), bird, false, Vector3(0.3, 0, 0))
	mouth = bird


func _build_gearbot() -> void:
	var brass := Color(0.8, 0.6, 0.25)
	var wheel := Node3D.new()
	wheel.position.y = 0.8
	body.add_child(wheel)
	parts.wheel = wheel
	cyl(0.7, 0.35, brass, Vector3.ZERO, wheel, true, Vector3(0, 0, PI / 2))
	for i in 10:
		var a := TAU * i / 10.0
		box(Vector3(0.36, 0.22, 0.25), brass.darkened(0.2), Vector3(0, sin(a) * 0.78, cos(a) * 0.78), wheel, false, Vector3(-a, 0, 0))
	cyl(0.25, 0.4, Color(0.3, 0.3, 0.32), Vector3.ZERO, wheel, false, Vector3(0, 0, PI / 2))
	eyes(Vector3(0, 1.05, -0.3), 0.14, 0.1, null, true)
	mouth = body


func _build_grandclock() -> void:
	# A grandfather clock. Literally. Twelve hundred years old.
	var wood := Color(0.36, 0.2, 0.1)
	var trim := Color(0.8, 0.6, 0.25)
	box(Vector3(1.6, 0.35, 1.1), wood.darkened(0.2), Vector3(0, 0.18, 0))
	box(Vector3(1.3, 2.4, 0.9), wood, Vector3(0, 1.55, 0))
	box(Vector3(0.9, 1.7, 0.05), Color(0.6, 0.8, 0.9), Vector3(0, 1.5, -0.46), null, false)
	var pend := Node3D.new()
	pend.position = Vector3(0, 2.2, -0.4)
	body.add_child(pend)
	parts.pendulum = pend
	box(Vector3(0.05, 1.1, 0.03), trim, Vector3(0, -0.55, 0), pend, false)
	cyl(0.2, 0.05, trim, Vector3(0, -1.15, 0), pend, false, Vector3(PI / 2, 0, 0))
	# The hood, with a big round face.
	box(Vector3(1.6, 1.5, 1.05), wood, Vector3(0, 3.5, 0))
	box(Vector3(1.8, 0.2, 1.15), trim, Vector3(0, 4.3, 0), null, false)
	for x in [-0.5, 0.0, 0.5]:
		ball(0.12, trim, Vector3(x, 4.5, 0), null, false)
	cyl(0.62, 0.06, Color(0.97, 0.94, 0.85), Vector3(0, 3.5, -0.54), null, true, Vector3(PI / 2, 0, 0))
	for i in 12:
		var a := TAU * i / 12.0
		box(Vector3(0.04, 0.1, 0.02), Color(0.1, 0.1, 0.1), Vector3(sin(a) * 0.5, 3.5 + cos(a) * 0.5, -0.58), null, false, Vector3(0, 0, -a))
	var minute := Node3D.new()
	minute.position = Vector3(0, 3.5, -0.6)
	body.add_child(minute)
	parts.minute = minute
	box(Vector3(0.04, 0.45, 0.02), Color(0.05, 0.05, 0.05), Vector3(0, 0.2, 0), minute, false)
	var hour := Node3D.new()
	hour.position = Vector3(0, 3.5, -0.61)
	body.add_child(hour)
	parts.hour = hour
	box(Vector3(0.06, 0.3, 0.02), Color(0.05, 0.05, 0.05), Vector3(0, 0.13, 0), hour, false)
	# Spectacles, eyebrows, a magnificent mustache.
	for s in [-1.0, 1.0]:
		var lens := MeshInstance3D.new()
		var t := TorusMesh.new()
		t.inner_radius = 0.13
		t.outer_radius = 0.16
		lens.mesh = t
		lens.material_override = Mats.gold()
		lens.rotation.x = PI / 2
		lens.position = Vector3(s * 0.22, 3.62, -0.64)
		body.add_child(lens)
		ball(0.05, Color(0.1, 0.1, 0.1), Vector3(s * 0.22, 3.62, -0.62), null, false)
		box(Vector3(0.36, 0.12, 0.1), Color(0.95, 0.95, 0.95), Vector3(s * 0.25, 3.85, -0.62), null, true, Vector3(0, 0, -s * 0.25))
		box(Vector3(0.45, 0.14, 0.12), Color(0.95, 0.95, 0.95), Vector3(s * 0.24, 3.28, -0.64), null, true, Vector3(0, 0, s * 0.35))
	mouth = box(Vector3(0.2, 0.05, 0.03), Color(0.2, 0.05, 0.05), Vector3(0, 3.16, -0.6), null, false)
	# Tiny arms and a cane.
	for s in [-1.0, 1.0]:
		var arm := Node3D.new()
		arm.position = Vector3(s * 0.75, 2.5, 0)
		body.add_child(arm)
		parts["arm_l" if s < 0.0 else "arm_r"] = arm
		box(Vector3(0.18, 0.8, 0.18), wood, Vector3(0, -0.38, 0), arm)
		ball(0.13, Color(0.95, 0.95, 0.95), Vector3(0, -0.82, 0), arm)
	cyl(0.04, 1.8, Color(0.2, 0.12, 0.06), Vector3(0, -1.6, -0.1), parts.arm_r, false)
	var cw := MeshInstance3D.new()
	var ct := TorusMesh.new()
	ct.inner_radius = 0.1
	ct.outer_radius = 0.15
	cw.mesh = ct
	cw.material_override = Mats.gold()
	cw.position = Vector3(0, -0.72, -0.2)
	parts.arm_r.add_child(cw)


func _build_baby() -> void:
	# Baby Bigbucks: sitting, facing -Z, about 2.8 units tall. Scaled up by the boss.
	var skin := Color(1.0, 0.8, 0.68)
	var onesie := Color(0.62, 0.8, 1.0)
	var white := Color(0.98, 0.97, 0.95)
	ball(0.8, white, Vector3(0, 0.55, 0.05), null, true, Vector3(1.1, 0.75, 1.0))
	ball(0.66, onesie, Vector3(0, 1.2, 0), null, true, Vector3(1.0, 1.05, 0.9))
	# A gold dollar sign on the onesie. Rich baby.
	var sign := MeshInstance3D.new()
	sign.mesh = Mats.dollar_mesh()
	sign.material_override = Mats.gold()
	sign.scale = Vector3(0.45, 0.45, 0.3)
	sign.position = Vector3(0, 1.2, -0.6)
	body.add_child(sign)
	# Stubby legs sticking out in front.
	for side in [-1.0, 1.0]:
		cyl(0.24, 0.7, skin, Vector3(side * 0.42, 0.3, -0.55), null, true, Vector3(PI / 2, 0, 0))
		ball(0.26, skin, Vector3(side * 0.42, 0.32, -0.95), null, true, Vector3(1, 1.1, 1.2))
	var head := Node3D.new()
	head.position.y = 2.05
	body.add_child(head)
	parts.head = head
	ball(0.74, skin, Vector3.ZERO, head)
	for side in [-1.0, 1.0]:
		ball(0.18, skin, Vector3(side * 0.72, 0.0, 0.0), head)
		ball(0.15, Color(1.0, 0.55, 0.6), Vector3(side * 0.4, -0.2, -0.55), head, false, Vector3(1, 0.7, 0.4))
	eyes(Vector3(0, 0.12, -0.6), 0.25, 0.14, head)
	ball(0.07, Color(1.0, 0.65, 0.55), Vector3(0, -0.05, -0.72), head, false)
	# The one hair curl.
	var curl := MeshInstance3D.new()
	var ct := TorusMesh.new()
	ct.inner_radius = 0.08
	ct.outer_radius = 0.13
	curl.mesh = ct
	curl.material_override = Mats.toon(Color(0.95, 0.75, 0.35))
	curl.position = Vector3(0, 0.78, -0.1)
	curl.rotation.z = PI / 2
	head.add_child(curl)
	# A solid-gold pacifier.
	var paci := Node3D.new()
	paci.position = Vector3(0, -0.3, -0.7)
	head.add_child(paci)
	parts.paci = paci
	cyl(0.2, 0.06, Color(1.0, 0.55, 0.75), Vector3.ZERO, paci, true, Vector3(PI / 2, 0, 0))
	var ring := MeshInstance3D.new()
	var rt := TorusMesh.new()
	rt.inner_radius = 0.1
	rt.outer_radius = 0.15
	ring.mesh = rt
	ring.material_override = Mats.gold()
	ring.rotation.x = PI / 2
	ring.position.z = -0.08
	paci.add_child(ring)
	mouth = box(Vector3(0.24, 0.07, 0.03), Color(0.55, 0.15, 0.2), Vector3(0, -0.34, -0.66), head, false)
	for side in [-1.0, 1.0]:
		var arm := Node3D.new()
		arm.position = Vector3(side * 0.62, 1.5, 0)
		body.add_child(arm)
		parts["arm_l" if side < 0.0 else "arm_r"] = arm
		cyl(0.2, 0.7, onesie, Vector3(0, -0.3, 0), arm)
		ball(0.22, skin, Vector3(0, -0.7, 0), arm)
	# A rattle in the right hand.
	var rattle := Node3D.new()
	rattle.position = Vector3(0, -0.72, -0.1)
	parts.arm_r.add_child(rattle)
	parts.rattle = rattle
	cyl(0.06, 0.8, Color(1.0, 0.85, 0.3), Vector3(0, 0, -0.3), rattle, true, Vector3(PI / 2, 0, 0))
	ball(0.3, Color(1.0, 0.4, 0.55), Vector3(0, 0, -0.8), rattle)
	for i in 4:
		var a := TAU * i / 4.0
		ball(0.08, Color(0.4, 0.8, 1.0), Vector3(cos(a) * 0.26, sin(a) * 0.26, -0.8), rattle, false)


func _build_teddy() -> void:
	# Sir Snuggles: a well-loved teddy bear with one button eye.
	var fur := Color(0.72, 0.5, 0.3)
	var light := Color(0.92, 0.78, 0.6)
	for side in [-1.0, 1.0]:
		ball(0.2, fur, Vector3(side * 0.24, 0.18, -0.12), null, true, Vector3(1, 0.8, 1.3))
	ball(0.45, fur, Vector3(0, 0.6, 0), null, true, Vector3(1, 1.05, 0.9))
	ball(0.28, light, Vector3(0, 0.55, -0.3), null, false, Vector3(1, 1.1, 0.4))
	# A patch, stitched on with love and poor technique.
	box(Vector3(0.18, 0.16, 0.03), Color(0.45, 0.65, 0.9), Vector3(0.22, 0.78, -0.36), null, false, Vector3(0, 0, 0.3))
	var head := Node3D.new()
	head.position.y = 1.25
	body.add_child(head)
	parts.head = head
	ball(0.36, fur, Vector3.ZERO, head)
	for side in [-1.0, 1.0]:
		ball(0.13, fur, Vector3(side * 0.28, 0.3, 0), head)
		ball(0.07, light, Vector3(side * 0.28, 0.3, -0.07), head, false)
	ball(0.16, light, Vector3(0, -0.08, -0.3), head, false, Vector3(1, 0.8, 0.8))
	ball(0.05, Color(0.1, 0.06, 0.04), Vector3(0, -0.02, -0.43), head, false)
	# One button eye, one stitched X.
	cyl(0.07, 0.03, Color(0.1, 0.1, 0.12), Vector3(-0.13, 0.08, -0.32), head, false, Vector3(PI / 2, 0, 0))
	for r in [0.7, -0.7]:
		box(Vector3(0.14, 0.02, 0.02), Color(0.1, 0.06, 0.04), Vector3(0.13, 0.08, -0.33), head, false, Vector3(0, 0, r))
	mouth = box(Vector3(0.1, 0.03, 0.02), Color(0.2, 0.08, 0.05), Vector3(0, -0.17, -0.4), head, false)
	for side in [-1.0, 1.0]:
		var arm := Node3D.new()
		arm.position = Vector3(side * 0.42, 0.85, 0)
		body.add_child(arm)
		parts["arm_l" if side < 0.0 else "arm_r"] = arm
		ball(0.14, fur, Vector3(side * 0.05, -0.2, 0), arm, true, Vector3(1, 1.6, 1))


func _build_soldier() -> void:
	# A wind-up tin soldier. Marches. Glares. Wound far too tight.
	var red := Color(0.85, 0.12, 0.12)
	var blue := Color(0.15, 0.2, 0.5)
	for side in [-1.0, 1.0]:
		var leg := box(Vector3(0.18, 0.5, 0.2), blue, Vector3(side * 0.13, 0.25, 0))
		parts["leg_l" if side < 0.0 else "leg_r"] = leg
	box(Vector3(0.5, 0.5, 0.34), red, Vector3(0, 0.75, 0))
	box(Vector3(0.52, 0.08, 0.36), Color(0.95, 0.95, 0.9), Vector3(0, 0.55, 0), null, false)
	for i in 3:
		ball(0.035, Mats.gold().albedo_color, Vector3(0, 0.9 - i * 0.12, -0.18), null, false)
	ball(0.2, Color(1.0, 0.82, 0.7), Vector3(0, 1.15, 0))
	ball(0.06, Color(0.95, 0.35, 0.35), Vector3(0.12, 1.1, -0.15), null, false)
	ball(0.06, Color(0.95, 0.35, 0.35), Vector3(-0.12, 1.1, -0.15), null, false)
	eyes(Vector3(0, 1.2, -0.16), 0.07, 0.045, null, true)
	cyl(0.19, 0.4, Color(0.08, 0.08, 0.1), Vector3(0, 1.48, 0))
	box(Vector3(0.1, 0.12, 0.03), Mats.gold().albedo_color, Vector3(0, 1.42, -0.19), null, false)
	# The wind-up key on his back.
	var key := Node3D.new()
	key.position = Vector3(0, 0.8, 0.25)
	body.add_child(key)
	parts.key = key
	cyl(0.03, 0.2, Color(0.8, 0.8, 0.85), Vector3(0, 0, 0.1), key, false, Vector3(PI / 2, 0, 0))
	for side in [-1.0, 1.0]:
		ball(0.1, Mats.gold().albedo_color, Vector3(side * 0.1, 0, 0.22), key, false, Vector3(1, 0.7, 0.3))
	mouth = body



func _build_snowman() -> void:
	# An angry snowman. Coal eyes, carrot nose, zero chill.
	var snow := Color(0.95, 0.97, 1.0)
	ball(0.45, snow, Vector3(0, 0.42, 0))
	ball(0.34, snow, Vector3(0, 0.98, 0))
	var head := Node3D.new()
	head.position.y = 1.42
	body.add_child(head)
	parts.head = head
	ball(0.25, snow, Vector3.ZERO, head)
	eyes(Vector3(0, 0.06, -0.2), 0.09, 0.05, head, true)
	cyl(0.05, 0.3, Color(1.0, 0.5, 0.1), Vector3(0, -0.03, -0.35), head, true, Vector3(PI / 2, 0, 0), 0.0)
	cyl(0.2, 0.04, Color(0.1, 0.1, 0.12), Vector3(0, 0.2, 0), head)
	cyl(0.14, 0.26, Color(0.1, 0.1, 0.12), Vector3(0, 0.34, 0), head)
	for i in 3:
		ball(0.04, Color(0.1, 0.1, 0.12), Vector3(0, 1.1 - i * 0.15, -0.32), null, false)
	for side in [-1.0, 1.0]:
		cyl(0.03, 0.6, Color(0.4, 0.25, 0.1), Vector3(side * 0.5, 1.05, 0), null, false, Vector3(0, 0, side * 1.1))
	mouth = head


func _build_ember() -> void:
	# A hopping blob of living fire.
	var core := ball(0.45, Color(1.0, 0.45, 0.1), Vector3(0, 0.5, 0), null, false, Vector3(1, 0.9, 1))
	core.material_override = Mats.glow(Color(1.0, 0.45, 0.08), 2.5)
	var flames := Node3D.new()
	flames.position.y = 0.75
	body.add_child(flames)
	parts.flames = flames
	for i in 5:
		var a := TAU * i / 5.0
		var f := cyl(0.16, 0.6, Color(1.0, 0.8, 0.2), Vector3(cos(a) * 0.22, 0.15, sin(a) * 0.22), flames, false, Vector3(sin(a) * 0.3, 0, -cos(a) * 0.3), 0.0)
		f.material_override = Mats.glow(Color(1.0, 0.75, 0.2), 3.0)
	eyes(Vector3(0, 0.6, -0.36), 0.12, 0.08, null, true)
	mouth = body


## A dragon's head, facing -Z, about 1 unit tall and 2 long. The boss scales
## it up and hangs it on a long neck.
func _build_dragon_head(fire: bool) -> void:
	var skin := Color(0.85, 0.2, 0.08) if fire else Color(0.55, 0.8, 0.98)
	var dark := Color(0.35, 0.06, 0.04) if fire else Color(0.25, 0.45, 0.7)
	var glow_col := Color(1.0, 0.85, 0.2) if fire else Color(0.5, 1.0, 1.0)
	var horn := Color(0.12, 0.08, 0.08) if fire else Color(0.9, 0.97, 1.0)
	box(Vector3(1.1, 0.8, 1.2), skin, Vector3(0, 0.1, 0.1))
	box(Vector3(0.8, 0.5, 1.1), skin, Vector3(0, 0.05, -0.95))
	box(Vector3(0.9, 0.12, 0.9), dark, Vector3(0, 0.5, 0.0), null, false)
	for side in [-1.0, 1.0]:
		# Glowing eyes under a heavy brow.
		var e := ball(0.13, glow_col, Vector3(side * 0.36, 0.3, -0.45), null, false, Vector3(1, 0.7, 0.6))
		e.material_override = Mats.glow(glow_col, 4.0)
		box(Vector3(0.36, 0.1, 0.3), dark, Vector3(side * 0.36, 0.43, -0.42), null, false, Vector3(0, 0, -side * 0.3))
		ball(0.05, Color(0.05, 0.05, 0.05), Vector3(side * 0.16, 0.22, -1.5), null, false)
		# Horns sweeping back.
		var h := cyl(0.14, 1.0, horn, Vector3(side * 0.35, 0.75, 0.55), null, true, Vector3(1.0, 0, side * 0.35), 0.0)
		if not fire:
			h.material_override = Mats.glass(horn, 0.8)
		cyl(0.08, 0.5, horn, Vector3(side * 0.56, 0.35, 0.45), null, true, Vector3(1.2, 0, side * 0.9), 0.0)
	# A crest of spikes (fire) or icicle frills (ice) down the back.
	for i in 4:
		var sp := cyl(0.12, 0.45, dark if fire else Color(0.8, 0.95, 1.0), Vector3(0, 0.62, 0.6 + i * 0.3), null, true, Vector3(-0.5, 0, 0), 0.0)
		if not fire:
			sp.material_override = Mats.glass(Color(0.8, 0.95, 1.0), 0.75)
	var jaw := Node3D.new()
	jaw.position = Vector3(0, -0.22, 0.4)
	body.add_child(jaw)
	parts.jaw = jaw
	box(Vector3(0.75, 0.22, 1.5), dark, Vector3(0, -0.05, -0.8), jaw)
	for i in 5:
		for side in [-1.0, 1.0]:
			box(Vector3(0.07, 0.14, 0.07), Color(0.98, 0.96, 0.9), Vector3(side * 0.3, 0.1, -1.4 + i * 0.22), jaw, false)
	var tongue := box(Vector3(0.3, 0.06, 0.8), glow_col, Vector3(0, 0.08, -0.8), jaw, false)
	tongue.material_override = Mats.glow(glow_col, 2.0)
	mouth = body



func _build_placeholder() -> void:
	# A character whose model never loaded: a grey box, a question mark and a name tag.
	var grey := Color(0.55, 0.55, 0.58)
	box(Vector3(0.8, 1.6, 0.5), grey, Vector3(0, 0.8, 0))
	var q := label("?", 200, Color(0.2, 0.2, 0.22), Vector3(0, 1.05, -0.26))
	q.pixel_size = 0.004
	var who: String = Voice.info(speaker).name if speaker != "" else "NPC"
	var tag := label("%s\n[model not found]" % who, 44, Color(1.0, 0.25, 0.8), Vector3(0, 2.0, 0))
	tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	tag.rotation = Vector3.ZERO
	mouth = body



## Where the red nose is, in this puppet's own space (the boss's weak point).
const CLOWN_NOSE := Vector3(0, 2.5, -0.62)


func _build_clown() -> void:
	# Chuckles the Colossal: a very large, very sincere clown. The level or the
	# boss scales him up; 1 unit is about a normal clown.
	var suit := Color(0.95, 0.25, 0.42)
	var skin := Color(0.99, 0.96, 0.94)
	var yellow := Color(1.0, 0.85, 0.25)
	var blue := Color(0.25, 0.4, 0.95)
	for side in [-1.0, 1.0]:
		var leg := Node3D.new()
		leg.position = Vector3(side * 0.28, 0.85, 0)
		body.add_child(leg)
		parts["leg_l" if side < 0.0 else "leg_r"] = leg
		cyl(0.17, 0.75, blue, Vector3(0, -0.4, 0), leg)
		ball(0.32, Color(0.9, 0.15, 0.15), Vector3(0, -0.78, -0.3), leg, true, Vector3(1.0, 0.55, 1.9))
		ball(0.09, yellow, Vector3(0, -0.66, -0.7), leg, false)
	# The baggy suit, with polka dots.
	ball(0.88, suit, Vector3(0, 1.5, 0), null, true, Vector3(1.0, 0.95, 0.9))
	for d in [[-0.4, 1.7], [0.4, 1.7], [0.0, 1.45], [-0.55, 1.3], [0.55, 1.3], [0.0, 1.9], [-0.25, 1.15], [0.25, 1.15]]:
		ball(0.11, yellow, Vector3(d[0], d[1], -0.78), null, false, Vector3(1, 1, 0.4))
	cyl(0.6, 0.16, yellow, Vector3(0, 2.05, 0), null, true, Vector3.ZERO, 0.4)
	for side in [-1.0, 1.0]:
		ball(0.09, blue, Vector3(side * 0.14, 1.95, -0.5), null, false)
	# Head.
	var head := Node3D.new()
	head.position.y = 2.6
	body.add_child(head)
	parts.head = head
	ball(0.56, skin, Vector3.ZERO, head)
	eyes(Vector3(0, 0.12, -0.46), 0.22, 0.13, head)
	for side in [-1.0, 1.0]:
		# Diamond makeup and eyebrows drawn a little too high.
		box(Vector3(0.14, 0.14, 0.03), blue, Vector3(side * 0.22, 0.0, -0.53), head, false, Vector3(0, 0, PI / 4))
		box(Vector3(0.3, 0.05, 0.03), Color(0.1, 0.05, 0.1), Vector3(side * 0.22, 0.36, -0.44), head, false, Vector3(0, 0, -side * 0.3))
	# The nose. Honk.
	var nose := ball(0.2, Color(1.0, 0.1, 0.1), Vector3(0, -0.07, -0.62), head, true)
	nose.material_override = Mats.glow(Color(1.0, 0.15, 0.1), 0.8)
	mouth = box(Vector3(0.52, 0.1, 0.05), Color(0.85, 0.05, 0.1), Vector3(0, -0.32, -0.5), head, false)
	# Rainbow hair and a tiny party hat.
	var hair := [Color(1.0, 0.3, 0.3), Color(1.0, 0.6, 0.2), Color(1.0, 0.9, 0.2), Color(0.3, 0.85, 0.4), Color(0.3, 0.6, 1.0), Color(0.7, 0.4, 0.95)]
	for i in 6:
		var a := TAU * i / 6.0
		ball(0.2, hair[i], Vector3(sin(a) * 0.55, 0.2 + cos(a * 2.0) * 0.06, cos(a) * 0.4 + 0.1), head)
	for i in 3:
		ball(0.2, hair[i * 2], Vector3(sin(i * 2.1) * 0.25, 0.55, cos(i * 2.1) * 0.2), head)
	cyl(0.25, 0.55, yellow, Vector3(0.12, 0.98, 0), head, true, Vector3(0, 0, -0.25), 0.0)
	ball(0.09, Color(1, 0.3, 0.4), Vector3(0.04, 1.28, 0), head, false)
	# Arms with big white gloves.
	for side in [-1.0, 1.0]:
		var arm := Node3D.new()
		arm.position = Vector3(side * 0.98, 1.9, 0)
		body.add_child(arm)
		parts["arm_l" if side < 0.0 else "arm_r"] = arm
		cyl(0.17, 0.95, suit, Vector3(0, -0.45, 0), arm)
		ball(0.3, Color.WHITE, Vector3(0, -1.0, 0), arm)


# ---------------------------------------------------------------- animation

func _process(delta: float) -> void:
	_t += delta
	var talking: bool = speaker != "" and Game.fx and Game.fx.dialogue_open and Game.fx.current_speaker().trim_suffix("_evil") == speaker
	_talk = lerpf(_talk, 1.0 if talking else 0.0, 10.0 * delta)
	var bounce := absf(sin(_t * 11.0)) * _talk
	squash = lerpf(squash, 1.0, 8.0 * delta)
	var s := squash + bounce * 0.06
	body.scale = Vector3(1.0 / sqrt(s), s, 1.0 / sqrt(s))
	body.position.y = sin(_t * 2.0) * 0.02
	if mouth and mouth != body and mouth != parts.get("head"):
		mouth.scale.y = 1.0 + bounce * 2.5

	match kind:
		"steve":
			var b: Node3D = parts.board
			b.rotation.z = sin(_t * 1.3) * 0.04 + (0.12 if emote == "shrug" else 0.0)
			if emote == "evil":
				b.rotation.z = sin(_t * 8.0) * 0.05
		"baron":
			parts.head.rotation.z = sin(_t * 1.5) * 0.05
			parts.arm_l.rotation.x = lerpf(parts.arm_l.rotation.x, -2.6 if emote in ["shocked", "point", "laugh"] else 0.0, 8.0 * delta)
			parts.arm_r.rotation.z = sin(_t * 2.0) * 0.1
			if emote == "laugh":
				body.position.y += absf(sin(_t * 14.0)) * 0.08
		"waffle":
			parts.arm_r.rotation.x = lerpf(parts.arm_r.rotation.x, -2.4 if emote in ["cheer", "point"] else sin(_t) * 0.2, 6.0 * delta)
		"gary":
			parts.arm_r.rotation.x = -1.2 + sin(_t * 0.7) * 0.1
			parts.head.rotation.x = 0.15 + sin(_t * 0.5) * 0.05
		"lefty":
			body.rotation.z = sin(_t * 3.0) * 0.08
			if emote == "cheer":
				body.position.y += absf(sin(_t * 9.0)) * 0.3
		"pigeon":
			parts.head.position.z = -0.25 - absf(sin(_t * 5.0)) * 0.1
		"toast":
			parts.leg_l.rotation.x = sin(_t * 12.0) * 0.6
			parts.leg_r.rotation.x = -sin(_t * 12.0) * 0.6
		"stapler":
			parts.jaw.rotation.x = -absf(sin(_t * 6.0)) * 0.5
		"moth":
			parts.wing_l.rotation.z = sin(_t * 18.0) * 0.6
			parts.wing_r.rotation.z = -sin(_t * 18.0) * 0.6
			body.position.y += sin(_t * 3.0) * 0.15
		"drone":
			parts.rotor_l.rotation.y += delta * 40.0
			parts.rotor_r.rotation.y -= delta * 40.0
			body.position.y += sin(_t * 2.5) * 0.12
		"doodle":
			# Hand-drawn "boiling" wobble.
			if fmod(_t, 0.12) < delta:
				body.rotation.z = randf_range(-0.04, 0.04)
			parts.arm_r.rotation.z = sin(_t * 3.0) * 0.3 + (1.0 if emote in ["cheer", "wave"] else 0.0)
			parts.arm_l.rotation.z = -sin(_t * 3.0) * 0.3 - (1.0 if emote == "cheer" else 0.0)
		"scribble":
			parts.tangle.rotation += Vector3(3.0, 5.0, 2.0) * delta
		"duck":
			body.rotation.z = sin(_t * 10.0) * 0.15
			parts.head.rotation.x = sin(_t * 5.0) * 0.1
		"camel":
			parts.head.rotation.x = sin(_t * 1.2) * 0.1
		"cuckoo":
			parts.bird.position.z = -absf(sin(_t * 3.0)) * 0.25
			parts.bird.rotation.x = sin(_t * 3.0) * 0.2
		"gearbot":
			parts.wheel.rotation.x -= delta * 6.0
		"grandclock":
			parts.pendulum.rotation.z = sin(_t * 2.2) * 0.35
			parts.minute.rotation.z -= delta * 0.6
			parts.hour.rotation.z -= delta * 0.05
			parts.arm_r.rotation.x = lerpf(parts.arm_r.rotation.x, -1.6 if emote == "attack" else -0.2, 4.0 * delta)
			body.rotation.z = sin(_t * 0.9) * 0.03 + (0.08 if emote == "tired" else 0.0)
		"baby":
			var fuss := emote in ["cry", "tantrum"]
			parts.head.rotation.z = sin(_t * (9.0 if fuss else 1.3)) * (0.12 if fuss else 0.05)
			parts.head.rotation.x = lerpf(parts.head.rotation.x, 0.45 if emote in ["sleepy", "asleep"] else 0.0, 3.0 * delta)
			var up: float = -2.6 + sin(_t * 14.0) * 0.5 if fuss else (-2.9 if emote == "throw" else (0.0 if emote == "asleep" else sin(_t * 2.0) * 0.2))
			parts.arm_r.rotation.x = lerpf(parts.arm_r.rotation.x, up, 10.0 * delta)
			var up_l: float = -2.6 - sin(_t * 14.0) * 0.5 if fuss else sin(_t * 2.0 + 1.0) * 0.2
			parts.arm_l.rotation.x = lerpf(parts.arm_l.rotation.x, up_l, 10.0 * delta)
			parts.paci.position.z = -0.7 - (0.0 if fuss else absf(sin(_t * 3.0)) * 0.05)
		"teddy":
			body.rotation.z = sin(_t * 1.6) * 0.05
			parts.head.rotation.z = sin(_t * 1.1) * 0.08
			parts.arm_r.rotation.x = lerpf(parts.arm_r.rotation.x, -2.2 if emote in ["cheer", "point", "wave"] else 0.0, 8.0 * delta)
			parts.arm_l.rotation.x = lerpf(parts.arm_l.rotation.x, -2.4 if emote == "shocked" else 0.0, 8.0 * delta)
		"soldier":
			parts.leg_l.rotation.x = sin(_t * 10.0) * 0.5
			parts.leg_r.rotation.x = -sin(_t * 10.0) * 0.5
			parts.key.rotation.z += delta * 5.0
		"snowman":
			body.rotation.z = sin(_t * 4.0) * 0.08
			parts.head.rotation.y = sin(_t * 1.3) * 0.3
		"ember":
			body.position.y += absf(sin(_t * 6.0)) * 0.25
			parts.flames.rotation.y += delta * 4.0
			parts.flames.scale.y = 1.0 + sin(_t * 17.0) * 0.2
		"clown":
			var running := emote != "stand"
			if running:
				parts.leg_l.rotation.x = sin(_t * 9.0) * 0.7
				parts.leg_r.rotation.x = -sin(_t * 9.0) * 0.7
			parts.head.rotation.z = sin(_t * 2.0) * 0.06
			var wave := sin(_t * 9.0) * 0.5 if running else sin(_t * 1.5) * 0.15
			var r_up: float = -2.8 if emote in ["throw", "smash", "laugh", "point"] else (-0.7 if emote == "shocked" else wave)
			var l_up: float = -2.9 if emote == "smash" else (-0.7 if emote == "shocked" else -wave)
			parts.arm_r.rotation.x = lerpf(parts.arm_r.rotation.x, r_up, 12.0 * delta)
			parts.arm_l.rotation.x = lerpf(parts.arm_l.rotation.x, l_up, 12.0 * delta)
			if emote == "laugh":
				body.position.y += absf(sin(_t * 14.0)) * 0.1
		"raver", "dj":
			# Dancing to the beat: bob, sway, and glow sticks in the air.
			var beat := _t * 6.5 + hash(tint) % 7
			body.position.y += absf(sin(beat)) * 0.14
			body.rotation.z = sin(beat) * 0.07
			parts.head.rotation.z = sin(beat * 0.5) * 0.15
			var cheer := emote in ["cheer", "wave", "shocked"]
			parts.arm_r.rotation.x = lerpf(parts.arm_r.rotation.x, -2.6 + sin(beat) * 0.5 if not cheer else -3.0 + sin(beat * 2.0) * 0.4, 10.0 * delta)
			parts.arm_l.rotation.x = lerpf(parts.arm_l.rotation.x, -2.6 - sin(beat) * 0.5 if kind == "dj" or cheer else sin(beat) * 0.4, 10.0 * delta)
		"placeholder":
			# Jitters like a model that can't decide whether it exists.
			if fmod(_t, 0.5) < delta:
				body.position.x = randf_range(-0.03, 0.03)
		"dragon_ice", "dragon_fire":
			var open := 0.75 if emote == "roar" else (0.15 if emote == "tired" else 0.0)
			# Negative X swings the front of the jaw down.
			parts.jaw.rotation.x = lerpf(parts.jaw.rotation.x, -(open + bounce * 0.45), 12.0 * delta)
			body.rotation.z = sin(_t * 0.9) * 0.04
		"moneybeard":
			body.rotation.z = sin(_t * 2.0) * 0.03
			parts.parrot.position.y = 2.02 + absf(sin(_t * 6.0)) * 0.06
			var swing := -2.2 if emote == "attack" else (-2.8 if emote in ["laugh", "point"] else sin(_t * 1.5) * 0.15)
			parts.arm_r.rotation.x = lerpf(parts.arm_r.rotation.x, swing, 10.0 * delta)
			if emote == "laugh":
				body.position.y += absf(sin(_t * 14.0)) * 0.08
	if emote == "shocked":
		body.position.y += 0.15
