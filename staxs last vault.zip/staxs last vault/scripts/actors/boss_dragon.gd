extends Node3D
## The Twin Dragon of the Frostfire Rift: Cold Hard Cash (the ice head, on the
## left) and Burn Rate (the fire head, on the right). One body, two heads, and
## they never agree on anything.
## Loop: Burn Rate sweeps a wall of fire across the arena (jump it) and rests
## his head on the floor -> Cold Hard Cash calls down an icicle storm (dodge
## the rings), the tail slams (jump the shockwave) and he rests. A resting
## head can be stomped or ground-pounded. At half health: FROSTFIRE. Both
## breaths at once, double tail slams, and the volcano starts throwing meteors.
##
## The node sits at the body, behind the arena, facing +Z (toward it).

signal hit(hp: int)
signal defeated
signal phase_two

const Puppet := preload("res://scripts/actors/puppet.gd")
const Mats := preload("res://scripts/world/mats.gd")
const Fx := preload("res://scripts/world/fx.gd")

const MAX_HP := 6
const HALF_HP := 3
const HEAD_S := 2.6
const NECK_BALLS := 12

enum B { WAIT, FIRE, ICE, BOTH, TAIL, REST, HURT, PHASE, DEAD }

const ICE := 0
const FIRE := 1
const HIT_LINES := [
	["burnrate", "OW! My SNOOT!"],
	["coldcash", "You'll pay for that. With interest."],
	["burnrate", "That's it! I'm going FULL BURN!"],
	["coldcash", "Frozen assets... cracking..."],
	["burnrate", "Why do you keep hitting ME?!"],
	["coldcash", "...Liquidate him."],
]

var player: CharacterBody3D
var level: Node3D
var arena_center := Vector3.ZERO
var arena_radius := 20.0
var hp := MAX_HP
var state: B = B.WAIT
var heads: Array[Node3D] = []          # puppets: [ice, fire]
var _head_pos: Array[Vector3] = [Vector3.ZERO, Vector3.ZERO]   # local
var _head_goal: Array[Vector3] = [Vector3.ZERO, Vector3.ZERO]
var _head_look: Array[Vector3] = [Vector3.ZERO, Vector3.ZERO]  # world
var _necks: Array = [[], []]
var _head_body: Array[StaticBody3D] = []
var _wings: Array[Node3D] = []
var _tail: Array[MeshInstance3D] = []
var _tail_lift := 0.0
var _t := 0.0
var _st := 0.0
var _anim := 0.0
var _cycle := 0
var _resting := ICE
var _did_attack := false
var _flap := 1.0
var _beam: Node3D
var _beam_hot: MeshInstance3D
var _beam_warn: MeshInstance3D
var _beam_fx: GPUParticles3D
var _beam_from := 0.0
var _beam_turn := PI
var _stream: MeshInstance3D
var _drops: Array = []
var _waves: Array = []
var _meteor_t := 0.0
var _phase2 := false
var _told_rest := false


func _ready() -> void:
	_build_body()
	for side in [ICE, FIRE]:
		var h := Puppet.new()
		h.kind = "dragon_fire" if side == FIRE else "dragon_ice"
		h.speaker = "burnrate" if side == FIRE else "coldcash"
		h.scale = Vector3.ONE * HEAD_S
		add_child(h)
		heads.append(h)
		_head_pos[side] = _home(side)
		_head_goal[side] = _home(side)
		var col := Color(1.0, 0.35, 0.1) if side == FIRE else Color(0.6, 0.85, 1.0)
		var mat := Mats.toon(col, 0.6, 0.3)
		for i in NECK_BALLS:
			var m := MeshInstance3D.new()
			var sm := SphereMesh.new()
			var r := lerpf(1.9, 1.0, float(i) / NECK_BALLS)
			sm.radius = r
			sm.height = r * 2.0
			sm.radial_segments = 16
			sm.rings = 8
			m.mesh = sm
			m.material_override = mat
			add_child(m)
			_necks[side].append(m)
		# Something to land on while the head rests on the floor.
		var hb := StaticBody3D.new()
		var cs := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = Vector3(2.6, 2.1, 5.0)
		cs.shape = shape
		hb.add_child(cs)
		hb.top_level = true
		add_child(hb)
		_set_solid(hb, false)
		_head_body.append(hb)
	_build_beam()
	_update_rig(0.0)


func _side_x(side: int) -> float:
	return -1.0 if side == ICE else 1.0


## Raised, looming over the arena.
func _home(side: int) -> Vector3:
	return Vector3(_side_x(side) * 9.0, 21.0, 12.0)


## Chin on the floor, inside the back of the arena.
func _rest_pos(side: int) -> Vector3:
	var w := arena_center + Vector3(_side_x(side) * 6.5, 0.8, -arena_radius + 6.0)
	return to_local(w)


func _floor_y() -> float:
	return arena_center.y


func _set_solid(b: StaticBody3D, on: bool) -> void:
	b.collision_layer = 1 if on else 0
	b.collision_mask = 0
	(b.get_child(0) as CollisionShape3D).disabled = not on


# ---------------------------------------------------------------- body

func _build_body() -> void:
	var ice := Mats.toon(Color(0.55, 0.8, 0.98), 0.5, 0.35)
	var fire := Mats.toon(Color(0.8, 0.18, 0.08), 0.6, 0.3)
	var belly := Mats.toon(Color(0.95, 0.85, 0.6), 0.7, 0.2)
	_ball(Vector3(-3.5, 7.0, 0), 8.0, ice, Vector3(1.0, 0.85, 1.2))
	_ball(Vector3(3.5, 7.0, 0), 8.0, fire, Vector3(1.0, 0.85, 1.2))
	_ball(Vector3(0, 5.5, 6.0), 5.0, belly, Vector3(1.4, 1.0, 0.6))
	# Legs, planted.
	for x in [-7.0, 7.0]:
		for z in [-4.0, 5.0]:
			_ball(Vector3(x, 1.5, z), 2.6, ice if x < 0.0 else fire, Vector3(1, 1.2, 1.3))
	# Wings: a frozen one and a burning one.
	for side in [ICE, FIRE]:
		var pivot := Node3D.new()
		pivot.position = Vector3(_side_x(side) * 7.0, 13.0, -2.0)
		add_child(pivot)
		var wmat: Material = Mats.glass(Color(0.7, 0.9, 1.0), 0.55) if side == ICE else Mats.toon(Color(0.45, 0.08, 0.05), 0.7, 0.3)
		for i in 4:
			var rib := MeshInstance3D.new()
			var bm := BoxMesh.new()
			bm.size = Vector3(16.0 - i * 2.5, 0.5, 5.0)
			rib.mesh = bm
			rib.material_override = wmat
			rib.position = Vector3(_side_x(side) * (8.0 - i * 1.2), 1.0 + i * 0.3, -3.0 - i * 3.5)
			rib.rotation = Vector3(0.1, _side_x(side) * (0.25 + i * 0.12), 0)
			pivot.add_child(rib)
		var edge := MeshInstance3D.new()
		var em := BoxMesh.new()
		em.size = Vector3(17.0, 0.35, 0.35)
		edge.mesh = em
		edge.material_override = Mats.glow(Color(0.6, 0.95, 1.0) if side == ICE else Color(1.0, 0.5, 0.1), 3.0)
		edge.position = Vector3(_side_x(side) * 8.5, 1.3, 0)
		pivot.add_child(edge)
		_wings.append(pivot)
	# The tail, which curls off behind and to the side.
	for i in 10:
		var m := MeshInstance3D.new()
		var sm := SphereMesh.new()
		var r := lerpf(2.4, 0.6, i / 10.0)
		sm.radius = r
		sm.height = r * 2.0
		m.mesh = sm
		m.material_override = ice if i % 2 == 0 else fire
		add_child(m)
		_tail.append(m)
	# Frost and embers pouring off the body.
	Fx.ambient(self, Vector3(-5, 12, 0), Vector3(6, 6, 7), Color(0.85, 0.95, 1.0, 0.7), 70, 0.18, Vector3(0, -1.0, 0), 3.0)
	Fx.ambient(self, Vector3(5, 12, 0), Vector3(6, 6, 7), Color(1.0, 0.55, 0.15, 0.9), 90, 0.16, Vector3(0, 2.5, 0), 2.0)


func _ball(pos: Vector3, r: float, mat: Material, squish := Vector3.ONE) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = r
	sm.height = r * 2.0
	m.mesh = sm
	m.material_override = mat
	m.position = pos
	m.scale = squish
	add_child(m)
	return m


func _build_beam() -> void:
	_beam = Node3D.new()
	_beam.top_level = true
	_beam.visible = false
	add_child(_beam)
	var len := arena_radius * 2.0 + 4.0
	_beam_hot = MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(len, 1.1, 0.9)
	_beam_hot.mesh = bm
	_beam_hot.material_override = Mats.glow(Color(1.0, 0.45, 0.08), 4.0)
	_beam_hot.position.y = 0.55
	_beam.add_child(_beam_hot)
	_beam_warn = MeshInstance3D.new()
	var wm := BoxMesh.new()
	wm.size = Vector3(len, 0.06, 1.4)
	_beam_warn.mesh = wm
	_beam_warn.material_override = Mats.unshaded(Color(1.0, 0.3, 0.1), 0.45)
	_beam_warn.position.y = 0.05
	_beam.add_child(_beam_warn)
	_beam_fx = Fx.ambient(_beam, Vector3(0, 1.0, 0), Vector3(len * 0.5, 0.6, 0.4), Color(1.0, 0.6, 0.15, 0.9), 220, 0.35, Vector3(0, 4.0, 0), 0.6)
	_stream = MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.9
	cm.bottom_radius = 0.4
	cm.height = 1.0
	_stream.mesh = cm
	_stream.material_override = Mats.glow(Color(1.0, 0.7, 0.2), 3.5)
	_stream.top_level = true
	_stream.visible = false
	add_child(_stream)


# ---------------------------------------------------------------- flow

func phase() -> int:
	return 2 if _phase2 else 1


func start() -> void:
	_cycle = 0
	_next()


## The attack order. Phase 1 alternates heads; phase 2 does everything at once.
func _next() -> void:
	var order: Array = [B.FIRE, B.REST, B.ICE, B.TAIL, B.REST] if not _phase2 else [B.BOTH, B.TAIL, B.REST]
	var s: B = order[_cycle % order.size()]
	if s == B.REST:
		# Phase 1: whoever just attacked rests. Phase 2: they take turns.
		if not _phase2:
			_resting = FIRE if _cycle % order.size() == 1 else ICE
		else:
			_resting = FIRE if (_cycle / order.size()) % 2 == 0 else ICE
	_cycle += 1
	_go(s)


func _go(s: B) -> void:
	state = s
	_st = 0.0
	_did_attack = false
	for h in heads:
		h.emote = ""
	match s:
		B.FIRE, B.BOTH:
			_head_goal[FIRE] = Vector3(12.0, 16.0, 16.0)
			heads[FIRE].emote = "roar"
			Audio.play("whoosh", 0.6)
			if level:
				level.bark("burnrate", ["Feel the BURN RATE!", "Everything must BURN! Especially money!", "HOT TAKE INCOMING!"][_cycle % 3])
			if s == B.BOTH:
				_head_goal[ICE] = Vector3(-8.0, 26.0, 10.0)
				heads[ICE].emote = "roar"
		B.ICE:
			_head_goal[ICE] = Vector3(-8.0, 26.0, 10.0)
			heads[ICE].emote = "roar"
			Audio.play("whoosh", 0.4)
			if level:
				level.bark("coldcash", ["Cold. Hard. CASH.", "Your assets are FROZEN.", "Let it snow. Let it HURT."][_cycle % 3])
		B.TAIL:
			Audio.play("rumble", 1.1)
		B.REST:
			_head_goal[_resting] = _rest_pos(_resting)
			heads[_resting].emote = "tired"
			Audio.play("whoosh", 0.35, 0.0, -4.0)
			if level and not _told_rest:
				_told_rest = true
				if level.has_method("on_boss_rest"):
					level.on_boss_rest()


func _physics_process(delta: float) -> void:
	_t += delta
	_st += delta
	_update_drops(delta)
	_update_waves(delta)
	_update_rig(delta)
	if player == null or state == B.WAIT or state == B.DEAD:
		return
	match state:
		B.FIRE: _st_fire(delta, false)
		B.BOTH: _st_fire(delta, true)
		B.ICE: _st_ice()
		B.TAIL: _st_tail()
		B.REST: _st_rest()
		B.HURT:
			if _st > 1.3:
				_head_goal[_resting] = _home(_resting)
				if hp <= HALF_HP and not _phase2:
					_begin_phase2()
				else:
					_next()
		B.PHASE:
			if _st > 3.2:
				_cycle = 0
				_next()
	if _phase2:
		_meteor_t -= delta
		if _meteor_t <= 0.0:
			_meteor_t = 1.6
			_drop(_near_player(5.0), true)


# ---------------------------------------------------------------- attacks

func _st_fire(delta: float, both: bool) -> void:
	var c := arena_center
	if _st < 0.05 and not _beam.visible:
		# Start the sweep away from Stax, so there's always time to see it coming.
		var to := player.global_position - c
		_beam_from = atan2(-to.z, to.x) + PI * 0.5
		_beam_turn = TAU if _phase2 else PI
		_beam.global_position = Vector3(c.x, _floor_y(), c.z)
		_beam.rotation.y = _beam_from
		_beam.visible = true
		_beam_hot.visible = false
		_beam_fx.emitting = false
		_beam_warn.visible = true
	var warn := 1.1
	var speed := 1.35 if not _phase2 else 1.6
	var sweep := _beam_turn / speed
	if _st >= warn:
		if not _beam_hot.visible:
			_beam_hot.visible = true
			_beam_fx.emitting = true
			_beam_warn.visible = false
			_stream.visible = true
			Audio.play("boom", 1.4, 0.0, -2.0)
			if level and level.rig:
				level.rig.shake(0.3)
		_beam.rotation.y = _beam_from + minf(_st - warn, sweep) * speed
		# The stream from Burn Rate's jaws to the far end of the wall of fire.
		var mouth: Vector3 = heads[FIRE].global_position - heads[FIRE].global_transform.basis.z.normalized() * (1.6 * HEAD_S)
		var tip: Vector3 = _beam.global_transform * Vector3(arena_radius * 0.6, 0.5, 0)
		_aim_stream(mouth, tip)
		_head_look[FIRE] = tip
		if not player.dead:
			var local: Vector3 = _beam.global_transform.affine_inverse() * player.global_position
			if absf(local.z) < 0.75 and absf(local.x) < arena_radius + 1.0 and local.y < 1.2:
				player.take_damage(1, player.global_position - _beam.global_transform.basis.z * signf(local.z + 0.001))
	if both and not _did_attack and _st > 0.6:
		_did_attack = true
		_icicle_storm(10)
	if _st >= warn + sweep:
		_beam.visible = false
		_stream.visible = false
		_head_look[FIRE] = Vector3.ZERO
		_next()


func _st_ice() -> void:
	if not _did_attack and _st > 0.8:
		_did_attack = true
		_icicle_storm(7)
	if _st > 3.0:
		_next()


func _icicle_storm(count: int) -> void:
	Audio.play("zap", 0.5)
	Game.fx.flash(Color(0.7, 0.9, 1.0), 0.2)
	for i in count:
		var target := player.global_position if i == 0 else _near_player(8.0)
		_drop(_clamp(target), false, i * 0.14)


func _st_tail() -> void:
	var slams := 2 if _phase2 else 1
	var per := 1.5
	var k := fmod(_st, per)
	var n := int(_st / per)
	if n < slams:
		_tail_lift = sin(clampf(k / 0.9, 0.0, 1.0) * PI * 0.5) if k < 0.9 else maxf(0.0, 1.0 - (k - 0.9) / 0.12)
		if k >= 1.02 and not _did_attack:
			_did_attack = true
			Audio.play("boom", 0.7)
			Audio.play("hit_low")
			if level and level.rig:
				level.rig.shake(0.7)
			var at := arena_center + Vector3(0, 0, -arena_radius + 1.0)
			Fx.burst(get_parent(), at + Vector3(0, 0.5, 0), Color(0.9, 0.9, 1.0, 0.9), 50, 12.0, 0.8, 0.9, -6.0)
			_spawn_wave(at)
		elif k < 0.5:
			_did_attack = false
	else:
		_tail_lift = 0.0
		if _st > slams * per + 0.4:
			_next()


func _st_rest() -> void:
	var side := _resting
	var near := heads[side].position.distance_to(_head_goal[side]) < 0.6
	_set_solid(_head_body[side], near)
	if near:
		var hp_pos: Vector3 = heads[side].global_position
		var hb := _head_body[side]
		hb.global_transform = Transform3D(Basis(Vector3.UP, heads[side].global_rotation.y), Vector3(hp_pos.x, _floor_y() + 1.05, hp_pos.z))
		var p := player.global_position
		var flat := Vector2(p.x - hp_pos.x, p.z - hp_pos.z).length()
		var top := _floor_y() + 2.1
		var pounded: bool = flat < 3.8 and player.state == player.S.POUND_LAND
		var stomped: bool = flat < 3.0 and p.y > top - 0.4 and (player.is_on_floor() or player.velocity.y < 0.0)
		if pounded or stomped:
			take_hit()
			return
	if _st > (5.5 if not _phase2 else 4.5):
		_set_solid(_head_body[side], false)
		_head_goal[side] = _home(side)
		heads[side].emote = "roar"
		_next()


## Registers a hit on whichever head is resting (also used by the tests).
func take_hit() -> void:
	if state == B.DEAD:
		return
	hp -= 1
	hit.emit(hp)
	var side := _resting
	_set_solid(_head_body[side], false)
	var at: Vector3 = heads[side].global_position + Vector3(0, 2, 0)
	Audio.play("clang", 0.7)
	Audio.play("stomp")
	Game.fx.flash(Color(1, 1, 1), 0.25)
	if level and level.rig:
		level.rig.shake(0.6)
	Fx.burst(get_parent(), at, Color(0.7, 0.95, 1.0) if side == ICE else Color(1.0, 0.5, 0.1), 40, 10.0, 0.4, 0.9, -10.0, "cube")
	Fx.burst(get_parent(), at, Color(1.0, 0.85, 0.3), 16, 7.0, 0.18, 0.8, -12.0, "coin")
	if player:
		player.bounce(16.0, false)
	heads[side].emote = "roar"
	heads[side].squash = 0.6
	_head_goal[side] = _home(side) + Vector3(0, 3, -3)
	if hp <= 0:
		_die()
		return
	if level:
		var line: Array = HIT_LINES[(MAX_HP - hp - 1) % HIT_LINES.size()]
		level.bark(line[0], line[1])
	_go(B.HURT)
	heads[side].emote = "roar"


func _begin_phase2() -> void:
	_phase2 = true
	_go(B.PHASE)
	for h in heads:
		h.emote = "roar"
	_head_goal[ICE] = Vector3(-6.0, 28.0, 6.0)
	_head_goal[FIRE] = Vector3(6.0, 28.0, 6.0)
	Audio.play("thunder")
	Audio.play("rumble", 0.6)
	Game.fx.flash(Color(1.0, 0.8, 1.0), 0.8)
	if level and level.rig:
		level.rig.shake(1.0)
	phase_two.emit()


## Back to full health, for a fresh attempt after Stax is knocked out.
func reset() -> void:
	_clear_attacks()
	hp = MAX_HP
	_phase2 = false
	_cycle = 0
	for side in [ICE, FIRE]:
		_head_goal[side] = _home(side)
		_set_solid(_head_body[side], false)
	_next()


func _die() -> void:
	state = B.DEAD
	_clear_attacks()
	for side in [ICE, FIRE]:
		_head_goal[side] = to_local(arena_center + Vector3(_side_x(side) * 3.0, 1.0, -arena_radius + 5.0))
		heads[side].emote = "tired"
	defeated.emit()


func _clear_attacks() -> void:
	for d in _drops:
		d.node.queue_free()
		d.ring.queue_free()
	_drops.clear()
	for w in _waves:
		w.node.queue_free()
	_waves.clear()
	_beam.visible = false
	_stream.visible = false
	_tail_lift = 0.0


# ---------------------------------------------------------------- rig

func _update_rig(delta: float) -> void:
	_anim += delta
	var flap_speed := 1.4 * _flap
	for side in [ICE, FIRE]:
		var s := _side_x(side)
		_wings[side].rotation.z = s * (0.25 + sin(_anim * flap_speed + side) * 0.35)
		# Heads glide toward their goal and bob a little while they wait.
		var goal := _head_goal[side]
		if state != B.REST or side != _resting:
			goal += Vector3(sin(_anim * 0.8 + side * 2.0) * 0.8, sin(_anim * 1.3 + side) * 0.6, 0)
		_head_pos[side] = _head_pos[side].lerp(goal, clampf(delta * 3.0, 0.0, 1.0))
		var h := heads[side]
		h.position = _head_pos[side]
		var look: Vector3 = _head_look[side]
		if look == Vector3.ZERO:
			look = player.global_position + Vector3(0, 1, 0) if player else arena_center
			if state == B.PHASE:
				look = h.global_position + Vector3(s * 4.0, 20.0, 6.0)
		if h.global_position.distance_to(look) > 1.0:
			h.look_at(look, Vector3.UP)
		# The neck: a curve from the shoulder, arching up, into the back of the head.
		var p0 := Vector3(s * 5.0, 13.0, 5.0)
		var p2 := _head_pos[side] + h.transform.basis.z.normalized() * (1.2 * HEAD_S)
		var p1 := (p0 + p2) * 0.5 + Vector3(s * 1.5, 7.0, -1.0)
		var balls: Array = _necks[side]
		for i in balls.size():
			var t := float(i) / (balls.size() - 1)
			(balls[i] as MeshInstance3D).position = p0.lerp(p1, t).lerp(p1.lerp(p2, t), t)
	# Tail: sways lazily, rears up to slam.
	for i in _tail.size():
		var t := float(i) / _tail.size()
		var sway := sin(_anim * 1.2 - t * 3.0) * t * 4.0
		var lift := _tail_lift * t * t * 16.0
		_tail[i].position = Vector3(10.0 * t + sway, 3.5 + t * 2.0 + lift, -8.0 - t * 14.0 + _tail_lift * t * 10.0)


func _aim_stream(from: Vector3, to: Vector3) -> void:
	var d := to - from
	var l := d.length()
	if l < 0.1:
		return
	var up := d / l
	var side := up.cross(Vector3.FORWARD if absf(up.dot(Vector3.FORWARD)) < 0.9 else Vector3.RIGHT).normalized()
	var fwd := side.cross(up)
	_stream.global_transform = Transform3D(Basis(side, up, fwd).scaled(Vector3(1, l, 1)), from + d * 0.5)


func set_flap(speed: float) -> void:
	_flap = speed


# ---------------------------------------------------------------- projectiles

func _near_player(spread: float) -> Vector3:
	var p := player.global_position if player else arena_center
	return _clamp(p + Vector3(randf_range(-spread, spread), 0, randf_range(-spread, spread)))


func _clamp(p: Vector3) -> Vector3:
	var d := p - arena_center
	d.y = 0.0
	if d.length() > arena_radius - 1.5:
		d = d.normalized() * (arena_radius - 1.5)
	return Vector3(arena_center.x + d.x, _floor_y(), arena_center.z + d.z)


## A meteor or icicle aimed at `target`, with a warning ring (also used by
## the level for the volcano's meteor shower).
func drop(target: Vector3, meteor: bool, delay := 0.0) -> void:
	_drop(target, meteor, delay)


## An icicle straight down from the sky, or (meteor) a fireball in at an angle.
func _drop(target: Vector3, meteor: bool, delay := 0.0) -> void:
	var ring := MeshInstance3D.new()
	var rc := CylinderMesh.new()
	rc.top_radius = 2.2
	rc.bottom_radius = 2.2
	rc.height = 0.04
	rc.radial_segments = 32
	ring.mesh = rc
	ring.material_override = Mats.unshaded(Color(1.0, 0.35, 0.1) if meteor else Color(0.4, 0.8, 1.0), 0.5)
	get_parent().add_child(ring)
	ring.global_position = target + Vector3(0, 0.05, 0)
	var node := MeshInstance3D.new()
	if meteor:
		var sm := SphereMesh.new()
		sm.radius = 1.2
		sm.height = 2.4
		node.mesh = sm
		node.material_override = Mats.glow(Color(1.0, 0.4, 0.05), 3.5)
	else:
		var cm := CylinderMesh.new()
		cm.top_radius = 0.7
		cm.bottom_radius = 0.0
		cm.height = 3.2
		node.mesh = cm
		node.material_override = Mats.glass(Color(0.75, 0.95, 1.0), 0.85)
	get_parent().add_child(node)
	var from := target + (Vector3(randf_range(-18, 18), 34, -16) if meteor else Vector3(0, 26, 0))
	node.global_position = from
	node.visible = false
	_drops.append({"node": node, "ring": ring, "from": from, "to": target, "t": -delay - 0.5, "dur": 1.4 if meteor else 0.9, "meteor": meteor})


func _update_drops(delta: float) -> void:
	for d in _drops.duplicate():
		d.t += delta
		var node: MeshInstance3D = d.node
		var ring: MeshInstance3D = d.ring
		ring.scale = Vector3.ONE * (0.8 + 0.2 * sin(_t * 18.0))
		if d.t < 0.0:
			continue
		node.visible = true
		var k: float = clampf(d.t / d.dur, 0.0, 1.0)
		node.global_position = d.from.lerp(d.to, k * k)
		if d.meteor:
			node.rotation += Vector3(3, 5, 2) * delta
		if k >= 1.0:
			if d.meteor:
				Audio.play("boom", 1.1, 0.1, -2.0)
				Fx.burst(get_parent(), d.to + Vector3(0, 0.6, 0), Color(1.0, 0.5, 0.1), 30, 9.0, 0.5, 0.7, -8.0)
			else:
				Audio.play("clang", 1.8, 0.1, -4.0)
				Fx.burst(get_parent(), d.to + Vector3(0, 0.6, 0), Color(0.8, 0.95, 1.0), 24, 7.0, 0.3, 0.6, -12.0, "cube")
			if player and not player.dead:
				var dist := Vector2(player.global_position.x - d.to.x, player.global_position.z - d.to.z).length()
				if dist < 2.3 and player.global_position.y < d.to.y + 2.5:
					player.take_damage(1, d.to)
			node.queue_free()
			ring.queue_free()
			_drops.erase(d)


func _spawn_wave(at: Vector3) -> void:
	var ring := MeshInstance3D.new()
	var tor := TorusMesh.new()
	tor.inner_radius = 0.85
	tor.outer_radius = 1.0
	tor.rings = 64
	tor.ring_segments = 8
	ring.mesh = tor
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.85, 0.7, 1.0, 0.9)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.emission_enabled = true
	m.emission = Color(0.8, 0.5, 1.0)
	m.emission_energy_multiplier = 3.0
	ring.material_override = m
	get_parent().add_child(ring)
	ring.global_position = at + Vector3(0, 0.35, 0)
	_waves.append({"node": ring, "r": 1.0, "mat": m, "center": at})


func _update_waves(delta: float) -> void:
	for w in _waves.duplicate():
		w.r += delta * (12.0 if not _phase2 else 14.0)
		var node: MeshInstance3D = w.node
		node.scale = Vector3(w.r, 1.3, w.r)
		w.mat.albedo_color.a = clampf(1.2 - w.r / (arena_radius * 2.0), 0.0, 1.0)
		if player and not player.dead:
			var flat := Vector2(player.global_position.x - w.center.x, player.global_position.z - w.center.z).length()
			if absf(flat - w.r) < 0.8 and player.global_position.y < w.center.y + 0.9:
				player.take_damage(1, w.center)
		if w.r > arena_radius * 2.0 + 2.0:
			node.queue_free()
			_waves.erase(w)
