extends CharacterBody3D
## Stax, the player. A classic N64-style moveset:
## jump chain (single/double/triple), long jump, backflip, side flip,
## wall kick, ground pound, dive + rollout, skid turn.
## Cutscenes can freeze input and steer Stax with `scripted_input`.

signal health_changed(hp: int)
signal coins_changed(coins: int)
signal died
signal landed(fall: float)

const StaxModel := preload("res://scripts/actors/stax_model.gd")
const Fx := preload("res://scripts/world/fx.gd")

const GRAVITY := 38.0
const MAX_FALL := 42.0
const RUN_MAX := 9.5
const ACCEL := 20.0
const DECEL := 28.0
const SKID_DECEL := 40.0
const AIR_ACCEL := 9.0
const TURN_RATE := 11.0
const JUMP_V: Array[float] = [12.5, 15.0, 19.5]
const CHAIN_WINDOW := 0.2
const TRIPLE_MIN_SPEED := 6.5
const LONG_JUMP_V := 10.0
const LONG_JUMP_MAX := 21.0
const BACKFLIP_V := 20.5
const SIDEFLIP_V := 19.0
const WALLKICK_V := 15.5
const WALLKICK_SPEED := 7.5
const WALLKICK_WINDOW := 0.22
const DIVE_SPEED := 15.0
const POUND_SPEED := 40.0
const FALL_DAMAGE_HEIGHT := 16.0
const COYOTE := 0.1
const JUMP_BUFFER := 0.1
const MAX_HP := 4
## Coins only heal a little: one health per this many coins (big coins heal 1).
const COINS_PER_HEAL := 25

enum S { GROUND, CROUCH, SKID, AIR, LONG_JUMP, BACKFLIP, SIDEFLIP, WALLKICK,
	POUND_SPIN, POUND_FALL, POUND_LAND, DIVE, BELLY_SLIDE, HURT }

var state: S = S.AIR
var speed := 0.0          # signed speed along facing direction
var facing := 0.0         # yaw in radians; model faces -Z at 0
var jump_chain := 0
var chain_timer := 0.0
var state_timer := 0.0
var wall_normal := Vector3.ZERO
var wall_timer := 0.0
var coyote_timer := 0.0
var buffer_timer := 0.0
var jump_cut := false
var peak_y := 0.0
var invuln := 0.0
var hp := MAX_HP
var coins := 0
var _heal_progress := 0
var spawn_point := Vector3.ZERO
var spawn_facing := 0.0
var camera_rig: Node3D
var kill_y := -40.0
var gravity_scale := 1.0
## Extra velocity from conveyors and wind; zones set it every physics frame.
var push := Vector3.ZERO
## When frozen, player input is ignored and `scripted_input` is used instead.
var frozen := false
var scripted_input := Vector3.ZERO
var model: Node3D
var dead := false
## Bought from the Chapter 10 shop: one extra jump in mid-air.
var double_jump := false
## Set the moment a boss is beaten: nothing can hurt or kill Stax any more,
## so a last-second hit can't turn the victory into a respawn.
var safe := false
var _air_jumps := 0

var _pivot: Node3D      # rotated for flips/spins
var _body: Node3D       # squashed and stretched
var _flip_axis := Vector3.RIGHT
var _flip_dir := 1.0
var _squash := 1.0
var _step_timer := 0.0


func _ready() -> void:
	floor_snap_length = 0.4
	floor_max_angle = deg_to_rad(50)
	var shape := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.45
	capsule.height = 1.5
	shape.shape = capsule
	shape.position.y = 0.75
	add_child(shape)
	_pivot = Node3D.new()
	_pivot.position.y = 0.75
	add_child(_pivot)
	_body = Node3D.new()
	_body.position.y = -0.75
	_pivot.add_child(_body)
	model = StaxModel.new()
	_body.add_child(model)
	spawn_point = global_position


# ---------------------------------------------------------------- helpers

func _fwd() -> Vector3:
	return Vector3(-sin(facing), 0, -cos(facing))


func _input_dir() -> Vector3:
	if frozen:
		return scripted_input
	var v := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var dir := Vector3(v.x, 0, v.y)
	var yaw := camera_rig.rotation.y if camera_rig else 0.0
	return dir.rotated(Vector3.UP, yaw)


func _pressed(action: String) -> bool:
	return not frozen and Input.is_action_just_pressed(action)


func _held(action: String) -> bool:
	return not frozen and Input.is_action_pressed(action)


## Jump presses are buffered briefly so a press just before landing counts.
func _jump() -> bool:
	if buffer_timer > 0.0:
		buffer_timer = 0.0
		return true
	return false


func _yaw_of(dir: Vector3) -> float:
	return atan2(-dir.x, -dir.z)


func _set_state(s: S) -> void:
	state = s
	state_timer = 0.0


func _apply_horizontal() -> void:
	var f := _fwd() * speed
	velocity.x = f.x + push.x
	velocity.z = f.z + push.z


func _gravity(delta: float, scale := 1.0) -> void:
	velocity.y = maxf(velocity.y - GRAVITY * gravity_scale * scale * delta, -MAX_FALL * sqrt(gravity_scale))


func _start_flip(axis: Vector3, dir: float) -> void:
	_flip_axis = axis
	_flip_dir = dir


# ---------------------------------------------------------------- main loop

func _physics_process(delta: float) -> void:
	state_timer += delta
	chain_timer -= delta
	wall_timer -= delta
	coyote_timer -= delta
	buffer_timer -= delta
	invuln -= delta
	if _pressed("jump"):
		buffer_timer = JUMP_BUFFER

	var input := _input_dir()
	var mag := minf(input.length(), 1.0)

	match state:
		S.GROUND: _st_ground(delta, input, mag)
		S.CROUCH: _st_crouch(delta, input, mag)
		S.SKID: _st_skid(delta, input, mag)
		S.AIR, S.WALLKICK, S.SIDEFLIP: _st_air(delta, input, mag, 1.0, true)
		S.BACKFLIP: _st_air(delta, input, mag, 0.4, false)
		S.LONG_JUMP: _st_long_jump(delta, input, mag)
		S.POUND_SPIN: _st_pound_spin(delta)
		S.POUND_FALL: velocity = Vector3(0, -POUND_SPEED, 0)
		S.POUND_LAND: _st_pound_land(delta)
		S.DIVE: _st_dive(delta, input, mag)
		S.BELLY_SLIDE: _st_belly_slide(delta, input, mag)
		S.HURT: _st_hurt(delta)

	var pre_speed := speed
	move_and_slide()
	push = Vector3.ZERO
	_after_move(pre_speed)
	_animate(delta)

	if safe and not dead and global_position.y < kill_y:
		# The boss is down, so a fall can't hurt, but it must not lose Stax
		# in the void either: quietly put him back at the last safe spot.
		respawn()
		invuln = 0.0
	elif not dead and (global_position.y < kill_y or _pressed("reset")):
		die()


func _after_move(pre_speed: float) -> void:
	var grounded_states := [S.GROUND, S.CROUCH, S.SKID, S.POUND_LAND, S.BELLY_SLIDE]
	if state in grounded_states:
		# Walls absorb forward speed on the ground.
		if is_on_wall() and speed > 0.0:
			var hv := Vector3(velocity.x, 0, velocity.z)
			speed = maxf(hv.dot(_fwd()), 0.0)
		return

	peak_y = maxf(peak_y, global_position.y)

	# Touching a wall mid-air opens the wall-kick window.
	if is_on_wall() and pre_speed > 2.0 and state != S.POUND_FALL and state != S.POUND_SPIN:
		var n := get_wall_normal()
		if n.dot(_fwd()) < -0.5:
			wall_normal = Vector3(n.x, 0, n.z).normalized()
			wall_timer = WALLKICK_WINDOW
			speed = 0.0
			if state == S.DIVE:
				_set_state(S.AIR)

	if is_on_ceiling() and velocity.y > 0.0:
		velocity.y = 0.0

	if is_on_floor() and velocity.y <= 0.0:
		_land()


func _land() -> void:
	_air_jumps = 0
	var fall := peak_y - global_position.y
	var from := state
	landed.emit(fall)
	match from:
		S.POUND_FALL:
			_set_state(S.POUND_LAND)
			_squash = 0.5
			Audio.play("pound")
			Fx.burst(get_parent(), global_position + Vector3(0, 0.1, 0), Color(1, 0.95, 0.8, 0.8), 24, 7.0, 0.5, 0.5, 0.0)
			if camera_rig and camera_rig.has_method("shake"):
				camera_rig.shake(0.25)
			return
		S.DIVE:
			_set_state(S.BELLY_SLIDE)
			return
		S.AIR:
			if jump_chain in [1, 2]:
				chain_timer = CHAIN_WINDOW
			else:
				jump_chain = 0
		_:
			jump_chain = 0
	if from == S.LONG_JUMP:
		speed *= 0.6
	elif from == S.BACKFLIP or from == S.SIDEFLIP:
		speed = 0.0
	_squash = 0.7
	_set_state(S.GROUND)
	if fall > 1.5:
		Audio.play("land", 1.0, 0.1, -4.0)
		Fx.burst(get_parent(), global_position + Vector3(0, 0.1, 0), Color(1, 1, 1, 0.5), 8, 3.0, 0.4, 0.4, 0.0)
	if fall > FALL_DAMAGE_HEIGHT:
		take_damage(2, Vector3.ZERO)


# ---------------------------------------------------------------- states

func _st_ground(delta: float, input: Vector3, mag: float) -> void:
	if not is_on_floor():
		peak_y = global_position.y
		coyote_timer = COYOTE
		jump_chain = 0
		_set_state(S.AIR)
		return

	if mag > 0.1:
		var target := _yaw_of(input)
		var diff := wrapf(target - facing, -PI, PI)
		if absf(diff) > 2.5 and speed > 6.0:
			_set_state(S.SKID)
			Audio.play("dive", 0.6, 0.05, -10.0)
			return
		var turn := TURN_RATE if speed < 5.0 else TURN_RATE * 0.6
		facing = rotate_toward(facing, target, turn * delta)
		speed = move_toward(speed, RUN_MAX * mag, ACCEL * delta)
	else:
		speed = move_toward(speed, 0.0, DECEL * delta)
	_apply_horizontal()
	velocity.y = -2.0

	if _jump():
		_ground_jump()
	elif _pressed("attack") and speed > 6.0:
		_start_dive()
	elif _held("crouch"):
		_set_state(S.CROUCH)


func _ground_jump() -> void:
	if chain_timer > 0.0 and jump_chain == 1:
		jump_chain = 2
	elif chain_timer > 0.0 and jump_chain == 2 and speed >= TRIPLE_MIN_SPEED:
		jump_chain = 3
		_start_flip(Vector3.RIGHT, -1.0)
	else:
		jump_chain = 1
	velocity.y = JUMP_V[jump_chain - 1] + absf(speed) * 0.12
	Audio.play(["jump", "jump2", "jump3"][jump_chain - 1])
	_air_start(S.AIR)


func _air_start(s: S) -> void:
	jump_cut = false
	coyote_timer = 0.0
	peak_y = global_position.y
	_squash = 1.3
	_set_state(s)


func _st_crouch(delta: float, _input: Vector3, _mag: float) -> void:
	if not is_on_floor():
		_set_state(S.AIR)
		return
	speed = move_toward(speed, 0.0, DECEL * 0.5 * delta)
	_apply_horizontal()
	velocity.y = -2.0
	if _jump():
		if speed > 4.0:
			speed = clampf(speed * 1.6, 12.0, LONG_JUMP_MAX)
			velocity.y = LONG_JUMP_V
			Audio.play("jump2", 0.8)
			_air_start(S.LONG_JUMP)
		else:
			speed = -4.5
			velocity.y = BACKFLIP_V
			_start_flip(Vector3.RIGHT, 1.0)
			Audio.play("jump3", 0.9)
			_air_start(S.BACKFLIP)
	elif not _held("crouch"):
		_set_state(S.GROUND)


func _st_skid(delta: float, input: Vector3, mag: float) -> void:
	speed = move_toward(speed, 0.0, SKID_DECEL * delta)
	_apply_horizontal()
	velocity.y = -2.0
	if int(state_timer * 30.0) % 3 == 0:
		Fx.burst(get_parent(), global_position, Color(1, 1, 1, 0.4), 2, 1.5, 0.35, 0.4, 0.0)
	if _jump():
		facing = _yaw_of(input) if mag > 0.1 else facing + PI
		speed = 4.0
		velocity.y = SIDEFLIP_V
		_start_flip(Vector3.FORWARD, 1.0)
		Audio.play("jump3", 1.1)
		_air_start(S.SIDEFLIP)
		return
	if speed <= 0.1:
		if mag > 0.1:
			facing = _yaw_of(input)
		_set_state(S.GROUND)


func _st_air(delta: float, input: Vector3, mag: float, control: float, can_act: bool) -> void:
	# Coyote time: a jump just after running off a ledge still counts.
	if state == S.AIR and coyote_timer > 0.0 and velocity.y <= 0.0 and _jump():
		jump_chain = 0
		_ground_jump()
		return
	# Variable jump height: releasing jump early cuts the rise.
	if state == S.AIR and not jump_cut and velocity.y > 0.0 and not (_held("jump") or frozen):
		velocity.y *= 0.5
		jump_cut = true
	_gravity(delta)

	if mag > 0.1:
		var along := input.normalized().dot(_fwd()) * mag
		var cap := maxf(absf(speed), RUN_MAX)
		speed = clampf(speed + along * AIR_ACCEL * control * delta, -RUN_MAX * 0.5, cap)
		facing = rotate_toward(facing, _yaw_of(input), 2.5 * control * delta)
	_apply_horizontal()

	if wall_timer > 0.0 and _jump():
		_wall_kick()
		return
	if double_jump and _air_jumps == 0 and _jump():
		_air_jumps = 1
		velocity.y = 13.0
		jump_cut = false
		_set_state(S.AIR)
		Audio.play("jump2", 1.3)
		Fx.burst(get_parent(), global_position + Vector3(0, 0.3, 0), Color(1.0, 0.5, 0.85, 0.9), 16, 4.0, 0.25, 0.5, 0.0)
		return
	if not can_act:
		return
	if _pressed("crouch"):
		_set_state(S.POUND_SPIN)
		_start_flip(Vector3.RIGHT, -1.0)
		Audio.play("whoosh", 2.0, 0.05, -8.0)
	elif _pressed("attack"):
		_start_dive()


func _wall_kick() -> void:
	facing = _yaw_of(wall_normal)
	speed = WALLKICK_SPEED
	velocity.y = WALLKICK_V
	wall_timer = 0.0
	jump_chain = 0
	Audio.play("jump2", 1.15)
	Fx.burst(get_parent(), global_position + Vector3(0, 0.8, 0) - wall_normal * 0.4, Color(1, 1, 1, 0.6), 8, 3.0, 0.3, 0.3, 0.0)
	_air_start(S.WALLKICK)


func _st_long_jump(delta: float, input: Vector3, mag: float) -> void:
	_gravity(delta, 0.6)
	if mag > 0.1:
		facing = rotate_toward(facing, _yaw_of(input), 0.8 * delta)
	_apply_horizontal()
	if wall_timer > 0.0 and _jump():
		_wall_kick()


func _st_pound_spin(_delta: float) -> void:
	velocity = Vector3.ZERO
	speed = 0.0
	if state_timer > 0.28:
		_set_state(S.POUND_FALL)


func _st_pound_land(_delta: float) -> void:
	velocity = Vector3(0, -2, 0)
	if state_timer > 0.35:
		_set_state(S.GROUND)
	elif state_timer > 0.1 and _jump():
		# Pound jump: a small bonus for chaining out of a ground pound.
		velocity.y = JUMP_V[1]
		jump_chain = 0
		Audio.play("jump2")
		_air_start(S.AIR)


func _start_dive() -> void:
	speed = maxf(speed, DIVE_SPEED)
	velocity.y = 6.0 if is_on_floor() else maxf(velocity.y, 3.0)
	peak_y = global_position.y
	Audio.play("dive")
	_set_state(S.DIVE)


func _st_dive(delta: float, input: Vector3, mag: float) -> void:
	_gravity(delta)
	if mag > 0.1:
		facing = rotate_toward(facing, _yaw_of(input), 1.0 * delta)
	_apply_horizontal()


func _st_belly_slide(delta: float, _input: Vector3, _mag: float) -> void:
	speed = move_toward(speed, 0.0, DECEL * 0.4 * delta)
	_apply_horizontal()
	velocity.y = -2.0
	if state_timer > 0.1 and (_jump() or _pressed("attack")):
		# Rollout back to your feet.
		velocity.y = 10.0
		jump_chain = 0
		_start_flip(Vector3.RIGHT, -1.0)
		Audio.play("jump")
		_air_start(S.SIDEFLIP)
	elif speed <= 0.1:
		_set_state(S.GROUND)


func _st_hurt(delta: float) -> void:
	_gravity(delta)
	_apply_horizontal()
	if state_timer > 0.5 and is_on_floor():
		_set_state(S.GROUND)


# ---------------------------------------------------------------- gameplay

func is_attacking() -> bool:
	return state in [S.DIVE, S.POUND_FALL, S.POUND_LAND, S.BELLY_SLIDE]


func is_falling_onto(top_y: float) -> bool:
	return velocity.y < 0.5 and global_position.y > top_y - 0.6


## Springs, stomps and bounce pads.
func bounce(vy: float, keep_speed := true) -> void:
	velocity.y = vy
	if not keep_speed:
		speed = 0.0
	jump_chain = 0
	_air_start(S.AIR)
	jump_cut = true   # a bounce ignores the jump button


func take_damage(amount: int, from_pos: Vector3) -> void:
	if invuln > 0.0 or dead or frozen or safe:
		return
	hp = maxi(hp - amount, 0)
	invuln = 1.2
	health_changed.emit(hp)
	Audio.play("hurt")
	if camera_rig and camera_rig.has_method("shake"):
		camera_rig.shake(0.35)
	if Game.fx:
		Game.fx.hit_flash()
	if hp == 0:
		die()
		return
	if from_pos != Vector3.ZERO:
		var away := global_position - from_pos
		away.y = 0
		if away.length() > 0.01:
			facing = _yaw_of(-away.normalized())
		speed = -7.0
		velocity.y = 9.0
		_set_state(S.HURT)


func die() -> void:
	if dead or safe:
		return
	dead = true
	died.emit()
	Audio.play("hurt", 0.7)
	if Game.fx and is_inside_tree():
		await Game.fx.fade_out(0.4)
		if safe:
			# The boss went down while we were fading out: stay put, the
			# victory cutscene takes it from here.
			dead = false
			hp = MAX_HP
			health_changed.emit(hp)
			Game.fx.fade_in(0.3)
			return
		respawn()
		Game.fx.fade_in(0.5)
	else:
		respawn()


func add_coin(value := 1) -> void:
	coins += value
	_heal_progress += value
	var heal := 1 if value >= 5 else 0
	while _heal_progress >= COINS_PER_HEAL:
		_heal_progress -= COINS_PER_HEAL
		heal += 1
	if heal > 0 and hp < MAX_HP:
		hp = mini(hp + heal, MAX_HP)
		health_changed.emit(hp)
	coins_changed.emit(coins)
	Audio.play("coin", 1.0, 0.02, -3.0)


func heal_full() -> void:
	hp = MAX_HP
	health_changed.emit(hp)


func respawn() -> void:
	global_position = spawn_point
	velocity = Vector3.ZERO
	speed = 0.0
	facing = spawn_facing
	hp = MAX_HP
	jump_chain = 0
	invuln = 1.0
	dead = false
	health_changed.emit(hp)
	peak_y = spawn_point.y
	_pivot.basis = Basis()
	_set_state(S.AIR)
	if camera_rig and camera_rig.has_method("snap_behind"):
		camera_rig.snap_behind()


## Teleports and faces a direction, for cutscenes.
func place(pos: Vector3, yaw: float) -> void:
	global_position = pos
	facing = yaw
	velocity = Vector3.ZERO
	speed = 0.0
	peak_y = pos.y
	_pivot.basis = Basis()
	_set_state(S.AIR)


# ---------------------------------------------------------------- animation

func _anim_state() -> String:
	match state:
		S.GROUND:
			return "run" if absf(speed) > 0.5 else "idle"
		S.CROUCH, S.POUND_LAND:
			return "crouch"
		S.SKID:
			return "skid"
		S.DIVE:
			return "dive"
		S.BELLY_SLIDE:
			return "slide"
		S.POUND_SPIN, S.POUND_FALL:
			return "pound"
		S.HURT:
			return "hurt"
		S.BACKFLIP, S.SIDEFLIP:
			return "flip"
		S.LONG_JUMP:
			return "dive"
		_:
			if jump_chain == 3:
				return "flip"
			return "air" if velocity.y > 0.0 else "fall"


func _animate(delta: float) -> void:
	rotation.y = facing
	_squash = lerpf(_squash, 1.0, 12.0 * delta)
	_body.scale = Vector3(1.0 / sqrt(_squash), _squash, 1.0 / sqrt(_squash))

	var target_basis := Basis()
	var flipping := (state == S.AIR and jump_chain == 3) or state in [S.BACKFLIP, S.SIDEFLIP, S.POUND_SPIN]
	if flipping:
		var dur := 0.28 if state == S.POUND_SPIN else 0.6
		var t := clampf(state_timer / dur, 0.0, 1.0)
		target_basis = Basis(_flip_axis, TAU * t * _flip_dir)
		_pivot.basis = target_basis
	else:
		match state:
			S.DIVE, S.BELLY_SLIDE:
				target_basis = Basis(Vector3.RIGHT, -PI * 0.5)
			S.LONG_JUMP:
				target_basis = Basis(Vector3.RIGHT, -0.5)
			S.CROUCH, S.POUND_LAND:
				_body.scale.y *= 0.75
			S.SKID:
				target_basis = Basis(Vector3.RIGHT, 0.35)
			S.HURT:
				target_basis = Basis(Vector3.RIGHT, 0.4)
		_pivot.basis = _pivot.basis.slerp(target_basis, clampf(15.0 * delta, 0.0, 1.0)).orthonormalized()

	var anim := _anim_state()
	model.animate(delta, anim, absf(speed))
	if anim == "run" and speed > 3.0:
		_step_timer -= delta * speed
		if _step_timer <= 0.0:
			_step_timer = 3.2
			Audio.play("step", 1.0, 0.2, -14.0)

	# Blink while invulnerable.
	visible = invuln <= 0.0 or int(invuln * 12.0) % 2 == 0 or frozen
