extends Node3D
## Chuckles the Colossal, running along the ground beside the rollercoaster
## and taller than the whole track. Stax rides the train; nobody rides him.
## Loop: BRICKS (a red ring shows where each lands; dive into one to bat it
## back at his nose) -> TICKET GATE (a giant striped barrier sweeps across one
## car: jump it, or hop to the next car) -> HAMMER (mallets drop on marked
## spots). He's much weaker than he looks: one brick batted into his nose
## and he screams and drops.

signal hit(hp: int)
signal defeated

const Puppet := preload("res://scripts/actors/puppet.gd")
const Mats := preload("res://scripts/world/mats.gd")
const Fx := preload("res://scripts/world/fx.gd")

const S := 14.0                            # how big he is
const MAX_HP := 1
const HAND := Vector3(0.98, 2.9, -0.2)     # his throwing hand, in puppet space

enum B { WAIT, THROW, SWEEP, SLAM, STAGGER, DEAD }

const HIT_LINES := [
	"NANI?! THAT WAS MY BRICK!",
	"You can't just BAT my bricks back at me!",
	"STOP CATCHING THEM! THEY ARE EXPENSIVE!",
]
const THROW_LINES := ["BRICK!", "CATCH!", "HAVE A BRICK!", "BRICK BRICK BRICK!", "FREE SAMPLE! IT'S A BRICK!"]

var player: CharacterBody3D
var level: Node3D
var coaster: Node3D
var puppet: Node3D
var hp := MAX_HP
var state: B = B.WAIT
var ground_y := 0.0
var follow := true
var _t := 0.0
var _st := 0.0
var _cycle := 0
var _lag := 70.0
var _lag_goal := 42.0
var _out := 26.0
var _launched := false
var _bricks: Array = []    # {node, mark, car, local, from, t, dur, back, spin}
var _bar: Node3D
var _bar_strip: MeshInstance3D
var _bar_car: Node3D
var _bar_dir := 1.0
var _bar_x := 0.0
var _mallets: Array = []   # {node, car, local, mark, t, hit}
var _told_reflect := false


func _ready() -> void:
	puppet = Puppet.new()
	puppet.kind = "clown"
	puppet.speaker = "clown"
	puppet.scale = Vector3.ONE * S
	add_child(puppet)


## With a single life he fights at one steady, fairly hard pace.
func phase() -> int:
	return 2


func _base_lag() -> float:
	return [42.0, 38.0, 34.0][phase() - 1]


func start() -> void:
	_lag = 70.0
	_lag_goal = _base_lag()
	_cycle = 0
	_next()


func _next() -> void:
	var order: Array
	match phase():
		1: order = [B.THROW, B.SWEEP, B.THROW, B.SWEEP]
		2: order = [B.THROW, B.SLAM, B.SWEEP, B.THROW, B.SLAM, B.SWEEP]
		_: order = [B.SLAM, B.THROW, B.SWEEP, B.THROW, B.SLAM]
	_go(order[_cycle % order.size()])
	_cycle += 1


func _go(s: B) -> void:
	state = s
	_st = 0.0
	_launched = false
	puppet.emote = ""
	match s:
		B.THROW:
			puppet.emote = "throw"
		B.SWEEP:
			_begin_sweep()
		B.SLAM:
			puppet.emote = "smash"
			_begin_slam()
		B.STAGGER:
			puppet.emote = "shocked"
			_lag_goal = _base_lag() + 45.0


func _physics_process(delta: float) -> void:
	_t += delta
	_st += delta
	if coaster == null or player == null:
		return
	if follow:
		_place(delta)
	_update_bricks(delta)
	_update_mallets(delta)
	# The train gets faster as he gets angrier.
	if state != B.WAIT and state != B.DEAD:
		coaster.speed = lerpf(coaster.speed, [13.0, 15.5, 18.0][phase() - 1], clampf(delta * 0.8, 0.0, 1.0))
	match state:
		B.THROW: _st_throw()
		B.SWEEP: _st_sweep(delta)
		B.SLAM: _st_slam()
		B.STAGGER:
			if _st > 2.4:
				_lag_goal = _base_lag()
				_next()


## He runs along the ground, level with the train but well outside the track.
func _place(delta: float) -> void:
	_lag = lerpf(_lag, _lag_goal, clampf(delta * 1.5, 0.0, 1.0))
	var s: float = coaster.head_s - _lag
	var p: Vector3 = coaster.pos_at(s)
	global_position = Vector3(p.x, ground_y, p.z) + coaster.out_at(s) * _out
	var d: Vector3 = player.global_position - global_position
	rotation.y = lerp_angle(rotation.y, atan2(-d.x, -d.z), clampf(4.0 * delta, 0.0, 1.0))


# ---------------------------------------------------------------- bricks

func _st_throw() -> void:
	var dur := _brick_time()
	if not _launched and _st > 0.8:
		_launched = true
		puppet.emote = ""
		_launch_bricks([1, 2, 3][phase() - 1])
	if _st > 0.8 + dur + 0.5:
		_next()


func _brick_time() -> float:
	return maxf(1.7 - 0.2 * phase(), 1.0)


func _pick_target(dz: float, dx: float) -> Dictionary:
	var car: Node3D = coaster.cars[coaster.nearest_car(player.global_position)]
	var local := car.to_local(player.global_position)
	var half: float = coaster.car_len * 0.5 - 1.0
	return {"car": car, "local": Vector3(clampf(local.x + dx, -3.0, 3.0), 0.0, clampf(local.z + dz, -half, half))}


func _launch_bricks(count: int) -> void:
	var hand: Vector3 = puppet.to_global(HAND)
	Audio.play("whoosh", 0.7)
	if level:
		level.bark("clown", THROW_LINES[_cycle % THROW_LINES.size()])
		if not _told_reflect and level.has_method("on_first_brick"):
			_told_reflect = true
			level.on_first_brick()
	for i in count:
		var tgt := _pick_target(0.0 if i == 0 else randf_range(-5.0, 5.0), 0.0 if i == 0 else randf_range(-2.5, 2.5))
		var brick := _brick_mesh()
		get_parent().add_child(brick)
		brick.global_position = hand
		brick.visible = false
		_bricks.append({"node": brick, "mark": _marker(tgt.car, tgt.local, 2.1), "car": tgt.car, "local": tgt.local,
			"from": hand, "t": -i * 0.3, "dur": _brick_time(), "back": false,
			"spin": Vector3(randf_range(-5, 5), randf_range(-5, 5), randf_range(-5, 5))})


func _brick_mesh() -> Node3D:
	var root := Node3D.new()
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(2.8, 1.4, 1.4)
	mi.mesh = bm
	mi.material_override = Mats.toon(Color(0.78, 0.3, 0.22), 0.8, 0.2)
	root.add_child(mi)
	for y in [-0.33, 0.33]:
		var ml := MeshInstance3D.new()
		var lm := BoxMesh.new()
		lm.size = Vector3(2.84, 0.1, 1.44)
		ml.mesh = lm
		ml.material_override = Mats.solid(Color(0.9, 0.88, 0.84), 0.9)
		ml.position.y = y
		root.add_child(ml)
	return root


func _marker(car: Node3D, local: Vector3, radius: float, color := Color(1.0, 0.15, 0.15)) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var c := CylinderMesh.new()
	c.top_radius = radius
	c.bottom_radius = radius
	c.height = 0.05
	c.radial_segments = 32
	m.mesh = c
	m.material_override = Mats.unshaded(color, 0.55)
	m.position = local + Vector3(0, 0.07, 0)
	car.add_child(m)
	return m


func _update_bricks(delta: float) -> void:
	for b in _bricks.duplicate():
		b.t += delta
		var node: Node3D = b.node
		if b.t < 0.0:
			continue
		node.visible = true
		if b.back:
			# Batted back at his nose.
			var k := clampf(b.t / 0.85, 0.0, 1.0)
			var nose: Vector3 = puppet.to_global(Puppet.CLOWN_NOSE)
			node.global_position = b.from.lerp(nose, k) + Vector3(0, sin(k * PI) * 5.0, 0)
			node.rotation += b.spin * delta * 2.0
			if k >= 1.0:
				node.queue_free()
				_bricks.erase(b)
				take_hit()
			continue
		var k := clampf(b.t / b.dur, 0.0, 1.0)
		var goal: Vector3 = b.car.to_global(b.local + Vector3(0, 0.7, 0))
		node.global_position = b.from.lerp(goal, k) + Vector3(0, sin(k * PI) * 14.0, 0)
		node.rotation += b.spin * delta
		if is_instance_valid(b.mark):
			(b.mark as Node3D).scale = Vector3.ONE * (0.85 + 0.15 * sin(_t * 20.0))
		# Dive (or ground pound) into it as it arrives.
		if k > 0.3 and not player.dead and player.is_attacking():
			if node.global_position.distance_to(player.global_position + Vector3(0, 0.9, 0)) < 3.2:
				_reflect(b)
				continue
		if k >= 1.0:
			Audio.play("clang", 1.2, 0.1, -2.0)
			Audio.play("stomp", 0.7, 0.1, -3.0)
			Fx.burst(get_parent(), goal, Color(0.8, 0.3, 0.22), 24, 8.0, 0.4, 0.7, -10.0, "cube")
			if not player.dead and player.global_position.distance_to(goal) < 2.7:
				player.take_damage(1, goal)
			_free_brick(b)


func _free_brick(b: Dictionary) -> void:
	if is_instance_valid(b.mark):
		(b.mark as Node).queue_free()
	(b.node as Node).queue_free()
	_bricks.erase(b)


func _reflect(b: Dictionary) -> void:
	b.back = true
	b.t = 0.0
	b.from = (b.node as Node3D).global_position
	if is_instance_valid(b.mark):
		(b.mark as Node).queue_free()
	Audio.play("clang", 0.6)
	Audio.play("stomp", 1.1)
	Game.fx.flash(Color(1, 1, 1), 0.12)
	Fx.burst(get_parent(), b.from, Color(1.0, 0.9, 0.5), 20, 7.0, 0.25, 0.5, -4.0)
	if level:
		level.bark("stax", "BATTER UP!")


# ---------------------------------------------------------------- ticket gate

func _begin_sweep() -> void:
	_bar_car = coaster.cars[coaster.nearest_car(player.global_position)]
	_bar_dir = 1.0 if randf() > 0.5 else -1.0
	_bar_x = _bar_dir * 7.5
	_bar = Node3D.new()
	_bar_car.add_child(_bar)
	_bar.position = Vector3(_bar_x, 0.55, 0)
	var len: float = coaster.car_len
	var segs := 8
	for i in segs:
		var seg := MeshInstance3D.new()
		var sb := BoxMesh.new()
		sb.size = Vector3(1.0, 1.0, len / segs)
		seg.mesh = sb
		seg.material_override = Mats.toon(Color(0.95, 0.15, 0.2) if i % 2 == 0 else Color(1, 1, 1), 0.6, 0.2)
		seg.position.z = -len * 0.5 + (i + 0.5) * len / segs
		_bar.add_child(seg)
	# The strip on the deck shows where it will pass.
	_bar_strip = MeshInstance3D.new()
	var st := BoxMesh.new()
	st.size = Vector3(coaster.car_width, 0.05, len)
	_bar_strip.mesh = st
	_bar_strip.material_override = Mats.unshaded(Color(1.0, 0.2, 0.15), 0.4)
	_bar_strip.position = Vector3(0, 0.07, 0)
	_bar_car.add_child(_bar_strip)
	if level:
		level.bark("clown", ["TICKET GATE! CLOSING!", "MIND THE GAP! ...THE BIG GATE!", "ALL PASSENGERS MUST JUMP!"][_cycle % 3])
	Audio.play("rumble", 1.4, 0.0, -4.0)


func _st_sweep(delta: float) -> void:
	var warn := 0.95
	if _st < warn:
		_bar_strip.visible = fmod(_st, 0.2) < 0.12
		return
	_bar_strip.visible = false
	var dur := 1.15 - 0.1 * phase()
	var k := clampf((_st - warn) / dur, 0.0, 1.0)
	_bar_x = lerpf(_bar_dir * 7.5, -_bar_dir * 7.5, k)
	_bar.position.x = _bar_x
	var local: Vector3 = _bar_car.to_local(player.global_position)
	if not player.dead and absf(local.z) < coaster.car_len * 0.5 + 0.3 and absf(local.x - _bar_x) < 1.0 and local.y < 1.7:
		player.take_damage(1, _bar.global_position)
	if k >= 1.0:
		_bar.queue_free()
		_bar_strip.queue_free()
		_next()


# ---------------------------------------------------------------- hammers

func _begin_slam() -> void:
	var count: int = [2, 3, 3][phase() - 1]
	if level:
		level.bark("clown", ["HAMMER TIME!", "WHACK-A-STAX!", "I BROUGHT THE BIG MALLET!"][_cycle % 3])
	for i in count:
		var tgt := _pick_target(0.0 if i == 0 else randf_range(-6.0, 6.0), randf_range(-2.0, 2.0))
		if i > 0 and randf() > 0.4:
			# Sometimes it lands on a neighbouring car.
			var ci: int = coaster.nearest_car(player.global_position)
			var other: int = clampi(ci + (1 if randf() > 0.5 else -1), 0, coaster.cars.size() - 1)
			tgt = {"car": coaster.cars[other], "local": Vector3(randf_range(-3.0, 3.0), 0.0, randf_range(-4.5, 4.5))}
		_mallets.append({"node": null, "car": tgt.car, "local": tgt.local, "mark": _marker(tgt.car, tgt.local, 3.0, Color(1.0, 0.5, 0.1)),
			"t": -i * 0.25, "hit": false})
	Audio.play("whoosh", 0.5)


func _st_slam() -> void:
	if _st > 3.0:
		_next()


func _update_mallets(delta: float) -> void:
	for m in _mallets.duplicate():
		m.t += delta
		if m.t < 0.0:
			continue
		var fall_at := 1.1
		if not m.hit:
			if is_instance_valid(m.mark):
				(m.mark as Node3D).scale = Vector3.ONE * (0.85 + 0.15 * sin(_t * 22.0))
			if m.t >= fall_at:
				m.hit = true
				m.t = 0.0
				m.node = _mallet_mesh()
				(m.car as Node3D).add_child(m.node)
				(m.node as Node3D).position = m.local + Vector3(0, 1.5, 0)
				Audio.play("boom", 1.0)
				Audio.play("hit_low", 1.3, 0.0, -2.0)
				if level and level.rig:
					level.rig.shake(0.5)
				var at: Vector3 = (m.car as Node3D).to_global(m.local)
				Fx.burst(get_parent(), at + Vector3(0, 0.4, 0), Color(1.0, 0.85, 0.5, 0.9), 30, 9.0, 0.5, 0.7, -6.0)
				if not player.dead and player.global_position.distance_to(at + Vector3(0, 0.5, 0)) < 3.4:
					player.take_damage(1, at)
			continue
		# The mallet stays a moment, then goes.
		if m.t > 0.6:
			if is_instance_valid(m.mark):
				(m.mark as Node).queue_free()
			if m.node:
				(m.node as Node).queue_free()
			_mallets.erase(m)


func _mallet_mesh() -> Node3D:
	var root := Node3D.new()
	var head := MeshInstance3D.new()
	var hm := CylinderMesh.new()
	hm.top_radius = 1.5
	hm.bottom_radius = 1.5
	hm.height = 4.0
	head.mesh = hm
	head.material_override = Mats.toon(Color(0.95, 0.75, 0.2), 0.6, 0.3)
	head.rotation.z = PI / 2
	head.position.y = 1.5
	root.add_child(head)
	for x in [-1.0, 1.0]:
		var band := MeshInstance3D.new()
		var bm := CylinderMesh.new()
		bm.top_radius = 1.55
		bm.bottom_radius = 1.55
		bm.height = 0.4
		band.mesh = bm
		band.material_override = Mats.toon(Color(0.95, 0.2, 0.25), 0.6, 0.3)
		band.rotation.z = PI / 2
		band.position = Vector3(x * 1.9, 1.5, 0)
		root.add_child(band)
	var handle := MeshInstance3D.new()
	var hd := CylinderMesh.new()
	hd.top_radius = 0.3
	hd.bottom_radius = 0.3
	hd.height = 22.0
	handle.mesh = hd
	handle.material_override = Mats.toon(Color(0.55, 0.32, 0.18), 0.8, 0.1)
	handle.position.y = 13.0
	root.add_child(handle)
	return root


# ---------------------------------------------------------------- hits

## A brick in the nose (also used by the tests).
func take_hit() -> void:
	if state == B.DEAD:
		return
	hp -= 1
	hit.emit(hp)
	var nose: Vector3 = puppet.to_global(Puppet.CLOWN_NOSE)
	Audio.play("boing", 0.4)
	Audio.play("clang", 0.5)
	Audio.play("boom", 1.2)
	Game.fx.flash(Color(1, 1, 1), 0.35)
	if level and level.rig:
		level.rig.shake(0.7)
	Fx.burst(get_parent(), nose, Color(1.0, 0.2, 0.2), 50, 14.0, 1.2, 1.2, -4.0)
	Fx.burst(get_parent(), nose, Color(1.0, 0.85, 0.3), 24, 10.0, 0.6, 1.0, -8.0, "coin")
	puppet.squash = 0.55
	_clear_attacks()
	if hp <= 0:
		_die()
		return
	if level:
		level.bark("clown", HIT_LINES[(MAX_HP - hp - 1) % HIT_LINES.size()])
	_go(B.STAGGER)


func _die() -> void:
	state = B.DEAD
	follow = false
	puppet.emote = "shocked"
	_clear_attacks()
	defeated.emit()


## Back to full health, for a fresh attempt after Stax is knocked out.
func reset() -> void:
	_clear_attacks()
	hp = MAX_HP
	_cycle = 0
	_lag = 70.0
	_lag_goal = _base_lag()
	follow = true
	_go(B.THROW)


func _clear_attacks() -> void:
	for b in _bricks:
		if is_instance_valid(b.mark):
			(b.mark as Node).queue_free()
		(b.node as Node).queue_free()
	_bricks.clear()
	for m in _mallets:
		if is_instance_valid(m.mark):
			(m.mark as Node).queue_free()
		if m.node:
			(m.node as Node).queue_free()
	_mallets.clear()
	if is_instance_valid(_bar):
		_bar.queue_free()
	if is_instance_valid(_bar_strip):
		_bar_strip.queue_free()
