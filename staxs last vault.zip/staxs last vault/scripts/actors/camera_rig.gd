extends Node3D
## Orbit camera: mouse / right stick to orbit, 45-degree snap turns,
## three zoom distances, a gentle drift behind the player while running,
## and trauma-based screen shake.

const ZOOMS: Array[float] = [6.0, 9.0, 13.0]
const MOUSE_SENS := 0.004
const STICK_SPEED := 2.6

var target: Node3D
var pitch := -0.3
var zoom_index := 1
var active := true
var _yaw_goal := 0.0
var _manual_timer := 0.0
var _trauma := 0.0
var _noise := FastNoiseLite.new()
var _t := 0.0
var _arm: SpringArm3D
var camera: Camera3D


func _ready() -> void:
	_arm = SpringArm3D.new()
	_arm.spring_length = ZOOMS[zoom_index]
	_arm.margin = 0.3
	var probe := SphereShape3D.new()
	probe.radius = 0.25
	_arm.shape = probe
	add_child(_arm)
	camera = Camera3D.new()
	camera.fov = 62.0
	camera.far = 900.0
	_arm.add_child(camera)
	_yaw_goal = rotation.y
	_noise.frequency = 2.0


func _unhandled_input(event: InputEvent) -> void:
	if not active:
		return
	var sens: float = MOUSE_SENS * Game.settings.get("mouse_sens", 1.0)
	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_LEFT:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		elif event.button_index == MOUSE_BUTTON_WHEEL_UP:
			zoom_index = maxi(zoom_index - 1, 0)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			zoom_index = mini(zoom_index + 1, ZOOMS.size() - 1)
	elif event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_yaw_goal -= event.relative.x * sens
		pitch = clampf(pitch - event.relative.y * sens, -1.3, 0.4)
		_manual_timer = 1.5


## Adds screen shake; strength 0..1.
func shake(amount: float) -> void:
	_trauma = minf(_trauma + amount, 1.0)


func snap_behind() -> void:
	if target:
		_yaw_goal = target.facing
		rotation.y = _yaw_goal
		global_position = target.global_position + Vector3(0, 1.4, 0)


func make_current() -> void:
	camera.current = true
	active = true


func _physics_process(delta: float) -> void:
	if not target:
		return
	_t += delta
	if active:
		var stick := Input.get_vector("cam_left", "cam_right", "cam_up", "cam_down")
		if stick.length() > 0.1:
			_yaw_goal -= stick.x * STICK_SPEED * delta
			pitch = clampf(pitch - stick.y * STICK_SPEED * 0.6 * delta, -1.3, 0.4)
			_manual_timer = 1.5
		if Input.is_action_just_pressed("cam_snap_left"):
			_yaw_goal = snappedf(_yaw_goal + PI / 4.0, PI / 4.0)
			_manual_timer = 3.0
		if Input.is_action_just_pressed("cam_snap_right"):
			_yaw_goal = snappedf(_yaw_goal - PI / 4.0, PI / 4.0)
			_manual_timer = 3.0
		if Input.is_action_just_pressed("cam_zoom"):
			zoom_index = (zoom_index + 1) % ZOOMS.size()

	# Drift behind the player when running and the camera was left alone.
	_manual_timer -= delta
	var tv: Vector3 = target.velocity
	if _manual_timer <= 0.0 and Vector2(tv.x, tv.z).length() > 4.0:
		var behind: float = target.facing
		_yaw_goal = lerp_angle(_yaw_goal, behind, 0.6 * delta)

	rotation.y = lerp_angle(rotation.y, _yaw_goal, clampf(10.0 * delta, 0.0, 1.0))
	_arm.rotation.x = pitch
	_arm.spring_length = lerpf(_arm.spring_length, ZOOMS[zoom_index], 6.0 * delta)

	var goal := target.global_position + Vector3(0, 1.4, 0)
	global_position = global_position.lerp(goal, clampf(12.0 * delta, 0.0, 1.0))

	# Shake: rotate the camera by smooth noise scaled by trauma squared.
	_trauma = maxf(_trauma - delta * 1.2, 0.0)
	var s := _trauma * _trauma
	camera.rotation = Vector3(
		_noise.get_noise_2d(_t * 30.0, 0.0) * 0.08 * s,
		_noise.get_noise_2d(0.0, _t * 30.0) * 0.08 * s,
		_noise.get_noise_2d(_t * 30.0, 50.0) * 0.1 * s)
