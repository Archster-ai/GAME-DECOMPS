extends Node
## Autoload "Voice": the cast list and how each character sounds.
## Lines are spoken with the operating system's text-to-speech when it is
## available ("speech"), and otherwise with synthesized character babble
## ("babble"), one blip per couple of letters, pitched per character.

const CAST := {
	"stax": {"name": "Stax", "color": Color(1.0, 0.78, 0.2), "pitch": 1.25, "rate": 1.1, "blip": 1.15},
	"steve": {"name": "Signpost Steve", "color": Color(0.55, 0.9, 0.45), "pitch": 1.05, "rate": 1.0, "blip": 0.95},
	"steve_evil": {"name": "STEVE", "color": Color(1.0, 0.25, 0.2), "pitch": 0.45, "rate": 0.82, "blip": 0.55},
	"baron": {"name": "Baron Von Bankrupt", "color": Color(0.75, 0.45, 1.0), "pitch": 0.55, "rate": 0.85, "blip": 0.6},
	"news": {"name": "Channel 9 News", "color": Color(0.45, 0.75, 1.0), "pitch": 0.95, "rate": 1.08, "blip": 0.85},
	"waffle": {"name": "Sir Waffleton", "color": Color(0.98, 0.72, 0.35), "pitch": 1.15, "rate": 0.9, "blip": 1.05},
	"gary": {"name": "Gary from Accounting", "color": Color(0.78, 0.78, 0.66), "pitch": 0.7, "rate": 0.78, "blip": 0.72},
	"lefty": {"name": "Lefty", "color": Color(1.0, 0.5, 0.8), "pitch": 1.8, "rate": 1.25, "blip": 1.6},
	"pigeon": {"name": "Pigeon", "color": Color(0.7, 0.75, 0.85), "pitch": 1.5, "rate": 1.3, "blip": 1.4},
	"doodle": {"name": "Doodle", "color": Color(0.7, 0.45, 1.0), "pitch": 1.6, "rate": 1.15, "blip": 1.5},
	"camel": {"name": "Towel Camel", "color": Color(0.55, 0.9, 0.9), "pitch": 0.8, "rate": 0.85, "blip": 0.8},
	"moneybeard": {"name": "Captain Moneybeard", "color": Color(0.95, 0.3, 0.2), "pitch": 0.6, "rate": 0.95, "blip": 0.65},
	"ticktock": {"name": "Lord Tick-Tock the Eternal", "color": Color(0.85, 0.7, 0.45), "pitch": 0.45, "rate": 0.7, "blip": 0.5},
	"cuckoo": {"name": "Cuckoo", "color": Color(0.95, 0.75, 0.4), "pitch": 1.7, "rate": 1.2, "blip": 1.55},
	"parrot": {"name": "Parrot", "color": Color(0.3, 0.9, 0.35), "pitch": 1.9, "rate": 1.3, "blip": 1.7},
	"baby": {"name": "Baby Bigbucks", "color": Color(1.0, 0.6, 0.75), "pitch": 2.0, "rate": 0.85, "blip": 1.85},
	"coldcash": {"name": "Cold Hard Cash", "color": Color(0.55, 0.85, 1.0), "pitch": 0.5, "rate": 0.8, "blip": 0.55},
	"burnrate": {"name": "Burn Rate", "color": Color(1.0, 0.45, 0.15), "pitch": 0.65, "rate": 1.15, "blip": 0.7},
	"theend": {"name": "THE END", "color": Color(0.95, 0.95, 0.95), "pitch": 0.4, "rate": 0.72, "blip": 0.45},
	"clown": {"name": "Chuckles the Colossal", "color": Color(1.0, 0.35, 0.55), "pitch": 1.45, "rate": 1.0, "blip": 1.35},
	"kilowatt": {"name": "Kilowatt", "color": Color(0.4, 0.9, 1.0), "pitch": 0.5, "rate": 1.05, "blip": 0.6},
	"goddragon": {"name": "THE GOD DRAGON", "color": Color(1.0, 0.35, 0.9), "pitch": 0.3, "rate": 0.68, "blip": 0.4},
	"djvolt": {"name": "DJ Volt", "color": Color(1.0, 0.3, 0.9), "pitch": 1.1, "rate": 1.25, "blip": 1.2},
	"fan": {"name": "Fan", "color": Color(0.9, 0.9, 0.4), "pitch": 1.35, "rate": 1.2, "blip": 1.3},
	"shop": {"name": "Shopkeeper", "color": Color(1.0, 0.55, 0.85), "pitch": 1.2, "rate": 1.1, "blip": 1.25},
	"npc4": {"name": "Unused NPC #4", "color": Color(0.6, 0.6, 0.6), "pitch": 1.0, "rate": 1.0, "blip": 1.0},
	"teddy": {"name": "Sir Snuggles", "color": Color(0.8, 0.6, 0.4), "pitch": 0.75, "rate": 0.85, "blip": 0.75},
	"narrator": {"name": "", "color": Color(0.9, 0.9, 0.9), "pitch": 0.85, "rate": 0.95, "blip": 0.8},
}

## Replacements so text-to-speech pronounces names the way they are meant.
const SAY_AS := {"Stax": "Stacks", "STAX": "Stacks", "Waffleton": "Waffle-ton",
	"$": " dollars", "...": ", ", "Von": "Fon", "Hmph": "Hmf", "Arr": "Arrr", "ye ": "yee "}

var _blips: Array[AudioStreamWAV] = []
var _player: AudioStreamPlayer
var _voices: PackedStringArray = []
var _rng := RandomNumberGenerator.new()
## Text-to-speech bookkeeping. Each spoken line gets an utterance id; a line
## counts as speaking until the engine reports it ended (or, if this platform
## never reports, until a generous estimate of its length runs out).
var _next_id := 0
var _live := {}                # utterance id -> true, until it ends
var _dialogue_id := -1         # the current cutscene/conversation line
var _speaking_until := 0.0     # start-up grace: speech takes a moment to begin
var _deadline := 0.0           # safety net if an "ended" report never arrives
var _callbacks_work := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_player = AudioStreamPlayer.new()
	_player.bus = "Voice"
	add_child(_player)
	var vowels := [[730.0, 1090.0], [530.0, 1840.0], [270.0, 2290.0], [570.0, 840.0], [300.0, 870.0]]
	for v in vowels:
		_blips.append(_make_blip(v[0], v[1]))
	if _tts_supported():
		_voices = DisplayServer.tts_get_voices_for_language("en")
		DisplayServer.tts_set_utterance_callback(DisplayServer.TTS_UTTERANCE_STARTED, _on_utterance_started)
		DisplayServer.tts_set_utterance_callback(DisplayServer.TTS_UTTERANCE_ENDED, _on_utterance_done)
		DisplayServer.tts_set_utterance_callback(DisplayServer.TTS_UTTERANCE_CANCELED, _on_utterance_done)


func info(speaker: String) -> Dictionary:
	return CAST.get(speaker, CAST.narrator)


## Resolved voice mode: "speech", "babble" or "off".
func mode() -> String:
	var m: String = Game.settings.voice
	if m == "auto":
		return "speech" if not _voices.is_empty() else "babble"
	if m == "speech" and _voices.is_empty():
		return "babble"
	return m


func has_speech() -> bool:
	return not _voices.is_empty()


## Called when a line appears. Dialogue lines (cutscenes, conversations) cut
## off whatever is playing. Barks (radio lines during play) never cut off a
## dialogue line, and queue up behind another bark instead of cutting it off.
func start_line(speaker: String, text: String, bark := false) -> void:
	if mode() != "speech":
		return
	if bark and _live.has(_dialogue_id):
		return
	var interrupt := not bark or not busy()
	if interrupt:
		stop()
	var c := info(speaker)
	var say := text
	for k in SAY_AS:
		say = say.replace(k, SAY_AS[k])
	# Different characters get different system voices when there are several.
	var voice: String = _voices[absi(hash(speaker)) % _voices.size()]
	var vol := int(clampf(Game.settings.voice_volume, 0.0, 1.0) * 100.0)
	_next_id += 1
	_live[_next_id] = true
	if not bark:
		_dialogue_id = _next_id
	DisplayServer.tts_speak(say, voice, vol, c.pitch, c.rate, _next_id, interrupt)
	var now := Time.get_ticks_msec() / 1000.0
	_speaking_until = now + 1.0
	# Speech runs about 13 characters a second at rate 1.0; this allows for a
	# much slower voice, plus slack. Queued barks add up.
	var length := say.length() / (8.0 * maxf(c.rate, 0.3)) + 3.0
	_deadline = (maxf(_deadline, now) if not interrupt else now) + length


## Called for each character the typewriter reveals.
func typed(speaker: String, ch: String, index: int) -> void:
	if mode() != "babble" or index % 2 == 1:
		return
	if ch == " " or ch == "." or ch == "," or ch == "!" or ch == "?":
		return
	var c := info(speaker)
	_player.stream = _blips[_rng.randi() % _blips.size()]
	_player.pitch_scale = c.blip * _rng.randf_range(0.92, 1.08)
	_player.play()


## True while text-to-speech is still reading the current line (or a bark
## queued behind it).
func busy() -> bool:
	if mode() != "speech" or _live.is_empty():
		return false
	var now := Time.get_ticks_msec() / 1000.0
	if now < _speaking_until:
		return true
	if now > _deadline:
		return false
	if _callbacks_work:
		return true
	return DisplayServer.tts_is_speaking()


func stop() -> void:
	_live.clear()
	_dialogue_id = -1
	if _tts_supported() and not _voices.is_empty():
		DisplayServer.tts_stop()


func _on_utterance_started(_id: int) -> void:
	_callbacks_work = true


func _on_utterance_done(id: int) -> void:
	_callbacks_work = true
	_live.erase(id)


func _tts_supported() -> bool:
	return DisplayServer.get_name() != "headless" and ProjectSettings.get_setting("audio/general/text_to_speech", false)


## A short vowel-like blip: additive harmonics shaped by two formants.
func _make_blip(f1: float, f2: float) -> AudioStreamWAV:
	var rate := 22050
	var dur := 0.075
	var n := int(dur * rate)
	var buf := PackedFloat32Array()
	buf.resize(n)
	var f0 := 190.0
	var harmonics := []
	var k := 1
	while k * f0 < 4000.0:
		var hf := k * f0
		var a := exp(-pow((hf - f1) / 110.0, 2.0)) + 0.7 * exp(-pow((hf - f2) / 160.0, 2.0)) + 0.15 / k
		harmonics.append([hf, a])
		k += 1
	for i in n:
		var t := float(i) / rate
		var s := 0.0
		for h in harmonics:
			s += sin(TAU * h[0] * t) * h[1]
		var env := minf(t * 400.0, 1.0) * pow(1.0 - float(i) / n, 1.5)
		buf[i] = s * env * 0.18
	return Audio.to_wav(buf)
