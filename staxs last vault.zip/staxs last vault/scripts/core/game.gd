extends Node
## Autoload "Game": progress, settings, saving, and switching between screens.

signal settings_changed

const SAVE_PATH := "user://stax_save.cfg"
## Version 2 added The Nursery of Doom before the finale.
const SAVE_VERSION := 2

const LEVELS: Array[Dictionary] = [
	{"script": "res://scripts/levels/l1_rooftops.gd", "chapter": "Chapter 1",
		"title": "Goldhaven Rooftops", "subtitle": "Where the money never sleeps"},
	{"script": "res://scripts/levels/l2_breakfast.gd", "chapter": "Chapter 2",
		"title": "The Breakfast Dimension", "subtitle": "Most important meal of the multiverse"},
	{"script": "res://scripts/levels/l3_office.gd", "chapter": "Chapter 3",
		"title": "The Infinite Tax Office", "subtitle": "Please take a number"},
	{"script": "res://scripts/levels/l4_nebula.gd", "chapter": "Chapter 4",
		"title": "The Lost Sock Nebula", "subtitle": "Where every missing sock goes"},
	{"script": "res://scripts/levels/l5_scribble.gd", "chapter": "Chapter 5",
		"title": "The Scribble Kingdom", "subtitle": "Drawn by a seven-year-old. Physics by a six-year-old."},
	{"script": "res://scripts/levels/l6_desert.gd", "chapter": "Chapter 6",
		"title": "The Rubber Duck Desert", "subtitle": "Please squeak responsibly"},
	{"script": "res://scripts/levels/l7_clocktower.gd", "chapter": "Chapter 7",
		"title": "The Clocktower of Forever", "subtitle": "Midnight lives at the top"},
	{"script": "res://scripts/levels/l8_nursery.gd", "chapter": "Chapter 8",
		"title": "The Nursery of Doom", "subtitle": "Naptime is not optional"},
	{"script": "res://scripts/levels/l9_vault.gd", "chapter": "Finale",
		"title": "The Last Vault", "subtitle": "Everything you ever lost"},
	{"script": "res://scripts/levels/l10_frostfire.gd", "chapter": "Chapter 9",
		"title": "The Frostfire Rift", "subtitle": "Sequel? SEQUEL."},
	{"script": "res://scripts/levels/l11_page.gd", "chapter": "Chapter 10",
		"title": "The Page After The End", "subtitle": "This chapter does not exist"},
]

## Quality: 0 = low, 1 = high, 2 = ultra.
var settings := {
	"quality": 1,
	"voice": "auto",      # auto | speech | babble | off
	"music": 0.7,
	"sfx": 0.9,
	"voice_volume": 1.0,
	"fullscreen": false,
	"mouse_sens": 1.0,
}

var unlocked := 1          # how many chapters can be picked from the menu
var bank := 0              # coins carried between chapters
var best_coins := {}       # level index -> most coins collected in one run
## Coins needed across one adventure (the bank at the end) for the perfect ending.
const PERFECT_COINS := 500
var perfect_ending := false
var has_double_jump := false    # the Chapter 10 shop's Double Jump Candy
var current_level := -1
## Speedrun mode: every chapter back to back against the clock, cutscenes
## skipped. The clock only runs while the game isn't paused.
var speedrun := false
var run_time := 0.0
var splits: Array[float] = []     # run_time at the end of each chapter
var best_run := 0.0               # 0 = no finished run yet
var best_splits: Array = []
## Chapter speedrun: one chapter alone against the clock. Same rules as a
## speedrun (cutscenes skipped, timer runs), but it doesn't touch the bank or
## the unlocks, and it returns to the chapter list when the key is taken.
var chapter_run := false
var chapter_best := {}           # level index -> fastest time for that chapter
var chapter_last := {}           # result of the last chapter run, for the chapter list
var return_to_chapters := false  # the title screen opens the chapter list next time
## Set when a run finishes, for the credits: {time, splits, best, new_best}.
var last_run := {}
var _tick_us := 0
var main: Node             # main.gd, set on startup
## Tests switch this off so they never touch the player's real save.
var saving_enabled := true
var fx: Node               # post_fx.gd, set on startup


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	load_game()
	apply_settings()


func level_count() -> int:
	return LEVELS.size()


func level_info(i: int) -> Dictionary:
	return LEVELS[clampi(i, 0, LEVELS.size() - 1)]


# ---------------------------------------------------------------- flow

func new_game() -> void:
	speedrun = false
	bank = 0
	start_level(0)


func start_speedrun() -> void:
	speedrun = true
	chapter_run = false
	run_time = 0.0
	splits.clear()
	last_run = {}
	bank = 0
	start_level(0)


## True whenever the clock is running for a speedrun or a chapter run.
func timing() -> bool:
	return speedrun or chapter_run


func start_chapter_run(i: int) -> void:
	speedrun = false
	chapter_run = true
	run_time = 0.0
	chapter_last = {}
	_begin_level(i)


## Real time, so slow-motion and hit-stop can't bend the clock.
func _process(_delta: float) -> void:
	var now := Time.get_ticks_usec()
	var dt := (now - _tick_us) / 1000000.0
	_tick_us = now
	if timing() and current_level >= 0 and not get_tree().paused:
		run_time += minf(dt, 0.25)


static func format_time(t: float) -> String:
	var m := int(t / 60.0)
	var sec := fmod(t, 60.0)
	if m >= 60:
		return "%d:%02d:%05.2f" % [m / 60, m % 60, sec]
	return "%02d:%05.2f" % [m, sec]


func continue_game() -> void:
	start_level(clampi(unlocked - 1, 0, LEVELS.size() - 1))


## A normal start: plays the chapter, ending the chapter run mode if it was on.
func start_level(i: int) -> void:
	chapter_run = false
	_begin_level(i)


## Restarts the current chapter in whatever mode it's being played in.
func restart_level() -> void:
	_begin_level(current_level)


func _begin_level(i: int) -> void:
	current_level = i
	if main:
		main.start_level(i)


func complete_level(coins: int) -> void:
	if chapter_run:
		_finish_chapter_run()
		return
	bank += coins
	best_coins[current_level] = maxi(best_coins.get(current_level, 0), coins)
	unlocked = maxi(unlocked, mini(current_level + 2, LEVELS.size()))
	if speedrun:
		splits.append(run_time)
		if current_level + 1 >= LEVELS.size():
			_finish_run()
	save_game()
	if current_level + 1 < LEVELS.size():
		start_level(current_level + 1)
	elif main:
		main.show_credits()


func _finish_chapter_run() -> void:
	chapter_run = false
	var old: float = chapter_best.get(current_level, 0.0)
	var new_best := old <= 0.0 or run_time < old
	chapter_last = {"index": current_level, "time": run_time, "best": old, "new_best": new_best}
	if new_best:
		chapter_best[current_level] = run_time
	return_to_chapters = true
	save_game()
	if main:
		main.show_title()


func _finish_run() -> void:
	speedrun = false
	var new_best := best_run <= 0.0 or run_time < best_run
	last_run = {"time": run_time, "splits": splits.duplicate(), "best": best_run, "new_best": new_best,
		"best_splits": best_splits.duplicate()}
	if new_best:
		best_run = run_time
		best_splits = splits.duplicate()


func to_title() -> void:
	speedrun = false
	chapter_run = false
	current_level = -1
	if main:
		main.show_title()


# ---------------------------------------------------------------- settings

func set_setting(key: String, value) -> void:
	settings[key] = value
	apply_settings()
	save_game()
	settings_changed.emit()


func apply_settings() -> void:
	_bus_volume("Music", settings.music)
	_bus_volume("SFX", settings.sfx)
	_bus_volume("Voice", settings.voice_volume)
	if DisplayServer.get_name() != "headless":
		var fs: bool = settings.fullscreen
		var mode := DisplayServer.WINDOW_MODE_FULLSCREEN if fs else DisplayServer.WINDOW_MODE_WINDOWED
		if DisplayServer.window_get_mode() != mode:
			DisplayServer.window_set_mode(mode)


func _bus_volume(bus: String, linear: float) -> void:
	var idx := AudioServer.get_bus_index(bus)
	if idx >= 0:
		AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(linear, 0.0001)))


# ---------------------------------------------------------------- save

func save_game() -> void:
	if not saving_enabled:
		return
	var cfg := ConfigFile.new()
	cfg.set_value("progress", "version", SAVE_VERSION)
	cfg.set_value("progress", "unlocked", unlocked)
	cfg.set_value("progress", "bank", bank)
	cfg.set_value("progress", "best_coins", best_coins)
	cfg.set_value("progress", "perfect_ending", perfect_ending)
	cfg.set_value("progress", "double_jump", has_double_jump)
	cfg.set_value("speedrun", "best", best_run)
	cfg.set_value("speedrun", "splits", best_splits)
	for i in chapter_best:
		cfg.set_value("chapter_speedrun", str(i), chapter_best[i])
	for k in settings:
		cfg.set_value("settings", k, settings[k])
	cfg.save(SAVE_PATH)


func load_game() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	unlocked = clampi(cfg.get_value("progress", "unlocked", 1), 1, LEVELS.size())
	bank = cfg.get_value("progress", "bank", 0)
	best_coins = cfg.get_value("progress", "best_coins", {})
	perfect_ending = cfg.get_value("progress", "perfect_ending", false)
	has_double_jump = cfg.get_value("progress", "double_jump", false)
	best_run = cfg.get_value("speedrun", "best", 0.0)
	best_splits = cfg.get_value("speedrun", "splits", [])
	if cfg.has_section("chapter_speedrun"):
		for key in cfg.get_section_keys("chapter_speedrun"):
			chapter_best[int(key)] = cfg.get_value("chapter_speedrun", key, 0.0)
	if cfg.get_value("progress", "version", 1) < 2 and best_coins.has(7):
		# The finale moved from chapter index 7 to 8.
		best_coins[8] = best_coins[7]
		best_coins.erase(7)
	for k in settings:
		settings[k] = cfg.get_value("settings", k, settings[k])
