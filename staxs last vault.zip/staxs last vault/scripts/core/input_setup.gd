extends RefCounted
## Registers all input actions at startup so project.godot stays small.

static func setup() -> void:
	if InputMap.has_action("talk"):
		return
	_keys("move_forward", [KEY_W, KEY_UP])
	_keys("move_back", [KEY_S, KEY_DOWN])
	_keys("move_left", [KEY_A, KEY_LEFT])
	_keys("move_right", [KEY_D, KEY_RIGHT])
	_keys("jump", [KEY_SPACE])
	_keys("crouch", [KEY_SHIFT, KEY_CTRL])
	_keys("attack", [KEY_E, KEY_K])
	_keys("talk", [KEY_F, KEY_ENTER])
	_keys("pause", [KEY_ESCAPE, KEY_P])
	_keys("cam_snap_left", [KEY_J, KEY_Q])
	_keys("cam_snap_right", [KEY_L])
	_keys("cam_zoom", [KEY_I])
	_keys("reset", [KEY_R])
	_keys("toggle_help", [KEY_F1, KEY_H])

	_axis("move_forward", JOY_AXIS_LEFT_Y, -1.0)
	_axis("move_back", JOY_AXIS_LEFT_Y, 1.0)
	_axis("move_left", JOY_AXIS_LEFT_X, -1.0)
	_axis("move_right", JOY_AXIS_LEFT_X, 1.0)
	_axis("cam_left", JOY_AXIS_RIGHT_X, -1.0)
	_axis("cam_right", JOY_AXIS_RIGHT_X, 1.0)
	_axis("cam_up", JOY_AXIS_RIGHT_Y, -1.0)
	_axis("cam_down", JOY_AXIS_RIGHT_Y, 1.0)
	_axis("crouch", JOY_AXIS_TRIGGER_LEFT, 1.0)
	_button("jump", JOY_BUTTON_A)
	_button("attack", JOY_BUTTON_B)
	_button("attack", JOY_BUTTON_X)
	_button("talk", JOY_BUTTON_Y)
	_button("pause", JOY_BUTTON_START)
	_button("crouch", JOY_BUTTON_LEFT_SHOULDER)
	_button("cam_zoom", JOY_BUTTON_RIGHT_SHOULDER)
	_button("cam_snap_left", JOY_BUTTON_DPAD_LEFT)
	_button("cam_snap_right", JOY_BUTTON_DPAD_RIGHT)
	_button("reset", JOY_BUTTON_BACK)


static func _ensure(action: String) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action, 0.25)


static func _keys(action: String, keys: Array) -> void:
	_ensure(action)
	for k in keys:
		var ev := InputEventKey.new()
		ev.physical_keycode = k
		InputMap.action_add_event(action, ev)


static func _button(action: String, button: JoyButton) -> void:
	_ensure(action)
	var ev := InputEventJoypadButton.new()
	ev.button_index = button
	InputMap.action_add_event(action, ev)


static func _axis(action: String, axis: JoyAxis, dir: float) -> void:
	_ensure(action)
	var ev := InputEventJoypadMotion.new()
	ev.axis = axis
	ev.axis_value = dir
	InputMap.action_add_event(action, ev)
