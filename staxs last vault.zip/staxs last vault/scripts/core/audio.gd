extends Node
## Autoload "Audio": every sound in the game is synthesized here at runtime.
## Sound effects are rendered once at startup. Music tracks are rendered
## on a worker thread the first time they are needed, as two seamless loops:
## the tonal "main" layer and a separate drum layer that can fade in and out.

const RATE := 22050

## Music tracks. Chords are semitone offsets from `root` (a MIDI note).
## One chord per bar; the progression is played twice (A, then a variation).
const TRACKS := {
	"title": {"bpm": 84, "root": 50, "seed": 3, "drums": "soft", "bass": "long",
		"lead": "bell", "pad": 0.10, "arp": 0.0,
		"chords": [[0, 7, 12, 16], [-4, 3, 8, 12], [-7, 0, 5, 9], [-5, 2, 7, 11]]},
	"rooftops": {"bpm": 108, "root": 45, "seed": 11, "drums": "funk", "bass": "pluck",
		"lead": "square", "pad": 0.07, "arp": 0.035,
		"chords": [[5, 9, 12, 16], [4, 7, 11, 14], [2, 5, 9, 12], [7, 11, 14, 17]]},
	"breakfast": {"bpm": 126, "root": 48, "seed": 5, "drums": "bouncy", "bass": "bounce",
		"lead": "pluck", "pad": 0.05, "arp": 0.04,
		"chords": [[0, 4, 7, 12], [5, 9, 12, 16], [-3, 4, 9, 12], [7, 11, 14, 17]]},
	"office": {"bpm": 92, "root": 46, "seed": 23, "drums": "bossa", "bass": "walk",
		"lead": "sine", "pad": 0.08, "arp": 0.0,
		"chords": [[0, 4, 7, 11], [2, 5, 9, 12], [0, 4, 7, 11], [-2, 2, 5, 9]]},
	"nebula": {"bpm": 76, "root": 50, "seed": 42, "drums": "none", "bass": "long",
		"lead": "bell", "pad": 0.11, "arp": 0.03,
		"chords": [[0, 4, 7, 14], [2, 6, 9, 16], [-5, 2, 7, 11], [-3, 4, 7, 11]]},
	"vault": {"bpm": 96, "root": 45, "seed": 8, "drums": "soft", "bass": "pluck",
		"lead": "sine", "pad": 0.09, "arp": 0.03,
		"chords": [[0, 3, 7, 12], [-4, 0, 3, 8], [-2, 2, 5, 10], [-5, -1, 2, 7]]},
	"boss": {"bpm": 150, "root": 40, "seed": 99, "drums": "driving", "bass": "eighths",
		"lead": "square", "pad": 0.06, "arp": 0.04,
		"chords": [[0, 3, 7, 12], [-4, 0, 3, 8], [-7, -3, 0, 5], [-5, -1, 2, 7]]},
	"crayon": {"bpm": 116, "root": 55, "seed": 17, "drums": "bouncy", "bass": "bounce",
		"lead": "pluck", "pad": 0.04, "arp": 0.045,
		"chords": [[0, 4, 7, 12], [5, 9, 12, 17], [7, 11, 14, 19], [0, 4, 7, 12]]},
	"desert": {"bpm": 98, "root": 50, "seed": 31, "drums": "funk", "bass": "pluck",
		"lead": "square", "pad": 0.06, "arp": 0.03,
		"chords": [[0, 3, 7, 13], [1, 5, 8, 13], [0, 3, 7, 10], [-2, 1, 5, 10]]},
	"pirate": {"bpm": 144, "root": 43, "seed": 77, "drums": "driving", "bass": "eighths",
		"lead": "square", "pad": 0.05, "arp": 0.035,
		"chords": [[0, 3, 7, 12], [-2, 2, 5, 10], [-4, 0, 3, 8], [-5, -1, 2, 7]]},
	"clocktower": {"bpm": 104, "root": 45, "seed": 12, "drums": "funk", "bass": "pluck",
		"lead": "bell", "pad": 0.08, "arp": 0.045,
		"chords": [[0, 3, 7, 12], [-2, 2, 5, 10], [-4, 0, 3, 8], [-5, -1, 2, 7]]},
	"nursery": {"bpm": 88, "root": 53, "seed": 27, "drums": "soft", "bass": "long",
		"lead": "bell", "pad": 0.09, "arp": 0.04,
		"chords": [[0, 4, 7, 12], [-3, 0, 4, 9], [-7, -3, 0, 5], [-5, -1, 2, 7]]},
	"tantrum": {"bpm": 140, "root": 46, "seed": 51, "drums": "bouncy", "bass": "eighths",
		"lead": "bell", "pad": 0.05, "arp": 0.045,
		"chords": [[0, 3, 7, 12], [-4, 0, 3, 8], [-2, 2, 5, 10], [-5, -1, 2, 7]]},
	"frostfire": {"bpm": 132, "root": 45, "seed": 90, "drums": "driving", "bass": "eighths",
		"lead": "bell", "pad": 0.08, "arp": 0.045,
		"chords": [[0, 3, 7, 12], [-4, 0, 3, 8], [-7, -3, 0, 5], [-2, 2, 5, 10]]},
	"dragon": {"bpm": 164, "root": 38, "seed": 13, "drums": "driving", "bass": "eighths",
		"lead": "square", "pad": 0.07, "arp": 0.05,
		"chords": [[0, 3, 7, 12], [1, 5, 8, 13], [-4, 0, 3, 8], [-5, -1, 2, 7]]},
	"page": {"bpm": 72, "root": 52, "seed": 404, "drums": "bossa", "bass": "walk",
		"lead": "sine", "pad": 0.1, "arp": 0.03,
		"chords": [[0, 4, 8, 12], [2, 6, 10, 14], [-2, 2, 6, 10], [0, 4, 8, 14]]},
	"theend": {"bpm": 152, "root": 41, "seed": 666, "drums": "driving", "bass": "eighths",
		"lead": "bell", "pad": 0.08, "arp": 0.05,
		"chords": [[0, 3, 7, 12], [0, 3, 6, 12], [-1, 3, 6, 11], [-4, 0, 3, 8]]},
	# THE CURSOR's remix of "theend": same key and chords, half-time drums, wobble bass.
	"theend_dub": {"bpm": 140, "root": 41, "seed": 666, "drums": "dubstep", "bass": "wobble",
		"lead": "square", "pad": 0.06, "arp": 0.03,
		"chords": [[0, 3, 7, 12], [0, 3, 6, 12], [-1, 3, 6, 11], [-4, 0, 3, 8]]},
	# Chapter 12: the city light show, then Kilowatt's electric dubstep.
	"lightshow": {"bpm": 128, "root": 45, "seed": 1212, "drums": "bouncy", "bass": "eighths",
		"lead": "square", "pad": 0.07, "arp": 0.06,
		"chords": [[0, 3, 7, 12], [-4, 0, 3, 8], [-2, 2, 5, 10], [-5, -1, 2, 7]]},
	"kilowatt": {"bpm": 150, "root": 38, "seed": 1313, "drums": "dubhard", "bass": "wobble_fast",
		"lead": "zap", "pad": 0.05, "arp": 0.05,
		"chords": [[0, 3, 7, 12], [1, 5, 8, 13], [-2, 2, 5, 10], [-4, 0, 3, 8]]},
	# The horror phase: slow, wrong, and full of tritones; then the god dragon's fight.
	"horror": {"bpm": 58, "root": 33, "seed": 1666, "drums": "none", "bass": "long",
		"lead": "bell", "pad": 0.2, "arp": 0.03,
		"chords": [[0, 1, 6, 11], [0, 3, 6, 10], [-1, 0, 6, 9], [0, 6, 7, 13]]},
	# The god dragon's last hit: everything electrified, faster and buzzing.
	"godshock": {"bpm": 168, "root": 34, "seed": 1668, "drums": "dubhard", "bass": "wobble_fast",
		"lead": "zap", "pad": 0.08, "arp": 0.09,
		"chords": [[0, 1, 6, 11], [0, 3, 6, 10], [-1, 0, 6, 9], [1, 6, 7, 13]]},
	"godlight": {"bpm": 140, "root": 34, "seed": 1667, "drums": "dubhard", "bass": "wobble",
		"lead": "bell", "pad": 0.14, "arp": 0.045,
		"chords": [[0, 1, 6, 11], [0, 3, 6, 10], [-1, 0, 6, 9], [1, 6, 7, 13]]},
	"carnival": {"bpm": 124, "root": 50, "seed": 111, "drums": "bouncy", "bass": "bounce",
		"lead": "pluck", "pad": 0.05, "arp": 0.045,
		"chords": [[0, 4, 7, 12], [5, 9, 12, 16], [7, 11, 14, 17], [0, 4, 7, 12]]},
	"chase": {"bpm": 160, "root": 43, "seed": 222, "drums": "driving", "bass": "eighths",
		"lead": "square", "pad": 0.06, "arp": 0.05,
		"chords": [[0, 3, 7, 12], [-2, 2, 5, 10], [-4, 0, 3, 8], [1, 5, 8, 13]]},
	"coaster": {"bpm": 172, "root": 45, "seed": 333, "drums": "driving", "bass": "eighths",
		"lead": "bell", "pad": 0.07, "arp": 0.06,
		"chords": [[0, 4, 7, 12], [-3, 0, 4, 9], [5, 9, 12, 16], [-5, -1, 2, 7]]},
	"credits": {"bpm": 100, "root": 50, "seed": 64, "drums": "funk", "bass": "pluck",
		"lead": "bell", "pad": 0.08, "arp": 0.03,
		"chords": [[0, 4, 7, 12], [-3, 0, 4, 9], [5, 9, 12, 16], [7, 11, 14, 17]]},
}

var _sfx := {}
var _pool: Array[AudioStreamPlayer] = []
var _next := 0
var _music: AudioStreamPlayer
var _drums: AudioStreamPlayer
var _cache := {}
var _rendering := {}
var _wanted := ""
var _drum_level := 1.0
var _music_tween: Tween
var _lowpass: AudioEffectLowPassFilter
var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_lowpass = AudioEffectLowPassFilter.new()
	_lowpass.cutoff_hz = 20000.0
	var music_verb := AudioEffectReverb.new()
	music_verb.room_size = 0.7
	music_verb.wet = 0.18
	music_verb.dry = 0.9
	_make_bus("Music", [music_verb, _lowpass])
	var sfx_verb := AudioEffectReverb.new()
	sfx_verb.room_size = 0.35
	sfx_verb.wet = 0.08
	_make_bus("SFX", [sfx_verb])
	_make_bus("Voice", [])

	for i in 14:
		var p := AudioStreamPlayer.new()
		p.bus = "SFX"
		add_child(p)
		_pool.append(p)
	_music = AudioStreamPlayer.new()
	_music.bus = "Music"
	add_child(_music)
	_drums = AudioStreamPlayer.new()
	_drums.bus = "Music"
	add_child(_drums)

	_build_sfx()
	Game.apply_settings()


func _make_bus(bus_name: String, effects: Array) -> void:
	if AudioServer.get_bus_index(bus_name) >= 0:
		return
	AudioServer.add_bus()
	var i := AudioServer.bus_count - 1
	AudioServer.set_bus_name(i, bus_name)
	AudioServer.set_bus_send(i, "Master")
	for e in effects:
		AudioServer.add_bus_effect(i, e)


# ---------------------------------------------------------------- public API

## Plays a sound effect. `vary` randomizes pitch by up to that fraction.
func play(sfx_name: String, pitch := 1.0, vary := 0.05, volume_db := 0.0) -> void:
	if not _sfx.has(sfx_name):
		return
	var p := _pool[_next]
	_next = (_next + 1) % _pool.size()
	p.stream = _sfx[sfx_name]
	p.pitch_scale = pitch * (1.0 + _rng.randf_range(-vary, vary))
	p.volume_db = volume_db
	p.play()


func play_music(track: String, fade := 1.5) -> void:
	if track == _wanted:
		return
	_wanted = track
	_fade_out(fade * 0.5)
	if track == "" or not TRACKS.has(track):
		return
	if DisplayServer.get_name() == "headless":
		return  # no one to hear it; skip the render work in tests
	if _cache.has(track):
		_start_track.call_deferred(track, fade * 0.5)
	elif not _rendering.has(track):
		_rendering[track] = true
		WorkerThreadPool.add_task(_render_task.bind(track), false, "music")


func stop_music(fade := 1.5) -> void:
	_wanted = ""
	_fade_out(fade)


## 0 = no drums (quiet, tense moments), 1 = full band.
func set_drums(level: float, fade := 1.0) -> void:
	_drum_level = level
	if _drums.playing:
		create_tween().tween_property(_drums, "volume_db", _level_db(level), fade)


## Muffles the music, e.g. while paused.
func muffle(on: bool) -> void:
	var t := create_tween()
	t.tween_property(_lowpass, "cutoff_hz", 700.0 if on else 20000.0, 0.4)


func stream(sfx_name: String) -> AudioStream:
	return _sfx.get(sfx_name)


func _level_db(level: float) -> float:
	return linear_to_db(maxf(level, 0.0001))


func _fade_out(t: float) -> void:
	if _music_tween:
		_music_tween.kill()
	if not _music.playing:
		return
	_music_tween = create_tween().set_parallel()
	_music_tween.tween_property(_music, "volume_db", -60.0, maxf(t, 0.05))
	_music_tween.tween_property(_drums, "volume_db", -60.0, maxf(t, 0.05))
	_music_tween.chain().tween_callback(func():
		_music.stop()
		_drums.stop())


func _start_track(track: String, delay: float) -> void:
	if delay > 0.0:
		await get_tree().create_timer(delay, true, false, true).timeout
	if track != _wanted or not _cache.has(track):
		return
	if _music_tween:
		_music_tween.kill()
	var pair: Array = _cache[track]
	_music.stream = pair[0]
	_drums.stream = pair[1]
	_music.volume_db = -30.0
	_drums.volume_db = -30.0
	_music.play()
	_drums.play()
	_music_tween = create_tween().set_parallel()
	_music_tween.tween_property(_music, "volume_db", 0.0, 1.2)
	_music_tween.tween_property(_drums, "volume_db", _level_db(_drum_level), 1.2)


func _render_task(track: String) -> void:
	var pair := render_track(track)
	_on_rendered.call_deferred(track, pair)


func _on_rendered(track: String, pair: Array) -> void:
	_rendering.erase(track)
	_cache[track] = pair
	if track == _wanted:
		_start_track(track, 0.0)


# ---------------------------------------------------------------- helpers

static func midi(n: float) -> float:
	return 440.0 * pow(2.0, (n - 69.0) / 12.0)


static func to_wav(buf: PackedFloat32Array, loop := false) -> AudioStreamWAV:
	var bytes := PackedByteArray()
	bytes.resize(buf.size() * 2)
	for i in buf.size():
		bytes.encode_s16(i * 2, int(clampf(buf[i], -1.0, 1.0) * 32000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = bytes
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = buf.size()
	return w


static func blank(seconds: float) -> PackedFloat32Array:
	var b := PackedFloat32Array()
	b.resize(int(seconds * RATE))
	return b


## Adds one tone. wave: 0 sine, 1 square, 2 saw, 3 triangle, 4 noise.
## The pitch sweeps exponentially from f0 to f1. `curve` shapes the decay.
static func tone(buf: PackedFloat32Array, start: float, dur: float, f0: float, f1: float,
		wave: int, vol: float, attack := 0.005, curve := 2.0, lp := 1.0) -> void:
	var s := int(start * RATE)
	var n := int(dur * RATE)
	var size := buf.size()
	var phase := 0.0
	var y := 0.0
	var att := maxf(attack * RATE, 1.0)
	var ratio := f1 / f0
	var seed := 12345 + s
	for i in n:
		var t := float(i) / n
		var f := f0 * pow(ratio, t)
		phase = fmod(phase + f / RATE, 1.0)
		var x := 0.0
		match wave:
			0: x = sin(phase * TAU)
			1: x = 1.0 if phase < 0.5 else -1.0
			2: x = phase * 2.0 - 1.0
			3: x = 4.0 * absf(phase - 0.5) - 1.0
			_:
				seed = (seed * 1103515245 + 12345) & 0x7fffffff
				x = float(seed) / 1073741823.5 - 1.0
		y += lp * (x - y)
		var env := minf(i / att, 1.0) * pow(1.0 - t, curve)
		var idx := s + i
		if idx < size:
			buf[idx] += y * env * vol


# ---------------------------------------------------------------- sound effects

func _build_sfx() -> void:
	var b: PackedFloat32Array

	b = blank(0.16)
	tone(b, 0, 0.16, 280, 620, 1, 0.22, 0.003, 1.5, 0.5)
	_sfx["jump"] = to_wav(b)

	b = blank(0.18)
	tone(b, 0, 0.18, 340, 760, 1, 0.22, 0.003, 1.5, 0.5)
	_sfx["jump2"] = to_wav(b)

	b = blank(0.45)
	tone(b, 0, 0.3, 380, 980, 1, 0.2, 0.003, 1.2, 0.5)
	tone(b, 0.12, 0.33, 1500, 2400, 0, 0.12, 0.01, 2.0)
	_sfx["jump3"] = to_wav(b)

	b = blank(0.12)
	tone(b, 0, 0.12, 180, 60, 4, 0.5, 0.001, 3.0, 0.12)
	_sfx["land"] = to_wav(b)

	b = blank(0.4)
	tone(b, 0, 0.07, 988, 988, 1, 0.16, 0.001, 0.3, 0.6)
	tone(b, 0.07, 0.33, 1319, 1319, 1, 0.16, 0.001, 1.6, 0.6)
	tone(b, 0.07, 0.33, 2638, 2638, 0, 0.05, 0.001, 2.5)
	_sfx["coin"] = to_wav(b)

	b = blank(0.38)
	tone(b, 0, 0.38, 620, 140, 2, 0.25, 0.002, 1.2, 0.4)
	tone(b, 0, 0.2, 800, 200, 4, 0.2, 0.001, 2.0, 0.3)
	_sfx["hurt"] = to_wav(b)

	b = blank(0.3)
	tone(b, 0, 0.1, 900, 300, 4, 0.4, 0.001, 2.0, 0.5)
	tone(b, 0, 0.3, 160, 40, 0, 0.6, 0.002, 1.5)
	_sfx["stomp"] = to_wav(b)

	b = blank(0.5)
	tone(b, 0, 0.5, 120, 30, 0, 0.8, 0.002, 1.3)
	tone(b, 0, 0.25, 400, 80, 4, 0.5, 0.001, 2.0, 0.2)
	_sfx["pound"] = to_wav(b)

	b = blank(0.32)
	tone(b, 0, 0.32, 1000, 3000, 4, 0.3, 0.08, 1.5, 0.08)
	_sfx["dive"] = to_wav(b)

	b = blank(0.9)
	var notes := [72, 76, 79, 84]
	for i in notes.size():
		tone(b, i * 0.09, 0.6, midi(notes[i]), midi(notes[i]), 0, 0.15, 0.002, 2.5)
		tone(b, i * 0.09, 0.4, midi(notes[i] + 12), midi(notes[i] + 12), 3, 0.05, 0.002, 3.0)
	_sfx["checkpoint"] = to_wav(b)

	b = blank(2.2)
	var fan := [67, 72, 76, 79, 84, 88]
	for i in fan.size():
		tone(b, i * 0.1, 1.6, midi(fan[i]), midi(fan[i]), 1, 0.07, 0.003, 2.0, 0.3)
		tone(b, i * 0.1, 1.8, midi(fan[i]), midi(fan[i]) * 1.003, 0, 0.1, 0.003, 2.0)
	for i in 10:
		var f := midi(84 + (i * 7) % 24)
		tone(b, 0.6 + i * 0.08, 0.5, f, f, 0, 0.04, 0.001, 3.0)
	_sfx["fanfare"] = to_wav(b)

	b = blank(1.0)
	tone(b, 0, 1.0, 300, 2500, 4, 0.35, 0.6, 1.0, 0.05)
	_sfx["whoosh"] = to_wav(b)

	b = blank(1.4)
	tone(b, 0, 1.4, 90, 25, 0, 0.9, 0.002, 1.2)
	tone(b, 0, 1.0, 600, 60, 4, 0.6, 0.001, 1.6, 0.15)
	_sfx["boom"] = to_wav(b)

	b = blank(0.8)
	for f in [523.0, 1187.0, 1703.0, 2397.0]:
		tone(b, 0, 0.8, f, f * 0.98, 0, 0.13, 0.001, 3.0)
	tone(b, 0, 0.08, 3000, 1000, 4, 0.4, 0.001, 2.0, 0.6)
	_sfx["clang"] = to_wav(b)

	b = blank(0.06)
	tone(b, 0, 0.06, 1200, 1200, 1, 0.1, 0.001, 1.0, 0.5)
	_sfx["ui_move"] = to_wav(b)

	b = blank(0.2)
	tone(b, 0, 0.08, 880, 880, 1, 0.12, 0.001, 0.5, 0.5)
	tone(b, 0.07, 0.13, 1320, 1320, 1, 0.12, 0.001, 1.5, 0.5)
	_sfx["ui_ok"] = to_wav(b)

	b = blank(0.45)
	tone(b, 0, 0.45, 180, 900, 0, 0.45, 0.002, 1.2)
	tone(b, 0, 0.45, 186, 930, 3, 0.15, 0.002, 1.2)
	_sfx["boing"] = to_wav(b)

	b = blank(0.2)
	tone(b, 0, 0.2, 1400, 300, 2, 0.15, 0.001, 1.5, 0.5)
	_sfx["zap"] = to_wav(b)

	b = blank(0.22)
	tone(b, 0, 0.22, 500, 1400, 0, 0.3, 0.001, 2.0)
	tone(b, 0, 0.05, 2000, 800, 4, 0.2, 0.001, 1.0, 0.7)
	_sfx["pop"] = to_wav(b)

	b = blank(0.25)
	tone(b, 0, 0.25, 90, 70, 1, 0.12, 0.01, 1.0, 0.1)
	_sfx["step"] = to_wav(b)

	b = blank(0.7)
	tone(b, 0, 0.7, 70, 45, 2, 0.35, 0.05, 1.0, 0.08)
	tone(b, 0, 0.7, 72, 46, 1, 0.2, 0.05, 1.0, 0.08)
	_sfx["rumble"] = to_wav(b)

	b = blank(1.2)
	tone(b, 0, 1.2, 55, 55, 0, 0.9, 0.001, 1.4)
	tone(b, 0, 0.9, 110, 108, 2, 0.25, 0.001, 2.0, 0.1)
	_sfx["hit_low"] = to_wav(b)

	b = blank(0.05)
	tone(b, 0, 0.05, 2400, 1800, 4, 0.25, 0.001, 3.0, 0.7)
	_sfx["tick"] = to_wav(b)

	b = blank(0.6)
	tone(b, 0, 0.6, 1400, 90, 4, 0.5, 0.001, 0.8, 0.35)
	tone(b, 0, 0.5, 600, 60, 2, 0.2, 0.001, 1.0, 0.3)
	_sfx["scratch"] = to_wav(b)

	b = blank(3.0)
	for f in [196.0, 392.0, 466.0, 587.0, 784.0, 1046.0]:
		tone(b, 0, 3.0, f, f * 0.999, 0, 0.12, 0.002, 2.2)
	_sfx["bong"] = to_wav(b)

	b = blank(2.5)
	tone(b, 0, 2.5, 200, 30, 4, 0.7, 0.05, 1.3, 0.04)
	tone(b, 0.1, 1.5, 70, 40, 0, 0.5, 0.01, 1.5)
	_sfx["thunder"] = to_wav(b)


# ---------------------------------------------------------------- music

## Renders a track to [main_layer, drum_layer]. Safe to call from any thread.
static func render_track(track: String) -> Array:
	var d: Dictionary = TRACKS[track]
	var rng := RandomNumberGenerator.new()
	rng.seed = d.seed
	var chords: Array = d.chords
	var bars: int = chords.size() * 2
	var beat := 60.0 / float(d.bpm)
	var bar_len := beat * 4.0
	var main := blank(bars * bar_len)
	var drums := blank(bars * bar_len)
	var root: int = d.root
	var melody := _make_melody(rng, chords.size())

	for b in bars:
		var chord: Array = chords[b % chords.size()]
		var t0 := b * bar_len
		# Pad: sustained chord.
		if d.pad > 0.0:
			for n in chord:
				_pad(main, t0, bar_len, midi(root + 12 + n), d.pad)
		# Bass.
		_bass(main, d.bass, t0, beat, root + int(chord[0]) - 12, chord, rng)
		# Arpeggio: chord tones climbing in sixteenths.
		if d.arp > 0.0:
			for s in 16:
				var n: int = chord[s % chord.size()] + 24 + 12 * int(s / 8.0 if b % 2 == 1 else 0)
				_pluck(main, t0 + s * beat * 0.25, beat * 0.3, midi(root + n), d.arp, 1)
		# Lead melody. Second half of the loop is an octave-varied answer.
		for note in melody:
			var bar_of: int = note[0]
			if bar_of != b % chords.size():
				continue
			var tone_idx: int = note[2]
			var n2: int = int(chord[tone_idx % chord.size()]) + 24 + note[3] * 12
			if b >= chords.size() and tone_idx == 0:
				n2 += 12
			_lead(main, d.lead, t0 + note[1] * beat * 0.5, note[4] * beat * 0.5, midi(root + n2))
		_drum_bar(drums, d.drums, t0, beat, b)

	return [to_wav(main, true), to_wav(drums, true)]


## Melody notes: [bar, start_eighth, chord_tone_index, octave, length_eighths].
static func _make_melody(rng: RandomNumberGenerator, chord_bars: int) -> Array:
	var rhythms := [[2, 1, 1, 2, 2], [1, 1, 2, 1, 1, 2], [3, 1, 2, 2], [2, 2, 2, 2],
		[1, 1, 1, 1, 4], [4, 2, 2], [3, 3, 2], [2, 1, 1, 4]]
	var motif := []
	for bar in 2:
		var r: Array = rhythms[rng.randi() % rhythms.size()]
		var pos := 0
		var last := rng.randi() % 3
		for dur in r:
			if rng.randf() > 0.15 or pos == 0:
				last = clampi(last + rng.randi_range(-1, 1), 0, 3)
				motif.append([bar, pos, last, 0 if rng.randf() > 0.2 else 1, dur])
			pos += dur
	var out := []
	for bar in chord_bars:
		for m in motif:
			if m[0] == bar % 2:
				var copy: Array = m.duplicate()
				copy[0] = bar
				# Every other pair of bars resolves on the root.
				if bar % 4 == 3 and m[1] >= 6:
					copy[2] = 0
				out.append(copy)
	return out


static func _pad(buf: PackedFloat32Array, start: float, dur: float, freq: float, vol: float) -> void:
	var s := int(start * RATE)
	var n := int((dur + 0.5) * RATE)
	var hold := dur * RATE
	var size := buf.size()
	var p1 := 0.0
	var p2 := 0.37
	var y := 0.0
	var inc1 := freq / RATE
	var inc2 := freq * 1.006 / RATE
	for i in n:
		p1 = fmod(p1 + inc1, 1.0)
		p2 = fmod(p2 + inc2, 1.0)
		var x := (p1 + p2) - 1.0
		y += 0.06 * (x - y)
		var env := minf(i / (0.35 * RATE), 1.0)
		if i > hold:
			env *= 1.0 - (i - hold) / (0.5 * RATE)
		buf[(s + i) % size] += y * env * vol


static func _pluck(buf: PackedFloat32Array, start: float, dur: float, freq: float, vol: float, wave: int) -> void:
	var s := int(start * RATE)
	var n := int(dur * RATE)
	var size := buf.size()
	var p := 0.0
	var inc := freq / RATE
	for i in n:
		p = fmod(p + inc, 1.0)
		var x := 0.0
		if wave == 1:
			x = 1.0 if p < 0.25 else -0.33
		else:
			x = 4.0 * absf(p - 0.5) - 1.0
		var env := pow(1.0 - float(i) / n, 3.0)
		buf[(s + i) % size] += x * env * vol


static func _lead(buf: PackedFloat32Array, kind: String, start: float, dur: float, freq: float) -> void:
	var s := int(start * RATE)
	var n := int((dur + 0.08) * RATE)
	var size := buf.size()
	var p := 0.0
	var y := 0.0
	for i in n:
		var t := float(i) / RATE
		var vib := 1.0 + 0.004 * sin(t * 34.0) * minf(t * 3.0, 1.0)
		p = fmod(p + freq * vib / RATE, 1.0)
		var x := 0.0
		var env := 1.0
		match kind:
			"square":
				x = (1.0 if p < 0.5 else -1.0) * 0.5
				y += 0.25 * (x - y)
				x = y
				env = minf(t * 200.0, 1.0) * (1.0 - 0.3 * minf(t / dur, 1.0))
			"pluck":
				x = 4.0 * absf(p - 0.5) - 1.0
				env = exp(-t * 7.0)
			"zap":
				# A buzzing, clipped saw: electricity.
				x = tanh(3.0 * (p * 2.0 - 1.0)) * 0.6 + 0.3 * sin(p * TAU * 3.0 + t * 90.0)
				env = minf(t * 300.0, 1.0) * exp(-t * 3.0)
			"bell":
				x = sin(p * TAU) + 0.35 * sin(p * TAU * 2.76) * exp(-t * 6.0) + 0.2 * sin(p * TAU * 5.4) * exp(-t * 9.0)
				env = exp(-t * 2.2)
			_:
				x = sin(p * TAU) + 0.15 * sin(p * TAU * 2.0)
				env = minf(t * 40.0, 1.0)
		if t > dur:
			env *= maxf(1.0 - (t - dur) / 0.08, 0.0)
		buf[(s + i) % size] += x * env * 0.11


static func _bass(buf: PackedFloat32Array, style: String, t0: float, beat: float, note: int,
		chord: Array, rng: RandomNumberGenerator) -> void:
	var f := midi(note)
	match style:
		"long":
			_bass_note(buf, t0, beat * 4.0, f, 0.16, 0.5)
		"pluck":
			for step in [[0, 1.5], [1.5, 0.5], [2.5, 1.0], [3.5, 0.5]]:
				var fifth: bool = step[0] == 2.5
				_bass_note(buf, t0 + step[0] * beat, step[1] * beat, f * (1.5 if fifth else 1.0), 0.2, 6.0)
		"bounce":
			for i in 8:
				var oct := 2.0 if i % 2 == 1 else 1.0
				_bass_note(buf, t0 + i * beat * 0.5, beat * 0.35, f * oct, 0.18, 9.0)
		"walk":
			for i in 4:
				var n: int = note + int(chord[i % chord.size()]) - int(chord[0])
				_bass_note(buf, t0 + i * beat, beat * 0.9, midi(n), 0.18, 3.0)
		"wobble":
			# Dubstep: two long growling notes a bar, the filter wobbling at a
			# different rate each half (eighths, then triplets, then sixteenths).
			var rates := [2.0, 3.0, 4.0, 2.0]
			var bar_i := int(round(t0 / (beat * 4.0)))
			_wobble(buf, t0, beat * 2.5, f, rates[bar_i % 4] / beat, 0.3)
			_wobble(buf, t0 + beat * 2.5, beat * 1.5, f * (1.5 if bar_i % 2 == 1 else 1.0), rates[(bar_i + 1) % 4] / beat, 0.3)
		"wobble_fast":
			# Kilowatt: shorter, meaner notes with a filter wobbling up to
			# sixteenth-triplets, and a stab on the last beat of every bar.
			var rates := [3.0, 4.0, 6.0, 8.0]
			var bar_i := int(round(t0 / (beat * 4.0)))
			_wobble(buf, t0, beat * 1.9, f, rates[bar_i % 4] / beat, 0.32)
			_wobble(buf, t0 + beat * 2.0, beat * 1.4, f * (1.5 if bar_i % 2 == 1 else 1.0), rates[(bar_i + 2) % 4] / beat, 0.32)
			_wobble(buf, t0 + beat * 3.5, beat * 0.5, f * 2.0, 12.0 / beat, 0.26)
		"eighths":
			for i in 8:
				var up := 1.0 if i < 6 else 1.5
				_bass_note(buf, t0 + i * beat * 0.5, beat * 0.45, f * up, 0.2, 4.0)


## A dubstep bass note: saw + square through a low-pass whose cutoff swings
## `rate` times a second, with a sine sub underneath.
static func _wobble(buf: PackedFloat32Array, start: float, dur: float, freq: float, rate: float, vol: float) -> void:
	var s := int(start * RATE)
	var n := int(dur * RATE)
	var size := buf.size()
	var lfo_hz := rate
	var p := 0.0
	var y := 0.0
	var y2 := 0.0
	for i in n:
		var t := float(i) / RATE
		p = fmod(p + freq / RATE, 1.0)
		var saw := p * 2.0 - 1.0
		var sq := 1.0 if fmod(p * 2.0 + 0.3 * sin(t * 5.0), 1.0) < 0.5 else -1.0
		var x := saw * 0.7 + sq * 0.3
		var lfo := 0.5 + 0.5 * sin(t * lfo_hz * TAU)
		var k := 0.04 + 0.5 * lfo * lfo
		y += k * (x - y)
		y2 += k * (y - y2)
		var sub := sin(p * TAU)
		var env := minf(t * 400.0, 1.0) * minf((n - i) / 300.0, 1.0)
		buf[(s + i) % size] += (y2 * 1.5 + sub * 0.5) * env * vol


static func _bass_note(buf: PackedFloat32Array, start: float, dur: float, freq: float, vol: float, decay: float) -> void:
	var s := int(start * RATE)
	var n := int(dur * RATE)
	var size := buf.size()
	var p := 0.0
	for i in n:
		var t := float(i) / RATE
		p = fmod(p + freq / RATE, 1.0)
		var x := 4.0 * absf(p - 0.5) - 1.0
		x = x * 0.8 + sin(p * TAU) * 0.4
		var env := minf(t * 300.0, 1.0) * exp(-t * decay) * minf((n - i) / 200.0, 1.0)
		buf[(s + i) % size] += x * env * vol


static func _drum_bar(buf: PackedFloat32Array, style: String, t0: float, beat: float, bar: int) -> void:
	var kick := []
	var snare := []
	var hat := []
	match style:
		"soft":
			kick = [0, 10]
			snare = [8]
			hat = [2, 6, 10, 14]
		"funk":
			kick = [0, 7, 10]
			snare = [4, 12]
			hat = [0, 2, 4, 6, 8, 10, 11, 12, 14]
		"bouncy":
			kick = [0, 4, 8, 12]
			snare = [4, 12]
			hat = [2, 6, 10, 14]
		"bossa":
			kick = [0, 6, 8, 14]
			snare = [3, 6, 10, 13]
			hat = [0, 2, 4, 6, 8, 10, 12, 14]
		"dubhard":
			kick = [0, 7]
			snare = [8]
			hat = [2, 6, 10, 14, 15]
			if bar % 4 == 3:
				snare = [8, 10, 12, 13, 14, 15]
				kick = [0, 7, 11]
		"dubstep":
			# Half-time: one big snare on the three, kick on the one.
			kick = [0, 10]
			snare = [8]
			hat = [4, 12, 14]
			if bar % 4 == 3:
				hat = [4, 12, 13, 14, 15]
		"driving":
			kick = [0, 4, 8, 10, 12]
			snare = [4, 12]
			hat = [0, 2, 4, 6, 8, 10, 12, 14]
			if bar % 4 == 3:
				snare = [4, 12, 13, 14, 15]
		_:
			return
	var step := beat * 0.25
	for s in kick:
		tone(buf, t0 + s * step, 0.3, 120, 42, 0, 0.55, 0.001, 1.8)
	for s in snare:
		var soft := style == "bossa"
		tone(buf, t0 + s * step, 0.18 if not soft else 0.06, 1800, 900, 4, 0.2 if not soft else 0.12, 0.001, 2.0, 0.6)
		if not soft:
			tone(buf, t0 + s * step, 0.12, 200, 160, 3, 0.18, 0.001, 2.0)
	for s in hat:
		var hb := int((t0 + s * step) * RATE)
		var n := int(0.04 * RATE)
		var seed := hb
		var prev := 0.0
		for i in n:
			seed = (seed * 1103515245 + 12345) & 0x7fffffff
			var x := float(seed) / 1073741823.5 - 1.0
			var hp := x - prev
			prev = x
			if hb + i < buf.size():
				buf[hb + i] += hp * 0.05 * pow(1.0 - float(i) / n, 2.0)
