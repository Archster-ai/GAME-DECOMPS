extends Node3D
## Runs cutscenes. Owns a cinematic camera with handheld sway, auto-focus
## depth of field and shake. Every step is awaitable and finishes instantly
## once the player skips (press pause twice).
##
##   await d.begin()
##   d.shot(pos, look, 40.0)
##   await d.move(pos2, look2, 3.0)
##   await d.say("stax", "Where'd all my money go?!", "shocked")
##   await d.end()

var level: Node3D
var player: CharacterBody3D
var hud: CanvasLayer
var cam: Camera3D
var attrs: CameraAttributesPractical
var active := false
var skipping := false
var sway := 1.0
## Speaker id -> node with an `emote` property, for gestures during lines.
var actors := {}

var _pos := Vector3(0, 5, 10)
var _look := Vector3.ZERO
var _fov := 50.0
var _roll := 0.0
var _trauma := 0.0
var _skip_armed := 0.0
var _busy := 0
var _noise := FastNoiseLite.new()
var _t := 0.0


func _ready() -> void:
	cam = Camera3D.new()
	cam.far = 900.0
	attrs = CameraAttributesPractical.new()
	cam.attributes = attrs
	add_child(cam)
	_noise.frequency = 0.35


func begin(bars := true) -> void:
	active = true
	skipping = false
	_skip_armed = 0.0
	player.frozen = true
	player.scripted_input = Vector3.ZERO
	if level.rig:
		level.rig.active = false
	cam.current = true
	hud.set_gameplay_visible(false)
	hud.prompt("")
	if bars:
		Game.fx.letterbox(true)
	attrs.dof_blur_far_enabled = Game.settings.quality >= 1
	attrs.dof_blur_near_enabled = Game.settings.quality >= 1
	actors["stax"] = player.model


func end() -> void:
	Game.fx.close_dialogue()
	Game.fx.letterbox(false)
	Game.fx.show_skip_hint(false)
	Game.fx.hide_card()
	player.frozen = false
	player.scripted_input = Vector3.ZERO
	player.model.emote = ""
	player.model.head_yaw = 0.0
	for a in actors.values():
		if is_instance_valid(a) and "emote" in a:
			a.emote = ""
	attrs.dof_blur_far_enabled = false
	attrs.dof_blur_near_enabled = false
	hud.set_gameplay_visible(true)
	if level.rig:
		level.rig.snap_behind()
		level.rig.make_current()
	active = false
	skipping = false


# ---------------------------------------------------------------- camera

## Cuts to a shot.
func shot(pos: Vector3, look: Vector3, fov := 50.0, roll := 0.0) -> void:
	_pos = pos
	_look = look
	_fov = fov
	_roll = roll
	_apply()


## Glides the camera to a new shot over `dur` seconds (smoothstep eased).
func move(pos: Vector3, look: Vector3, dur: float, fov := -1.0, ease_mode := "smooth") -> void:
	var p0 := _pos
	var l0 := _look
	var f0 := _fov
	var f1 := f0 if fov < 0.0 else fov
	var t := 0.0
	_busy += 1
	while t < dur and not skipping:
		t += await _frame()
		var k := _ease(clampf(t / dur, 0.0, 1.0), ease_mode)
		_pos = p0.lerp(pos, k)
		_look = l0.lerp(look, k)
		_fov = lerpf(f0, f1, k)
	_busy -= 1
	_pos = pos
	_look = look
	_fov = f1


## Circles `center` from angle a0 to a1 (radians) at a radius and height.
func orbit(center: Vector3, radius: float, height: float, a0: float, a1: float, dur: float, fov := -1.0) -> void:
	var t := 0.0
	var f0 := _fov
	var f1 := f0 if fov < 0.0 else fov
	_busy += 1
	while t < dur and not skipping:
		t += await _frame()
		var k := _ease(clampf(t / dur, 0.0, 1.0), "smooth")
		var a := lerpf(a0, a1, k)
		_pos = center + Vector3(cos(a) * radius, height, sin(a) * radius)
		_look = center
		_fov = lerpf(f0, f1, k)
	_busy -= 1
	var a_end := a1
	_pos = center + Vector3(cos(a_end) * radius, height, sin(a_end) * radius)
	_look = center
	_fov = f1


## Keeps the camera at `offset` from a moving node for `dur` seconds.
func track(node: Node3D, offset: Vector3, look_offset: Vector3, dur: float) -> void:
	var t := 0.0
	_busy += 1
	while t < dur and not skipping and is_instance_valid(node):
		var dt := await _frame()
		t += dt
		var k := clampf(6.0 * dt, 0.0, 1.0)
		_pos = _pos.lerp(node.global_position + offset, k)
		_look = _look.lerp(node.global_position + look_offset, k)
	_busy -= 1


## A shot framing two nodes side by side, as in a conversation.
func two_shot(a: Node3D, b: Node3D, side := 1.0, fov := 42.0) -> void:
	var pa := a.global_position
	var pb := b.global_position
	var mid := (pa + pb) * 0.5 + Vector3(0, 1.3, 0)
	var across := pb - pa
	across.y = 0
	var dist := maxf(across.length(), 1.0)
	var perp := Vector3(-across.z, 0, across.x).normalized() * side
	shot(mid + perp * (dist * 1.2 + 3.0) + Vector3(0, 0.6, 0), mid, fov)


func shake(amount: float) -> void:
	_trauma = minf(_trauma + amount, 1.0)


func _apply() -> void:
	if _pos.distance_to(_look) < 0.01:
		return
	var s := sway * 0.012
	var n1 := _noise.get_noise_2d(_t, 0.0)
	var n2 := _noise.get_noise_2d(0.0, _t)
	var shake_s := _trauma * _trauma
	var sn1 := _noise.get_noise_2d(_t * 40.0, 7.0) * shake_s
	var sn2 := _noise.get_noise_2d(7.0, _t * 40.0) * shake_s
	var up := Vector3.UP
	if absf((_look - _pos).normalized().dot(Vector3.UP)) > 0.98:
		up = Vector3.FORWARD
	cam.look_at_from_position(_pos, _look, up)
	cam.rotate_object_local(Vector3.UP, n1 * s + sn1 * 0.06)
	cam.rotate_object_local(Vector3.RIGHT, n2 * s + sn2 * 0.06)
	cam.rotate_object_local(Vector3.BACK, _roll + sn1 * 0.04)
	cam.fov = _fov
	var focus := _pos.distance_to(_look)
	attrs.dof_blur_far_distance = focus + 5.0
	attrs.dof_blur_far_transition = 12.0
	attrs.dof_blur_near_distance = maxf(focus - 4.0, 0.3)
	attrs.dof_blur_near_transition = 1.5
	attrs.dof_blur_amount = 0.06


func _ease(k: float, mode: String) -> float:
	match mode:
		"linear": return k
		"out": return 1.0 - pow(1.0 - k, 3.0)
		"in": return k * k * k
		_: return k * k * (3.0 - 2.0 * k)


# ---------------------------------------------------------------- timing

func _frame() -> float:
	await get_tree().process_frame
	return get_process_delta_time()


## Waits until every camera move started without `await` has finished.
func settle() -> void:
	while _busy > 0 and not skipping:
		await _frame()


func wait(seconds: float) -> void:
	var t := 0.0
	while t < seconds and not skipping:
		t += await _frame()


func _process(delta: float) -> void:
	if not active:
		return
	_t += delta
	_trauma = maxf(_trauma - delta * 1.1, 0.0)
	_apply()
	_skip_armed -= delta
	# Speedruns skip every cutscene.
	if Game.timing() and not skipping:
		skip()
		return
	if Input.is_action_just_pressed("pause") and not skipping:
		if _skip_armed > 0.0:
			skip()
		else:
			_skip_armed = 2.5
			Game.fx.show_skip_hint(true)
	elif _skip_armed <= 0.0:
		Game.fx.show_skip_hint(false)


func skip() -> void:
	skipping = true
	Game.fx.show_skip_hint(false)
	Game.fx.abort_line()
	Game.fx.hide_card()


# ---------------------------------------------------------------- story beats

## One line of dialogue. `emote` is applied to the speaker's actor.
func say(speaker: String, text: String, emote := "") -> void:
	if skipping:
		return
	var actor = actors.get(speaker.trim_suffix("_evil"))
	if actor and emote != "" and "emote" in actor:
		actor.emote = emote
	await Game.fx.say(speaker, text)


## Plays [speaker, text, emote?] lines in order.
func lines(list: Array) -> void:
	for l in list:
		if skipping:
			break
		await say(l[0], l[1], l[2] if l.size() > 2 else "")
	Game.fx.close_dialogue()


func title(chapter: String, title_text: String, subtitle: String, hold := 2.4) -> void:
	if skipping:
		return
	var done := [false]
	var run := func():
		await Game.fx.title_card(chapter, title_text, subtitle, hold)
		done[0] = true
	run.call()
	while not done[0] and not skipping:
		await _frame()
	if skipping:
		Game.fx.hide_card()


## Walks the player toward a point using scripted input.
func walk(to: Vector3, max_time := 4.0, pace := 0.6) -> void:
	var t := 0.0
	while t < max_time and not skipping:
		var d := to - player.global_position
		d.y = 0.0
		if d.length() < 0.35:
			break
		player.scripted_input = d.normalized() * pace
		t += await _frame()
	player.scripted_input = Vector3.ZERO
	if skipping:
		player.global_position = Vector3(to.x, player.global_position.y, to.z)


## Turns the player to face a point.
func face(target: Vector3) -> void:
	var d := target - player.global_position
	player.facing = atan2(-d.x, -d.z)


## A full in-level conversation with an NPC.
func conversation(npc: Node3D, list: Array) -> void:
	begin(true)
	actors[npc.speaker] = npc.puppet
	face(npc.global_position)
	npc.face_toward(player.global_position)
	two_shot(player, npc, 1.0 if randf() > 0.5 else -1.0)
	await lines(list)
	end()
