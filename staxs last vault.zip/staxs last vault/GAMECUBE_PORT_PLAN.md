# STAX: The Last Vault — GameCube Port Plan

Target: **Dolphin emulator** (decided 2026-10-16; earlier draft said real hardware). Toolchain: devkitPro / devkitPPC + libogc, written in C.

Because the target is Dolphin, I can build and run everything here. Still keep the GameCube budgets below as soft limits (24 MB RAM, fixed-function GX, no shaders) so a real-hardware build stays possible later. The hardware-only risks (milestone 6, risk 1) become optional.

## Hardware budget (the hard constraints)

| Resource | GameCube | Consequence |
|---|---|---|
| CPU | 485 MHz PowerPC 750 (Gekko), single core, FPU | No per-frame physics against thousands of colliders; fixed 60 Hz or 30 Hz step. |
| Main RAM | 24 MB (shared by code, level, textures, heap) | One chapter resident at a time. Budget ~8 MB geometry+collision, ~4 MB textures, rest code/heap. |
| Texture memory | 1 MB texture cache (on-GPU), 2 MB embedded framebuffer | Small textures (<=128x128, CMPR/I4/IA8). Mostly flat vertex colors. |
| ARAM | 16 MB slow audio RAM (DMA only) | Stream/stash music and SFX here. |
| GPU (Flipper) | Fixed-function TEV, 8 lights, hardware fog, no shaders | Every Godot ShaderMaterial / post effect must be replaced by TEV setups or dropped. |
| Disc | 1.4 GB mini-DVD | Plenty. Asset baking is fine. |
| Memory card | 59 blocks min | Save file is tiny (progress, coins, settings). |

## What the Godot project uses that can't come along

- Forward+ rendering: SSAO, SDFGI, volumetric fog, DOF, film grain, MSAA/SSAA, soft shadows -> **cut**. Replace with vertex-color lighting baked per chapter + hardware fog + one blob shadow under Stax.
- 24 `ShaderMaterial` uses (sky shader, chapter-specific effects in l2/l4/l5, `post_fx.gd`) -> rebuild as TEV combos or bake into textures/vertex colors; the Scribble Kingdom wobble becomes vertex animation on the CPU for a few meshes only.
- GPUParticles3D (8) -> small CPU billboard-quad pools.
- `Label3D` signs and all UI text -> a bitmap font texture.
- Godot physics (`CharacterBody3D`, `AnimatableBody3D`, `StaticBody3D`, `Area3D`) -> custom collision (see below).
- OS text-to-speech voices -> **cut**. Keep the existing "babble" mode (blip per couple letters, pitch per character) as the only voice, which suits the console.
- Runtime-synthesized audio (`AudioStreamWAV`, procedural music) -> pre-render on the Mac to ADPCM (DSP-ADPCM, the GameCube native format) at build time; ship as data.

## What carries over cleanly

- **Level geometry is already primitives.** Levels are built from `box`, `cylinder`, `ball`, `deco_*`, `mover`, `hazard_box`, `bouncer`, `zone`, `coin_*` calls (~60 Box/Cylinder/Sphere/Torus meshes counted per use). A Godot-side **exporter** can run each level's `build()` headless and dump a flat list of meshes, colliders, and gameplay objects. No hand-redrawing of levels.
- The moveset (`player.gd`, 662 lines) is a clean state machine with tuned constants. It can be ported to C near line-for-line, and tested against the existing `tests/move_test.gd` numbers (jump heights, wall-kick behaviour).
- Procedural character models (`stax_model.gd`, `puppet.gd`) are primitive-built too, so they export to low-poly rigid-part hierarchies (no skinning needed).
- Cinematics are camera paths + dialogue lines; they become small scripted keyframe tracks.

## Architecture

```
gc/                          (new C project, devkitPPC)
  source/
    main.c        boot, video init (480i/480p, double-buffered XFB), main loop @ 60 Hz
    gfx.c         GX setup, display lists for static level meshes, fog, blob shadow
    input.c       PAD_* stick/buttons, deadzones, C-stick camera, L/R triggers
    player.c      movement state machine (port of player.gd)
    collide.c     collision: axis-aligned boxes + oriented boxes + cylinders + spheres, uniform grid broadphase
    camera.c      orbit camera with wall avoidance (port of camera_rig.gd)
    level.c       loads baked chapter blob, spawns objects (coins, keys, checkpoints, movers, hazards)
    actors.c      enemies, NPCs, bosses (one file per boss)
    audio.c       libasnd/AESND: ADPCM voices, music streaming from disc
    save.c        memory card (CARD_*) save/load
    ui.c          HUD, dialogue box, title, pause, bitmap font
  data/           baked output of the exporter (git-ignored, regenerated)
tools/
  export_level.gd   Godot headless script: build chapter -> JSON/binary
  bake_level.py     converts export -> GC blob (display lists, collision grid, vertex-lit colors)
  bake_audio.py     renders procedural SFX/music -> DSP-ADPCM
```

### Collision approach
Godot gives us continuous shape queries for free; on GC we write our own. Because level colliders are boxes/cylinders/spheres, use: uniform spatial grid of collider indices, capsule-vs-primitive sweep for Stax, swept tests for movers (AnimatableBody -> carry the player by platform delta). This is the highest-risk system for game feel, so build it first.

### Rendering approach
- Static level = one display list per material batch, vertex colors pre-lit at bake time (sun direction, ambient, per-chapter tint); GX fog for depth cueing; 1 directional light only when needed.
- Dynamic parts (Stax, enemies, bosses) = rigid part hierarchy drawn with matrices; at most 2-3 GX lights.
- Target **30 fps stable first**, 60 fps where scenes allow. Poly budget guess: 15-25k triangles per frame visible.
- Skybox/sky shader -> a baked gradient dome or per-chapter backdrop.

## Chapter feasibility

| Chapter | Risk | Notes |
|---|---|---|
| 1 Rooftops | Low-Med | Traffic, blimp, billboard are rigid movers. **Pilot chapter.** |
| 2 Breakfast | Med | 11 shader uses (syrup etc.); bake to textures/vertex colors. |
| 3 Tax Office | Med | Conveyors, stamps, staplers = movers/hazards; large (884 lines). |
| 4 Nebula | Med-High | Low-gravity zones are easy; 8 shader uses and a lot of objects. |
| 5 Scribble | High | The signature "draws itself" look relies on shaders; needs bespoke vertex-wobble + texture. |
| 6 Desert | Low-Med | Plus pirate boss. |
| 7 Clocktower | Med | Many rotating gears (movers); fine if collision handles rotation. |
| 8 Nursery | Low-Med | Baby boss is a squash-stars fight. |
| 9 Vault | Med | Final boss `boss_kilowatt.gd` is 880 lines. |
| 10 Frostfire | High | 921 lines, meteor shower, avalanche run, 3 boss cameos + Twin Dragon. |
| 11 Page After the End | High | Deliberately glitchy UI-as-level; boss_end is 797 lines. |

Bosses (9) are bespoke state machines, ported one by one after the chapter works.

## Milestones

0. **Toolchain**: install devkitPro (devkitPPC, libogc), Dolphin; "hello triangle" boots in Dolphin. Produce a bootable `.dol`, then an ISO/`.gcm` for hardware via a loader (Swiss/modchip/GCLoader/Sd2sp2 - your setup decides).
1. **Moveset sandbox**: grey-box floor + Stax capsule; port `player.gd` + camera; match `move_test.gd` figures.
2. **Exporter + Chapter 1 geometry**: Godot dump -> bake -> render Goldhaven in GX with fog; collision working.
3. **Gameplay objects**: coins, checkpoints, keys, movers, bouncers, hazards, enemies, NPC dialogue, HUD, goal -> Chapter 1 completable.
4. **Audio**: baked SFX + music for Chapter 1, babble voice.
5. **Cinematics + save**: opening/closing cutscene, title screen, memory card save.
6. **Hardware pass**: measure frame time and RAM on real console; adjust budgets.
7. **Remaining chapters** in roughly the order 6, 8, 7, 3, 2, 4, 5, 9, 10, 11; bosses alongside.

Milestones 0-4 are the "vertical slice" and the real go/no-go for the whole port.

## Risks / decisions needed

1. **Hardware testing**: I can only run Dolphin here. Real-hardware verification needs you to run builds on a console (and tell me about stutter, crashes, memory). Hardware-only bugs (cache coherency, DMA alignment, 32-byte alignment of display lists/textures) are likely.
2. **Scope**: ~19k lines of GDScript to re-implement in C is weeks of work, not an afternoon. Cutting chapters (e.g. ship 1-8 + Finale) is a reasonable option.
3. **Look**: the port will look noticeably different (no SSAO/GI/DOF). Flat-shaded, fogged, vertex-lit low-poly suits the GameCube era and the primitive-built art.
4. **Distribution**: a real-disc release is out of scope; run via homebrew loader / SD adapter / emulator.
5. **Legal**: this is your own original game, so no issues. Don't use Nintendo SDK leaks; libogc is the open-source route.
