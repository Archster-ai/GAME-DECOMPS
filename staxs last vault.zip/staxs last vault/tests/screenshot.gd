extends SceneTree
## Renders screenshots of a chapter (or the title) for visual checks:
##   godot --path . -s tests/screenshot.gd -- <level index or -1> <out_dir> [frames...]

func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	var idx := int(args[0]) if args.size() > 0 else -1
	var out := args[1] if args.size() > 1 else "user://shots"
	var frames := [60, 200, 400]
	var skip := false
	if args.size() > 2:
		frames = []
		for a in args.slice(2):
			if a == "skip":
				skip = true
			else:
				frames.append(int(a))
	DirAccess.make_dir_recursive_absolute(out)
	var main: Node = load("res://main.tscn").instantiate()
	root.add_child(main)
	await process_frame
	if idx >= 0:
		root.get_node("Game").start_level(idx)
	var n := 0
	for f in frames:
		while n < f:
			await process_frame
			n += 1
			# "skip": jump past cutscenes to show gameplay.
			if skip and main.current and "director" in main.current and main.current.director and main.current.director.active:
				main.current.director.skip()
		var img := root.get_viewport().get_texture().get_image()
		img.save_png("%s/shot_%d_%04d.png" % [out, idx, f])
		print("saved frame ", f)
	quit()
