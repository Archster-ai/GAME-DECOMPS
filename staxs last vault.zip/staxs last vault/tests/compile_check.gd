extends SceneTree
## Loads every script so parse errors show up:
##   godot --headless --path . -s tests/compile_check.gd

func _initialize() -> void:
	var bad := 0
	for path in _scripts("res://scripts"):
		var s = load(path)
		if s == null or not s.can_instantiate():
			print("BROKEN ", path)
			bad += 1
	print("compile check: %d broken" % bad)
	quit(bad)


func _scripts(dir: String) -> Array:
	var out := []
	for f in DirAccess.get_files_at(dir):
		if f.ends_with(".gd"):
			out.append(dir + "/" + f)
	for d in DirAccess.get_directories_at(dir):
		out.append_array(_scripts(dir + "/" + d))
	return out
