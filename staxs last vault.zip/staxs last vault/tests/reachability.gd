extends SceneTree
## Checks a chapter's Vault Key can be reached from the spawn using Stax's
## jump metrics over the level's walkable surfaces (a conservative estimate):
##   godot --headless --path . -s tests/reachability.gd -- <chapter index>
## Surfaces are box/cylinder tops of static bodies and moving platforms (their
## whole travel), bounce pads add height, low-gravity zones add range.

const SINGLE_RISE := 2.2
const FLIP_RISE := 5.2        # backflip / triple jump, short gap only
const RUN_GAP := 5.5
const LONG_GAP := 11.0

var surfaces: Array = []      # {min: Vector2, max: Vector2, y, boost, grav, name}


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var game = root.get_node("Game")
	var idx := int(OS.get_cmdline_user_args()[0])
	root.get_node("Game").saving_enabled = false
	var main: Node = load("res://main.tscn").instantiate()
	root.add_child(main)
	await physics_frame
	game.start_level(idx)
	for i in 60:
		await physics_frame
	var level: Node3D = main.current
	for i in 900:
		if not level.director.active:
			break
		level.director.skip()
		await physics_frame
	for i in 30:
		await physics_frame
	level.process_mode = Node.PROCESS_MODE_DISABLED
	_collect(level)
	_find_shafts()
	var start := _find(level.spawn_point)
	# Chapters whose key only appears later (after a boss) name a stand-in target.
	var target: Vector3 = level.goal.global_position if level.goal else level.get("reach_target")
	var goal := _find(target + Vector3(0, 0.3, 0))
	print("surfaces: %d  start: %d  goal: %d" % [surfaces.size(), start, goal])
	if OS.get_cmdline_user_args().size() > 1:
		for s in surfaces:
			print("  S y=%.1f x[%.1f..%.1f] z[%.1f..%.1f]" % [s.y, s.min.x, s.max.x, s.min.y, s.max.y])
	var reached := {start: true}
	var parent := {}
	var queue := [start]
	while not queue.is_empty():
		var a: int = queue.pop_front()
		for b in surfaces.size():
			if not reached.has(b) and _can_jump(surfaces[a], surfaces[b]):
				reached[b] = true
				parent[b] = a
				queue.append(b)
	var ok := goal >= 0 and reached.has(goal)
	print("wall-kick shafts: %d" % _kicks.size())
	if ok:
		var path := []
		var n := goal
		while n != start:
			path.push_front(n)
			n = parent[n]
		print("route (%d hops):" % path.size())
		for p in path:
			var s: Dictionary = surfaces[p]
			print("   y=%.1f  x[%.1f..%.1f] z[%.1f..%.1f] %s" % [s.y, s.min.x, s.max.x, s.min.y, s.max.y, s.name])
	else:
		# Show the highest surfaces reached, to see where the route breaks.
		var best := []
		for r in reached:
			best.append(surfaces[r])
		best.sort_custom(func(a, b): return a.y > b.y)
		print("UNREACHABLE. Highest reached:")
		for s in best.slice(0, 8):
			print("   y=%.1f  x[%.1f..%.1f] z[%.1f..%.1f] %s" % [s.y, s.min.x, s.max.x, s.min.y, s.max.y, s.name])
	print("REACHABLE" if ok else "NOT REACHABLE")
	quit(0 if ok else 1)


func _collect(level: Node) -> void:
	var zones := []
	var pads := []
	for n in _all(level):
		if n is Area3D and "mode" in n and n.mode == "gravity":
			zones.append(n)
		elif n is Area3D and "mode" in n and n.mode in ["hurt", "kill"]:
			_bad_zones.append(n)
		elif n is Area3D and "strength" in n:
			pads.append(n)
	for n in _all(level):
		if not (n is StaticBody3D or n is AnimatableBody3D):
			continue
		# Collision that's switched on by a cutscene (e.g. a bridge that arrives) counts.
		if n is StaticBody3D and n.collision_layer == 0 and not n.has_meta("scripted"):
			continue
		for cs in n.get_children():
			if not cs is CollisionShape3D or cs.shape == null:
				continue
			var xf: Transform3D = cs.global_transform
			# ...placed where the cutscene will put it, if it says so.
			# Moving platforms: measure from where they start, not wherever
			# they happen to be right now.
			if n is AnimatableBody3D and "_origin" in n:
				xf.origin += n._origin - n.position
			if n.has_meta("scripted") and n.get_meta("scripted") is Transform3D:
				xf = n.get_meta("scripted") * cs.transform
			var ext := Vector3.ZERO
			if cs.shape is BoxShape3D:
				ext = cs.shape.size * 0.5
			elif cs.shape is CylinderShape3D:
				ext = Vector3(cs.shape.radius, cs.shape.height * 0.5, cs.shape.radius)
			elif cs.shape is SphereShape3D:
				ext = Vector3.ONE * cs.shape.radius * 0.7
			else:
				continue
			# Only roughly level tops count as floors.
			if absf(xf.basis.y.normalized().dot(Vector3.UP)) < 0.85:
				continue
			var aabb := AABB()
			var first := true
			for sx in [-1, 1]:
				for sz in [-1, 1]:
					var p := xf * Vector3(ext.x * sx, ext.y, ext.z * sz)
					if first:
						aabb = AABB(p, Vector3.ZERO)
						first = false
					else:
						aabb = aabb.expand(p)
			if n is AnimatableBody3D and "travel" in n:
				aabb = aabb.merge(AABB(aabb.position + n.travel, aabb.size))
			# Platforms on a circular path publish the area they sweep.
			if n.has_meta("sweep"):
				aabb = aabb.merge(n.get_meta("sweep"))
			var bottom: float = (xf * Vector3(0, -ext.y, 0)).y
			var top := aabb.end.y if n is AnimatableBody3D else aabb.position.y
			if n is AnimatableBody3D:
				top = aabb.position.y + (n.travel.y if "travel" in n and n.travel.y > 0.0 else 0.0)
			var s := {"min": Vector2(aabb.position.x, aabb.position.z), "max": Vector2(aabb.end.x, aabb.end.z),
				"y": top, "low": bottom, "boost": 0.0, "grav": 1.0, "name": n.name}
			if s.max.x - s.min.x < 0.5 and s.max.y - s.min.y < 0.5:
				continue
			# Floors that hurt (hot sand, syrup) don't count as safe ground.
			var hurt := 0
			for sx in [0.1, 0.5, 0.9]:
				for sz in [0.1, 0.5, 0.9]:
					var q := Vector3(lerpf(s.min.x, s.max.x, sx), top + 0.4, lerpf(s.min.y, s.max.y, sz))
					for z in _bad_zones:
						if _inside_area(z, q):
							hurt += 1
							break
			if hurt >= 7:
				continue
			for z in zones:
				var zc: Vector3 = z.global_position
				var near := Vector3(clampf(zc.x, s.min.x, s.max.x), top + 0.5, clampf(zc.z, s.min.y, s.max.y))
				if _inside_area(z, near):
					s.grav = z.gravity_scale
			surfaces.append(s)
			# Lifts: board at the bottom of the travel, ride to the top.
			if n is AnimatableBody3D and "travel" in n and absf(n.travel.y) > 0.5:
				var lo := s.duplicate()
				lo.y = top - absf(n.travel.y)
				lo.ride = surfaces.size() - 1
				surfaces.append(lo)
	# Bounce pads become tiny surfaces with a launch height.
	for p in pads:
		var h: float = p.strength * p.strength / (2.0 * 38.0) - 0.5
		var gp: Vector3 = p.global_position
		surfaces.append({"min": Vector2(gp.x - 1, gp.z - 1), "max": Vector2(gp.x + 1, gp.z + 1),
			"y": gp.y, "low": gp.y, "boost": h, "grav": 1.0, "name": "bouncer"})


func _inside_area(a: Area3D, p: Vector3) -> bool:
	for cs in a.get_children():
		if cs is CollisionShape3D and cs.shape is BoxShape3D:
			var local: Vector3 = cs.global_transform.affine_inverse() * p
			var e: Vector3 = cs.shape.size * 0.5
			if absf(local.x) <= e.x and absf(local.y) <= e.y + 3.0 and absf(local.z) <= e.z:
				return true
		elif cs is CollisionShape3D and cs.shape is CylinderShape3D:
			var local: Vector3 = cs.global_transform.affine_inverse() * p
			if Vector2(local.x, local.z).length() <= cs.shape.radius and absf(local.y) <= cs.shape.height * 0.5 + 3.0:
				return true
	return false


var _bad_zones: Array = []
var _kicks: Array = []   # [shaft rect min, max, low y, top y]


## Pairs of tall walls 3-5.5 m apart facing each other form a wall-kick shaft.
func _find_shafts() -> void:
	for i in surfaces.size():
		for j in surfaces.size():
			var a: Dictionary = surfaces[i]
			var b: Dictionary = surfaces[j]
			if i == j or a.y - a.low < 5.0 or b.y - b.low < 5.0:
				continue
			for axis: int in [0, 1]:
				var other: int = 1 - axis
				var gap: float = b.min[axis] - a.max[axis]
				var lo: float = maxf(a.min[other], b.min[other])
				var hi: float = minf(a.max[other], b.max[other])
				if gap >= 3.0 and gap <= 5.5 and hi - lo > 2.0:
					var mn := Vector2.ZERO
					var mx := Vector2.ZERO
					mn[axis] = a.max[axis]
					mx[axis] = b.min[axis]
					mn[other] = lo
					mx[other] = hi
					_kicks.append([mn, mx, maxf(a.low, b.low), minf(a.y, b.y)])


## True if a solid surface hangs over `a` between heights y0 and y1.
func _covered(a: Dictionary, y0: float, y1: float) -> bool:
	for c in surfaces:
		if c == a or c.has("ride") or c.name == "bouncer":
			continue
		if c.low > y0 + 1.2 and c.low < y1 and c.max.x > a.min.x + 0.3 and c.min.x < a.max.x - 0.3 \
				and c.max.y > a.min.y + 0.3 and c.min.y < a.max.y - 0.3:
			var cover: float = (minf(c.max.x, a.max.x) - maxf(c.min.x, a.min.x)) * (minf(c.max.y, a.max.y) - maxf(c.min.y, a.min.y))
			if cover > 0.9 * (a.max.x - a.min.x) * (a.max.y - a.min.y):
				return true
	return false


func _can_jump(a: Dictionary, b: Dictionary) -> bool:
	if a.has("ride") and surfaces[a.ride] == b:
		return true
	if b.y > a.y + 0.5 and _covered(a, a.y, b.y):
		return false
	for k in _kicks:
		# Standing inside a shaft lets you climb to the walls' tops.
		var inside: bool = a.max.x > k[0].x and a.min.x < k[1].x and a.max.y > k[0].y and a.min.y < k[1].y
		if inside and a.y < k[3] and b.y <= k[3] + 0.5 and b.y > a.y and absf(b.y - k[3]) < 0.6:
			var near := maxf(0.0, maxf(b.min.x - k[1].x, k[0].x - b.max.x)) + maxf(0.0, maxf(b.min.y - k[1].y, k[0].y - b.max.y))
			if near < 1.0:
				return true
	var dx := maxf(0.0, maxf(b.min.x - a.max.x, a.min.x - b.max.x))
	var dz := maxf(0.0, maxf(b.min.y - a.max.y, a.min.y - b.max.y))
	var gap := Vector2(dx, dz).length()
	var rise: float = b.y - a.y
	var g: float = 1.0 / a.grav
	if a.boost > 0.0:
		return rise <= a.boost and gap <= 8.0
	if rise <= SINGLE_RISE * g and gap <= RUN_GAP * sqrt(g) + maxf(0.0, -rise) * 0.8:
		return true
	if rise <= 0.6 * g and gap <= LONG_GAP * sqrt(g) + maxf(0.0, -rise) * 0.8:
		return true
	if rise <= FLIP_RISE * g and gap <= 1.5 * g:
		return true
	return false


func _find(p: Vector3) -> int:
	var best := -1
	var best_dy := 1e9
	for i in surfaces.size():
		var s: Dictionary = surfaces[i]
		if p.x >= s.min.x - 0.5 and p.x <= s.max.x + 0.5 and p.z >= s.min.y - 0.5 and p.z <= s.max.y + 0.5:
			var dy: float = p.y - s.y
			if dy > -0.6 and dy < best_dy:
				best_dy = dy
				best = i
	return best


func _all(n: Node) -> Array:
	var out := [n]
	for c in n.get_children():
		out.append_array(_all(c))
	return out
