extends SceneTree
## Headless smoke test for the moveset:
##   godot --headless --path . -s tests/move_test.gd

var arena: Node3D
var p: CharacterBody3D
var failures := 0


func _initialize() -> void:
	load("res://scripts/core/input_setup.gd").setup()
	# A flat test arena with a wall-kick shaft (inner faces at x=-19 and x=-23).
	arena = Node3D.new()
	root.add_child(arena)
	_box(Vector3(0, -1, 0), Vector3(120, 2, 120))
	_box(Vector3(-17, 8, 0), Vector3(4, 16, 14))
	_box(Vector3(-24, 8, 0), Vector3(2, 16, 14))
	p = load("res://scripts/actors/player.gd").new()
	p.position = Vector3(0, 1, 22)
	arena.add_child(p)
	var rig := Node3D.new()
	arena.add_child(rig)
	p.camera_rig = rig
	_run.call_deferred()


func _box(pos: Vector3, size: Vector3) -> void:
	var body := StaticBody3D.new()
	body.position = pos
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	cs.shape = shape
	body.add_child(cs)
	arena.add_child(body)


func frames(n: int) -> void:
	for i in n:
		await physics_frame


func press(action: String, n := 1) -> void:
	Input.action_press(action)
	await frames(n)
	Input.action_release(action)


func check(name: String, ok: bool, info := "") -> void:
	print(("PASS " if ok else "FAIL ") + name + "  " + info)
	if not ok:
		failures += 1


func reset_at(pos: Vector3, yaw := 0.0) -> void:
	p.spawn_point = pos
	p.respawn()
	p.facing = yaw
	p.camera_rig.rotation.y = 0.0
	await frames(30)


func peak_during(n: int) -> float:
	var start := p.global_position.y
	var peak := start
	for i in n:
		await physics_frame
		peak = maxf(peak, p.global_position.y)
	return peak - start


func _run() -> void:
	await frames(60)
	check("lands on ground", p.is_on_floor(), str(p.global_position))

	# Single jump
	await reset_at(Vector3(0, 1, 30))
	Input.action_press("jump")
	var h1 := await peak_during(50)
	Input.action_release("jump")
	check("single jump height", h1 > 1.8 and h1 < 3.0, "%.2f" % h1)

	# Triple jump chain while running forward (-Z)
	await reset_at(Vector3(-5, 1, 35))
	Input.action_press("move_forward")
	await frames(40)
	var heights := []
	for i in 3:
		Input.action_press("jump")
		var start := p.global_position.y
		var peak := start
		var t := 0
		while t < 120:
			await physics_frame
			t += 1
			peak = maxf(peak, p.global_position.y)
			if t > 5 and p.is_on_floor():
				break
		Input.action_release("jump")
		heights.append(peak - start)
		await physics_frame
	Input.action_release("move_forward")
	check("jump chain rises", heights[1] > heights[0] and heights[2] > heights[1], str(heights))
	check("triple jump high", heights[2] > 5.0, "%.2f" % heights[2])

	# Backflip
	await reset_at(Vector3(5, 1, 30))
	Input.action_press("crouch")
	await frames(5)
	Input.action_press("jump")
	var hb := await peak_during(60)
	Input.action_release("jump")
	Input.action_release("crouch")
	check("backflip height", hb > 4.5, "%.2f" % hb)

	# Long jump distance
	await reset_at(Vector3(4, 1, 38))
	Input.action_press("move_forward")
	await frames(45)
	var z0 := p.global_position.z
	Input.action_press("crouch")
	await frames(1)
	Input.action_press("jump")
	await frames(2)
	Input.action_release("crouch")
	Input.action_release("jump")
	var t2 := 0
	while t2 < 200:
		await physics_frame
		t2 += 1
		if t2 > 5 and p.is_on_floor():
			break
	Input.action_release("move_forward")
	var dist := z0 - p.global_position.z
	check("long jump distance", dist > 13.0, "%.2f" % dist)

	# Ground pound
	await reset_at(Vector3(0, 1, 30))
	await press("jump", 12)
	await press("crouch", 2)
	var saw_fall := false
	for i in 80:
		await physics_frame
		if p.state == p.S.POUND_FALL:
			saw_fall = true
		if p.state == p.S.POUND_LAND:
			break
	check("ground pound", saw_fall and p.state == p.S.POUND_LAND, str(p.state))

	# Wall kicks up the twin-wall shaft (inner faces at x=-19 and x=-23)
	await reset_at(Vector3(-22.3, 1, 0), -PI / 2.0)  # facing +X
	var best := 0.0
	Input.action_press("move_right")
	await frames(12)
	await press("jump", 10)
	Input.action_release("move_right")
	for i in 600:
		await physics_frame
		best = maxf(best, p.global_position.y)
		if p.wall_timer > 0.0:
			Input.action_press("jump")
			await physics_frame
			Input.action_release("jump")
		if p.is_on_floor() and i > 10:
			break
	check("wall kicks climb", best > 10.0, "peak y %.2f" % best)

	# Dive + rollout
	await reset_at(Vector3(-8, 1, 38))
	Input.action_press("move_forward")
	await frames(40)
	await press("attack", 2)
	var slid := false
	for i in 90:
		await physics_frame
		if p.state == p.S.BELLY_SLIDE:
			slid = true
			break
	Input.action_release("move_forward")
	check("dive to belly slide", slid, str(p.state))

	print("FAILURES: %d" % failures)
	quit(failures)
