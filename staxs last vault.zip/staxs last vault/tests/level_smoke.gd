extends SceneTree
## Plays through chapters headlessly: skips the intro, checks Stax stands on
## solid ground, talks to every NPC, then grabs the Vault Key and checks the
## outro hands over to the next chapter.
##   godot --headless --path . -s tests/level_smoke.gd -- [level index]

var failures := 0
var game: Node


func check(name: String, ok: bool, info := "") -> void:
	print(("PASS " if ok else "FAIL ") + name + "  " + info)
	if not ok:
		failures += 1


func frames(n: int) -> void:
	for i in n:
		await physics_frame


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	game = root.get_node("Game")
	var args := OS.get_cmdline_user_args()
	var only := int(args[0]) if args.size() > 0 else -1
	root.get_node("Game").saving_enabled = false
	var main: Node = load("res://main.tscn").instantiate()
	root.add_child(main)
	await frames(10)
	for i in game.level_count():
		if only >= 0 and i != only:
			continue
		await _play(main, i)
	print("FAILURES: %d" % failures)
	quit(failures)


func _play(main: Node, i: int) -> void:
	print("--- chapter %d: %s" % [i, game.level_info(i).title])
	game.start_level(i)
	await frames(90)
	var level: Node = main.current
	check("level %d loaded" % i, level != null and level.has_method("is_cinematic"))
	if level == null or not level.has_method("is_cinematic"):
		return
	# Skip the intro cutscene.
	for n in 600:
		if not level.is_cinematic() and not level.player.frozen:
			break
		if level.director.active:
			level.director.skip()
		await physics_frame
	check("intro finishes", not level.is_cinematic() and not level.player.frozen)
	await frames(60)
	var p: CharacterBody3D = level.player
	check("stands on ground at spawn", p.is_on_floor(), str(p.global_position))

	# Talk to everyone (and skip through each conversation).
	for npc in get_nodes_in_group("npcs"):
		if not is_instance_valid(npc):
			continue
		level._talk(npc)
		await frames(5)
		level.director.skip()
		for n in 300:
			if not level.director.active:
				break
			await physics_frame
		check("talked to %s" % npc.speaker, not level.director.active)
		await frames(5)

	# Walk over every checkpoint.
	for c in get_nodes_in_group("checkpoints"):
		p.global_position = c.global_position + Vector3(0, 1, -1.2).rotated(Vector3.UP, c.rotation.y)
		await frames(10)
	check("checkpoints set spawn", get_nodes_in_group("checkpoints").is_empty() or p.spawn_point != level.spawn_point)

	# Level-specific extra checks (e.g. boss fights).
	if level.has_method("test_hook"):
		var ok: bool = await level.test_hook(self)
		check("level test hook", ok)
		if level.complete:
			for n in 1500:
				if main.current != level:
					break
				if is_instance_valid(level) and level.director.active:
					level.director.skip()
				await physics_frame
			check("finale hands over", main.current != level)
			await frames(60)
			return

	if level.goal == null:
		check("has a goal", false)
		return
	var before: int = game.current_level
	p.global_position = level.goal.global_position + Vector3(0, 0.5, 0)
	for n in 1200:
		if game.current_level != before or main.current != level:
			break
		if is_instance_valid(level) and level.director.active and n > 30:
			level.director.skip()
		await physics_frame
	check("key completes chapter", game.current_level != before or main.current != level)
	await frames(60)
